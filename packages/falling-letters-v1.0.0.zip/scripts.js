// ==========================================
// TeachIT Educational Game: Falling Letter
// Keyboard Recognition & Typing Speed Module
// ==========================================

// 1. Game Configuration
const gameConfig = {
  levels: {
    easy: { speed: 2, spawnRate: 2500 },
    medium: { speed: 4.5, spawnRate: 2000 },
    hard: { speed: 7, spawnRate: 1500 },
  },
  speedIncrease: 0.3,
  speedIncreaseInterval: 30000, // 30 seconds
  correctPoints: 10,
  missedPenalty: 5,
  reducePointsOnMiss: true,
};

// 2. Game State
let gameState = {
  currentLevel: 'easy',
  score: 0,
  timeLeft: 60,
  gameRunning: false,
  fallingLetters: [],
  currentSpeed: 2,
  availableLetters: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split(''),
  gameTimer: 60,
  // Statistics
  correctCount: 0,
  missedCount: 0,
  totalLetters: 0,
  gameStartTime: 0,
  hearts: 5,
  // Session & Reporting Guards
  roundReported: false,
  sessionInfo: null,
};

let spawnIntervalId = null;
let speedIncreaseIntervalId = null;
let gameTimerId = null;
let animationFrameId = null;

// 3. DOM Elements
const startScreen = document.getElementById('startScreen');
const settingsScreen = document.getElementById('settingsScreen');
const gameScreen = document.getElementById('gameScreen');
const gameOverScreen = document.getElementById('gameOverScreen');
const scoreValue = document.getElementById('scoreValue');
const timerValue = document.getElementById('timerValue');
const finalScore = document.getElementById('finalScore');
const gameArea = document.getElementById('gameArea');
const columns = document.querySelectorAll('.column');
const heartsValue = document.getElementById('heartsValue');
const saveStatusMsg = document.getElementById('saveStatusMsg');
const sessionBadge = document.getElementById('sessionBadge');
const sessionStudentName = document.getElementById('sessionStudentName');

// 4. TeachIT Integration Layer
function getTeachit() {
  return typeof window !== 'undefined' && window.teachit ? window.teachit : null;
}

async function initTeachitSession() {
  const teachit = getTeachit();
  if (!teachit || typeof teachit.getSessionInfo !== 'function') {
    return;
  }

  try {
    const info = await teachit.getSessionInfo();
    if (info) {
      gameState.sessionInfo = info;
      if (info.studentId && sessionBadge && sessionStudentName) {
        sessionBadge.style.display = 'inline-flex';
        sessionStudentName.textContent = info.studentId.substring(0, 8) + '...';
      }
    }
  } catch {
    // Graceful fallback for standalone browser testing
  }
}

function exitToLauncher() {
  const teachit = getTeachit();
  if (teachit && typeof teachit.exitGame === 'function') {
    teachit.exitGame().catch(() => {
      window.close();
    });
  } else {
    window.close();
  }
}

// 5. Initialize Page
function init() {
  setupEventListeners();
  generateLetterCheckboxes();
  updateTimerDisplay();
  initTeachitSession();
}

// 6. Setup Event Listeners
function setupEventListeners() {
  // Level selection buttons
  document.querySelectorAll('.level-btn').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      document.querySelectorAll('.level-btn').forEach((b) => b.classList.remove('selected'));
      const target = e.currentTarget;
      target.classList.add('selected');
      gameState.currentLevel = target.dataset.level || 'easy';
    });
  });

  // Action buttons
  document.getElementById('startGameBtn').addEventListener('click', startGame);
  document.getElementById('settingsBtn').addEventListener('click', showSettings);
  document.getElementById('backBtn').addEventListener('click', showStartScreen);
  document.getElementById('applyBtn').addEventListener('click', applySettings);
  document.getElementById('restartBtn').addEventListener('click', restartGame);
  document.getElementById('headerExitBtn').addEventListener('click', quitRoundToMenu);
  document.getElementById('exitLauncherBtn').addEventListener('click', exitToLauncher);
  document.getElementById('exitGameOverBtn').addEventListener('click', exitToLauncher);

  // Timer & settings inputs
  document.getElementById('gameTimer').addEventListener('change', (e) => {
    const val = parseInt(e.target.value, 10);
    if (!Number.isNaN(val) && val >= 15) {
      gameState.gameTimer = val;
      gameState.timeLeft = val;
      updateTimerDisplay();
    }
  });

  document.getElementById('reducePointsOnMiss').addEventListener('change', (e) => {
    gameConfig.reducePointsOnMiss = e.target.checked;
  });

  // Letter controls
  document.getElementById('selectAllBtn').addEventListener('click', () => selectLetters('all'));
  document.getElementById('selectNoneBtn').addEventListener('click', () => selectLetters('none'));
  document
    .getElementById('selectVowelsBtn')
    .addEventListener('click', () => selectLetters('vowels'));
  document
    .getElementById('selectConsonantsBtn')
    .addEventListener('click', () => selectLetters('consonants'));
  document.getElementById('customLetters').addEventListener('input', handleCustomLetters);

  // Keyboard game input
  document.addEventListener('keydown', handleKeyPress);
}

// 7. Letter Checkboxes in Settings
function generateLetterCheckboxes() {
  const container = document.getElementById('letterCheckboxes');
  container.innerHTML = '';

  'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').forEach((letter) => {
    const div = document.createElement('div');
    div.className = 'letter-checkbox';
    div.innerHTML = `
      <input type="checkbox" id="letter-${letter}" checked>
      <label for="letter-${letter}">${letter}</label>
    `;
    container.appendChild(div);
  });
}

// 8. Screen Navigation
function showStartScreen() {
  startScreen.style.display = 'flex';
  settingsScreen.style.display = 'none';
  gameScreen.style.display = 'none';
  gameOverScreen.style.display = 'none';
}

function showSettings() {
  startScreen.style.display = 'none';
  settingsScreen.style.display = 'flex';
  gameScreen.style.display = 'none';
  gameOverScreen.style.display = 'none';
}

function showGameScreen() {
  startScreen.style.display = 'none';
  settingsScreen.style.display = 'none';
  gameScreen.style.display = 'block';
  gameOverScreen.style.display = 'none';
}

function showGameOverScreen() {
  gameOverScreen.style.display = 'flex';
  finalScore.textContent = gameState.score;
}

// 9. Letter Controls
function selectLetters(type) {
  const checkboxes = document.querySelectorAll('#letterCheckboxes input[type="checkbox"]');
  const vowels = ['A', 'E', 'I', 'O', 'U'];

  checkboxes.forEach((checkbox) => {
    const letter = checkbox.id.split('-')[1];
    switch (type) {
      case 'all':
        checkbox.checked = true;
        break;
      case 'none':
        checkbox.checked = false;
        break;
      case 'vowels':
        checkbox.checked = vowels.includes(letter);
        break;
      case 'consonants':
        checkbox.checked = !vowels.includes(letter);
        break;
    }
  });
}

function handleCustomLetters(e) {
  const customText = e.target.value.toUpperCase().replace(/[^A-Z]/g, '');
  e.target.value = customText;

  const checkboxes = document.querySelectorAll('#letterCheckboxes input[type="checkbox"]');
  checkboxes.forEach((checkbox) => {
    const letter = checkbox.id.split('-')[1];
    checkbox.checked = customText.includes(letter);
  });
}

function applySettings() {
  const timerInput = document.getElementById('gameTimer');
  const timerVal = parseInt(timerInput.value, 10);
  if (!Number.isNaN(timerVal) && timerVal >= 15) {
    gameState.gameTimer = timerVal;
    gameState.timeLeft = timerVal;
    updateTimerDisplay();
  }

  gameConfig.reducePointsOnMiss = document.getElementById('reducePointsOnMiss').checked;
  showStartScreen();
}

// 10. Display Functions
function renderHearts() {
  heartsValue.innerHTML = '';
  for (let i = 0; i < gameState.hearts; i++) {
    const heart = document.createElement('span');
    heart.textContent = '❤️';
    heart.classList.add('heart');
    heartsValue.appendChild(heart);
  }
}

function updateDisplay() {
  scoreValue.textContent = gameState.score;
  renderHearts();
}

function updateTimerDisplay() {
  const minutes = Math.floor(gameState.timeLeft / 60);
  const seconds = gameState.timeLeft % 60;
  timerValue.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
}

// 11. Start Game Round
function startGame() {
  const selectedLetters = [];
  document
    .querySelectorAll('#letterCheckboxes input[type="checkbox"]:checked')
    .forEach((checkbox) => {
      selectedLetters.push(checkbox.id.split('-')[1]);
    });

  if (selectedLetters.length === 0) {
    alert('Please select at least one letter to practice!');
    return;
  }

  // Clear existing falling letters from previous rounds
  clearFallingLetterElements();

  // Reset state for new round
  gameState.hearts = 5;
  gameState.availableLetters = selectedLetters;
  gameState.score = 0;
  gameState.timeLeft = gameState.gameTimer;
  gameState.gameRunning = true;
  gameState.fallingLetters = [];
  gameState.currentSpeed = gameConfig.levels[gameState.currentLevel].speed;
  gameState.correctCount = 0;
  gameState.missedCount = 0;
  gameState.totalLetters = 0;
  gameState.gameStartTime = Date.now();
  gameState.roundReported = false;

  showGameScreen();
  updateDisplay();
  updateTimerDisplay();

  // Notify TeachIT that activity has started
  const teachit = getTeachit();
  if (teachit && typeof teachit.reportProgress === 'function') {
    teachit
      .reportProgress({
        activityId: `falling-letters-${gameState.currentLevel}`,
        eventType: 'activity_started',
        payload: {
          attemptNumber: 1,
          customData: {
            level: gameState.currentLevel,
            timerSeconds: gameState.gameTimer,
            alphabetLength: selectedLetters.length,
          },
        },
      })
      .catch(() => {});
  }

  startGameLoop();
  // Immediately spawn the first letter so student doesn't wait with an empty screen
  spawnLetter();
  window.focus();
}

// 12. Main Game Loop
function startGameLoop() {
  stopIntervals();

  // Spawn letters interval
  spawnIntervalId = setInterval(() => {
    if (!gameState.gameRunning) {
      stopIntervals();
      return;
    }
    spawnLetter();
  }, gameConfig.levels[gameState.currentLevel].spawnRate);

  // Speed increase interval
  speedIncreaseIntervalId = setInterval(() => {
    if (!gameState.gameRunning) {
      stopIntervals();
      return;
    }
    gameState.currentSpeed += gameConfig.speedIncrease;
    showSpeedIncrease();
  }, gameConfig.speedIncreaseInterval);

  // Game timer countdown (1s tick)
  gameTimerId = setInterval(() => {
    if (!gameState.gameRunning) {
      stopIntervals();
      return;
    }

    gameState.timeLeft--;
    updateTimerDisplay();

    if (gameState.timeLeft <= 0) {
      endGame();
    }
  }, 1000);

  // Animation frame loop
  function animate() {
    if (!gameState.gameRunning) return;
    updateFallingLetters();
    animationFrameId = requestAnimationFrame(animate);
  }
  animationFrameId = requestAnimationFrame(animate);
}

function stopIntervals() {
  if (spawnIntervalId) {
    clearInterval(spawnIntervalId);
    spawnIntervalId = null;
  }
  if (speedIncreaseIntervalId) {
    clearInterval(speedIncreaseIntervalId);
    speedIncreaseIntervalId = null;
  }
  if (gameTimerId) {
    clearInterval(gameTimerId);
    gameTimerId = null;
  }
  if (animationFrameId) {
    cancelAnimationFrame(animationFrameId);
    animationFrameId = null;
  }
}

function clearFallingLetterElements() {
  if (gameState.fallingLetters) {
    gameState.fallingLetters.forEach((letterObj) => {
      if (letterObj.element && letterObj.element.parentNode) {
        letterObj.element.remove();
      }
    });
  }
  gameState.fallingLetters = [];
}

// 13. Spawn Falling Letter
function spawnLetter() {
  if (!gameState.availableLetters || gameState.availableLetters.length === 0) return;
  const letter =
    gameState.availableLetters[Math.floor(Math.random() * gameState.availableLetters.length)];
  const columnIndex = Math.floor(Math.random() * 4);

  const letterElement = document.createElement('div');
  letterElement.className = 'falling-letter';
  letterElement.textContent = letter;
  letterElement.style.top = '0px';

  columns[columnIndex].appendChild(letterElement);

  gameState.fallingLetters.push({
    element: letterElement,
    letter: letter,
    column: columnIndex,
    y: 0,
    handled: false,
  });

  gameState.totalLetters++;
}

// 14. Update Letter Positions
function updateFallingLetters() {
  const bottomThreshold = gameArea.clientHeight - 85;

  for (let i = gameState.fallingLetters.length - 1; i >= 0; i--) {
    const letterObj = gameState.fallingLetters[i];
    if (letterObj.handled) continue;

    letterObj.y += gameState.currentSpeed;
    letterObj.element.style.top = `${letterObj.y}px`;

    // Letter hits bottom -> Missed
    if (letterObj.y > bottomThreshold) {
      letterObj.handled = true;
      letterObj.element.style.background = '#ef4444';
      letterObj.element.style.color = '#ffffff';
      letterObj.element.style.animation = 'missedShake 0.4s ease';

      setTimeout(() => {
        if (gameConfig.reducePointsOnMiss) {
          gameState.score = Math.max(0, gameState.score - gameConfig.missedPenalty);
        }
        gameState.missedCount++;
        removeLetter(letterObj);
        updateDisplay();
        showFeedback('missed', letterObj.column);
      }, 100);
    }
  }
}

// 15. Keyboard Input
function handleKeyPress(event) {
  if (!gameState.gameRunning) {
    if (event.key === 'Enter' || event.key === ' ') {
      startGame();
    }
    return;
  }

  const pressedKey = event.key.toUpperCase();
  if (!/^[A-Z]$/.test(pressedKey)) return;

  // Don't penalize if no letters are active on screen yet
  if (gameState.fallingLetters.length === 0) return;

  let bestMatch = null;
  let bestDistance = -1;

  for (let i = 0; i < gameState.fallingLetters.length; i++) {
    const letterObj = gameState.fallingLetters[i];
    if (letterObj.handled) continue;

    if (letterObj.letter === pressedKey) {
      if (letterObj.y > bestDistance) {
        bestMatch = letterObj;
        bestDistance = letterObj.y;
      }
    }
  }

  if (bestMatch) {
    // Correct letter matched
    const letterObj = bestMatch;
    letterObj.handled = true;

    letterObj.element.style.background = '#10b981';
    letterObj.element.style.color = 'white';
    letterObj.element.style.transform = 'translateX(-50%) scale(1.15)';

    gameState.score += gameConfig.correctPoints;
    gameState.correctCount++;

    setTimeout(() => {
      removeLetter(letterObj);
      showFeedback('correct', letterObj.column);
    }, 250);

    updateDisplay();
  } else {
    // Wrong key pressed
    if (gameState.hearts > 0) {
      const hearts = heartsValue.querySelectorAll('.heart');
      const lastHeart = hearts[hearts.length - 1];
      if (lastHeart) {
        lastHeart.classList.add('heart-lost');
        setTimeout(() => lastHeart.remove(), 500);
      }
    }

    gameState.hearts = Math.max(0, gameState.hearts - 1);
    document.body.classList.add('shake');
    setTimeout(() => document.body.classList.remove('shake'), 400);
    showFeedback('wrong', -1, pressedKey);
    updateDisplay();

    if (gameState.hearts <= 0) {
      endGame();
    }
  }
}

function removeLetter(letterObj) {
  const index = gameState.fallingLetters.indexOf(letterObj);
  if (index !== -1) {
    if (letterObj.element && letterObj.element.parentNode) {
      letterObj.element.remove();
    }
    gameState.fallingLetters.splice(index, 1);
  }
}

function showFeedback(type, columnIndex, extraText = '') {
  const feedback = document.createElement('div');
  feedback.className = `feedback ${type}`;

  let text = '';
  switch (type) {
    case 'correct':
      text = '+10';
      break;
    case 'missed':
      text = '-5';
      break;
    case 'wrong':
      text = extraText ? `${extraText} ✕` : '✕';
      break;
  }
  feedback.textContent = text;

  if (columnIndex >= 0) {
    feedback.style.left = '50%';
    feedback.style.top = '40%';
    feedback.style.transform = 'translateX(-50%)';
    columns[columnIndex].appendChild(feedback);
  } else {
    feedback.style.left = '50%';
    feedback.style.top = '50%';
    feedback.style.transform = 'translate(-50%, -50%)';
    gameArea.appendChild(feedback);
  }

  setTimeout(() => {
    feedback.remove();
  }, 900);
}

function showSpeedIncrease() {
  const indicator = document.createElement('div');
  indicator.className = 'speed-indicator';
  indicator.textContent = '⚡ Speed Up! ⚡';
  gameArea.appendChild(indicator);

  setTimeout(() => {
    indicator.remove();
  }, 1600);
}

// 16. End Game & TeachIT Progress Telemetry
function endGame() {
  if (!gameState.gameRunning && gameState.roundReported) return;
  gameState.gameRunning = false;
  stopIntervals();
  clearFallingLetterElements();

  updateGameStatistics();
  showGameOverScreen();

  // Report progress idempotently to TeachIT
  recordRoundProgress();
}

function recordRoundProgress() {
  if (gameState.roundReported) return;
  gameState.roundReported = true;

  const teachit = getTeachit();
  if (!teachit || typeof teachit.reportProgress !== 'function') {
    if (saveStatusMsg) {
      saveStatusMsg.textContent = 'Standalone mode (not connected to TeachIT launcher)';
    }
    return;
  }

  if (saveStatusMsg) {
    saveStatusMsg.textContent = 'Saving progress to student profile...';
  }

  const durationSeconds = Math.max(1, Math.round((Date.now() - gameState.gameStartTime) / 1000));
  const accuracy =
    gameState.totalLetters > 0
      ? Math.round((gameState.correctCount / gameState.totalLetters) * 100)
      : 0;

  // 1. Report activity completed event
  teachit
    .reportProgress({
      activityId: `falling-letters-${gameState.currentLevel}`,
      eventType: 'activity_completed',
      payload: {
        score: gameState.score,
        maxScore: Math.max(100, gameState.score),
        durationSeconds: durationSeconds,
        success: gameState.score > 0,
        metrics: {
          correctLetters: gameState.correctCount,
          missedLetters: gameState.missedCount,
          totalLetters: gameState.totalLetters,
          accuracyPercent: accuracy,
          heartsRemaining: gameState.hearts,
          level: gameState.currentLevel,
        },
      },
    })
    .then((res) => {
      if (res && res.success) {
        if (saveStatusMsg) {
          saveStatusMsg.className = 'save-status-msg saved';
          saveStatusMsg.textContent = '✓ Progress recorded in TeachIT student profile';
        }
      } else {
        if (saveStatusMsg) {
          saveStatusMsg.textContent = res?.error || 'Could not record progress (Guest session)';
        }
      }
    })
    .catch((err) => {
      if (saveStatusMsg) {
        saveStatusMsg.textContent = 'Failed to record progress: ' + String(err);
      }
    });

  // 2. Report score recorded event
  teachit
    .reportProgress({
      activityId: 'falling-letters-score',
      eventType: 'score_recorded',
      payload: {
        score: gameState.score,
        durationSeconds: durationSeconds,
      },
    })
    .catch(() => {});

  // 3. Optional Achievements
  if (gameState.score >= 50) {
    teachit
      .reportProgress({
        activityId: 'falling-letters-score',
        eventType: 'achievement_unlocked',
        payload: {
          achievementId: 'typing_cadet',
          achievementName: 'Keyboard Cadet',
          description: 'Achieved 50 or more points in Falling Letter.',
        },
      })
      .catch(() => {});
  }

  if (accuracy >= 85 && gameState.correctCount >= 10) {
    teachit
      .reportProgress({
        activityId: 'falling-letters-accuracy',
        eventType: 'achievement_unlocked',
        payload: {
          achievementId: 'typing_sharpshooter',
          achievementName: 'Keyboard Sharpshooter',
          description: 'Achieved 85% or higher typing accuracy with at least 10 correct letters.',
        },
      })
      .catch(() => {});
  }
}

function updateGameStatistics() {
  const gameTimeMinutes = (Date.now() - gameState.gameStartTime) / 60000;
  const accuracy =
    gameState.totalLetters > 0
      ? Math.round((gameState.correctCount / gameState.totalLetters) * 100)
      : 0;
  const lettersPerMinute =
    gameTimeMinutes > 0 ? Math.round(gameState.correctCount / gameTimeMinutes) : 0;

  document.getElementById('correctLetters').textContent = gameState.correctCount;
  document.getElementById('missedLetters').textContent = gameState.missedCount;
  document.getElementById('accuracy').textContent = `${accuracy}%`;
  document.getElementById('lettersPerMinute').textContent = lettersPerMinute;
}

function quitRoundToMenu() {
  // Graceful abandon: stops loop and returns to menu without falsely recording completion
  gameState.gameRunning = false;
  stopIntervals();
  clearFallingLetterElements();
  showStartScreen();
}

function restartGame() {
  clearFallingLetterElements();
  showStartScreen();
}

// 17. Boot Game
init();
