const POWERS = [128, 64, 32, 16, 8, 4, 2, 1];
let bitStates = [0, 0, 0, 0, 0, 0, 0, 0];
let targetNum = 13;
let score = 0;

function renderBits() {
  const container = document.getElementById('bits-container');
  if (!container) return;
  container.innerHTML = '';
  POWERS.forEach((power, idx) => {
    const col = document.createElement('div');
    col.className = 'bit-col';

    const label = document.createElement('span');
    label.className = 'power-label';
    label.textContent = power;

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'bit-btn' + (bitStates[idx] ? ' active' : '');
    btn.textContent = bitStates[idx];
    btn.addEventListener('click', () => toggleBit(idx));

    col.appendChild(label);
    col.appendChild(btn);
    container.appendChild(col);
  });
}

function toggleBit(idx) {
  bitStates[idx] = bitStates[idx] === 1 ? 0 : 1;
  updateSum();
  renderBits();
}

function updateSum() {
  const sum = bitStates.reduce((acc, bit, idx) => acc + bit * POWERS[idx], 0);
  const currentSumEl = document.getElementById('current-sum');
  if (currentSumEl) currentSumEl.textContent = sum;

  const statusEl = document.getElementById('status-msg');
  const nextBtn = document.getElementById('next-btn');

  if (sum === targetNum) {
    if (statusEl) {
      statusEl.className = 'status-msg correct';
      statusEl.textContent = '✓ Correct! Target reached!';
    }
    if (nextBtn) nextBtn.style.display = 'inline-block';
    score++;
    const scoreEl = document.getElementById('score');
    if (scoreEl) scoreEl.textContent = score;

    // Report progress via TeachIT safe game integration API
    if (window.teachit && window.teachit.reportProgress) {
      window.teachit
        .reportProgress({
          activityId: 'binary-switch-score',
          eventType: 'score_recorded',
          payload: { score: score * 10, maxScore: 100, durationSeconds: 15 },
        })
        .catch(() => {});

      window.teachit
        .reportProgress({
          activityId: 'binary-target-' + targetNum,
          eventType: 'activity_completed',
          payload: { score: 10, success: true, durationSeconds: 15 },
        })
        .catch(() => {});

      if (score === 1) {
        window.teachit
          .reportProgress({
            activityId: 'binary-target-' + targetNum,
            eventType: 'achievement_unlocked',
            payload: {
              achievementId: 'first_byte',
              achievementName: 'First Byte Mastered',
              description: 'Successfully matched your first binary decimal target.',
            },
          })
          .catch(() => {});
      }
    }
  } else if (sum > targetNum) {
    if (statusEl) {
      statusEl.className = 'status-msg wrong';
      statusEl.textContent = 'Sum exceeds target. Turn off switches.';
    }
    if (nextBtn) nextBtn.style.display = 'none';
  } else {
    if (statusEl) {
      statusEl.className = 'status-msg';
      statusEl.textContent = 'Keep toggling to reach ' + targetNum;
    }
    if (nextBtn) nextBtn.style.display = 'none';
  }
}

function newRound() {
  targetNum = Math.floor(Math.random() * 255) + 1;
  bitStates = [0, 0, 0, 0, 0, 0, 0, 0];
  const targetEl = document.getElementById('target');
  if (targetEl) targetEl.textContent = targetNum;
  const nextBtn = document.getElementById('next-btn');
  if (nextBtn) nextBtn.style.display = 'none';
  const statusEl = document.getElementById('status-msg');
  if (statusEl) statusEl.textContent = '';
  renderBits();
  updateSum();
}

function exitToTeachIT() {
  if (window.teachit && typeof window.teachit.exitGame === 'function') {
    window.teachit.exitGame().catch(() => window.close());
  } else {
    window.close();
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const nextBtn = document.getElementById('next-btn');
  if (nextBtn) nextBtn.addEventListener('click', newRound);

  const exitBtn = document.getElementById('exit-btn');
  if (exitBtn) exitBtn.addEventListener('click', exitToTeachIT);

  newRound();
});

// Run directly in case DOM is already loaded
if (document.readyState === 'interactive' || document.readyState === 'complete') {
  const nextBtn = document.getElementById('next-btn');
  if (nextBtn) nextBtn.addEventListener('click', newRound);

  const exitBtn = document.getElementById('exit-btn');
  if (exitBtn) exitBtn.addEventListener('click', exitToTeachIT);

  newRound();
}
