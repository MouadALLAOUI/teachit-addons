// ==========================================================================
// TeachIT Educational Game: Mouse Master
// Interactive Mouse Training Engine for Computer Science Beginners
// ==========================================================================

(function (global) {
  'use strict';

  // --- Scoring Constants ---
  // 5 ateliers x 3 manches x 30 pts + 5 bonus de fin d'atelier = 500 pts maximum.
  const MAX_SCORE = 500;
  const POINTS_PER_ROUND = 30;
  const COMPLETION_BONUS = 10;

  // --- Configuration & Challenges Definition ---
  const CHALLENGES_CONFIG = [
    {
      id: 'pointer-movement',
      title: 'Atelier 1 : Déplacer le pointeur',
      vocab: 'Le pointeur',
      description: "Déplace la souris pour placer le pointeur sur l'élément cible.",
      icon: '🎯',
      rounds: [
        { label: 'Centre', x: 50, y: 50, size: 140, icon: '⭐', text: 'Étoile' },
        { label: 'Haut-Droite', x: 75, y: 25, size: 120, icon: '🌟', text: 'Cible' },
        { label: 'Bas-Gauche', x: 25, y: 75, size: 110, icon: '✨', text: 'Balise' },
      ],
    },
    {
      id: 'left-click',
      title: 'Atelier 2 : Le clic gauche',
      vocab: 'Le clic gauche',
      description: "Clique une fois avec le bouton gauche (index) pour allumer l'élément.",
      icon: '👆',
      rounds: [
        {
          name: 'Ampoule',
          icon: '💡',
          btnText: 'Allumer la lumière',
          desc: 'Une ampoule de bureau',
        },
        {
          name: 'Ordinateur',
          icon: '💻',
          btnText: 'Démarrer le PC',
          desc: 'Un ordinateur de classe',
        },
        {
          name: 'Cloche',
          icon: '🔔',
          btnText: 'Faire sonner la cloche',
          desc: 'La cloche de récréation',
        },
      ],
    },
    {
      id: 'double-click',
      title: 'Atelier 3 : Le double-clic',
      vocab: 'Le double-clic',
      description: "Double-clique rapidement avec le bouton gauche pour ouvrir l'élément.",
      icon: '⚡',
      doubleClickThresholdMs: 650,
      rounds: [
        { name: 'Dossier', closedIcon: '📁', openedIcon: '📂', label: 'Dossier de cours' },
        { name: 'Coffre', closedIcon: '📦', openedIcon: '🎁', label: 'Boîte mystère' },
        { name: 'Fichier', closedIcon: '📄', openedIcon: '📑', label: 'Document secret' },
      ],
    },
    {
      id: 'drag-and-drop',
      title: 'Atelier 4 : Le glisser-déposer',
      vocab: 'Le glisser-déposer',
      description:
        "Maintiens le bouton gauche enfoncé, déplace l'élément et relâche-le dans la zone correspondante.",
      icon: '📦',
      rounds: [
        {
          itemIcon: '📄',
          itemTitle: 'Fichier.txt',
          targetIcon: '🗑️',
          targetTitle: 'Corbeille',
          hint: 'Déplace le fichier dans la corbeille.',
        },
        {
          itemIcon: '💾',
          itemTitle: 'Clé USB',
          targetIcon: '💻',
          targetTitle: 'Ordinateur',
          hint: 'Branche la clé USB sur l’ordinateur.',
        },
        {
          itemIcon: '⭐',
          itemTitle: 'Étoile dorée',
          targetIcon: '🏆',
          targetTitle: 'Socle du trophée',
          hint: 'Pose l’étoile sur son socle.',
        },
      ],
    },
    {
      id: 'right-click-menu',
      title: 'Atelier 5 : Le clic droit et le menu contextuel',
      vocab: 'Le clic droit',
      description: "Clique avec le bouton droit sur l'objet pour ouvrir son menu contextuel.",
      icon: '📋',
      rounds: [
        {
          cardIcon: '📄',
          cardTitle: 'document_cours.txt',
          cardDesc: 'Document texte scolaire',
          targetAction: 'info',
          actionInstruction: 'Fais un clic droit sur le document et choisis « Informations ».',
        },
        {
          cardIcon: '🎨',
          cardTitle: 'carte_graphique.png',
          cardDesc: 'Image illustrative',
          targetAction: 'color',
          actionInstruction: 'Fais un clic droit sur la carte et choisis « Changer la couleur ».',
        },
        {
          cardIcon: '📁',
          cardTitle: 'Dossier_Projet',
          cardDesc: 'Dossier de travail',
          targetAction: 'open',
          actionInstruction: 'Fais un clic droit sur le dossier et choisis « Ouvrir ».',
        },
      ],
    },
  ];

  // --- Core Game Class ---
  class MouseMasterEngine {
    constructor() {
      this.currentChallengeIndex = 0;
      this.currentRoundIndex = 0;
      this.unlockedChallenges = new Set([0]);
      this.completedChallenges = new Set();
      this.awardedRounds = new Set();
      this.score = 0;
      this.attemptsPerChallenge = [0, 0, 0, 0, 0];
      this.successesPerChallenge = [0, 0, 0, 0, 0];
      this.startTime = Date.now();
      this.started = false;
      this.sessionReported = false;
      this.sessionInfo = null;

      // Context menu action tracking
      this.cmenuOpen = false;
      this.cmenuPosition = { x: 0, y: 0 };
    }

    start() {
      this.startTime = Date.now();
      this.currentChallengeIndex = 0;
      this.currentRoundIndex = 0;
      this.unlockedChallenges = new Set([0]);
      this.completedChallenges = new Set();
      this.awardedRounds = new Set();
      this.score = 0;
      this.attemptsPerChallenge = [0, 0, 0, 0, 0];
      this.successesPerChallenge = [0, 0, 0, 0, 0];
      this.started = true;
      this.sessionReported = false;
    }

    recordAttempt(challengeIdx) {
      if (challengeIdx >= 0 && challengeIdx < 5) {
        this.attemptsPerChallenge[challengeIdx]++;
      }
    }

    /**
     * Adds points while guaranteeing the session score never exceeds MAX_SCORE.
     */
    addScore(points) {
      this.score = Math.min(MAX_SCORE, this.score + Math.max(0, points));
    }

    recordSuccess(challengeIdx) {
      if (challengeIdx < 0 || challengeIdx >= 5) return;

      this.successesPerChallenge[challengeIdx]++;

      // Each round of each atelier can only award points once per session,
      // so retrying a round or replaying a completed atelier cannot farm points.
      const roundKey = `${challengeIdx}:${this.currentRoundIndex}`;
      if (!this.awardedRounds.has(roundKey)) {
        this.awardedRounds.add(roundKey);
        this.addScore(POINTS_PER_ROUND);
      }
    }

    completeCurrentRound() {
      const challenge = CHALLENGES_CONFIG[this.currentChallengeIndex];
      const challengeIdx = this.currentChallengeIndex;
      this.recordSuccess(challengeIdx);

      if (this.currentRoundIndex + 1 < challenge.rounds.length) {
        this.currentRoundIndex++;
        return { isChallengeComplete: false, isGameComplete: false };
      } else {
        // Challenge completed: the completion bonus is awarded only once.
        if (!this.completedChallenges.has(challengeIdx)) {
          this.addScore(COMPLETION_BONUS);
        }
        this.completedChallenges.add(challengeIdx);

        if (this.currentChallengeIndex + 1 < CHALLENGES_CONFIG.length) {
          const nextIndex = this.currentChallengeIndex + 1;
          this.unlockedChallenges.add(nextIndex);
          this.currentChallengeIndex = nextIndex;
          this.currentRoundIndex = 0;
          return { isChallengeComplete: true, isGameComplete: false };
        } else {
          return { isChallengeComplete: true, isGameComplete: true };
        }
      }
    }

    goToChallenge(index) {
      if (this.unlockedChallenges.has(index)) {
        this.currentChallengeIndex = index;
        this.currentRoundIndex = 0;
        return true;
      }
      return false;
    }

    getTotalAttempts() {
      return this.attemptsPerChallenge.reduce((sum, a) => sum + a, 0);
    }

    getTotalSuccesses() {
      return this.successesPerChallenge.reduce((sum, s) => sum + s, 0);
    }

    getDurationSeconds() {
      return Math.max(1, Math.round((Date.now() - this.startTime) / 1000));
    }

    getSummary() {
      const durationSeconds = this.getDurationSeconds();
      const mins = Math.floor(durationSeconds / 60);
      const secs = durationSeconds % 60;
      const formattedDuration = `${mins}:${secs < 10 ? '0' : ''}${secs}`;

      return {
        score: this.score,
        maxScore: MAX_SCORE,
        completedChallenges: this.completedChallenges.size,
        totalChallenges: 5,
        totalAttempts: this.getTotalAttempts(),
        successfulActions: this.getTotalSuccesses(),
        durationSeconds,
        formattedDuration,
        challengeDetails: CHALLENGES_CONFIG.map((c, i) => ({
          id: c.id,
          title: c.title,
          vocab: c.vocab,
          completed: this.completedChallenges.has(i),
          attempts: this.attemptsPerChallenge[i],
          successes: this.successesPerChallenge[i],
        })),
      };
    }
  }

  // --- TeachIT Desktop Integration ---
  function getTeachit() {
    return typeof window !== 'undefined' && window.teachit ? window.teachit : null;
  }

  // --- UI Controller & Event Handlers ---
  let engine = new MouseMasterEngine();

  // DOM Elements
  const screenWelcome = document.getElementById('screenWelcome');
  const screenGame = document.getElementById('screenGame');
  const screenResults = document.getElementById('screenResults');

  const btnStartGame = document.getElementById('btnStartGame');
  const btnExitWelcome = document.getElementById('btnExitWelcome');
  const btnExitHeader = document.getElementById('btnExitHeader');
  const btnPrevChallenge = document.getElementById('btnPrevChallenge');
  const btnResetRound = document.getElementById('btnResetRound');
  const btnReplay = document.getElementById('btnReplay');
  const btnExitResults = document.getElementById('btnExitResults');

  const _challengeTabs = document.getElementById('challengeTabs');
  const challengeIndicator = document.getElementById('challengeIndicator');
  const roundIndicator = document.getElementById('roundIndicator');
  const challengeProgressFill = document.getElementById('challengeProgressFill');
  const scoreValue = document.getElementById('scoreValue');
  const attemptsValue = document.getElementById('attemptsValue');

  const instructionIcon = document.getElementById('instructionIcon');
  const instructionTitle = document.getElementById('instructionTitle');
  const instructionDesc = document.getElementById('instructionDesc');
  const feedbackBanner = document.getElementById('feedbackBanner');
  const feedbackIcon = document.getElementById('feedbackIcon');
  const feedbackText = document.getElementById('feedbackText');
  const vocabHighlight = document.getElementById('vocabHighlight');

  const stageArea = document.getElementById('stageArea');
  const stageContainer = document.getElementById('stageContainer');
  const customContextMenu = document.getElementById('customContextMenu');
  const infoCardOverlay = document.getElementById('infoCardOverlay');
  const btnInfoCardClose = document.getElementById('btnInfoCardClose');

  const sessionBadge = document.getElementById('sessionBadge');
  const sessionStudentName = document.getElementById('sessionStudentName');
  const saveStatusMsg = document.getElementById('saveStatusMsg');
  const saveStatusIcon = document.getElementById('saveStatusIcon');

  // Screen Switcher
  function showScreen(screenId) {
    [screenWelcome, screenGame, screenResults].forEach((s) => {
      if (s) {
        s.classList.remove('active');
      }
    });

    if (screenId === 'welcome' && screenWelcome) screenWelcome.classList.add('active');
    if (screenId === 'game' && screenGame) screenGame.classList.add('active');
    if (screenId === 'results' && screenResults) screenResults.classList.add('active');
  }

  // Feedback Banner Helper
  let feedbackTimer = null;

  // When the "Informations" panel is open, round progression is paused until
  // the student explicitly confirms with "Compris !".
  let pendingInfoAdvance = false;

  function showFeedback(text, type = 'info', icon = '💡', autoHideMs = 3500) {
    if (!feedbackBanner) return;
    if (feedbackTimer) clearTimeout(feedbackTimer);

    feedbackBanner.className = `feedback-banner ${type}`;
    if (feedbackIcon) feedbackIcon.textContent = icon;
    if (feedbackText) feedbackText.textContent = text;
    feedbackBanner.style.display = 'flex';

    if (autoHideMs > 0) {
      feedbackTimer = setTimeout(() => {
        feedbackBanner.style.display = 'none';
      }, autoHideMs);
    }
  }

  function hideFeedback() {
    if (feedbackBanner) feedbackBanner.style.display = 'none';
  }

  // Update Navigation Tabs
  function updateTabs() {
    for (let i = 0; i < 5; i++) {
      const tab = document.getElementById(`tab${i}`);
      if (!tab) continue;

      tab.classList.remove('active', 'completed', 'locked');
      if (i === engine.currentChallengeIndex) {
        tab.classList.add('active');
      }
      if (engine.completedChallenges.has(i)) {
        tab.classList.add('completed');
      }
      if (!engine.unlockedChallenges.has(i)) {
        tab.classList.add('locked');
      }
    }
  }

  // Update Meta Header
  function updateMeta() {
    const cIdx = engine.currentChallengeIndex;
    const challenge = CHALLENGES_CONFIG[cIdx];
    const totalRounds = challenge.rounds.length;

    if (challengeIndicator) challengeIndicator.textContent = `Atelier ${cIdx + 1}/5`;
    if (roundIndicator)
      roundIndicator.textContent = `Manche ${engine.currentRoundIndex + 1}/${totalRounds}`;
    if (scoreValue) scoreValue.textContent = String(engine.score);
    if (attemptsValue) attemptsValue.textContent = String(engine.attemptsPerChallenge[cIdx]);
    if (btnPrevChallenge) btnPrevChallenge.disabled = cIdx === 0;

    const pct = ((cIdx + (engine.currentRoundIndex + 1) / totalRounds) / 5) * 100;
    if (challengeProgressFill)
      challengeProgressFill.style.width = `${Math.min(100, Math.round(pct))}%`;

    if (instructionIcon) instructionIcon.textContent = challenge.icon;
    if (instructionTitle) instructionTitle.textContent = challenge.title;
    if (vocabHighlight) vocabHighlight.textContent = challenge.vocab;

    updateTabs();
  }

  // -------------------------------------------------------------
  // Challenge Renderers
  // -------------------------------------------------------------

  function renderCurrentChallenge() {
    hideFeedback();
    closeContextMenu();
    pendingInfoAdvance = false;
    if (infoCardOverlay) infoCardOverlay.style.display = 'none';
    if (!stageArea) return;
    stageArea.innerHTML = '';

    updateMeta();

    switch (engine.currentChallengeIndex) {
      case 0:
        renderChallenge1();
        break;
      case 1:
        renderChallenge2();
        break;
      case 2:
        renderChallenge3();
        break;
      case 3:
        renderChallenge4();
        break;
      case 4:
        renderChallenge5();
        break;
    }
  }

  // 1. Challenge 1 : Déplacer le pointeur
  function renderChallenge1() {
    const round = CHALLENGES_CONFIG[0].rounds[engine.currentRoundIndex];
    if (instructionDesc) {
      // Target name comes from the round configuration so the instruction can
      // never drift out of sync with the displayed target.
      instructionDesc.textContent = `Déplace la souris pour placer le pointeur sur « ${round.text} ». (Ne clique pas)`;
    }

    const target = document.createElement('div');
    target.className = 'c1-target';
    target.id = 'pointerTarget';
    target.style.left = `calc(${round.x}% - ${round.size / 2}px)`;
    target.style.top = `calc(${round.y}% - ${round.size / 2}px)`;
    target.style.width = `${round.size}px`;
    target.style.height = `${round.size}px`;

    target.innerHTML = `
      <span class="c1-target-icon" aria-hidden="true">${round.icon}</span>
      <span class="c1-target-label">${round.text}</span>
    `;

    let entered = false;
    // Enter target triggers success without requiring a click!
    const onEnter = () => {
      if (entered) return;
      entered = true;
      // Hovering the target is the interaction being practised: it is counted
      // as an attempt as well as a success.
      engine.recordAttempt(0);
      if (attemptsValue) attemptsValue.textContent = String(engine.attemptsPerChallenge[0]);
      target.classList.add('hovered');
      showFeedback(`Bravo ! Pointeur positionné avec succès.`, 'success', '✨', 1200);

      setTimeout(() => {
        advanceRound();
      }, 500);
    };

    target.addEventListener('pointerenter', onEnter);
    target.addEventListener('mouseenter', onEnter);

    stageArea.appendChild(target);
  }

  // 2. Challenge 2 : Le clic gauche
  function renderChallenge2() {
    const round = CHALLENGES_CONFIG[1].rounds[engine.currentRoundIndex];
    if (instructionDesc) {
      instructionDesc.textContent = `Clique une fois avec le bouton gauche (index) sur le bouton pour activer l'élément.`;
    }

    const container = document.createElement('div');
    container.className = 'c2-interactive-object';

    const device = document.createElement('div');
    device.className = 'c2-device';
    device.id = 'c2Device';
    device.innerHTML = `<span class="c2-device-icon" aria-hidden="true">${round.icon}</span>`;

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'c2-button';
    btn.id = 'c2Button';
    btn.textContent = round.btnText;

    let activated = false;

    // Detect click with button 0 (left click)
    const handleAction = (e) => {
      engine.recordAttempt(1);
      attemptsValue.textContent = String(engine.attemptsPerChallenge[1]);

      if (e.button === 2) {
        // Right click used by mistake
        showFeedback(
          'Tu as utilisé le clic droit ! Utilise le bouton GAUCHE de la souris.',
          'error',
          '⚠️',
        );
        return;
      }

      if (e.button === 0 && !activated) {
        activated = true;
        device.classList.add('active');
        btn.textContent = '✓ Activé !';
        btn.disabled = true;
        showFeedback(`Super ! Clic gauche réussi.`, 'success', '🎉', 1200);

        setTimeout(() => {
          advanceRound();
        }, 600);
      }
    };

    btn.addEventListener('pointerdown', (e) => {
      if (e.button === 2) {
        handleAction(e);
      }
    });
    btn.addEventListener('click', handleAction);

    container.appendChild(device);
    container.appendChild(btn);
    stageArea.appendChild(container);
  }

  // 3. Challenge 3 : Le double-clic
  function renderChallenge3() {
    const round = CHALLENGES_CONFIG[2].rounds[engine.currentRoundIndex];
    if (instructionDesc) {
      instructionDesc.textContent = `Double-clique rapidement avec le bouton gauche pour ouvrir l'élément.`;
    }

    const container = document.createElement('div');
    container.className = 'c3-interactive-container';

    const box = document.createElement('div');
    box.className = 'c3-box';
    box.id = 'c3Box';
    box.tabIndex = 0;
    box.setAttribute('role', 'button');
    box.setAttribute('aria-label', `Double-cliquer pour ouvrir ${round.name}`);

    box.innerHTML = `
      <span class="c3-box-icon" id="c3BoxIcon" aria-hidden="true">${round.closedIcon}</span>
      <span class="c3-box-label">${round.label}</span>
      <span class="c3-hint-tag">2 clics rapides</span>
    `;

    let clickCount = 0;
    let timer = null;
    let opened = false;
    const threshold = CHALLENGES_CONFIG[2].doubleClickThresholdMs || 650;

    const markOpened = (feedbackText, feedbackType, feedbackIcon) => {
      opened = true;
      if (timer) clearTimeout(timer);
      clickCount = 0;
      engine.recordAttempt(2);
      if (attemptsValue) attemptsValue.textContent = String(engine.attemptsPerChallenge[2]);

      box.classList.add('opened');
      const iconEl = box.querySelector('#c3BoxIcon');
      if (iconEl) iconEl.textContent = round.openedIcon;

      showFeedback(feedbackText, feedbackType, feedbackIcon, 1500);

      setTimeout(() => {
        advanceRound();
      }, 700);
    };

    const handlePointerDown = (e) => {
      if (opened) return;

      if (e.button === 2) {
        engine.recordAttempt(2);
        attemptsValue.textContent = String(engine.attemptsPerChallenge[2]);
        showFeedback(
          "Tu as fait un clic droit ! Le double-clic s'effectue avec le bouton GAUCHE.",
          'error',
          '⚠️',
        );
        return;
      }

      if (e.button !== 0) return;

      clickCount++;

      if (clickCount === 1) {
        timer = setTimeout(() => {
          if (clickCount === 1) {
            // First click timed out before second click
            engine.recordAttempt(2);
            attemptsValue.textContent = String(engine.attemptsPerChallenge[2]);
            showFeedback(
              'Trop lent ! Enchaîne deux clics rapides sur le même objet sans attendre.',
              'error',
              '⏱️',
            );
          }
          clickCount = 0;
        }, threshold);
      } else if (clickCount === 2) {
        markOpened(
          `Excellent double-clic ! Le ${round.name.toLowerCase()} s'est ouvert.`,
          'success',
          '⚡',
        );
      }
    };

    box.addEventListener('pointerdown', handlePointerDown);

    // Keyboard activation for the element that declares role="button".
    // The mouse double-click remains the learning objective; this is the
    // accessible equivalent for students who cannot use a pointing device.
    box.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter' && e.key !== ' ') return;
      e.preventDefault();
      if (opened) return;
      markOpened(
        "Ouvert au clavier (équivalent accessible). L'objectif reste le double-clic à la souris.",
        'info',
        '⌨️',
      );
    });

    // Also support native dblclick event as fallback
    box.addEventListener('dblclick', (e) => {
      if (e.button === 0 && !opened) {
        markOpened(
          `Excellent double-clic ! Le ${round.name.toLowerCase()} s'est ouvert.`,
          'success',
          '⚡',
        );
      }
    });

    container.appendChild(box);
    stageArea.appendChild(container);
  }

  // 4. Challenge 4 : Le glisser-déposer
  function renderChallenge4() {
    const round = CHALLENGES_CONFIG[3].rounds[engine.currentRoundIndex];
    if (instructionDesc) {
      instructionDesc.textContent = round.hint;
    }

    const stage = document.createElement('div');
    stage.className = 'c4-drag-stage';

    const sourceZone = document.createElement('div');
    sourceZone.className = 'c4-source-zone';
    sourceZone.id = 'c4SourceZone';
    sourceZone.innerHTML = `<span class="c4-zone-label">Départ</span>`;

    const targetZone = document.createElement('div');
    targetZone.className = 'c4-target-zone';
    targetZone.id = 'c4TargetZone';
    targetZone.innerHTML = `
      <span style="font-size: 3rem; pointer-events: none;">${round.targetIcon}</span>
      <span class="c4-zone-label">${round.targetTitle} (Destination)</span>
    `;

    const item = document.createElement('div');
    item.className = 'c4-draggable-item';
    item.id = 'c4DraggableItem';
    item.innerHTML = `
      <span class="c4-item-icon" aria-hidden="true">${round.itemIcon}</span>
      <span class="c4-item-title">${round.itemTitle}</span>
    `;

    sourceZone.appendChild(item);
    stage.appendChild(sourceZone);
    stage.appendChild(targetZone);
    stageArea.appendChild(stage);

    let isDragging = false;
    let offsetX = 0;
    let offsetY = 0;

    const onPointerDown = (e) => {
      if (e.button !== 0) {
        showFeedback("Maintiens le bouton GAUCHE enfoncé pour déplacer l'objet.", 'error', '⚠️');
        return;
      }

      isDragging = true;
      item.classList.add('dragging');
      item.setPointerCapture(e.pointerId);

      const rect = item.getBoundingClientRect();
      offsetX = e.clientX - rect.left;
      offsetY = e.clientY - rect.top;

      item.style.position = 'fixed';
      item.style.left = `${rect.left}px`;
      item.style.top = `${rect.top}px`;
      item.style.zIndex = '999';
    };

    const onPointerMove = (e) => {
      if (!isDragging) return;

      const currentX = e.clientX - offsetX;
      const currentY = e.clientY - offsetY;

      item.style.left = `${currentX}px`;
      item.style.top = `${currentY}px`;

      // Hit test target zone
      const tRect = targetZone.getBoundingClientRect();
      const iRect = item.getBoundingClientRect();

      const itemCenterX = iRect.left + iRect.width / 2;
      const itemCenterY = iRect.top + iRect.height / 2;

      // Generous bounding box check
      const isInside =
        itemCenterX >= tRect.left - 20 &&
        itemCenterX <= tRect.right + 20 &&
        itemCenterY >= tRect.top - 20 &&
        itemCenterY <= tRect.bottom + 20;

      if (isInside) {
        targetZone.classList.add('drag-over');
      } else {
        targetZone.classList.remove('drag-over');
      }
    };

    const onPointerUp = (e) => {
      if (!isDragging) return;
      isDragging = false;
      item.classList.remove('dragging');
      try {
        item.releasePointerCapture(e.pointerId);
      } catch {
        // Safe release
      }

      engine.recordAttempt(3);
      attemptsValue.textContent = String(engine.attemptsPerChallenge[3]);

      const tRect = targetZone.getBoundingClientRect();
      const iRect = item.getBoundingClientRect();
      const itemCenterX = iRect.left + iRect.width / 2;
      const itemCenterY = iRect.top + iRect.height / 2;

      const isInside =
        itemCenterX >= tRect.left - 30 &&
        itemCenterX <= tRect.right + 30 &&
        itemCenterY >= tRect.top - 30 &&
        itemCenterY <= tRect.bottom + 30;

      if (isInside) {
        // Success drop
        targetZone.classList.remove('drag-over');
        item.style.position = 'static';
        item.style.left = '';
        item.style.top = '';
        item.style.zIndex = '';
        targetZone.appendChild(item);

        showFeedback(`Bravo ! Objet déposé dans la bonne zone.`, 'success', '📦', 1200);

        setTimeout(() => {
          advanceRound();
        }, 600);
      } else {
        // Failed drop - snap back
        targetZone.classList.remove('drag-over');
        item.style.transition = 'all 200ms ease';
        item.style.position = 'static';
        item.style.left = '';
        item.style.top = '';
        item.style.zIndex = '';
        sourceZone.appendChild(item);

        setTimeout(() => {
          item.style.transition = '';
        }, 200);

        showFeedback("Relâche l'objet bien à l'intérieur de la zone en pointillés.", 'error', '🎯');
      }
    };

    item.addEventListener('pointerdown', onPointerDown);
    item.addEventListener('pointermove', onPointerMove);
    item.addEventListener('pointerup', onPointerUp);
    item.addEventListener('pointercancel', onPointerUp);
  }

  // 5. Challenge 5 : Le clic droit et le menu contextuel
  function renderChallenge5() {
    const round = CHALLENGES_CONFIG[4].rounds[engine.currentRoundIndex];
    if (instructionDesc) {
      instructionDesc.textContent = round.actionInstruction;
    }

    const container = document.createElement('div');
    container.className = 'c5-stage-content';

    const card = document.createElement('div');
    card.className = 'c5-target-card';
    card.id = 'c5TargetCard';
    card.tabIndex = 0;
    card.setAttribute('role', 'button');
    card.setAttribute('aria-label', `Objet à clic droit : ${round.cardTitle}`);

    card.innerHTML = `
      <span class="c5-card-icon" id="c5CardIcon" aria-hidden="true">${round.cardIcon}</span>
      <span class="c5-card-title">${round.cardTitle}</span>
      <span class="c5-card-desc">${round.cardDesc}</span>
    `;

    // Genuine right click triggers context menu
    const handleContextMenu = (e) => {
      e.preventDefault(); // Prevent default browser context menu inside the game arena
      engine.recordAttempt(4);
      attemptsValue.textContent = String(engine.attemptsPerChallenge[4]);

      openContextMenu(e.clientX, e.clientY, card);
      showFeedback(
        "Menu contextuel ouvert ! Sélectionne maintenant l'action demandée.",
        'info',
        '📋',
        2000,
      );
    };

    // If student left-clicks the card, guide them with feedback
    const handleLeftClick = (e) => {
      if (e.button === 0) {
        engine.recordAttempt(4);
        attemptsValue.textContent = String(engine.attemptsPerChallenge[4]);
        showFeedback(
          "C'est un clic gauche ! Utilise le bouton DROIT de la souris (avec ton majeur).",
          'error',
          '🖱️',
        );
      }
    };

    // Keyboard equivalent: activating the element that declares role="button"
    // opens the same context menu (standard Shift+F10 / Menu key behaviour).
    const handleKeyboardMenu = (e) => {
      const isActivation =
        e.key === 'Enter' ||
        e.key === ' ' ||
        e.key === 'ContextMenu' ||
        (e.shiftKey && e.key === 'F10');
      if (!isActivation) return;
      e.preventDefault();

      engine.recordAttempt(4);
      attemptsValue.textContent = String(engine.attemptsPerChallenge[4]);

      const rect = card.getBoundingClientRect();
      openContextMenu(rect.left + rect.width / 2, rect.top + 24, card);
      showFeedback(
        'Menu contextuel ouvert au clavier. Utilise les flèches puis Entrée pour choisir une action.',
        'info',
        '⌨️',
        2500,
      );
    };

    card.addEventListener('contextmenu', handleContextMenu);
    card.addEventListener('click', handleLeftClick);
    card.addEventListener('keydown', handleKeyboardMenu);

    container.appendChild(card);
    stageArea.appendChild(container);
  }

  // Context Menu Management
  let lastMenuTrigger = null;

  function openContextMenu(clientX, clientY, triggerEl) {
    if (!customContextMenu || !stageContainer) return;

    const containerRect = stageContainer.getBoundingClientRect();
    const menuWidth = 190;
    const menuHeight = 160;

    // Relative to container
    let relX = clientX - containerRect.left;
    let relY = clientY - containerRect.top;

    // Clamp inside container
    if (relX + menuWidth > containerRect.width) {
      relX = containerRect.width - menuWidth - 8;
    }
    if (relY + menuHeight > containerRect.height) {
      relY = containerRect.height - menuHeight - 8;
    }

    relX = Math.max(8, relX);
    relY = Math.max(8, relY);

    customContextMenu.style.left = `${relX}px`;
    customContextMenu.style.top = `${relY}px`;
    customContextMenu.style.display = 'block';
    engine.cmenuOpen = true;
    lastMenuTrigger = triggerEl || document.activeElement;

    // Focus first item for accessibility
    const firstItem = customContextMenu.querySelector('.context-menu-item');
    if (firstItem) firstItem.focus();
  }

  function closeContextMenu(restoreFocus = false) {
    if (customContextMenu) {
      customContextMenu.style.display = 'none';
      engine.cmenuOpen = false;
    }
    if (restoreFocus && lastMenuTrigger && typeof lastMenuTrigger.focus === 'function') {
      lastMenuTrigger.focus();
    }
    lastMenuTrigger = null;
  }

  // Execute Context Menu Action
  function executeContextAction(action) {
    closeContextMenu();
    const round = CHALLENGES_CONFIG[4].rounds[engine.currentRoundIndex];

    if (action === 'close') {
      showFeedback('Menu contextuel fermé.', 'info', '✖️', 1200);
      return;
    }

    if (action === 'info') {
      // Show info overlay modal
      if (infoCardOverlay) {
        const infoTitle = document.getElementById('infoCardTitle');
        const infoContent = document.getElementById('infoCardContent');
        if (infoTitle) infoTitle.textContent = `Informations sur ${round.cardTitle}`;
        if (infoContent) {
          infoContent.innerHTML = `
            <p><strong>Nom :</strong> ${round.cardTitle}</p>
            <p><strong>Description :</strong> ${round.cardDesc}</p>
            <p><strong>Type :</strong> Document d'exercice</p>
            <p><strong>Statut :</strong> Accessible en mode hors-ligne</p>
          `;
        }
        infoCardOverlay.style.display = 'flex';
        if (btnInfoCardClose) btnInfoCardClose.focus();
      }
    } else if (action === 'color') {
      // Dynamically change target card color
      const card = document.getElementById('c5TargetCard');
      if (card) {
        const colors = [
          'linear-gradient(135deg, #1e1b4b, #312e81)',
          'linear-gradient(135deg, #064e3b, #047857)',
          'linear-gradient(135deg, #701a75, #a21caf)',
          'linear-gradient(135deg, #7c2d12, #c2410c)',
        ];
        const nextColor = colors[Math.floor(Math.random() * colors.length)];
        card.style.background = nextColor;
        card.style.borderColor = 'var(--color-accent-warning)';
      }
      showFeedback('Couleur modifiée avec succès !', 'success', '🎨', 1500);
    } else if (action === 'open') {
      const card = document.getElementById('c5TargetCard');
      if (card) {
        card.style.transform = 'scale(1.08)';
        setTimeout(() => (card.style.transform = ''), 300);
      }
      showFeedback(`${round.cardTitle} a été ouvert !`, 'success', '📂', 1500);
    }

    // Check if this action matches the round requirement
    if (action === round.targetAction) {
      if (action === 'info') {
        // Reading the panel is part of the exercise: progression is paused
        // until the student explicitly clicks "Compris !".
        pendingInfoAdvance = true;
        showFeedback(
          `Action réussie ! Lis les informations puis clique sur « Compris ! » pour continuer.`,
          'success',
          '🏆',
          3000,
        );
      } else {
        showFeedback(
          `Action réussie ! Clic droit et menu contextuel maîtrisés.`,
          'success',
          '🏆',
          1500,
        );
        setTimeout(() => {
          advanceRound();
        }, 700);
      }
    } else {
      showFeedback(
        `Action exécutée, mais la consigne demandait : « ${round.actionInstruction} »`,
        'info',
        '💡',
        2500,
      );
    }
  }

  // Advance Round / Challenge Progression
  function advanceRound() {
    const res = engine.completeCurrentRound();

    if (res.isGameComplete) {
      showResultsScreen();
    } else if (res.isChallengeComplete) {
      showFeedback(`Atelier terminé ! Passage à l'atelier suivant.`, 'success', '🚀', 1500);
      renderCurrentChallenge();
    } else {
      renderCurrentChallenge();
    }
  }

  // Results Screen Display & Persistence
  function showResultsScreen() {
    showScreen('results');
    const summary = engine.getSummary();

    const resTotalScore = document.getElementById('resTotalScore');
    const resCompletedChallenges = document.getElementById('resCompletedChallenges');
    const resSuccessfulActions = document.getElementById('resSuccessfulActions');
    const resTotalAttempts = document.getElementById('resTotalAttempts');
    const resDuration = document.getElementById('resDuration');
    const resultsBreakdownList = document.getElementById('resultsBreakdownList');

    if (resTotalScore) resTotalScore.textContent = String(summary.score);
    if (resCompletedChallenges)
      resCompletedChallenges.textContent = `${summary.completedChallenges} / 5`;
    if (resSuccessfulActions) resSuccessfulActions.textContent = String(summary.successfulActions);
    if (resTotalAttempts) resTotalAttempts.textContent = String(summary.totalAttempts);
    if (resDuration) resDuration.textContent = summary.formattedDuration;

    if (resultsBreakdownList) {
      resultsBreakdownList.innerHTML = summary.challengeDetails
        .map(
          (c) => `
          <li class="breakdown-item">
            <span class="breakdown-name">
              <span>${c.completed ? '✅' : '⚪'}</span>
              <span>${c.title} (<strong>${c.vocab}</strong>)</span>
            </span>
            <span class="breakdown-status">
              ${
                c.completed
                  ? `Réussi (${c.attempts} tent., ${c.successes} réussite${c.successes > 1 ? 's' : ''})`
                  : 'Non terminé'
              }
            </span>
          </li>
        `,
        )
        .join('');
    }

    // Save progress to TeachIT
    reportProgressToTeachit(true);
  }

  // Telemetry & Persistence via TeachIT IPC
  function reportProgressToTeachit(isComplete = true) {
    if (engine.sessionReported) return;
    engine.sessionReported = true;

    const teachit = getTeachit();
    if (!teachit || typeof teachit.reportProgress !== 'function') {
      if (saveStatusMsg) {
        saveStatusMsg.textContent = 'Mode autonome (non connecté au lanceur TeachIT)';
      }
      return;
    }

    if (saveStatusMsg) {
      saveStatusMsg.textContent = 'Enregistrement des compétences dans le profil élève...';
      if (saveStatusIcon) saveStatusIcon.textContent = '⏳';
    }

    const summary = engine.getSummary();
    const isSuccess = isComplete && summary.completedChallenges >= 5;
    const eventType = isSuccess ? 'activity_completed' : 'score_recorded';

    teachit
      .reportProgress({
        activityId: 'mouse-master-complete',
        eventType,
        payload: {
          score: summary.score,
          maxScore: MAX_SCORE,
          durationSeconds: summary.durationSeconds,
          success: isSuccess,
          metrics: {
            completedChallenges: summary.completedChallenges,
            totalChallenges: 5,
            totalAttempts: summary.totalAttempts,
            successfulActions: summary.successfulActions,
            durationSeconds: summary.durationSeconds,
            status: isSuccess ? 'completed' : 'abandoned',
            challenge1_pointer: engine.completedChallenges.has(0),
            challenge2_click: engine.completedChallenges.has(1),
            challenge3_doubleClick: engine.completedChallenges.has(2),
            challenge4_dragDrop: engine.completedChallenges.has(3),
            challenge5_rightClick: engine.completedChallenges.has(4),
          },
        },
      })
      .then((res) => {
        if (res && res.success) {
          if (saveStatusMsg) {
            saveStatusMsg.textContent = '✓ Progression enregistrée dans le profil TeachIT';
          }
          if (saveStatusIcon) saveStatusIcon.textContent = '✅';
          const parentBox = saveStatusMsg?.parentElement;
          if (parentBox) parentBox.classList.add('saved');
        } else {
          if (saveStatusMsg) {
            saveStatusMsg.textContent = res?.error || 'Non enregistré (Mode invité sans profil)';
          }
        }
      })
      .catch((err) => {
        if (saveStatusMsg) {
          saveStatusMsg.textContent = `Erreur d'enregistrement : ${String(err)}`;
        }
      });
  }

  // Handle Early Exit & Abandonment
  function handleExitGame() {
    // Never report an abandoned session when the student leaves the welcome
    // screen without ever starting the training.
    if (engine.started && engine.completedChallenges.size < 5 && !engine.sessionReported) {
      reportProgressToTeachit(false);
    }

    const teachit = getTeachit();
    if (teachit && typeof teachit.exitGame === 'function') {
      teachit.exitGame().catch(() => {
        window.close();
      });
    } else {
      window.close();
    }
  }

  // Setup Global Event Listeners
  function setupListeners() {
    // Welcome Buttons
    if (btnStartGame) {
      btnStartGame.addEventListener('click', () => {
        engine.start();
        showScreen('game');
        renderCurrentChallenge();
      });
    }

    if (btnExitWelcome) {
      btnExitWelcome.addEventListener('click', handleExitGame);
    }

    if (btnExitHeader) {
      btnExitHeader.addEventListener('click', handleExitGame);
    }

    // Navigation Tabs
    for (let i = 0; i < 5; i++) {
      const tab = document.getElementById(`tab${i}`);
      if (tab) {
        tab.addEventListener('click', () => {
          if (engine.unlockedChallenges.has(i)) {
            engine.goToChallenge(i);
            showScreen('game');
            renderCurrentChallenge();
          } else {
            showFeedback(
              'Cet atelier est verrouillé. Termine les ateliers précédents pour le débloquer !',
              'info',
              '🔒',
            );
          }
        });
      }
    }

    // Game Footer Buttons
    if (btnPrevChallenge) {
      btnPrevChallenge.addEventListener('click', () => {
        if (engine.currentChallengeIndex > 0) {
          engine.goToChallenge(engine.currentChallengeIndex - 1);
          renderCurrentChallenge();
        }
      });
    }

    if (btnResetRound) {
      btnResetRound.addEventListener('click', () => {
        engine.recordAttempt(engine.currentChallengeIndex);
        renderCurrentChallenge();
        showFeedback('Manche réinitialisée.', 'info', '🔄', 1200);
      });
    }

    // Results Buttons
    if (btnReplay) {
      btnReplay.addEventListener('click', () => {
        engine.start();
        showScreen('game');
        renderCurrentChallenge();
      });
    }

    if (btnExitResults) {
      btnExitResults.addEventListener('click', handleExitGame);
    }

    // Info Modal Close
    if (btnInfoCardClose && infoCardOverlay) {
      btnInfoCardClose.addEventListener('click', () => {
        infoCardOverlay.style.display = 'none';
        // Progression resumes only now that the student confirmed they read it.
        if (pendingInfoAdvance) {
          pendingInfoAdvance = false;
          advanceRound();
        }
      });
    }

    // Context Menu Buttons
    const menuItems = document.querySelectorAll('.context-menu-item');
    menuItems.forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const action = btn.getAttribute('data-action');
        if (action) executeContextAction(action);
      });
    });

    // Dismiss Context Menu on Click Outside or Escape Key
    document.addEventListener('click', (e) => {
      if (engine.cmenuOpen && customContextMenu && !customContextMenu.contains(e.target)) {
        closeContextMenu();
      }
    });

    document.addEventListener('keydown', (e) => {
      // Focus trap while the "Informations" panel is open
      if (infoCardOverlay && infoCardOverlay.style.display !== 'none' && e.key === 'Tab') {
        e.preventDefault();
        if (btnInfoCardClose) btnInfoCardClose.focus();
        return;
      }

      // Keyboard navigation inside the custom context menu
      if (engine.cmenuOpen && customContextMenu) {
        const items = Array.from(customContextMenu.querySelectorAll('.context-menu-item'));
        const currentIdx = items.indexOf(document.activeElement);

        if (e.key === 'ArrowDown') {
          e.preventDefault();
          items[(currentIdx + 1) % items.length]?.focus();
          return;
        }
        if (e.key === 'ArrowUp') {
          e.preventDefault();
          items[(currentIdx - 1 + items.length) % items.length]?.focus();
          return;
        }
        if (e.key === 'Home') {
          e.preventDefault();
          items[0]?.focus();
          return;
        }
        if (e.key === 'End') {
          e.preventDefault();
          items[items.length - 1]?.focus();
          return;
        }
        if (e.key === 'Tab') {
          // Keep focus inside the open menu instead of escaping to the page.
          e.preventDefault();
          const next = e.shiftKey
            ? (currentIdx - 1 + items.length) % items.length
            : (currentIdx + 1) % items.length;
          items[next]?.focus();
          return;
        }
      }

      if (e.key === 'Escape') {
        if (infoCardOverlay && infoCardOverlay.style.display !== 'none') {
          infoCardOverlay.style.display = 'none';
          // Escape closes the panel without validating the round; the student
          // can reopen it and confirm with "Compris !".
          pendingInfoAdvance = false;
        } else if (engine.cmenuOpen) {
          closeContextMenu(true);
        }
      }
    });
  }

  // Initialize Session Info from TeachIT
  async function initSession() {
    const teachit = getTeachit();
    if (!teachit || typeof teachit.getSessionInfo !== 'function') return;

    try {
      const info = await teachit.getSessionInfo();
      if (info) {
        engine.sessionInfo = info;
        if (info.studentId && sessionBadge && sessionStudentName) {
          sessionBadge.style.display = 'inline-flex';
          // Students are identified by internal UUIDs: never display them.
          sessionStudentName.textContent = 'Élève';
        }
      }
    } catch {
      // Standalone mode fallback
    }
  }

  // Init on DOM Ready
  function init() {
    setupListeners();
    initSession();
    updateTabs();
  }

  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', init);
    } else {
      init();
    }
  }

  // Expose engine class for testing and modularity
  const exportTarget = typeof exports !== 'undefined' ? exports : global;
  exportTarget.MouseMasterEngine = MouseMasterEngine;
  exportTarget.CHALLENGES_CONFIG = CHALLENGES_CONFIG;
  exportTarget.MAX_SCORE = MAX_SCORE;

  // Narrow automation surface used by the TeachIT regression suite to drive the
  // UI controller without duplicating its internal wiring.
  exportTarget.MouseMasterUI = {
    getEngine: () => engine,
    showScreen,
    renderCurrentChallenge,
    executeContextAction,
    advanceRound,
    showResultsScreen,
    reportProgressToTeachit,
    handleExitGame,
    isInfoPending: () => pendingInfoAdvance,
  };
})(typeof window !== 'undefined' ? window : globalThis);
