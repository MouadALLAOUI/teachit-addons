/**
 * Binary Switch Circuit — TeachIT Educational Game
 * Platform: Offline-first Windows Electron (Chromium)
 * Target: Teenagers (12-16) learning computer science basics (informatique)
 */

// TODO: Arabic strings native-speaker review
const I18N = {
  fr: {
    gameTitle: 'Circuit Binaire',
    menuTagline: 'Maîtrise le binaire en basculant les interrupteurs logiques',
    modePracticeTitle: 'Entraînement',
    modePracticeDesc: 'Sans pression • Apprends à ton rythme',
    modeTimedTitle: 'Défi Chrono',
    modeTimedDesc: '60 secondes • Course contre la montre',
    modeEndlessTitle: 'Mode Infini',
    modeEndlessDesc: '3 vies • Les nombres augmentent',
    howToPlay: 'Comment Jouer',
    achievements: 'Succès',
    statistics: 'Statistiques',
    settings: 'Paramètres',
    hudScore: 'Score',
    hudAttempts: 'Essais',
    hudStreak: 'Série',
    hudTime: 'Temps',
    hudLives: 'Vies',
    hudLevel: 'Niveau',
    hudHints: 'Indices',
    targetNumber: 'Nombre Cible',
    currentTotal: 'Total Actuel',
    hintHidden: '???',
    hintBtn: 'Vérifier le Total',
    hintRevealedLabel: 'Total vérifié ✓',
    hintUsedFeedback: '💡 Total actuel révélé !',
    hintNoMoreFeedback: '⚠️ Aucun indice restant pour cette partie !',
    matchPrompt: 'Bascule les interrupteurs pour atteindre la cible !',
    feedbackCorrect: '✓ Correct ! Excellent travail !',
    feedbackTooHigh: 'Trop grand ! Éteins certains interrupteurs.',
    feedbackTooLow: 'Trop petit ! Allume d\'autres interrupteurs.',
    btnCheck: 'VÉRIFIER',
    btnNext: 'NOMBRE SUIVANT',
    btnGotIt: 'Compris ! Jouer',
    exitConfirmTitle: 'Quitter vers TeachIT',
    exitConfirmMsg: 'Quitter le jeu et retourner à TeachIT ?',
    exitRunWarning: 'Votre partie en cours sera perdue.',
    menuConfirmTitle: 'Retour au Menu',
    menuConfirmMsg: 'Retourner au menu principal ?',
    btnStay: 'Rester',
    btnLeave: 'Quitter',
    tutStep1Title: '1. Regarde la Cible',
    tutStep1Desc: 'Ton objectif est de créer ce nombre décimal avec le binaire.',
    tutStep2Title: '2. Bascule les Interrupteurs',
    tutStep2Desc: 'Chaque interrupteur ajoute sa puissance de 2 (128, 64, 32, 16, 8, 4, 2, 1).',
    tutStep3Title: '3. Vérifie ta Réponse',
    tutStep3Desc: 'Quand le total correspond à la cible, appuie sur VÉRIFIER ou Entrée !',
    settingSfx: 'Effets Sonores',
    settingMusic: 'Musique',
    settingLanguage: 'Langue',
    btnResetProgress: 'Réinitialiser la progression',
    resetConfirm: 'Réinitialiser tous les scores et succès ? Cette action est irréversible.',
    btnBack: 'Retour',
    statTotalSolved: 'Total Résolu',
    statTimedBest: 'Meilleur Score Chrono',
    statEndlessBest: 'Niveau Max Infini',
    statTotalFlips: 'Total Bascules',
    statAvgAttempts: 'Moyenne d\'Essais',
    statFastestSolve: 'Plus Rapide',
    gameOverTime: 'Temps Écoulé !',
    gameOverLives: 'Partie Terminée',
    summaryTitle: 'Résumé de la Partie',
    btnPlayAgain: 'REJOUER',
    btnMainMenu: 'MENU PRINCIPAL',
    achUnlockedToast: 'Succès Débloqué !',
    ach_first_byte_name: 'Premier Octet',
    ach_first_byte_desc: 'Résous ton premier nombre binaire',
    ach_bit_flipper_name: 'Basculeur de Bits',
    ach_bit_flipper_desc: 'Bascule des interrupteurs 50 fois',
    ach_perfect_byte_name: 'Octet Parfait',
    ach_perfect_byte_desc: 'Résous une cible dès la première tentative',
    ach_speed_daemon_name: 'Circuit Éclair',
    ach_speed_daemon_desc: 'Résous un nombre en moins de 5 secondes',
    ach_power_of_two_name: 'Pure Puissance de Deux',
    ach_power_of_two_desc: 'Résous une cible puissance exacte de 2',
    ach_century_club_name: 'Club des 100',
    ach_century_club_desc: 'Résous le nombre 100 ou atteins 100 points',
    ach_time_master_name: 'Maître du Temps',
    ach_time_master_desc: 'Résous 10 nombres en Défi Chrono',
    ach_circuit_survivor_name: 'Survivant du Circuit',
    ach_circuit_survivor_desc: 'Atteins le niveau 4 en Mode Infini',
  },
  en: {
    gameTitle: 'Binary Switch Circuit',
    menuTagline: 'Master binary numbers by toggling logic switches',
    modePracticeTitle: 'Practice',
    modePracticeDesc: 'No pressure • Learn at your own pace',
    modeTimedTitle: 'Timed Challenge',
    modeTimedDesc: '60 seconds • Race against the clock',
    modeEndlessTitle: 'Endless Mode',
    modeEndlessDesc: '3 lives • Numbers get bigger',
    howToPlay: 'How to Play',
    achievements: 'Achievements',
    statistics: 'Statistics',
    settings: 'Settings',
    hudScore: 'Score',
    hudAttempts: 'Attempts',
    hudStreak: 'Streak',
    hudTime: 'Time',
    hudLives: 'Lives',
    hudLevel: 'Level',
    hudHints: 'Hints',
    targetNumber: 'Target Number',
    currentTotal: 'Current Total',
    hintHidden: '???',
    hintBtn: 'Verify Total',
    hintRevealedLabel: 'Total verified ✓',
    hintUsedFeedback: '💡 Current total revealed!',
    hintNoMoreFeedback: '⚠️ No hints remaining for this run!',
    matchPrompt: 'Flip switches to reach the target!',
    feedbackCorrect: '✓ Correct! Awesome job!',
    feedbackTooHigh: 'Too high! Turn off some switches.',
    feedbackTooLow: 'Too low! Turn on more switches.',
    btnCheck: 'CHECK',
    btnNext: 'NEXT NUMBER',
    btnGotIt: 'Got It! Let\'s Play',
    exitConfirmTitle: 'Exit to TeachIT',
    exitConfirmMsg: 'Leave the game and go back to TeachIT?',
    exitRunWarning: 'Your current run will be lost.',
    menuConfirmTitle: 'Return to Menu',
    menuConfirmMsg: 'Return to the main menu?',
    btnStay: 'Stay',
    btnLeave: 'Leave',
    tutStep1Title: '1. See the Target Number',
    tutStep1Desc: 'Your goal is to build this decimal number using binary bits.',
    tutStep2Title: '2. Flip the Switches',
    tutStep2Desc: 'Each switch adds its power of 2 (128, 64, 32, 16, 8, 4, 2, 1). Turn on the bits that add up to the target!',
    tutStep3Title: '3. Check Your Answer',
    tutStep3Desc: 'When your total matches, press CHECK or hit Enter to score points and advance!',
    settingSfx: 'Sound Effects',
    settingMusic: 'Music',
    settingLanguage: 'Language',
    btnResetProgress: 'Reset Progress',
    resetConfirm: 'Reset all scores and achievements? This cannot be undone.',
    btnBack: 'Back',
    statTotalSolved: 'Total Solved',
    statTimedBest: 'Timed Challenge Best',
    statEndlessBest: 'Endless Max Level',
    statTotalFlips: 'Total Switch Flips',
    statAvgAttempts: 'Average Attempts',
    statFastestSolve: 'Fastest Solve',
    gameOverTime: 'Time\'s Up!',
    gameOverLives: 'Game Over',
    summaryTitle: 'Run Summary',
    btnPlayAgain: 'PLAY AGAIN',
    btnMainMenu: 'MAIN MENU',
    achUnlockedToast: 'Achievement Unlocked!',
    ach_first_byte_name: 'First Byte',
    ach_first_byte_desc: 'Match your first binary decimal target',
    ach_bit_flipper_name: 'Bit Flipper',
    ach_bit_flipper_desc: 'Toggle switches 50 times',
    ach_perfect_byte_name: 'Perfect Byte',
    ach_perfect_byte_desc: 'Solve a target on your very first try',
    ach_speed_daemon_name: 'Speed Circuit',
    ach_speed_daemon_desc: 'Solve a puzzle in under 5 seconds',
    ach_power_of_two_name: 'Pure Power of Two',
    ach_power_of_two_desc: 'Solve a target that is an exact power of 2',
    ach_century_club_name: 'Century Club',
    ach_century_club_desc: 'Solve decimal 100 or reach 100 points',
    ach_time_master_name: 'Time Master',
    ach_time_master_desc: 'Solve 10 puzzles in Timed Challenge',
    ach_circuit_survivor_name: 'Circuit Survivor',
    ach_circuit_survivor_desc: 'Reach Level 4 in Endless Mode',
  },
  ar: {
    gameTitle: 'دائرة المفاتيح الثنائية',
    menuTagline: 'احترف الأرقام الثنائية بتبديل المفاتيح المنطقية',
    modePracticeTitle: 'تدريب',
    modePracticeDesc: 'بدون ضغط • تعلّم بالسرعة التي تناسبك',
    modeTimedTitle: 'تحدي الوقت',
    modeTimedDesc: '60 ثانية • سباق ضد الساعة',
    modeEndlessTitle: 'الوضع اللانهائي',
    modeEndlessDesc: '3 محاولات • الأرقام تكبر تدريجياً',
    howToPlay: 'كيفية اللعب',
    achievements: 'الإنجازات',
    statistics: 'الإحصائيات',
    settings: 'الإعدادات',
    hudScore: 'النقاط',
    hudAttempts: 'المحاولات',
    hudStreak: 'التوالي',
    hudTime: 'الوقت',
    hudLives: 'المحاولات',
    hudLevel: 'المستوى',
    hudHints: 'تلميحات',
    targetNumber: 'الرقم المطلوب',
    currentTotal: 'المجموع الحالي',
    hintHidden: '؟؟؟',
    hintBtn: 'التحقق من المجموع',
    hintRevealedLabel: 'تم التحقق من المجموع ✓',
    hintUsedFeedback: '💡 تم كشف المجموع الحالي!',
    hintNoMoreFeedback: '⚠️ لا توجد تلميحات متبقية في هذه الجولة!',
    matchPrompt: 'بدّل المفاتيح للوصول إلى الرقم المطلوب!',
    feedbackCorrect: '✓ صحيح! أحسنت العمل!',
    feedbackTooHigh: 'المجموع أكبر من المطلوب! أطفئ بعض المفاتيح.',
    feedbackTooLow: 'المجموع أصغر من المطلوب! شغّل مفاتيح إضافية.',
    btnCheck: 'تحقق',
    btnNext: 'الرقم التالي',
    btnGotIt: 'فهمت! لنلعب الآن',
    exitConfirmTitle: 'الخروج إلى TeachIT',
    exitConfirmMsg: 'هل تريد مغادرة اللعبة والعودة إلى TeachIT؟',
    exitRunWarning: 'ستفقد تقدمك في الجولة الحالية.',
    menuConfirmTitle: 'العودة إلى القائمة',
    menuConfirmMsg: 'هل تريد العودة إلى القائمة الرئيسية؟',
    btnStay: 'البقاء',
    btnLeave: 'مغادرة',
    tutStep1Title: '1. انظر إلى الرقم المطلوب',
    tutStep1Desc: 'هدفك هو تكوين هذا الرقم العشري بالنظام الثنائي.',
    tutStep2Title: '2. شغّل المفاتيح المناسبة',
    tutStep2Desc: 'كل مفتاح يضيف قيمته (128، 64، 32، 16، 8، 4، 2، 1).',
    tutStep3Title: '3. تحقق من إجابتك',
    tutStep3Desc: 'عندما يتطابق المجموع مع الرقم، اضغط على تحقق أو زر Enter!',
    settingSfx: 'المؤثرات الصوتية',
    settingMusic: 'الموسيقى',
    settingLanguage: 'اللغة',
    btnResetProgress: 'إعادة ضبط التقدم',
    resetConfirm: 'هل تريد إعادة ضبط جميع النقاط والإنجازات؟ لا يمكن التراجع عن هذا الإجراء.',
    btnBack: 'رجوع',
    statTotalSolved: 'إجمالي المحلول',
    statTimedBest: 'أفضل نتيجة في الوقت',
    statEndlessBest: 'أعلى مستوى في اللانهائي',
    statTotalFlips: 'إجمالي تبديل المفاتيح',
    statAvgAttempts: 'متوسط المحاولات',
    statFastestSolve: 'أسرع حل',
    gameOverTime: 'انتهى الوقت!',
    gameOverLives: 'انتهت اللعبة',
    summaryTitle: 'ملخص الجولة',
    btnPlayAgain: 'العب مجدداً',
    btnMainMenu: 'القائمة الرئيسية',
    achUnlockedToast: 'تم فتح إنجاز جديد!',
    ach_first_byte_name: 'البايت الأول',
    ach_first_byte_desc: 'طابق أول رقم ثنائي بنجاح',
    ach_bit_flipper_name: 'مبدل البتات',
    ach_bit_flipper_desc: 'بدّل المفاتيح 50 مرة',
    ach_perfect_byte_name: 'بايت مثالي',
    ach_perfect_byte_desc: 'حل الرقم من المحاولة الأولى مباشرة',
    ach_speed_daemon_name: 'دائرة البرق',
    ach_speed_daemon_desc: 'حل الرقم في أقل من 5 ثوانٍ',
    ach_power_of_two_name: 'قوة ثنائية خالصة',
    ach_power_of_two_desc: 'حل رقماً يمثل قوة ثنائية دقيقة',
    ach_century_club_name: 'نادي المئة',
    ach_century_club_desc: 'حل الرقم 100 أو حقق 100 نقطة',
    ach_time_master_name: 'سيد الوقت',
    ach_time_master_desc: 'حل 10 أرقام في تحدي الوقت',
    ach_circuit_survivor_name: 'ناجي الدائرة',
    ach_circuit_survivor_desc: 'بلغ المستوى 4 في الوضع اللانهائي',
  },
};

// ==========================================================================
// CONSTANTS & GAME STATE
// ==========================================================================
const POWERS = [128, 64, 32, 16, 8, 4, 2, 1];
const STORAGE_KEY_V2 = 'teachit.binary.v2';
const STORAGE_KEY_V1 = 'teachit.binary.v1';

const ACHIEVEMENTS_LIST = [
  { id: 'first_byte', icon: '⚡' },
  { id: 'bit_flipper', icon: '🔄' },
  { id: 'perfect_byte', icon: '🎯' },
  { id: 'speed_daemon', icon: '⏱️' },
  { id: 'power_of_two', icon: '💎' },
  { id: 'century_club', icon: '💯' },
  { id: 'time_master', icon: '⏳' },
  { id: 'circuit_survivor', icon: '🛡️' },
];

let state = {
  lang: 'fr',
  soundEnabled: true,
  musicEnabled: true,
  sfxVolume: 0.8,
  musicVolume: 0.4,
  currentMode: null, // 'practice' | 'timed' | 'endless'
  targetNum: 13,
  bitStates: [0, 0, 0, 0, 0, 0, 0, 0],
  score: 0,
  streak: 0,
  attemptsThisRound: 0,
  roundStartTime: Date.now(),
  isSolved: false,

  // Mode specific
  timeLeft: 60,
  lives: 3,
  hints: 3,
  hintRevealedThisRound: false,
  level: 1, // Endless: 1 (range 15), 2 (range 31), 3 (range 63), 4 (range 127), 5 (range 255)
  totalSolvedInRun: 0,
  totalAttemptsInRun: 0,

  // Persistent stats
  stats: {
    totalSolved: 0,
    practiceSolved: 0,
    timedBest: 0,
    endlessMaxLevel: 1,
    totalFlips: 0,
    totalAttemptsEver: 0,
    fastestSolveSeconds: null,
  },

  // Persistent achievements
  unlockedAchievements: [],
  hasSeenTutorial: false,
};

let timerInterval = null;

// ==========================================================================
// AUDIO SYNTHESIZER (WebAudio API, 100% Offline, Zero Copyright)
// ==========================================================================
class WebAudioEngine {
  constructor() {
    this.ctx = null;
    this.musicGain = null;
    this.sfxGain = null;
    this.musicTimer = null;
    this.stepIndex = 0;
    this.isMusicPlaying = false;
  }

  init() {
    if (this.ctx) return;
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      this.ctx = new AudioCtx();

      this.musicGain = this.ctx.createGain();
      this.sfxGain = this.ctx.createGain();

      this.musicGain.gain.value = state.musicEnabled ? state.musicVolume : 0;
      this.sfxGain.gain.value = state.soundEnabled ? state.sfxVolume : 0;

      this.musicGain.connect(this.ctx.destination);
      this.sfxGain.connect(this.ctx.destination);

      if (this.ctx.state === 'suspended') {
        this.ctx.resume();
      }

      if (state.musicEnabled) {
        this.startMusic();
      }
    } catch {
      // AudioContext not supported
    }
  }

  updateVolumes() {
    if (!this.ctx) return;
    if (this.musicGain) {
      this.musicGain.gain.linearRampToValueAtTime(
        state.musicEnabled ? state.musicVolume : 0,
        this.ctx.currentTime + 0.05
      );
    }
    if (this.sfxGain) {
      this.sfxGain.gain.linearRampToValueAtTime(
        state.soundEnabled ? state.sfxVolume : 0,
        this.ctx.currentTime + 0.05
      );
    }
  }

  setMusicDucking(isDucked) {
    if (!this.ctx || !this.musicGain) return;
    const targetVol = state.musicEnabled
      ? (isDucked ? state.musicVolume * 0.25 : state.musicVolume)
      : 0;
    this.musicGain.gain.linearRampToValueAtTime(targetVol, this.ctx.currentTime + 0.1);
  }

  startMusic() {
    if (!this.ctx || this.isMusicPlaying) return;
    this.isMusicPlaying = true;
    this.stepIndex = 0;

    // Gentle arpeggio chord progression in minor/major (D, F, A, C)
    const notes = [
      220.00, 261.63, 329.63, 392.00, // A minor / C major feel
      261.63, 329.63, 392.00, 440.00,
      196.00, 246.94, 293.66, 392.00,
      174.61, 220.00, 261.63, 349.23,
    ];

    const playStep = () => {
      if (!this.isMusicPlaying || !this.ctx) return;

      const freq = notes[this.stepIndex % notes.length];
      this.stepIndex++;

      try {
        const osc = this.ctx.createOscillator();
        const noteGain = this.ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, this.ctx.currentTime);

        noteGain.gain.setValueAtTime(0, this.ctx.currentTime);
        noteGain.gain.linearRampToValueAtTime(0.08, this.ctx.currentTime + 0.04);
        noteGain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 0.42);

        osc.connect(noteGain);
        noteGain.connect(this.musicGain);

        osc.start();
        osc.stop(this.ctx.currentTime + 0.45);
      } catch {
        // Safe play
      }

      this.musicTimer = setTimeout(playStep, 260); // ~115 BPM 8th notes
    };

    playStep();
  }

  stopMusic() {
    this.isMusicPlaying = false;
    if (this.musicTimer) {
      clearTimeout(this.musicTimer);
      this.musicTimer = null;
    }
  }

  playSfx(type) {
    if (!this.ctx || !state.soundEnabled) return;
    if (this.ctx.state === 'suspended') this.ctx.resume();

    const now = this.ctx.currentTime;
    try {
      if (type === 'switchOn') {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(440, now);
        osc.frequency.exponentialRampToValueAtTime(660, now + 0.07);
        gain.gain.setValueAtTime(0.15, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
        osc.connect(gain);
        gain.connect(this.sfxGain);
        osc.start(now);
        osc.stop(now + 0.09);
      } else if (type === 'switchOff') {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(520, now);
        osc.frequency.exponentialRampToValueAtTime(310, now + 0.07);
        gain.gain.setValueAtTime(0.14, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
        osc.connect(gain);
        gain.connect(this.sfxGain);
        osc.start(now);
        osc.stop(now + 0.09);
      } else if (type === 'correct') {
        [523.25, 659.25, 783.99, 1046.50].forEach((freq, idx) => {
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          const startTime = now + idx * 0.06;
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, startTime);
          gain.gain.setValueAtTime(0.18, startTime);
          gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.28);
          osc.connect(gain);
          gain.connect(this.sfxGain);
          osc.start(startTime);
          osc.stop(startTime + 0.3);
        });
      } else if (type === 'wrong') {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(160, now);
        osc.frequency.linearRampToValueAtTime(110, now + 0.16);
        gain.gain.setValueAtTime(0.25, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
        osc.connect(gain);
        gain.connect(this.sfxGain);
        osc.start(now);
        osc.stop(now + 0.2);
      } else if (type === 'tick') {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(880, now);
        gain.gain.setValueAtTime(0.12, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);
        osc.connect(gain);
        gain.connect(this.sfxGain);
        osc.start(now);
        osc.stop(now + 0.05);
      } else if (type === 'hint') {
        // Bright pleasant dual bell chime (E5 -> B5)
        [659.25, 987.77].forEach((freq, idx) => {
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          const startTime = now + idx * 0.09;
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, startTime);
          gain.gain.setValueAtTime(0.2, startTime);
          gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.3);
          osc.connect(gain);
          gain.connect(this.sfxGain);
          osc.start(startTime);
          osc.stop(startTime + 0.32);
        });
      } else if (type === 'achievement') {
        [523.25, 659.25, 783.99, 880, 1046.50].forEach((freq, idx) => {
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          const startTime = now + idx * 0.08;
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(freq, startTime);
          gain.gain.setValueAtTime(0.2, startTime);
          gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.35);
          osc.connect(gain);
          gain.connect(this.sfxGain);
          osc.start(startTime);
          osc.stop(startTime + 0.38);
        });
      } else if (type === 'gameOver') {
        [440, 392, 349.23, 293.66].forEach((freq, idx) => {
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          const startTime = now + idx * 0.12;
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, startTime);
          gain.gain.setValueAtTime(0.18, startTime);
          gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.35);
          osc.connect(gain);
          gain.connect(this.sfxGain);
          osc.start(startTime);
          osc.stop(startTime + 0.4);
        });
      }
    } catch {
      // Safe fallback
    }
  }
}

const audio = new WebAudioEngine();

// First-gesture audio unlock
function ensureAudioStarted() {
  audio.init();
}
window.addEventListener('click', ensureAudioStarted, { once: true });
window.addEventListener('keydown', ensureAudioStarted, { once: true });
window.addEventListener('touchstart', ensureAudioStarted, { once: true });

// Background pause on window hide / minimize
document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    audio.stopMusic();
  } else if (state.musicEnabled) {
    audio.startMusic();
  }
});

// ==========================================================================
// CIRCUIT BACKGROUND CANVAS
// ==========================================================================
function initCircuitCanvas() {
  const canvas = document.getElementById('circuit-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const isReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (isReducedMotion) {
    canvas.style.display = 'none';
    return;
  }

  let width = (canvas.width = window.innerWidth);
  let height = (canvas.height = window.innerHeight);

  window.addEventListener('resize', () => {
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
  });

  const particles = [];
  const COUNT = 28;
  for (let i = 0; i < COUNT; i++) {
    particles.push({
      x: Math.random() * width,
      y: Math.random() * height,
      char: Math.random() > 0.5 ? '1' : '0',
      vy: 0.2 + Math.random() * 0.4,
      size: 14 + Math.random() * 10,
      alpha: 0.05 + Math.random() * 0.08,
    });
  }

  function draw() {
    if (document.hidden) {
      requestAnimationFrame(draw);
      return;
    }

    ctx.clearRect(0, 0, width, height);

    // Subtle Circuit Traces
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.035)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    for (let x = 40; x < width; x += 120) {
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
    }
    for (let y = 40; y < height; y += 120) {
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
    }
    ctx.stroke();

    // Floating binary digits
    ctx.font = 'bold 16px monospace';
    for (const p of particles) {
      p.y -= p.vy;
      if (p.y < -20) {
        p.y = height + 20;
        p.x = Math.random() * width;
      }
      ctx.fillStyle = `rgba(56, 189, 248, ${p.alpha})`;
      ctx.fillText(p.char, p.x, p.y);
    }

    requestAnimationFrame(draw);
  }

  requestAnimationFrame(draw);
}

// ==========================================================================
// I18N ROUTING & TRANSLATION ENGINE
// ==========================================================================
function t(key) {
  const langDict = I18N[state.lang] || I18N.fr;
  return langDict[key] || I18N.fr[key] || I18N.en[key] || key;
}

function updateTranslations() {
  document.documentElement.setAttribute('lang', state.lang);
  document.documentElement.setAttribute('dir', state.lang === 'ar' ? 'rtl' : 'ltr');

  document.querySelectorAll('[data-i18n]').forEach((el) => {
    const key = el.getAttribute('data-i18n');
    if (key) {
      el.textContent = t(key);
    }
  });

  // Active language button highlighting
  document.querySelectorAll('.lang-btn').forEach((btn) => {
    btn.classList.toggle('active', btn.getAttribute('data-lang') === state.lang);
  });

  // Update dynamic elements
  updateHeaderModeBadge();
  renderAchievementsModal();
  updateStatsDisplay();
  updateSumDisplay();
  updateHintButtonState();
}

function setLanguage(lang) {
  if (!I18N[lang]) return;
  state.lang = lang;
  saveState();
  updateTranslations();
}

// ==========================================================================
// PERSISTENCE & V1 TO V2 MIGRATION
// ==========================================================================
function loadState() {
  try {
    // Check v2
    const rawV2 = localStorage.getItem(STORAGE_KEY_V2);
    if (rawV2) {
      const parsed = JSON.parse(rawV2);
      state = { ...state, ...parsed };
      return;
    }

    // Check v1 migration
    const rawV1 = localStorage.getItem(STORAGE_KEY_V1);
    if (rawV1) {
      const parsedV1 = JSON.parse(rawV1);
      state.stats.totalSolved = Number(parsedV1.score) || 0;
      state.stats.practiceSolved = Number(parsedV1.score) || 0;
      if (state.stats.totalSolved > 0) {
        state.unlockedAchievements.push('first_byte');
      }
      saveState();
    }
  } catch {
    // LocalStorage fallback
  }
}

function saveState() {
  try {
    const toSave = {
      lang: state.lang,
      soundEnabled: state.soundEnabled,
      musicEnabled: state.musicEnabled,
      sfxVolume: state.sfxVolume,
      musicVolume: state.musicVolume,
      stats: state.stats,
      unlockedAchievements: state.unlockedAchievements,
      hasSeenTutorial: state.hasSeenTutorial,
    };
    localStorage.setItem(STORAGE_KEY_V2, JSON.stringify(toSave));
  } catch {
    // LocalStorage unavailable
  }
}

// ==========================================================================
// EXIT & MENU NAVIGATION INTEGRATION
// ==========================================================================
function exitGame() {
  if (window.teachit && typeof window.teachit.exitGame === 'function') {
    window.teachit.exitGame().catch(() => window.close());
  } else if (window.teachit && typeof window.teachit.exit === 'function') {
    window.teachit.exit().catch(() => window.close());
  } else if (window.history.length > 1) {
    window.history.back();
  } else {
    window.close();
  }
}

function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.add('active');
    // Default focus on primary action
    const primaryBtn = modal.querySelector('.primary-btn, .secondary-btn');
    primaryBtn?.focus();
  }
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.remove('active');
  }
}

function closeAllModals() {
  document.querySelectorAll('.modal-overlay').forEach((m) => m.classList.remove('active'));
}

// ==========================================================================
// ACHIEVEMENTS & TOASTS
// ==========================================================================
function reportAchievementToTeachit(id) {
  if (window.teachit && typeof window.teachit.reportProgress === 'function') {
    const achName = t(`ach_${id}_name`);
    const achDesc = t(`ach_${id}_desc`);
    window.teachit
      .reportProgress({
        activityId: `binary-achievement-${id}`,
        eventType: 'achievement_unlocked',
        payload: {
          achievementId: id,
          achievementName: achName,
          description: achDesc,
        },
      })
      .catch((err) => {
        console.warn(`[TeachIT] Progress telemetry note: ${err}`);
      });
  }
}

function syncAllAchievementsWithTeachit() {
  if (!window.teachit || typeof window.teachit.reportProgress !== 'function') return;
  if (Array.isArray(state.unlockedAchievements) && state.unlockedAchievements.length > 0) {
    state.unlockedAchievements.forEach((id) => {
      reportAchievementToTeachit(id);
    });
  }
}

function checkAchievement(id) {
  // Always guarantee TeachIT launcher receives the achievement unlock event
  reportAchievementToTeachit(id);

  if (state.unlockedAchievements.includes(id)) return;
  state.unlockedAchievements.push(id);
  saveState();
  audio.playSfx('achievement');

  // Show Toast
  const toastContainer = document.getElementById('toast-container');
  if (toastContainer) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    const achName = t(`ach_${id}_name`);
    const achIcon = ACHIEVEMENTS_LIST.find((a) => a.id === id)?.icon || '🏆';

    toast.innerHTML = `
      <span class="toast-icon">${achIcon}</span>
      <div>
        <div style="font-size:0.75rem; text-transform:uppercase; color:var(--accent-cyan); font-weight:700;">${t('achUnlockedToast')}</div>
        <div style="font-weight:700; font-size:0.95rem;">${achName}</div>
      </div>
    `;
    toastContainer.appendChild(toast);
    setTimeout(() => toast.classList.add('show'), 10);
    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 400);
    }, 3800);
  }
}

function renderAchievementsModal() {
  const container = document.getElementById('achievements-list-container');
  if (!container) return;
  container.innerHTML = '';

  for (const ach of ACHIEVEMENTS_LIST) {
    const isUnlocked = state.unlockedAchievements.includes(ach.id);
    const card = document.createElement('div');
    card.className = `achievement-card ${isUnlocked ? 'unlocked' : 'locked'}`;
    card.innerHTML = `
      <div class="achievement-icon">${ach.icon}</div>
      <div class="achievement-info">
        <h4>${t(`ach_${ach.id}_name`)}</h4>
        <p>${t(`ach_${ach.id}_desc`)}</p>
      </div>
    `;
    container.appendChild(card);
  }
}

// ==========================================================================
// STATISTICS
// ==========================================================================
function updateStatsDisplay() {
  const totalSolvedEl = document.getElementById('stat-total-solved');
  const timedBestEl = document.getElementById('stat-timed-best');
  const endlessBestEl = document.getElementById('stat-endless-best');
  const totalFlipsEl = document.getElementById('stat-total-flips');
  const avgAttemptsEl = document.getElementById('stat-avg-attempts');
  const fastestSolveEl = document.getElementById('stat-fastest-solve');

  if (totalSolvedEl) totalSolvedEl.textContent = state.stats.totalSolved;
  if (timedBestEl) timedBestEl.textContent = state.stats.timedBest;
  if (endlessBestEl) endlessBestEl.textContent = state.stats.endlessMaxLevel;
  if (totalFlipsEl) totalFlipsEl.textContent = state.stats.totalFlips;

  const avg = state.stats.totalSolved > 0
    ? (state.stats.totalAttemptsEver / state.stats.totalSolved).toFixed(1)
    : '0.0';
  if (avgAttemptsEl) avgAttemptsEl.textContent = avg;

  if (fastestSolveEl) {
    fastestSolveEl.textContent = state.stats.fastestSolveSeconds
      ? `${state.stats.fastestSolveSeconds.toFixed(1)}s`
      : '--';
  }
}

// ==========================================================================
// GAMEPLAY LOGIC
// ==========================================================================
function getActiveBitsForMode() {
  if (state.currentMode === 'endless') {
    // Progressive bit unlock every 5 solved
    if (state.level === 1) return 4; // range 1..15, bits 8, 4, 2, 1
    if (state.level === 2) return 5; // range 1..31
    if (state.level === 3) return 6; // range 1..63
    if (state.level === 4) return 7; // range 1..127
    return 8; // range 1..255
  }
  return 8;
}

function generateTargetNumber() {
  if (state.currentMode === 'endless') {
    const activeBits = getActiveBitsForMode();
    const maxVal = Math.pow(2, activeBits) - 1;
    return Math.floor(Math.random() * maxVal) + 1;
  }
  return Math.floor(Math.random() * 255) + 1;
}

function startMode(mode) {
  state.currentMode = mode;
  state.score = 0;
  state.streak = 0;
  state.totalSolvedInRun = 0;
  state.totalAttemptsInRun = 0;
  state.level = 1;
  state.lives = 3;
  state.hints = 3;
  state.hintRevealedThisRound = false;
  state.timeLeft = 60;
  state.isSolved = false;

  // View switch
  document.getElementById('view-menu')?.classList.remove('active');
  document.getElementById('view-game')?.classList.add('active');
  document.getElementById('btn-game-menu')?.style.setProperty('display', 'inline-flex');

  updateHeaderModeBadge();
  setupModeHud();

  if (window.teachit && typeof window.teachit.reportProgress === 'function') {
    window.teachit.reportProgress({
      activityId: `binary-${mode}-start`,
      eventType: 'activity_started',
      payload: {
        mode,
        attemptNumber: 1,
      },
    }).catch(() => {});
  }

  if (mode === 'timed') {
    startTimedTimer();
  }

  nextRound();
}

function updateHeaderModeBadge() {
  const badge = document.getElementById('header-mode-badge');
  if (!badge) return;

  if (!state.currentMode) {
    badge.style.display = 'none';
    return;
  }
  badge.style.display = 'inline-block';
  if (state.currentMode === 'practice') badge.textContent = t('modePracticeTitle');
  if (state.currentMode === 'timed') badge.textContent = t('modeTimedTitle');
  if (state.currentMode === 'endless') badge.textContent = t('modeEndlessTitle');
}

function setupModeHud() {
  const timerGroup = document.getElementById('hud-timer-group');
  const livesGroup = document.getElementById('hud-lives-group');
  const levelGroup = document.getElementById('hud-level-group');
  const hintsGroup = document.getElementById('hud-hints-group');
  const hintBtn = document.getElementById('btn-use-hint');

  const isChallenge = state.currentMode === 'timed' || state.currentMode === 'endless';

  if (timerGroup) timerGroup.style.display = state.currentMode === 'timed' ? 'flex' : 'none';
  if (livesGroup) livesGroup.style.display = state.currentMode === 'endless' ? 'flex' : 'none';
  if (levelGroup) levelGroup.style.display = state.currentMode === 'endless' ? 'flex' : 'none';
  if (hintsGroup) hintsGroup.style.display = isChallenge ? 'flex' : 'none';
  if (hintBtn) hintBtn.style.display = isChallenge ? 'inline-flex' : 'none';

  updateHud();
}

function updateHud() {
  const scoreVal = document.getElementById('hud-score-val');
  const attemptsVal = document.getElementById('hud-attempts-val');
  const streakVal = document.getElementById('hud-streak-val');
  const timerVal = document.getElementById('hud-timer-val');
  const levelVal = document.getElementById('hud-level-val');
  const hintsVal = document.getElementById('hud-hints-val');
  const livesContainer = document.getElementById('hud-lives-container');

  if (scoreVal) scoreVal.textContent = state.score;
  if (attemptsVal) attemptsVal.textContent = state.attemptsThisRound;
  if (streakVal) streakVal.textContent = state.streak;
  if (hintsVal) hintsVal.textContent = state.hints;

  updateHintButtonState();

  if (state.currentMode === 'timed' && timerVal) {
    timerVal.textContent = `${state.timeLeft}s`;
    timerVal.classList.toggle('warning', state.timeLeft <= 5);
  }

  if (state.currentMode === 'endless') {
    if (levelVal) levelVal.textContent = state.level;
    if (livesContainer) {
      livesContainer.innerHTML = '';
      for (let i = 0; i < 3; i++) {
        const heart = document.createElement('span');
        heart.innerHTML = `<svg class="heart-icon ${i < state.lives ? '' : 'lost'}" viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>`;
        livesContainer.appendChild(heart.firstChild);
      }
    }
  }
}

function renderSwitches() {
  const container = document.getElementById('switches-container');
  if (!container) return;
  container.innerHTML = '';

  const activeBitsCount = getActiveBitsForMode();
  const disabledBitsCount = 8 - activeBitsCount;

  POWERS.forEach((power, idx) => {
    const isDisabled = idx < disabledBitsCount;
    const col = document.createElement('div');
    col.className = 'bit-column';

    // Keyboard shortcut label [1] to [8]
    const keyHint = document.createElement('span');
    keyHint.className = 'bit-key-hint';
    keyHint.textContent = `${idx + 1}`;

    // Place value label (128 .. 1)
    const valLabel = document.createElement('span');
    valLabel.className = 'bit-value-label';
    valLabel.textContent = power;

    // Switch Button
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = `switch-button ${state.bitStates[idx] ? 'active' : ''}`;
    btn.disabled = isDisabled;
    btn.setAttribute('aria-label', `Bit ${power}: ${state.bitStates[idx] ? 'ON' : 'OFF'}`);

    // Inside LED & State Digit
    const led = document.createElement('div');
    led.className = 'switch-indicator-led';
    const digitSpan = document.createElement('span');
    digitSpan.textContent = state.bitStates[idx];

    btn.appendChild(led);
    btn.appendChild(digitSpan);

    btn.addEventListener('click', () => toggleBit(idx));

    col.appendChild(keyHint);
    col.appendChild(valLabel);
    col.appendChild(btn);
    container.appendChild(col);
  });
}

function toggleBit(idx) {
  const activeBitsCount = getActiveBitsForMode();
  const disabledBitsCount = 8 - activeBitsCount;
  if (idx < disabledBitsCount) return;

  state.bitStates[idx] = state.bitStates[idx] === 1 ? 0 : 1;
  state.stats.totalFlips++;
  saveState();

  if (state.stats.totalFlips >= 50) {
    checkAchievement('bit_flipper');
  }

  audio.playSfx(state.bitStates[idx] === 1 ? 'switchOn' : 'switchOff');

  renderSwitches();
  updateSumDisplay();
}

function calculateCurrentSum() {
  return state.bitStates.reduce((acc, bit, idx) => acc + bit * POWERS[idx], 0);
}

function updateHintButtonState() {
  const hintBtn = document.getElementById('btn-use-hint');
  const hintCountPill = document.getElementById('hint-btn-count');
  const hintLabel = document.getElementById('hint-btn-label');
  if (!hintBtn) return;

  const isChallenge = state.currentMode === 'timed' || state.currentMode === 'endless';
  if (!isChallenge) {
    hintBtn.style.display = 'none';
    return;
  }

  hintBtn.style.display = 'inline-flex';
  if (hintCountPill) hintCountPill.textContent = state.hints;

  if (state.hintRevealedThisRound || state.isSolved) {
    hintBtn.disabled = true;
    hintBtn.classList.add('revealed');
    if (hintLabel) hintLabel.textContent = t('hintRevealedLabel');
  } else {
    hintBtn.classList.remove('revealed');
    hintBtn.disabled = state.hints <= 0;
    if (hintLabel) {
      hintLabel.textContent = state.hints > 0 ? t('hintBtn') : t('hintNoMoreFeedback');
    }
  }
}

function updateSumDisplay() {
  const sum = calculateCurrentSum();
  const sumEl = document.getElementById('current-sum-display');

  const isChallenge = state.currentMode === 'timed' || state.currentMode === 'endless';
  const shouldReveal = !isChallenge || state.hintRevealedThisRound || state.isSolved;

  if (sumEl) {
    if (shouldReveal) {
      sumEl.textContent = sum;
      sumEl.classList.remove('hidden-sum');
      if (isChallenge && state.hintRevealedThisRound && !state.isSolved) {
        sumEl.classList.add('revealed-sum');
      } else {
        sumEl.classList.remove('revealed-sum');
      }
    } else {
      sumEl.textContent = t('hintHidden');
      sumEl.classList.add('hidden-sum');
      sumEl.classList.remove('revealed-sum');
    }
  }

  const feedbackEl = document.getElementById('feedback-message');
  if (feedbackEl && !state.isSolved && !state.hintRevealedThisRound) {
    feedbackEl.className = 'feedback-msg hint';
    feedbackEl.textContent = t('matchPrompt');
  }

  updateHintButtonState();
}

function useHint() {
  const isChallenge = state.currentMode === 'timed' || state.currentMode === 'endless';
  if (!isChallenge || state.isSolved) return;
  if (state.hintRevealedThisRound) return;

  if (state.hints <= 0) {
    audio.playSfx('wrong');
    const feedbackEl = document.getElementById('feedback-message');
    if (feedbackEl) {
      feedbackEl.className = 'feedback-msg wrong';
      feedbackEl.textContent = t('hintNoMoreFeedback');
    }
    const hintBtn = document.getElementById('btn-use-hint');
    if (hintBtn) {
      hintBtn.classList.add('shake');
      setTimeout(() => hintBtn.classList.remove('shake'), 400);
    }
    return;
  }

  state.hints--;
  state.hintRevealedThisRound = true;
  audio.playSfx('hint');

  const feedbackEl = document.getElementById('feedback-message');
  if (feedbackEl) {
    feedbackEl.className = 'feedback-msg hint';
    feedbackEl.textContent = t('hintUsedFeedback');
  }

  updateHud();
  updateSumDisplay();
}

function nextRound() {
  state.targetNum = generateTargetNumber();
  state.bitStates = [0, 0, 0, 0, 0, 0, 0, 0];
  state.attemptsThisRound = 0;
  state.roundStartTime = Date.now();
  state.isSolved = false;
  state.hintRevealedThisRound = false;

  const targetDisplay = document.getElementById('target-number-display');
  if (targetDisplay) targetDisplay.textContent = state.targetNum;

  const checkBtn = document.getElementById('btn-check-answer');
  const nextBtn = document.getElementById('btn-next-number');
  if (checkBtn) checkBtn.style.display = 'inline-flex';
  if (nextBtn) nextBtn.style.display = 'none';

  const feedbackEl = document.getElementById('feedback-message');
  if (feedbackEl) {
    feedbackEl.className = 'feedback-msg hint';
    feedbackEl.textContent = t('matchPrompt');
  }

  updateHud();
  renderSwitches();
  updateSumDisplay();
}

function checkAnswer() {
  if (state.isSolved) {
    nextRound();
    return;
  }

  state.attemptsThisRound++;
  state.totalAttemptsInRun++;
  state.stats.totalAttemptsEver++;
  updateHud();

  const currentSum = calculateCurrentSum();
  const feedbackEl = document.getElementById('feedback-message');

  if (currentSum === state.targetNum) {
    // CORRECT!
    state.isSolved = true;
    state.score++;
    state.streak++;
    state.totalSolvedInRun++;
    state.stats.totalSolved++;

    if (state.currentMode === 'practice') {
      state.stats.practiceSolved++;
    }

    const durationSeconds = (Date.now() - state.roundStartTime) / 1000;
    if (state.stats.fastestSolveSeconds === null || durationSeconds < state.stats.fastestSolveSeconds) {
      state.stats.fastestSolveSeconds = durationSeconds;
    }

    // Achievements validation
    checkAchievement('first_byte');
    if (state.attemptsThisRound === 1) checkAchievement('perfect_byte');
    if (durationSeconds < 5.0) checkAchievement('speed_daemon');
    if ([1, 2, 4, 8, 16, 32, 64, 128].includes(state.targetNum)) checkAchievement('power_of_two');
    if (state.targetNum === 100 || state.score >= 100) checkAchievement('century_club');

    audio.playSfx('correct');

    if (feedbackEl) {
      feedbackEl.className = 'feedback-msg correct';
      feedbackEl.textContent = t('feedbackCorrect');
    }

    // Mode-specific rewards
    if (state.currentMode === 'timed') {
      // +3s for 1st attempt, +1s otherwise
      const addedTime = state.attemptsThisRound === 1 ? 3 : 1;
      state.timeLeft += addedTime;
      if (state.score >= 10) checkAchievement('time_master');
      if (state.score > state.stats.timedBest) {
        state.stats.timedBest = state.score;
      }
    } else if (state.currentMode === 'endless') {
      // Level progression every 5 solved
      const newLevel = Math.min(5, Math.floor(state.totalSolvedInRun / 5) + 1);
      if (newLevel > state.level) {
        state.level = newLevel;
        state.hints = Math.min(5, state.hints + 1); // Bonus hint for reaching new level
        if (state.level >= 4) checkAchievement('circuit_survivor');
        if (state.level > state.stats.endlessMaxLevel) {
          state.stats.endlessMaxLevel = state.level;
        }
      }
    }

    saveState();
    updateHud();
    updateSumDisplay();

    // TeachIT safe progress telemetry
    if (window.teachit && typeof window.teachit.reportProgress === 'function') {
      window.teachit.reportProgress({
        activityId: `binary-round-${state.targetNum}`,
        eventType: 'activity_completed',
        payload: {
          score: state.score,
          target: state.targetNum,
          durationSeconds: Math.round(durationSeconds),
          attempts: state.attemptsThisRound,
        },
      }).catch(() => {});

      window.teachit.reportProgress({
        activityId: `binary-round-${state.targetNum}`,
        eventType: 'score_recorded',
        payload: {
          score: state.score,
          durationSeconds: Math.round(durationSeconds),
        },
      }).catch(() => {});
    }

    // Auto-advance after 1.2s delay or display Next button
    const checkBtn = document.getElementById('btn-check-answer');
    const nextBtn = document.getElementById('btn-next-number');
    if (checkBtn) checkBtn.style.display = 'none';
    if (nextBtn) nextBtn.style.display = 'inline-flex';

    setTimeout(() => {
      if (state.isSolved) {
        nextRound();
      }
    }, 1200);
  } else {
    // WRONG
    state.streak = 0;
    audio.playSfx('wrong');

    if (feedbackEl) {
      feedbackEl.className = 'feedback-msg wrong';
      feedbackEl.textContent = currentSum > state.targetNum
        ? t('feedbackTooHigh')
        : t('feedbackTooLow');
    }

    if (state.currentMode === 'endless') {
      state.lives--;
      updateHud();
      if (state.lives <= 0) {
        endGame('lives');
        return;
      }
    }
  }
}

// ==========================================================================
// TIMED CHALLENGE CLOCK & GAME OVER
// ==========================================================================
function startTimedTimer() {
  if (timerInterval) clearInterval(timerInterval);
  timerInterval = setInterval(() => {
    if (state.currentMode !== 'timed') {
      clearInterval(timerInterval);
      return;
    }

    state.timeLeft--;
    updateHud();

    if (state.timeLeft <= 5 && state.timeLeft > 0) {
      audio.playSfx('tick');
      audio.setMusicDucking(true);
    } else {
      audio.setMusicDucking(false);
    }

    if (state.timeLeft <= 0) {
      clearInterval(timerInterval);
      endGame('time');
    }
  }, 1000);
}

function endGame(reason) {
  if (timerInterval) clearInterval(timerInterval);
  audio.playSfx('gameOver');
  audio.setMusicDucking(false);

  const modal = document.getElementById('modal-game-over');
  const title = document.getElementById('game-over-title');
  const summaryScore = document.getElementById('summary-score');
  const summaryAvg = document.getElementById('summary-avg-attempts');

  if (title) {
    title.textContent = reason === 'time' ? t('gameOverTime') : t('gameOverLives');
  }
  if (summaryScore) summaryScore.textContent = state.score;

  const avg = state.totalSolvedInRun > 0
    ? (state.totalAttemptsInRun / state.totalSolvedInRun).toFixed(1)
    : '1.0';
  if (summaryAvg) summaryAvg.textContent = avg;

  // Report full session results to TeachIT
  if (window.teachit && typeof window.teachit.reportProgress === 'function') {
    window.teachit.reportProgress({
      activityId: `binary-${state.currentMode || 'game'}-session`,
      eventType: 'activity_completed',
      payload: {
        score: state.score,
        success: state.score > 0,
        mode: state.currentMode,
        reason,
        metrics: {
          totalSolved: state.totalSolvedInRun,
          totalAttempts: state.totalAttemptsInRun,
        },
      },
    }).catch(() => {});

    window.teachit.reportProgress({
      activityId: `binary-${state.currentMode || 'game'}-final-score`,
      eventType: 'score_recorded',
      payload: {
        score: state.score,
      },
    }).catch(() => {});
  }

  openModal('modal-game-over');
}

function returnToMainMenu() {
  if (timerInterval) clearInterval(timerInterval);
  state.currentMode = null;
  closeAllModals();

  document.getElementById('view-game')?.classList.remove('active');
  document.getElementById('view-menu')?.classList.add('active');
  document.getElementById('btn-game-menu')?.style.setProperty('display', 'none');

  updateHeaderModeBadge();
  updateStatsDisplay();
  syncAllAchievementsWithTeachit();
}

// ==========================================================================
// EVENT LISTENERS & INITIALIZATION
// ==========================================================================
document.addEventListener('DOMContentLoaded', () => {
  loadState();
  initCircuitCanvas();
  updateTranslations();

  // Synchronize any existing achievements with TeachIT launcher profile
  syncAllAchievementsWithTeachit();
  if (window.teachit && typeof window.teachit.getSessionInfo === 'function') {
    window.teachit.getSessionInfo().then((session) => {
      if (session) {
        syncAllAchievementsWithTeachit();
      }
    }).catch(() => {});
  }

  // Mode Selection
  document.getElementById('btn-mode-practice')?.addEventListener('click', () => startMode('practice'));
  document.getElementById('btn-mode-timed')?.addEventListener('click', () => startMode('timed'));
  document.getElementById('btn-mode-endless')?.addEventListener('click', () => startMode('endless'));

  // Header Buttons
  document.getElementById('btn-exit-teachit')?.addEventListener('click', () => {
    const isRunActive = state.currentMode && !state.isSolved && state.score > 0;
    const warning = document.getElementById('exit-run-warning');
    if (warning) warning.style.display = isRunActive ? 'block' : 'none';
    openModal('modal-exit-confirm');
  });

  document.getElementById('btn-game-menu')?.addEventListener('click', () => {
    const isRunActive = state.currentMode && !state.isSolved && state.score > 0;
    const warning = document.getElementById('menu-run-warning');
    if (warning) warning.style.display = isRunActive ? 'block' : 'none';
    openModal('modal-menu-confirm');
  });

  document.getElementById('btn-quick-settings')?.addEventListener('click', () => openModal('modal-settings'));

  // Modal Closers & Actions
  document.getElementById('btn-close-exit-modal')?.addEventListener('click', () => closeModal('modal-exit-confirm'));
  document.getElementById('btn-confirm-exit-stay')?.addEventListener('click', () => closeModal('modal-exit-confirm'));
  document.getElementById('btn-confirm-exit-leave')?.addEventListener('click', () => {
    closeModal('modal-exit-confirm');
    exitGame();
  });

  document.getElementById('btn-close-menu-modal')?.addEventListener('click', () => closeModal('modal-menu-confirm'));
  document.getElementById('btn-confirm-menu-stay')?.addEventListener('click', () => closeModal('modal-menu-confirm'));
  document.getElementById('btn-confirm-menu-leave')?.addEventListener('click', () => returnToMainMenu());

  // Menu Secondary Modals
  document.getElementById('btn-open-how-to-play')?.addEventListener('click', () => openModal('modal-how-to-play'));
  document.getElementById('btn-close-how-to-play')?.addEventListener('click', () => closeModal('modal-how-to-play'));
  document.getElementById('btn-dismiss-tutorial')?.addEventListener('click', () => {
    state.hasSeenTutorial = true;
    saveState();
    closeModal('modal-how-to-play');
  });

  document.getElementById('btn-open-achievements')?.addEventListener('click', () => {
    renderAchievementsModal();
    openModal('modal-achievements');
  });
  document.getElementById('btn-close-achievements')?.addEventListener('click', () => closeModal('modal-achievements'));

  document.getElementById('btn-open-stats')?.addEventListener('click', () => {
    updateStatsDisplay();
    openModal('modal-stats');
  });
  document.getElementById('btn-close-stats')?.addEventListener('click', () => closeModal('modal-stats'));

  document.getElementById('btn-open-settings')?.addEventListener('click', () => openModal('modal-settings'));
  document.getElementById('btn-close-settings')?.addEventListener('click', () => closeModal('modal-settings'));
  document.getElementById('btn-dismiss-settings')?.addEventListener('click', () => closeModal('modal-settings'));

  // Settings Controls
  const toggleSfx = document.getElementById('toggle-sfx');
  const toggleMusic = document.getElementById('toggle-music');
  const sliderSfx = document.getElementById('slider-sfx-volume');
  const sliderMusic = document.getElementById('slider-music-volume');

  if (toggleSfx) {
    toggleSfx.checked = state.soundEnabled;
    toggleSfx.addEventListener('change', (e) => {
      state.soundEnabled = e.target.checked;
      audio.updateVolumes();
      saveState();
    });
  }

  if (toggleMusic) {
    toggleMusic.checked = state.musicEnabled;
    toggleMusic.addEventListener('change', (e) => {
      state.musicEnabled = e.target.checked;
      audio.updateVolumes();
      if (state.musicEnabled) audio.startMusic();
      else audio.stopMusic();
      saveState();
    });
  }

  if (sliderSfx) {
    sliderSfx.value = Math.round(state.sfxVolume * 100);
    sliderSfx.addEventListener('input', (e) => {
      state.sfxVolume = Number(e.target.value) / 100;
      audio.updateVolumes();
      saveState();
    });
  }

  if (sliderMusic) {
    sliderMusic.value = Math.round(state.musicVolume * 100);
    sliderMusic.addEventListener('input', (e) => {
      state.musicVolume = Number(e.target.value) / 100;
      audio.updateVolumes();
      saveState();
    });
  }

  // Language Picker
  document.querySelectorAll('.lang-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      const selected = btn.getAttribute('data-lang');
      if (selected) setLanguage(selected);
    });
  });

  // Reset Progress
  document.getElementById('btn-reset-progress')?.addEventListener('click', () => {
    if (confirm(t('resetConfirm'))) {
      state.stats = {
        totalSolved: 0,
        practiceSolved: 0,
        timedBest: 0,
        endlessMaxLevel: 1,
        totalFlips: 0,
        totalAttemptsEver: 0,
        fastestSolveSeconds: null,
      };
      state.unlockedAchievements = [];
      saveState();
      updateStatsDisplay();
      renderAchievementsModal();
    }
  });

  // Gameplay Actions
  document.getElementById('btn-check-answer')?.addEventListener('click', checkAnswer);
  document.getElementById('btn-next-number')?.addEventListener('click', nextRound);
  document.getElementById('btn-use-hint')?.addEventListener('click', useHint);

  // Game Over Actions
  document.getElementById('btn-game-over-replay')?.addEventListener('click', () => {
    closeModal('modal-game-over');
    startMode(state.currentMode);
  });
  document.getElementById('btn-game-over-menu')?.addEventListener('click', () => {
    closeModal('modal-game-over');
    returnToMainMenu();
  });

  // First-launch tutorial auto-show
  if (!state.hasSeenTutorial) {
    openModal('modal-how-to-play');
  }

  // Global Keyboard Shortcuts
  window.addEventListener('keydown', (e) => {
    // Escape closes modals or prompts menu
    if (e.key === 'Escape') {
      const activeModal = document.querySelector('.modal-overlay.active');
      if (activeModal) {
        closeAllModals();
        return;
      }
      if (state.currentMode) {
        const isRunActive = !state.isSolved && state.score > 0;
        const warning = document.getElementById('menu-run-warning');
        if (warning) warning.style.display = isRunActive ? 'block' : 'none';
        openModal('modal-menu-confirm');
      }
      return;
    }

    // Number keys 1-8 toggle switches
    const num = parseInt(e.key, 10);
    if (!isNaN(num) && num >= 1 && num <= 8) {
      if (state.currentMode) {
        toggleBit(num - 1);
      }
      return;
    }

    // H uses hint to reveal total in challenge modes
    if (e.key === 'h' || e.key === 'H') {
      if (state.currentMode && !state.isSolved) {
        useHint();
        return;
      }
    }

    // Enter checks answer
    if (e.key === 'Enter') {
      const activeModal = document.querySelector('.modal-overlay.active');
      if (activeModal) {
        // If an exit dialog is active, Enter clicks the Stay button
        const stayBtn = activeModal.querySelector('#btn-confirm-exit-stay, #btn-confirm-menu-stay, #btn-dismiss-tutorial');
        stayBtn?.click();
        return;
      }
      if (state.currentMode) {
        if (state.isSolved) {
          nextRound();
        } else {
          checkAnswer();
        }
      }
    }
  });
});
