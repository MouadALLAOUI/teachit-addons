# CHANGELOG — Binary Switch Circuit (v2.0.0)

## Overview
Comprehensive modernization and rewrite of the "Binary Switch Circuit" educational game for Moroccan middle school students (12–16 years old) within TeachIT. The game transforms from a centered card into an immersive, responsive full-screen experience with rich audio, three distinct game modes, trilingual support (Arabic, French, English), offline-first mechanics, and achievement progression.

---

## Changes by Area

### 1. Full-Screen Architecture & Layout
- **Full Viewport Integration:** Replaced the small floating card layout with a 100vw × 100vh responsive grid/flex container designed for 1280×720 up to 1920×1080+ resolutions without scrollbars.
- **Circuit Matrix Background:** Implemented an animated HTML5 canvas rendering subtle circuit traces and gently floating 0/1 bits in dark navy/cyan.
- **Accessibility & Reduced Motion:** Automatically disables canvas animation when `prefers-reduced-motion` is detected.
- **Ergonomics:** All buttons exceed 56px in height with high-contrast active/hover states; switches feature large click/touch targets and keyboard support.

### 2. Main Menu & Navigation
- **Play Flow & Game Modes:**
  - **Practice Mode:** Zero time pressure, instant feedback, free exploration.
  - **Timed Challenge:** 60-second countdown with time bonuses (+3s first try, +1s subsequent).
  - **Endless Mode:** 3 lives with progressive bit unlocks (range expands 15 → 31 → 63 → 127 → 255 every 5 completed targets; inactive bit switches are dimmed and disabled).
- **Secondary Actions:** Interactive 3-step "How to Play" tutorial (auto-opened on first launch), Statistics modal, Achievements modal, and Settings modal.
- **Safe Exit Architecture:** Small, discreet exit icon button located in the top-right header away from interactive gameplay controls. Clicking triggers a confirmation dialog with **Stay** focused by default (Esc cancels). Calls `window.teachit.exitGame()` / `window.teachit.exit()` with safe browser fallbacks.

### 3. Trilingual Localization (AR / FR / EN)
- **Centralized Dictionary:** All UI strings, achievement names/descriptions, tutorial steps, and feedback messages are routed through a reactive translation engine `t(key)`.
- **RTL Support:** Full Right-to-Left bidirectional layout for Arabic (`dir="rtl"`, mirrored menus, headers, and modals).
- **Positional Binary Exception:** Binary switch row (`128 ... 1`) and numerical target/total indicators remain strictly Left-to-Right (`direction: ltr !important`) using Western digits (0–9) across all languages, preserving mathematical place-value notation.
- **Native Review Comments:** Included `TODO` comments identifying strings marked for Moroccan dialect/school curriculum native speaker verification.

### 4. Audio Engine (100% Synthetic WebAudio)
- **Zero Remote/Copyrighted Audio:** Custom WebAudio synthesizer with no external audio assets.
- **Procedural Background Music:** Calm ambient arpeggio chord progression (Cmaj7 / Am / F / G) with soft bandpass filtering. Auto-ducking during the final 5 seconds of timed mode.
- **Dynamic Sound Effects:**
  - Distinct pitch frequencies for switch toggle ON vs OFF.
  - Harmonic chime for correct answer.
  - Low buzz for incorrect submission.
  - Warning ticks during final 5-second countdown.
  - Victorious fanfares for achievements and stage completions.
- **Autoplay & Lifecycle Handling:** Audio context activates strictly on first user interaction. Audio automatically pauses when the window is hidden (`visibilitychange`) and resumes on focus.

### 5. Persistence & Migration
- **Schema Key:** Stored under `localStorage["teachit.binary.v2"]`.
- **Safe Migration:** Automatically detects and migrates legacy statistics from `teachit.binary.v1` (games played, high scores, completed runs) upon initialization without data loss.
- **TeachIT Progress Reporting:** Emits typed telemetry events via `window.teachit.reportProgress()` upon session completion or milestone unlock.

### 6. UI View Isolation & Launcher Achievement Synchronization (v2.0.1 Patch)
- **View Isolation Bug Fix:** Resolved an issue where CSS ID specificity on `#view-game` overrode `.view { display: none; }`, causing `#view-menu` and `#view-game` to render concurrently on initial load and push the bit switches off-screen. Fixed with strict `.view { display: none !important; }` and `.view.active { display: flex !important; }`.
- **Launcher Achievement Recognition:**
  - Implemented proactive achievement synchronization `syncAllAchievementsWithTeachit()` on startup (`DOMContentLoaded`), session resolution (`getSessionInfo()`), and when returning to the main menu.
  - Ensures existing achievements in local storage are idempotently pushed to the TeachIT SQLite database (`student_achievements`).
  - `checkAchievement()` now dispatches to the TeachIT IPC bridge on every evaluation regardless of previous local cache state.
  - Added `activity_started` telemetry upon entering any game mode, and `score_recorded` events for rounds and full sessions.

### 7. Hidden Total & Hint Budget Mechanic (v2.1.0)
- **Challenge Hidden Total:** In Timed Challenge and Endless Mode, the "Total Actuel" indicator is obscured by default as `???` to require students to perform mental binary addition.
- **Practice Mode Unchanged:** In Practice Mode, the total remains permanently visible for stress-free learning.
- **Hint Economy:**
  - Players start with 3 hints per run in challenge modes.
  - Endless mode rewards +1 bonus hint upon each progressive bit level advance (every 5 puzzles).
  - Clicking the **"Vérifier le Total"** hint button (or pressing `H`) costs 1 hint and reveals the active total with an amber pulse animation and dedicated dual-bell chime WebAudio SFX.
  - When hints reach 0, the button displays a warning state and disabled styling.
  - Trilingual localization added for hint labels, count pill, feedback messages, and controls across French, English, and Arabic.

---

## Assumptions
1. **Target Hardware:** Targets classroom PCs running Windows 10/11 with 1280×720 or 1920×1080 display resolutions.
2. **Audio Availability:** System supports standard WebAudio API (`AudioContext` / `webkitAudioContext`).
3. **No External Fonts:** Uses local system font stack (`Segoe UI`, `Cairo`, system Arabic fallbacks) ensuring zero network traffic.
