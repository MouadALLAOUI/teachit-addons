/**
 * TeachIT Educational Game: Data Detective (Comprendre l'information)
 * Offline-first, vanilla JavaScript engine teaching the fundamental cycle:
 * DONNÉES → TRAITEMENT INFORMATIQUE → INFORMATION
 * (Collecter -> Stocker -> Traiter -> Diffuser -> Utiliser)
 */

'use strict';

// ============================================================================
// 1. Translations & Localized Content
// ============================================================================
const TRANSLATIONS = {
  fr: {
    title: "Data Detective — Comprendre l'information",
    offlineMode: "Mode Hors-Ligne",
    categoryTag: "Traitement de l'info",
    tabs: [
      "Données & Info",
      "Types de données",
      "Parcours de l'info",
      "Supermarché",
      "Mission Bibliothèque"
    ],
    studentLabel: "Élève :",
    quit: "Quitter",
    welcome: {
      title: "Comprendre l'information",
      sub: "Bienvenue dans l'académie des Détectives de Données ! Découvre comment les ordinateurs transforment des données brutes en informations utiles pour prendre des décisions.",
      start: "Commencer l'enquête (Défi 1)",
      resume: "Reprendre la partie",
      reset: "Recommencer à zéro"
    },
    hints: {
      c1: "Indice : Une donnée est un élément brut (chiffre, mot isolé). Une information apporte du sens ou un résultat après calcul ou analyse.",
      c2: "Indice : Glisse ou clique sur un élément puis sur son type : Texte, Numérique, Date, Image, Son ou Vidéo.",
      c3: "Indice : L'ordre obligatoire est : 1. Collecter ➔ 2. Stocker ➔ 3. Traiter ➔ 4. Diffuser ➔ 5. Utiliser.",
      c4: "Indice : Scanne d'abord les 3 produits, clique ensuite sur Calculer le total, puis valide le paiement.",
      c5: "Indice : Associe chaque tâche à sa phase : Scanner = Collecter, Sauvegarder = Stocker, Calculer = Traiter, Afficher = Diffuser, Décider d'acheter = Utiliser."
    },
    c1: {
      badge: "Différencier",
      title: "Découvre la transformation de la donnée en information",
      sub: "Observe la calculatrice transformer les notes, puis classe chaque exemple.",
      eduTitle: "Donnée brute vs Information utile",
      eduDesc: "Une <strong>donnée</strong> est une valeur brute (nombre, mot, mesure). Une <strong>information</strong> est le résultat compréhensible obtenu après avoir traité et interprété ces données.",
      animHeader: "Laboratoire de Transformation Informatique",
      btnAnim: "Animer le traitement",
      conveyor: "Données Brutes (Notes)",
      machine: "Traitement Informatique",
      screenIdle: "En attente de calcul...",
      screenProc: "Calcul de la moyenne...",
      screenDone: "(12 + 15 + 8 + 17 + 18) / 5 = 14",
      outputVal: "Moyenne : 14 / 20",
      outputDesc: "Information obtenue (Sens : bonne moyenne générale)",
      quizTitle: "À toi de jouer : Est-ce une Donnée ou une Information ?"
    },
    c2: {
      badge: "Classification",
      title: "Reconnais et classe les 6 grands types de données",
      sub: "Glisse ou clique sur chaque élément pour le ranger dans la bonne catégorie.",
      eduTitle: "Les 6 types de données numériques",
      eduDesc: "Un ordinateur manipule différentes formes d'informations : du <strong>Texte</strong>, des <strong>Nombres</strong>, des <strong>Dates</strong>, des <strong>Images</strong>, du <strong>Son</strong> et des <strong>Vidéos</strong>.",
      trayLabel: "Éléments à classer (sélectionne ou glisse-dépose) :"
    },
    c3: {
      badge: "Cycle Complet",
      title: "Maîtrise le parcours de l'information en 5 étapes",
      sub: "Observe le voyage des données, puis reconstitue l'ordre chronologique obligatoire.",
      eduTitle: "Les 5 étapes incontournables du traitement",
      eduDesc: "Toute information numérique suit exactement cet ordre : <strong>1. Collecter</strong> (capturer) ➔ <strong>2. Stocker</strong> (sauvegarder) ➔ <strong>3. Traiter</strong> (calculer/trier) ➔ <strong>4. Diffuser</strong> (afficher) ➔ <strong>5. Utiliser</strong> (agir/décider).",
      pipeTitle: "Visualisation interactive du trajet d'une donnée",
      btnAnim: "Lancer le parcours",
      orderTitle: "Reconstitue l'ordre obligatoire des 5 étapes :"
    },
    c4: {
      badge: "Simulation Réelle",
      title: "Dans la peau d'un ordinateur : La caisse du supermarché",
      sub: "Scanne les 3 articles, lance le calcul du total et valide le paiement du client.",
      eduTitle: "Cas concret : Le système de caisse enregistreuse",
      eduDesc: "Découvre comment les 5 étapes se déroulent dans la vie quotidienne : scanner le code-barres (<strong>Collecter</strong>), mémoriser les prix (<strong>Stocker</strong>), calculer la somme (<strong>Traiter</strong>), afficher le ticket (<strong>Diffuser</strong>) et payer ses achats (<strong>Utiliser</strong>).",
      btnCalc: "Calculer le total",
      btnPay: "Payer les achats",
      tipScan: "Clique sur un produit pour le passer sous le scanner"
    },
    c5: {
      badge: "Mission Finale",
      title: "Mission finale : Le système de la bibliothèque scolaire",
      sub: "Attribue chaque tâche de gestion à l'une des 5 étapes du traitement.",
      eduTitle: "Scénario d'autonomie : La Bibliothèque Scolaire",
      eduDesc: "Le documentaliste souhaite renouveler les livres les plus populaires et suivre les emprunts des élèves. En tant que Data Detective en chef, attribue chaque opération à sa phase correspondante.",
      poolTitle: "Opérations de la bibliothèque :"
    },
    results: {
      title: "Enquête Réussie avec Succès !",
      sub: "Félicitations, tu as brillamment maîtrisé le cycle complet du traitement informatique de l'information !",
      btnReplay: "Rejouer l'enquête",
      btnFinish: "Terminer et Quitter"
    },
    footer: {
      prev: "Défi précédent",
      next: "Défi suivant",
      hint: "Indice"
    }
  },
  ar: {
    title: "محقق البيانات — فهم المعلومة",
    offlineMode: "وضع غير متصل",
    categoryTag: "معالجة المعلومات",
    tabs: [
      "البيانات والمعلومات",
      "أنواع البيانات",
      "مسار المعلومة",
      "السوبرماركت",
      "مهمة المكتبة"
    ],
    studentLabel: "التلميذ :",
    quit: "خروج",
    welcome: {
      title: "فهم المعلومة",
      sub: "مرحبًا بك في أكاديمية محققي البيانات! اكتشف كيف يحول الحاسوب البيانات الخام إلى معلومات مفيدة لاتخاذ القرارات.",
      start: "بدء التحقيق (التحدي 1)",
      resume: "متابعة اللعبة",
      reset: "إعادة البدء من الصفر"
    },
    hints: {
      c1: "تلميح: البيان عنصر خام مجرد (رقم أو كلمة منفصلة). المعلومة تعطي معنى أو نتيجة بعد الحساب أو التحليل.",
      c2: "تلميح: اسحب أو انقر على العنصر ثم اختر نوعه: نص، عددي، تاريخ، صورة، صوت أو فيديو.",
      c3: "تلميح: الترتيب الإلزامي هو: 1. جمع ➔ 2. تخزين ➔ 3. معالجة ➔ 4. نشر ➔ 5. استخدام.",
      c4: "تلميح: امسح المنتجات الثلاثة أولاً، ثم انقر على حساب المجموع، ثم قم بالدفع.",
      c5: "تلميح: اربط كل مهمة بمرحلتها: المسح = جمع، الحفظ = تخزين، الحساب = معالجة، العرض = نشر، قرار الشراء = استخدام."
    },
    c1: {
      badge: "التمييز",
      title: "اكتشف تحويل البيانات إلى معلومات مفيدة",
      sub: "شاهد الآلة الحاسبة تعالج النقط، ثم صنف كل مثال.",
      eduTitle: "البيان الخام مقابل المعلومة المفيدة",
      eduDesc: "<strong>البيان</strong> هو قيمة خام (رقم، كلمة، قياس). <strong>المعلومة</strong> هي نتيجة مفهومة نحصل عليها بعد معالجة وتفسير هذه البيانات.",
      animHeader: "مختبر المعالجة المعلوماتية",
      btnAnim: "تشغيل المعالجة",
      conveyor: "بيانات خام (النقط)",
      machine: "معالجة معلوماتية",
      screenIdle: "في انتظار الحساب...",
      screenProc: "حساب المعدل...",
      screenDone: "(12 + 15 + 8 + 17 + 18) / 5 = 14",
      outputVal: "المعدل : 14 / 20",
      outputDesc: "معلومة مفيدة (المعنى: مستوى عام جيد)",
      quizTitle: "دورك الآن: هل هذا بيان أم معلومة ؟"
    },
    c2: {
      badge: "التصنيف",
      title: "تعرف على الأنواع الستة للبيانات وصنفها",
      sub: "اسحب أو انقر على كل عنصر لوضعه في الفئة المناسبة.",
      eduTitle: "الأنواع الستة للبيانات الرقمية",
      eduDesc: "يتعامل الحاسوب مع أشكال متعددة للمعلومات: <strong>نص</strong>، <strong>أرقام</strong>، <strong>تاريخ ووقت</strong>، <strong>صور</strong>، <strong>صوت</strong> و <strong>فيديو</strong>.",
      trayLabel: "عناصر للتصنيف (حدد أو اسحب وأفلت) :"
    },
    c3: {
      badge: "دورة كاملة",
      title: "أتقن مسار المعلومة في 5 مراحل",
      sub: "شاهد رحلة البيانات، ثم رتب المراحل بالترتيب الزمني الصحيح.",
      eduTitle: "المراحل الخمس الأساسية لمعالجة المعلومات",
      eduDesc: "تتبع كل معلومة هذا المسار الإلزامي: <strong>1. جمع</strong> ➔ <strong>2. تخزين</strong> ➔ <strong>3. معالجة</strong> ➔ <strong>4. نشر</strong> ➔ <strong>5. استخدام</strong>.",
      pipeTitle: "عرض تفاعلي لمسار البيان",
      btnAnim: "بدء المسار",
      orderTitle: "رتب المراحل الخمس بالترتيب الصحيح :"
    },
    c4: {
      badge: "محاكاة واقعية",
      title: "في مكان الحاسوب: صندوق السوبرماركت",
      sub: "امسح المنتجات الثلاثة، احسب المجموع، وأكد دفع الزبون.",
      eduTitle: "حالة واقعية: نظام آلة تسجيل النقود",
      eduDesc: "اكتشف كيف تحدث المراحل الخمس في الحياة اليومية: مسح الرمز الشريطي (<strong>جمع</strong>)، حفظ الأسعار (<strong>تخزين</strong>)، حساب المجموع (<strong>معالجة</strong>)، عرض الفاتورة (<strong>نشر</strong>)، ودفع المشتريات (<strong>استخدام</strong>).",
      btnCalc: "حساب المجموع",
      btnPay: "دفع المشتريات",
      tipScan: "انقر على منتج لتمريره تحت الماسح الضوئي"
    },
    c5: {
      badge: "المهمة الختامية",
      title: "المهمة النهائية: نظام المكتبة المدرسية",
      sub: "اربط كل مهمة إدارية بالمرحلة المناسبة من مراحل المعالجة.",
      eduTitle: "سيناريو تطبيقي: المكتبة المدرسية",
      eduDesc: "يرغب أمين المكتبة في تجديد الكتب الأكثر طلبًا ومتابعة استعارات التلاميذ. بصفتك المحقق الرئيسي، وزع كل عملية على مرحلتها المناسبة.",
      poolTitle: "عمليات المكتبة المدرسية :"
    },
    results: {
      title: "تم إنجاز التحقيق بنجاح باهر !",
      sub: "تهانينا! لقد أتقنت ببراعة دورة معالجة المعلومات بواسطة الحاسوب.",
      btnReplay: "إعادة التحقيق",
      btnFinish: "إنهاء وخروج"
    },
    footer: {
      prev: "التحدي السابق",
      next: "التحدي التالي",
      hint: "تلميح"
    }
  }
};

// ============================================================================
// 2. Data Sets for Challenges
// ============================================================================
const C1_QUIZ_ITEMS = [
  {
    id: "q1",
    fr: { text: "12 / 20", context: "Une note obtenue par un élève" },
    ar: { text: "12 / 20", context: "نقطة حصل عليها تلميذ" },
    type: "donnee", // Raw datum
    icon: "📝"
  },
  {
    id: "q2",
    fr: { text: "Moyenne de la classe : 14,5 / 20", context: "Calculée à partir de toutes les notes" },
    ar: { text: "معدل القسم : 14.5 / 20", context: "محسوب انطلاقًا من جميع النقط" },
    type: "information",
    icon: "📊"
  },
  {
    id: "q3",
    fr: { text: "35°C", context: "Mesure prise par un capteur thermique à midi" },
    ar: { text: "35° مئوية", context: "قياس مسجل بمستشعر حراري عند الزوال" },
    type: "donnee",
    icon: "🌡️"
  },
  {
    id: "q4",
    fr: { text: "Alerte Canicule : Risque Élevé", context: "Message préventif diffusé après analyse météo" },
    ar: { text: "إنذار بموجة حر: خطر مرتفع", context: "رسالة تحذيرية بعد تحليل معطيات الطقس" },
    type: "information",
    icon: "⚠️"
  },
  {
    id: "q5",
    fr: { text: "Code-barres : 6111234567890", context: "Suite de chiffres imprimée sur un cahier" },
    ar: { text: "رمز شريطي : 6111234567890", context: "سلسلة أرقام مطبوعة على دفتر" },
    type: "donnee",
    icon: "🏷️"
  },
  {
    id: "q6",
    fr: { text: "Total du panier : 145 DH (3 articles)", context: "Somme calculée par la caisse" },
    ar: { text: "مجموع السلة : 145 درهم (3 مواد)", context: "مجموع محسوب بواسطة الصندوق" },
    type: "information",
    icon: "🧾"
  }
];

const C2_ITEMS = [
  { id: "c2-1", type: "texte", labelFr: "Mouad", labelAr: "معاذ", icon: "👤" },
  { id: "c2-2", type: "texte", labelFr: "Notice d'utilisation", labelAr: "دليل الاستعمال", icon: "📄" },
  { id: "c2-3", type: "numerique", labelFr: "15", labelAr: "15", icon: "🔢" },
  { id: "c2-4", type: "numerique", labelFr: "3.14", labelAr: "3.14", icon: "📐" },
  { id: "c2-5", type: "date", labelFr: "30/10/2026", labelAr: "30/10/2026", icon: "📅" },
  { id: "c2-6", type: "date", labelFr: "14:30:00", labelAr: "14:30:00", icon: "⏰" },
  { id: "c2-7", type: "image", labelFr: "Photo de classe", labelAr: "صورة القسم", icon: "📸" },
  { id: "c2-8", type: "image", labelFr: "Logo du collège", labelAr: "شعار الإعدادية", icon: "🎨" },
  { id: "c2-9", type: "son", labelFr: "Enregistrement vocal", labelAr: "تسجيل صوتي", icon: "🎙️" },
  { id: "c2-10", type: "son", labelFr: "Sonnerie de fin de cours", labelAr: "جرس نهاية الحصة", icon: "🔔" },
  { id: "c2-11", type: "video", labelFr: "Résumé du match de foot", labelAr: "ملخص مباراة كرة قدم", icon: "⚽" },
  { id: "c2-12", type: "video", labelFr: "Tutoriel vidéo informatique", labelAr: "فيديو تعليمي في المعلوميات", icon: "💻" }
];

const C3_STAGES = [
  { step: 1, nameFr: "Collecter", nameAr: "جمع", descFr: "Saisir ou capter la donnée", descAr: "إدخال أو التقاط البيان", icon: "📥" },
  { step: 2, nameFr: "Stocker", nameAr: "تخزين", descFr: "Sauvegarder en mémoire", descAr: "حفظ في الذاكرة", icon: "💾" },
  { step: 3, nameFr: "Traiter", nameAr: "معالجة", descFr: "Calculer et transformer", descAr: "حساب وتحويل البيانات", icon: "⚙️" },
  { step: 4, nameFr: "Diffuser", nameAr: "نشر", descFr: "Présenter le résultat", descAr: "عرض وتقديم النتيجة", icon: "📢" },
  { step: 5, nameFr: "Utiliser", nameAr: "استخدام", descFr: "Prendre une décision", descAr: "اتخاذ قرار أو تصرف", icon: "🎯" }
];

const C5_LIBRARY_TASKS = [
  {
    id: "lib-1",
    stage: 1,
    titleFr: "Scanner le code-barres de la carte de l'élève",
    titleAr: "مسح الرمز الشريطي لبطاقة التلميذ",
    icon: "🏷️"
  },
  {
    id: "lib-2",
    stage: 2,
    titleFr: "Sauvegarder l'emprunt dans la base de données",
    titleAr: "حفظ عملية الاستعارة في قاعدة البيانات",
    icon: "💾"
  },
  {
    id: "lib-3",
    stage: 3,
    titleFr: "Calculer le classement des 5 livres les plus demandés",
    titleAr: "حساب ترتيب الكتب الـ5 الأكثر طلباً",
    icon: "⚙️"
  },
  {
    id: "lib-4",
    stage: 4,
    titleFr: "Afficher le palmarès des lectures préférées au CDI",
    titleAr: "نشر قائمة القراءات المفضلة في لوحة الإعلانات",
    icon: "📢"
  },
  {
    id: "lib-5",
    stage: 5,
    titleFr: "Acheter 20 exemplaires du roman le plus populaire",
    titleAr: "شراء 20 نسخة إضافية من الرواية الأكثر شعبية",
    icon: "🛒"
  }
];

// ============================================================================
// 3. Game Engine & State Management
// ============================================================================
class DataDetectiveEngine {
  constructor() {
    this.currentLanguage = 'fr';
    this.currentChallenge = 0; // 0 = welcome screen, 1-5 = challenges, 6 = results
    this.unlockedChallenge = 1;
    this.score = 0;
    this.startTime = Date.now();
    this.isReducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Challenge specific states
    this.c1Answers = {};
    this.c2Placed = {};
    this.c2SelectedCardId = null;
    this.c3Slots = { 1: null, 2: null, 3: null, 4: null, 5: null };
    this.c3SelectedPill = null;
    this.c4Scanned = { pain: false, lait: false, jus: false };
    this.c4Calculated = false;
    this.c4Paid = false;
    this.c5Assignments = { 1: null, 2: null, 3: null, 4: null, 5: null };
    this.c5SelectedTask = null;

    // Student identification & persistence
    this.studentId = 'guest';
    this.initSession();
    this.bindEvents();
    this.renderLanguage();
    this.checkSavedState();
  }

  initSession() {
    try {
      if (window.teachit && window.teachit.sessionInfo && window.teachit.sessionInfo.studentId) {
        this.studentId = window.teachit.sessionInfo.studentId;
      }
    } catch {
      this.studentId = 'guest';
    }
    const studentBadge = document.getElementById('session-student-id');
    if (studentBadge) {
      studentBadge.textContent = this.studentId.substring(0, 8);
    }
  }

  getStorageKey() {
    return `teachit_data_detective_${this.studentId}`;
  }

  saveToStorage() {
    try {
      const state = {
        unlockedChallenge: this.unlockedChallenge,
        currentChallenge: this.currentChallenge,
        score: this.score,
        c1Answers: this.c1Answers,
        c2Placed: this.c2Placed,
        c3Slots: this.c3Slots,
        c4Scanned: this.c4Scanned,
        c4Calculated: this.c4Calculated,
        c4Paid: this.c4Paid,
        c5Assignments: this.c5Assignments,
        timestamp: Date.now()
      };
      localStorage.setItem(this.getStorageKey(), JSON.stringify(state));
      this.reportTeachITProgress();
    } catch {
      // Ignore quota errors in restricted test environments
    }
  }

  loadFromStorage() {
    try {
      const raw = localStorage.getItem(this.getStorageKey());
      if (!raw) return false;
      const state = JSON.parse(raw);
      this.unlockedChallenge = state.unlockedChallenge || 1;
      this.score = state.score || 0;
      this.c1Answers = state.c1Answers || {};
      this.c2Placed = state.c2Placed || {};
      this.c3Slots = state.c3Slots || { 1: null, 2: null, 3: null, 4: null, 5: null };
      this.c4Scanned = state.c4Scanned || { pain: false, lait: false, jus: false };
      this.c4Calculated = !!state.c4Calculated;
      this.c4Paid = !!state.c4Paid;
      this.c5Assignments = state.c5Assignments || { 1: null, 2: null, 3: null, 4: null, 5: null };
      return true;
    } catch {
      return false;
    }
  }

  hasSavedProgress() {
    try {
      return !!localStorage.getItem(this.getStorageKey());
    } catch {
      return false;
    }
  }

  resetAllProgress() {
    try {
      localStorage.removeItem(this.getStorageKey());
    } catch {
      // ignore
    }
    this.unlockedChallenge = 1;
    this.score = 0;
    this.c1Answers = {};
    this.c2Placed = {};
    this.c3Slots = { 1: null, 2: null, 3: null, 4: null, 5: null };
    this.c4Scanned = { pain: false, lait: false, jus: false };
    this.c4Calculated = false;
    this.c4Paid = false;
    this.c5Assignments = { 1: null, 2: null, 3: null, 4: null, 5: null };
    this.goToScreen(1);
    this.updateNavigationUI();
  }

  reportTeachITProgress() {
    if (window.teachit) {
      const percent = Math.min(100, Math.round((Math.max(1, this.unlockedChallenge - 1) / 5) * 100));
      const payload = {
        gameId: 'data-detective',
        studentId: this.studentId,
        score: this.score,
        completed: this.unlockedChallenge > 5,
        progressPercent: percent,
        details: {
          unlockedChallenge: this.unlockedChallenge,
          challengesCompleted: Math.max(0, this.unlockedChallenge - 1)
        }
      };

      if (typeof window.teachit.recordProgress === 'function') {
        window.teachit.recordProgress(payload).catch(() => {});
      } else if (typeof window.teachit.reportProgress === 'function') {
        window.teachit.reportProgress(payload).catch(() => {});
      }
    }
  }

  checkSavedState() {
    const hasSaved = this.hasSavedProgress();
    const btnResume = document.getElementById('btn-resume-game');
    const btnReset = document.getElementById('btn-reset-saved');
    if (btnResume && btnReset) {
      if (hasSaved) {
        btnResume.style.display = 'inline-flex';
        btnReset.style.display = 'inline-flex';
      } else {
        btnResume.style.display = 'none';
        btnReset.style.display = 'none';
      }
    }
  }

  // ==========================================================================
  // 4. UI Rendering & Screen Navigation
  // ==========================================================================
  bindEvents() {
    // Language Toggle
    const btnLang = document.getElementById('lang-toggle-btn');
    if (btnLang) {
      btnLang.addEventListener('click', () => {
        this.currentLanguage = this.currentLanguage === 'fr' ? 'ar' : 'fr';
        this.renderLanguage();
      });
    }

    // Quit button
    const btnQuit = document.getElementById('btn-quit');
    if (btnQuit) {
      btnQuit.addEventListener('click', () => {
        if (window.teachit && typeof window.teachit.exitGame === 'function') {
          window.teachit.exitGame();
        } else {
          window.close();
        }
      });
    }

    // Start / Resume / Reset
    const btnStart = document.getElementById('btn-start-game');
    if (btnStart) {
      btnStart.addEventListener('click', () => {
        this.goToScreen(1);
      });
    }

    const btnResume = document.getElementById('btn-resume-game');
    if (btnResume) {
      btnResume.addEventListener('click', () => {
        this.loadFromStorage();
        this.goToScreen(this.unlockedChallenge > 5 ? 5 : this.unlockedChallenge);
      });
    }

    const btnReset = document.getElementById('btn-reset-saved');
    if (btnReset) {
      btnReset.addEventListener('click', () => {
        this.resetAllProgress();
      });
    }

    // Header Challenge Tabs
    for (let i = 1; i <= 5; i++) {
      const tab = document.getElementById(`tab-c${i}`);
      if (tab) {
        tab.addEventListener('click', () => {
          if (i <= this.unlockedChallenge) {
            this.goToScreen(i);
          }
        });
      }
    }

    // Footer Prev / Next / Hint
    const btnPrev = document.getElementById('btn-prev-challenge');
    if (btnPrev) {
      btnPrev.addEventListener('click', () => {
        if (this.currentChallenge > 1) {
          this.goToScreen(this.currentChallenge - 1);
        }
      });
    }

    const btnNext = document.getElementById('btn-next-challenge');
    if (btnNext) {
      btnNext.addEventListener('click', () => {
        if (this.currentChallenge < this.unlockedChallenge && this.currentChallenge < 5) {
          this.goToScreen(this.currentChallenge + 1);
        } else if (this.currentChallenge === 5 && this.unlockedChallenge > 5) {
          this.goToScreen(6); // Results screen
        }
      });
    }

    const btnHint = document.getElementById('btn-hint');
    if (btnHint) {
      btnHint.addEventListener('click', () => {
        const hintKey = `c${this.currentChallenge}`;
        const hintText = TRANSLATIONS[this.currentLanguage].hints[hintKey] || "Explore les options interactives !";
        this.showToast(hintText, "info");
      });
    }

    // Results screen actions
    const btnReplay = document.getElementById('btn-replay');
    if (btnReplay) {
      btnReplay.addEventListener('click', () => {
        this.resetAllProgress();
      });
    }

    const btnFinish = document.getElementById('btn-finish-quit');
    if (btnFinish) {
      btnFinish.addEventListener('click', () => {
        if (window.teachit && typeof window.teachit.exitGame === 'function') {
          window.teachit.exitGame();
        } else {
          this.goToScreen(0);
        }
      });
    }

    // Bind Challenge specific events
    this.bindChallenge1Events();
    this.bindChallenge2Events();
    this.bindChallenge3Events();
    this.bindChallenge4Events();
    this.bindChallenge5Events();
  }

  goToScreen(num) {
    this.currentChallenge = num;
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));

    if (num === 0) {
      document.getElementById('screen-welcome')?.classList.add('active');
    } else if (num >= 1 && num <= 5) {
      document.getElementById(`screen-c${num}`)?.classList.add('active');
      this.setupChallenge(num);
    } else if (num === 6) {
      document.getElementById('screen-results')?.classList.add('active');
      this.renderResults();
    }

    this.updateNavigationUI();
    this.saveToStorage();
  }

  updateNavigationUI() {
    const isWelcome = this.currentChallenge === 0;
    const isResults = this.currentChallenge === 6;

    // Tabs update
    for (let i = 1; i <= 5; i++) {
      const tab = document.getElementById(`tab-c${i}`);
      if (!tab) continue;
      tab.classList.remove('active', 'completed', 'locked');

      if (i === this.currentChallenge) {
        tab.classList.add('active');
      } else if (i < this.unlockedChallenge) {
        tab.classList.add('completed');
      } else if (i > this.unlockedChallenge) {
        tab.classList.add('locked');
      }
    }

    // Footer buttons
    const btnPrev = document.getElementById('btn-prev-challenge');
    const btnNext = document.getElementById('btn-next-challenge');
    if (btnPrev) {
      btnPrev.disabled = isWelcome || this.currentChallenge <= 1;
    }
    if (btnNext) {
      btnNext.disabled = isWelcome || isResults || (this.currentChallenge >= this.unlockedChallenge && this.unlockedChallenge <= 5);
    }

    // Score displays
    for (let i = 1; i <= 5; i++) {
      const sc = document.getElementById(`score-val-${i}`);
      if (sc) sc.textContent = this.score;
    }
  }

  renderLanguage() {
    const lang = this.currentLanguage;
    const t = TRANSLATIONS[lang];
    const isArabic = lang === 'ar';

    document.documentElement.lang = lang;
    document.documentElement.dir = isArabic ? 'rtl' : 'ltr';

    const langText = document.getElementById('lang-text');
    if (langText) langText.textContent = isArabic ? 'Français' : 'العربية';

    // Header labels
    const brandTitle = document.getElementById('header-brand-title');
    if (brandTitle) brandTitle.textContent = isArabic ? "محقق البيانات" : "Data Detective";

    const offTag = document.getElementById('header-tag-offline');
    if (offTag) offTag.textContent = t.offlineMode;

    const catTag = document.getElementById('header-tag-category');
    if (catTag) catTag.textContent = t.categoryTag;

    const stLbl = document.getElementById('lbl-student');
    if (stLbl) stLbl.textContent = t.studentLabel;

    const quitText = document.getElementById('btn-quit-text');
    if (quitText) quitText.textContent = t.quit;

    // Tabs labels
    for (let i = 0; i < 5; i++) {
      const tabLbl = document.getElementById(`tab-label-${i + 1}`);
      if (tabLbl) tabLbl.textContent = t.tabs[i];
    }

    // Welcome screen
    const wTitle = document.getElementById('welcome-title');
    if (wTitle) wTitle.textContent = t.welcome.title;
    const wSub = document.getElementById('welcome-sub');
    if (wSub) wSub.textContent = t.welcome.sub;
    const bStart = document.getElementById('btn-start-text');
    if (bStart) bStart.textContent = t.welcome.start;
    const bResume = document.getElementById('btn-resume-text');
    if (bResume) bResume.textContent = t.welcome.resume;
    const bReset = document.getElementById('btn-reset-text');
    if (bReset) bReset.textContent = t.welcome.reset;

    // Challenge 1 text
    const c1Step = document.getElementById('c1-step-badge');
    if (c1Step) c1Step.textContent = t.c1.badge;
    const c1Title = document.getElementById('c1-inst-title');
    if (c1Title) c1Title.textContent = t.c1.title;
    const c1Sub = document.getElementById('c1-inst-sub');
    if (c1Sub) c1Sub.textContent = t.c1.sub;
    const c1EduT = document.getElementById('c1-edu-title');
    if (c1EduT) c1EduT.textContent = t.c1.eduTitle;
    const c1EduD = document.getElementById('c1-edu-desc');
    if (c1EduD) c1EduD.innerHTML = t.c1.eduDesc;
    const c1AnimH = document.getElementById('c1-anim-header');
    if (c1AnimH) c1AnimH.textContent = t.c1.animHeader;
    const bC1Anim = document.getElementById('btn-calc-anim-text');
    if (bC1Anim) bC1Anim.textContent = t.c1.btnAnim;
    const c1ConvLbl = document.getElementById('c1-conveyor-lbl');
    if (c1ConvLbl) c1ConvLbl.textContent = t.c1.conveyor;
    const c1MachLbl = document.getElementById('c1-machine-lbl');
    if (c1MachLbl) c1MachLbl.textContent = t.c1.machine;
    const c1QuizT = document.getElementById('c1-quiz-title');
    if (c1QuizT) c1QuizT.textContent = t.c1.quizTitle;

    // Challenge 2 text
    const c2Step = document.getElementById('c2-step-badge');
    if (c2Step) c2Step.textContent = t.c2.badge;
    const c2Title = document.getElementById('c2-inst-title');
    if (c2Title) c2Title.textContent = t.c2.title;
    const c2Sub = document.getElementById('c2-inst-sub');
    if (c2Sub) c2Sub.textContent = t.c2.sub;
    const c2EduT = document.getElementById('c2-edu-title');
    if (c2EduT) c2EduT.textContent = t.c2.eduTitle;
    const c2EduD = document.getElementById('c2-edu-desc');
    if (c2EduD) c2EduD.innerHTML = t.c2.eduDesc;
    const c2TrayLbl = document.getElementById('c2-tray-lbl');
    if (c2TrayLbl) c2TrayLbl.textContent = t.c2.trayLabel;

    // Challenge 3 text
    const c3Step = document.getElementById('c3-step-badge');
    if (c3Step) c3Step.textContent = t.c3.badge;
    const c3Title = document.getElementById('c3-inst-title');
    if (c3Title) c3Title.textContent = t.c3.title;
    const c3Sub = document.getElementById('c3-inst-sub');
    if (c3Sub) c3Sub.textContent = t.c3.sub;
    const c3EduT = document.getElementById('c3-edu-title');
    if (c3EduT) c3EduT.textContent = t.c3.eduTitle;
    const c3EduD = document.getElementById('c3-edu-desc');
    if (c3EduD) c3EduD.innerHTML = t.c3.eduDesc;
    const c3PipeT = document.getElementById('c3-pipe-title');
    if (c3PipeT) c3PipeT.textContent = t.c3.pipeTitle;
    const bC3Anim = document.getElementById('btn-pipe-anim-text');
    if (bC3Anim) bC3Anim.textContent = t.c3.btnAnim;
    const c3OrdT = document.getElementById('c3-order-title');
    if (c3OrdT) c3OrdT.textContent = t.c3.orderTitle;

    // Challenge 4 text
    const c4Step = document.getElementById('c4-step-badge');
    if (c4Step) c4Step.textContent = t.c4.badge;
    const c4Title = document.getElementById('c4-inst-title');
    if (c4Title) c4Title.textContent = t.c4.title;
    const c4Sub = document.getElementById('c4-inst-sub');
    if (c4Sub) c4Sub.textContent = t.c4.sub;
    const c4EduT = document.getElementById('c4-edu-title');
    if (c4EduT) c4EduT.textContent = t.c4.eduTitle;
    const c4EduD = document.getElementById('c4-edu-desc');
    if (c4EduD) c4EduD.innerHTML = t.c4.eduDesc;
    const bC4Calc = document.getElementById('btn-c4-calc-lbl');
    if (bC4Calc) bC4Calc.textContent = t.c4.btnCalc;
    const bC4Pay = document.getElementById('btn-c4-pay-lbl');
    if (bC4Pay) bC4Pay.textContent = t.c4.btnPay;
    const c4Tip = document.getElementById('c4-scan-tip');
    if (c4Tip) c4Tip.textContent = t.c4.tipScan;

    // Challenge 5 text
    const c5Step = document.getElementById('c5-step-badge');
    if (c5Step) c5Step.textContent = t.c5.badge;
    const c5Title = document.getElementById('c5-inst-title');
    if (c5Title) c5Title.textContent = t.c5.title;
    const c5Sub = document.getElementById('c5-inst-sub');
    if (c5Sub) c5Sub.textContent = t.c5.sub;
    const c5EduT = document.getElementById('c5-edu-title');
    if (c5EduT) c5EduT.textContent = t.c5.eduTitle;
    const c5EduD = document.getElementById('c5-edu-desc');
    if (c5EduD) c5EduD.innerHTML = t.c5.eduDesc;
    const c5PoolT = document.getElementById('c5-pool-title');
    if (c5PoolT) c5PoolT.textContent = t.c5.poolTitle;

    // Footer buttons
    const fPrev = document.getElementById('btn-prev-lbl');
    if (fPrev) fPrev.textContent = t.footer.prev;
    const fNext = document.getElementById('btn-next-lbl');
    if (fNext) fNext.textContent = t.footer.next;
    const fHint = document.getElementById('btn-hint-lbl');
    if (fHint) fHint.textContent = t.footer.hint;

    // Re-render dynamic active challenge content
    if (this.currentChallenge >= 1 && this.currentChallenge <= 5) {
      this.setupChallenge(this.currentChallenge);
    }
  }

  showToast(message, type = 'info') {
    const existing = document.querySelector('.feedback-banner');
    if (existing) existing.remove();

    const banner = document.createElement('div');
    banner.className = `feedback-banner ${type}`;
    banner.innerHTML = `
      <span style="font-size: 1.2rem;">${type === 'success' ? '✅' : type === 'error' ? '❌' : 'ℹ️'}</span>
      <span class="feedback-text">${message}</span>
    `;

    const activeScreen = document.querySelector('.screen.active');
    if (activeScreen) {
      activeScreen.insertBefore(banner, activeScreen.querySelector('.challenge-workspace') || activeScreen.firstChild);
      setTimeout(() => banner.remove(), 4000);
    }
  }

  setupChallenge(num) {
    switch (num) {
      case 1: this.renderChallenge1(); break;
      case 2: this.renderChallenge2(); break;
      case 3: this.renderChallenge3(); break;
      case 4: this.renderChallenge4(); break;
      case 5: this.renderChallenge5(); break;
    }
  }

  // ==========================================================================
  // 5. Challenge 1: Data vs Information & Calculator Animation
  // ==========================================================================
  bindChallenge1Events() {
    const btnAnim = document.getElementById('btn-run-calc-anim');
    if (btnAnim) {
      btnAnim.addEventListener('click', () => {
        this.runCalculatorAnimation();
      });
    }
  }

  runCalculatorAnimation() {
    const lang = this.currentLanguage;
    const t = TRANSLATIONS[lang].c1;
    const chips = document.querySelectorAll('#c1-raw-chips .data-chip');
    const gears = document.getElementById('c1-gears');
    const screen = document.getElementById('c1-machine-screen');
    const outVal = document.getElementById('c1-out-val');
    const outDesc = document.getElementById('c1-out-desc');

    if (!gears || !screen || !outVal || !outDesc) return;

    if (this.isReducedMotion) {
      screen.textContent = t.screenDone;
      outVal.textContent = t.outputVal;
      outDesc.textContent = t.outputDesc;
      return;
    }

    gears.classList.add('active');
    screen.textContent = t.screenProc;

    // Sequential chip animation
    chips.forEach((chip, idx) => {
      setTimeout(() => {
        chip.classList.add('flying');
      }, idx * 250);
    });

    setTimeout(() => {
      gears.classList.remove('active');
      screen.textContent = t.screenDone;
      outVal.textContent = t.outputVal;
      outDesc.textContent = t.outputDesc;
      chips.forEach(chip => chip.classList.remove('flying'));
      this.showToast(lang === 'ar' ? "تم التحويل بنجاح! تحولت النقط إلى معدل ذي دلالة." : "Traitement réussi ! Les notes brutes ont donné une moyenne signifiante.", "success");
    }, 1600);
  }

  renderChallenge1() {
    const container = document.getElementById('c1-cards-container');
    if (!container) return;
    container.innerHTML = '';
    const lang = this.currentLanguage;

    C1_QUIZ_ITEMS.forEach(item => {
      const card = document.createElement('div');
      card.className = 'c1-quiz-card';
      const text = item[lang].text;
      const context = item[lang].context;
      const currentChoice = this.c1Answers[item.id];

      card.innerHTML = `
        <div class="c1-item-content">
          <span class="c1-item-icon" aria-hidden="true">${item.icon}</span>
          <div>
            <div class="c1-item-title">${text}</div>
            <div class="c1-item-context">${context}</div>
          </div>
        </div>
        <div class="c1-choices-row">
          <button type="button" class="c1-choice-btn ${currentChoice === 'donnee' ? 'selected-donnee' : ''}" data-choice="donnee">
            ${lang === 'ar' ? 'بيان خام' : 'Donnée brute'}
          </button>
          <button type="button" class="c1-choice-btn ${currentChoice === 'information' ? 'selected-info' : ''}" data-choice="information">
            ${lang === 'ar' ? 'معلومة مفيدة' : 'Information utile'}
          </button>
        </div>
      `;

      card.querySelectorAll('.c1-choice-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const choice = e.currentTarget.getAttribute('data-choice');
          this.c1Answers[item.id] = choice;

          // Check correctness
          const isCorrect = choice === item.type;
          if (isCorrect) {
            e.currentTarget.classList.add('correct');
            this.score += 5;
          } else {
            e.currentTarget.classList.add('wrong');
          }

          this.renderChallenge1();
          this.checkChallenge1Completion();
          this.saveToStorage();
        });
      });

      container.appendChild(card);
    });
  }

  checkChallenge1Completion() {
    const allAnswered = C1_QUIZ_ITEMS.every(i => this.c1Answers[i.id]);
    const allCorrect = C1_QUIZ_ITEMS.every(i => this.c1Answers[i.id] === i.type);

    if (allAnswered && allCorrect) {
      if (this.unlockedChallenge <= 1) {
        this.unlockedChallenge = 2;
        this.score += 20;
        this.showToast(this.currentLanguage === 'ar' ? "أحسنت! أكملت التحدي الأول وتم فتح التحدي الثاني." : "Bravo ! Défi 1 réussi, Défi 2 débloqué !", "success");
      }
      this.updateNavigationUI();
      this.saveToStorage();
    }
  }

  // ==========================================================================
  // 6. Challenge 2: 6 Data Types Classification
  // ==========================================================================
  bindChallenge2Events() {
    const buckets = document.querySelectorAll('.type-bucket');
    buckets.forEach(bucket => {
      const type = bucket.getAttribute('data-type');

      // Drag & drop support
      bucket.addEventListener('dragover', (e) => {
        e.preventDefault();
        bucket.classList.add('drag-over');
      });
      bucket.addEventListener('dragleave', () => {
        bucket.classList.remove('drag-over');
      });
      bucket.addEventListener('drop', (e) => {
        e.preventDefault();
        bucket.classList.remove('drag-over');
        const cardId = e.dataTransfer.getData('text/plain');
        this.assignC2Item(cardId, type);
      });

      // Click-to-assign fallback (for accessibility and touch)
      bucket.addEventListener('click', () => {
        if (this.c2SelectedCardId) {
          this.assignC2Item(this.c2SelectedCardId, type);
          this.c2SelectedCardId = null;
          document.querySelectorAll('.draggable-data-card').forEach(c => c.classList.remove('is-dragging'));
        }
      });
    });
  }

  assignC2Item(cardId, targetType) {
    const item = C2_ITEMS.find(it => it.id === cardId);
    if (!item) return;

    if (item.type === targetType) {
      this.c2Placed[cardId] = targetType;
      this.score += 5;
      this.showToast(this.currentLanguage === 'ar' ? `تصنيف صحيح: ${item.labelAr}` : `Correct : ${item.labelFr}`, "success");
    } else {
      this.showToast(this.currentLanguage === 'ar' ? `خطأ: هذا العنصر ليس من نوع ${targetType}` : `Erreur : Cet élément n'est pas de type ${targetType}`, "error");
    }

    this.renderChallenge2();
    this.checkChallenge2Completion();
    this.saveToStorage();
  }

  renderChallenge2() {
    const tray = document.getElementById('c2-source-tray');
    if (!tray) return;
    tray.innerHTML = '';
    const lang = this.currentLanguage;

    // Reset buckets dropzones & counts
    ['texte', 'numerique', 'date', 'image', 'son', 'video'].forEach(type => {
      const dropzone = document.getElementById(`drop-${type}`);
      const countEl = document.getElementById(`count-${type}`);
      if (dropzone) dropzone.innerHTML = '';
      if (countEl) countEl.textContent = '0/2';
    });

    const bucketCounts = { texte: 0, numerique: 0, date: 0, image: 0, son: 0, video: 0 };

    C2_ITEMS.forEach(item => {
      const placedType = this.c2Placed[item.id];
      const label = lang === 'ar' ? item.labelAr : item.labelFr;

      if (placedType) {
        bucketCounts[placedType] = (bucketCounts[placedType] || 0) + 1;
        const dropzone = document.getElementById(`drop-${placedType}`);
        if (dropzone) {
          const placedTag = document.createElement('span');
          placedTag.className = 'draggable-data-card placed';
          placedTag.innerHTML = `<span>${item.icon}</span> <span>${label}</span>`;
          dropzone.appendChild(placedTag);
        }
      } else {
        // Render in source tray
        const card = document.createElement('div');
        card.className = `draggable-data-card ${this.c2SelectedCardId === item.id ? 'is-dragging' : ''}`;
        card.setAttribute('draggable', 'true');
        card.setAttribute('data-id', item.id);
        card.innerHTML = `<span>${item.icon}</span> <span>${label}</span>`;

        card.addEventListener('dragstart', (e) => {
          e.dataTransfer.setData('text/plain', item.id);
          card.classList.add('is-dragging');
        });
        card.addEventListener('dragend', () => {
          card.classList.remove('is-dragging');
        });

        // Click-select fallback
        card.addEventListener('click', () => {
          if (this.c2SelectedCardId === item.id) {
            this.c2SelectedCardId = null;
            card.classList.remove('is-dragging');
          } else {
            this.c2SelectedCardId = item.id;
            document.querySelectorAll('.draggable-data-card').forEach(c => c.classList.remove('is-dragging'));
            card.classList.add('is-dragging');
            this.showToast(lang === 'ar' ? "انقر الآن على الفئة المناسبة لوضعه فيها" : "Clique maintenant sur la catégorie cible pour le ranger", "info");
          }
        });

        tray.appendChild(card);
      }
    });

    // Update counts
    Object.keys(bucketCounts).forEach(type => {
      const countEl = document.getElementById(`count-${type}`);
      if (countEl) countEl.textContent = `${bucketCounts[type]}/2`;
    });
  }

  checkChallenge2Completion() {
    const totalPlaced = Object.keys(this.c2Placed).length;
    if (totalPlaced >= C2_ITEMS.length) {
      if (this.unlockedChallenge <= 2) {
        this.unlockedChallenge = 3;
        this.score += 25;
        this.showToast(this.currentLanguage === 'ar' ? "رائع! لقد ميزت جميع أنواع البيانات. التحدي الثالث مفتوح." : "Superbe ! Tous les types de données sont maîtrisés. Défi 3 débloqué !", "success");
      }
      this.updateNavigationUI();
      this.saveToStorage();
    }
  }

  // ==========================================================================
  // 7. Challenge 3: 5-Stage Pipeline Journey & Ordering
  // ==========================================================================
  bindChallenge3Events() {
    const btnReplay = document.getElementById('btn-replay-pipeline');
    if (btnReplay) {
      btnReplay.addEventListener('click', () => {
        this.runPipelineAnimation();
      });
    }

    // Slots click/drop listeners
    for (let slot = 1; slot <= 5; slot++) {
      const slotEl = document.querySelector(`.order-slot[data-slot="${slot}"]`);
      if (slotEl) {
        slotEl.addEventListener('click', () => {
          if (this.c3SelectedPill !== null) {
            this.assignC3Slot(slot, this.c3SelectedPill);
            this.c3SelectedPill = null;
          }
        });
      }
    }
  }

  runPipelineAnimation() {
    const packet = document.getElementById('anim-data-packet');
    if (!packet) return;
    const stations = [1, 2, 3, 4, 5];
    const positions = ['8%', '28%', '48%', '68%', '88%'];

    packet.style.opacity = '1';

    stations.forEach((st, idx) => {
      setTimeout(() => {
        const node = document.getElementById(`st-node-${st}`);
        document.querySelectorAll('.pipeline-station-node').forEach(n => n.classList.remove('active-stage'));
        if (node) node.classList.add('active-stage');
        packet.style.left = positions[idx];
      }, idx * 700);
    });

    setTimeout(() => {
      document.querySelectorAll('.pipeline-station-node').forEach(n => n.classList.remove('active-stage'));
      packet.style.opacity = '0';
      packet.style.left = '8%';
      this.showToast(this.currentLanguage === 'ar' ? "اكتملت الدورة: جمع ➔ تخزين ➔ معالجة ➔ نشر ➔ استخدام" : "Cycle terminé : Collecter ➔ Stocker ➔ Traiter ➔ Diffuser ➔ Utiliser", "success");
    }, stations.length * 700 + 400);
  }

  assignC3Slot(slotNum, stageStep) {
    // Check if stageStep is already placed in another slot
    for (let s = 1; s <= 5; s++) {
      if (this.c3Slots[s] === stageStep) {
        this.c3Slots[s] = null;
      }
    }

    this.c3Slots[slotNum] = stageStep;
    this.renderChallenge3();
    this.checkChallenge3Completion();
    this.saveToStorage();
  }

  renderChallenge3() {
    const lang = this.currentLanguage;
    const pool = document.getElementById('c3-pool-pills');
    if (!pool) return;
    pool.innerHTML = '';

    // Render slots
    for (let s = 1; s <= 5; s++) {
      const slotContent = document.getElementById(`slot-${s}-content`);
      const slotEl = document.querySelector(`.order-slot[data-slot="${s}"]`);
      const placedStageStep = this.c3Slots[s];

      if (slotContent && slotEl) {
        slotContent.innerHTML = '';
        if (placedStageStep) {
          const stageInfo = C3_STAGES.find(st => st.step === placedStageStep);
          slotEl.classList.add('filled');
          const pill = document.createElement('div');
          pill.className = 'order-draggable-pill';
          pill.style.cursor = 'pointer';
          const name = lang === 'ar' ? stageInfo.nameAr : stageInfo.nameFr;
          pill.innerHTML = `<span>${stageInfo.icon}</span> <strong>${name}</strong>`;
          pill.addEventListener('click', (e) => {
            e.stopPropagation();
            this.c3Slots[s] = null;
            this.renderChallenge3();
            this.saveToStorage();
          });
          slotContent.appendChild(pill);
        } else {
          slotEl.classList.remove('filled');
        }
      }
    }

    // Render pool pills for unplaced stages
    const placedValues = Object.values(this.c3Slots);
    const unplacedStages = C3_STAGES.filter(st => !placedValues.includes(st.step));

    unplacedStages.forEach(st => {
      const pill = document.createElement('div');
      pill.className = `order-draggable-pill ${this.c3SelectedPill === st.step ? 'selected' : ''}`;
      const name = lang === 'ar' ? st.nameAr : st.nameFr;
      pill.innerHTML = `<span>${st.icon}</span> <strong>${name}</strong>`;

      pill.addEventListener('click', () => {
        if (this.c3SelectedPill === st.step) {
          this.c3SelectedPill = null;
          pill.classList.remove('selected');
        } else {
          this.c3SelectedPill = st.step;
          document.querySelectorAll('.order-draggable-pill').forEach(p => p.classList.remove('selected'));
          pill.classList.add('selected');
          this.showToast(lang === 'ar' ? "اختر الآن رقم الترتيب لوضعه فيه" : "Clique sur l'étape 1, 2, 3, 4 ou 5 pour placer cette phase", "info");
        }
      });

      pool.appendChild(pill);
    });
  }

  checkChallenge3Completion() {
    const isFull = Object.values(this.c3Slots).every(val => val !== null);
    if (!isFull) return;

    const isCorrect = this.c3Slots[1] === 1 &&
                      this.c3Slots[2] === 2 &&
                      this.c3Slots[3] === 3 &&
                      this.c3Slots[4] === 4 &&
                      this.c3Slots[5] === 5;

    if (isCorrect) {
      if (this.unlockedChallenge <= 3) {
        this.unlockedChallenge = 4;
        this.score += 25;
        this.showToast(this.currentLanguage === 'ar' ? "ترتيب مثالي! تم فتح التحدي الرابع (السوبرماركت)." : "Ordre parfait ! Le Défi 4 (Supermarché) est débloqué.", "success");
      }
      this.updateNavigationUI();
      this.saveToStorage();
    } else {
      this.showToast(this.currentLanguage === 'ar' ? "الترتيب غير صحيح، تذكر: جمع ➔ تخزين ➔ معالجة ➔ نشر ➔ استخدام" : "Ordre incorrect. Rappel : Collecter ➔ Stocker ➔ Traiter ➔ Diffuser ➔ Utiliser", "error");
    }
  }

  // ==========================================================================
  // 8. Challenge 4: Supermarket Cash Register Simulation
  // ==========================================================================
  bindChallenge4Events() {
    const conveyor = document.getElementById('c4-products-conveyor');
    if (conveyor) {
      conveyor.querySelectorAll('.product-item-card').forEach(card => {
        card.addEventListener('click', () => {
          const prodKey = card.getAttribute('data-prod');
          this.scanProduct(prodKey, card);
        });
      });
    }

    const btnCalc = document.getElementById('btn-c4-calculate');
    if (btnCalc) {
      btnCalc.addEventListener('click', () => {
        this.calculateSupermarketTotal();
      });
    }

    const btnPay = document.getElementById('btn-c4-pay');
    if (btnPay) {
      btnPay.addEventListener('click', () => {
        this.paySupermarketTotal();
      });
    }
  }

  scanProduct(prodKey, cardEl) {
    if (this.c4Scanned[prodKey]) return;

    const laser = document.getElementById('c4-laser');
    if (laser) {
      laser.classList.add('active');
      setTimeout(() => laser.classList.remove('active'), 500);
    }

    this.c4Scanned[prodKey] = true;
    cardEl.classList.add('scanned');

    this.renderChallenge4();

    // Check if all products scanned
    const allScanned = Object.values(this.c4Scanned).every(v => v);
    if (allScanned) {
      const btnCalc = document.getElementById('btn-c4-calculate');
      if (btnCalc) btnCalc.disabled = false;

      // Update timeline step 1 and 2
      this.setTimelineStep(1, 'done');
      this.setTimelineStep(2, 'done');
      this.setTimelineStep(3, 'active');
      this.showToast(this.currentLanguage === 'ar' ? "تم مسح وحفظ المواد في الذاكرة. انقر على حساب المجموع الآن." : "Articles scannés et enregistrés en mémoire. Clique sur « Calculer le total ».", "info");
    }

    this.saveToStorage();
  }

  calculateSupermarketTotal() {
    this.c4Calculated = true;
    const totalEl = document.getElementById('c4-screen-total');
    if (totalEl) totalEl.textContent = '25 DH';

    const btnPay = document.getElementById('btn-c4-pay');
    if (btnPay) btnPay.disabled = false;

    const btnCalc = document.getElementById('btn-c4-calculate');
    if (btnCalc) btnCalc.disabled = true;

    this.setTimelineStep(3, 'done');
    this.setTimelineStep(4, 'done');
    this.setTimelineStep(5, 'active');

    this.showToast(this.currentLanguage === 'ar' ? "تمت معالجة الحساب (5 + 8 + 12 = 25 درهم) وعرض النتيجة." : "Calcul effectué (5 + 8 + 12 = 25 DH) et diffusé sur l'écran.", "info");
    this.saveToStorage();
  }

  paySupermarketTotal() {
    this.c4Paid = true;
    const btnPay = document.getElementById('btn-c4-pay');
    if (btnPay) btnPay.disabled = true;

    this.setTimelineStep(5, 'done');

    if (this.unlockedChallenge <= 4) {
      this.unlockedChallenge = 5;
      this.score += 25;
      this.showToast(this.currentLanguage === 'ar' ? "تم الدفع واستخدام المعلومة بنجاح! تم فتح المهمة النهائية." : "Paiement réussi ! Tu as complété les 5 étapes. Mission Finale débloquée !", "success");
    }

    this.updateNavigationUI();
    this.saveToStorage();
  }

  setTimelineStep(stepNum, status) {
    const row = document.getElementById(`step-row-${stepNum}`);
    const icon = document.getElementById(`c4-s${stepNum}-icon`);
    if (!row || !icon) return;

    row.classList.remove('active', 'done');
    if (status === 'done') {
      row.classList.add('done');
      icon.textContent = '✅';
    } else if (status === 'active') {
      row.classList.add('active');
      icon.textContent = '⏳';
    } else {
      icon.textContent = '⚪';
    }
  }

  renderChallenge4() {
    const screenItems = document.getElementById('c4-screen-items');
    if (!screenItems) return;

    screenItems.innerHTML = '';
    const prods = [
      { key: 'pain', nameFr: 'Pain', nameAr: 'خبز', price: '5 DH' },
      { key: 'lait', nameFr: 'Lait', nameAr: 'حليب', price: '8 DH' },
      { key: 'jus', nameFr: 'Jus d\'orange', nameAr: 'عصير برتقال', price: '12 DH' }
    ];

    const lang = this.currentLanguage;
    let anyScanned = false;

    prods.forEach(p => {
      if (this.c4Scanned[p.key]) {
        anyScanned = true;
        const line = document.createElement('div');
        line.style.display = 'flex';
        line.style.justifyContent = 'space-between';
        line.style.padding = '2px 0';
        const name = lang === 'ar' ? p.nameAr : p.nameFr;
        line.innerHTML = `<span>• ${name}</span><span>${p.price}</span>`;
        screenItems.appendChild(line);
      }
    });

    if (!anyScanned) {
      screenItems.innerHTML = `<span style="color: var(--text-dim); text-align: center; margin-top: 10px;">${lang === 'ar' ? 'في انتظار المسح...' : 'En attente de scan...'}</span>`;
    }

    // Buttons state
    const btnCalc = document.getElementById('btn-c4-calculate');
    const btnPay = document.getElementById('btn-c4-pay');
    const allScanned = Object.values(this.c4Scanned).every(v => v);

    if (btnCalc) btnCalc.disabled = !allScanned || this.c4Calculated;
    if (btnPay) btnPay.disabled = !this.c4Calculated || this.c4Paid;

    if (this.c4Calculated) {
      const totalEl = document.getElementById('c4-screen-total');
      if (totalEl) totalEl.textContent = '25 DH';
    }
  }

  // ==========================================================================
  // 9. Challenge 5: Final Mission - School Library
  // ==========================================================================
  bindChallenge5Events() {
    for (let stage = 1; stage <= 5; stage++) {
      const slot = document.getElementById(`lib-slot-${stage}`);
      if (slot) {
        slot.addEventListener('click', () => {
          if (this.c5SelectedTask !== null) {
            this.assignC5Task(stage, this.c5SelectedTask);
            this.c5SelectedTask = null;
          }
        });
      }
    }
  }

  assignC5Task(stageNum, taskObj) {
    if (taskObj.stage === stageNum) {
      this.c5Assignments[stageNum] = taskObj.id;
      this.score += 5;
      this.showToast(this.currentLanguage === 'ar' ? `ممتاز! مهمة صحيحة للمرحلة ${stageNum}` : `Excellent ! Tâche assignée avec succès à l'étape ${stageNum}`, "success");
    } else {
      this.showToast(this.currentLanguage === 'ar' ? "هذه المهمة لا تنتمي إلى هذه المرحلة" : "Cette tâche ne correspond pas à cette phase du traitement", "error");
    }

    this.renderChallenge5();
    this.checkChallenge5Completion();
    this.saveToStorage();
  }

  renderChallenge5() {
    const lang = this.currentLanguage;
    const pool = document.getElementById('c5-tasks-pool');
    if (!pool) return;
    pool.innerHTML = '';

    const assignedIds = Object.values(this.c5Assignments).filter(Boolean);

    // Render task cards in pool
    C5_LIBRARY_TASKS.forEach(task => {
      const isAssigned = assignedIds.includes(task.id);
      if (!isAssigned) {
        const card = document.createElement('div');
        card.className = `mission-action-card ${this.c5SelectedTask?.id === task.id ? 'selected' : ''}`;
        const title = lang === 'ar' ? task.titleAr : task.titleFr;
        card.innerHTML = `
          <div style="display: flex; align-items: center; gap: 8px;">
            <span>${task.icon}</span>
            <span style="font-size: 0.85rem; font-weight: 700;">${title}</span>
          </div>
          <span style="font-size: 0.75rem; color: var(--accent-primary);">Sélectionner ➔</span>
        `;

        card.addEventListener('click', () => {
          if (this.c5SelectedTask?.id === task.id) {
            this.c5SelectedTask = null;
            card.classList.remove('selected');
          } else {
            this.c5SelectedTask = task;
            document.querySelectorAll('.mission-action-card').forEach(c => c.classList.remove('selected'));
            card.classList.add('selected');
            this.showToast(lang === 'ar' ? "انقر الآن على المرحلة المناسبة على اليمين" : "Clique maintenant sur l'étape correspondante à droite", "info");
          }
        });

        pool.appendChild(card);
      }
    });

    // Render targets
    for (let st = 1; st <= 5; st++) {
      const target = document.getElementById(`lib-target-${st}`);
      const slotEl = document.getElementById(`lib-slot-${st}`);
      const assignedId = this.c5Assignments[st];

      if (target && slotEl) {
        target.innerHTML = '';
        if (assignedId) {
          const task = C5_LIBRARY_TASKS.find(t => t.id === assignedId);
          slotEl.classList.add('correct');
          const title = lang === 'ar' ? task.titleAr : task.titleFr;
          target.innerHTML = `
            <div style="color: #34d399; font-weight: 700; font-size: 0.85rem; padding: 4px 0;">
              ✅ ${task.icon} ${title}
            </div>
          `;
        } else {
          slotEl.classList.remove('correct');
          target.innerHTML = `<span style="font-size: 0.75rem; color: var(--text-dim);">${lang === 'ar' ? 'انقر لإسناد المهمة المحددة هنا' : 'Clique pour assigner la tâche ici'}</span>`;
        }
      }
    }
  }

  checkChallenge5Completion() {
    const allAssigned = Object.values(this.c5Assignments).every(val => val !== null);
    if (allAssigned) {
      if (this.unlockedChallenge <= 5) {
        this.unlockedChallenge = 6;
        this.score += 25;
      }
      this.updateNavigationUI();
      this.saveToStorage();
      setTimeout(() => {
        this.goToScreen(6); // Results screen
      }, 1000);
    }
  }

  // ==========================================================================
  // 10. Results Screen & Reporting
  // ==========================================================================
  renderResults() {
    const elapsedSeconds = Math.max(1, Math.floor((Date.now() - this.startTime) / 1000));
    const mins = Math.floor(elapsedSeconds / 60);
    const secs = elapsedSeconds % 60;
    const timeFormatted = `${mins}:${secs < 10 ? '0' : ''}${secs}`;

    const scoreTotal = document.getElementById('res-score-total');
    if (scoreTotal) scoreTotal.textContent = this.score;

    const timeSpent = document.getElementById('res-time-spent');
    if (timeSpent) timeSpent.textContent = timeFormatted;

    this.reportTeachITProgress();
  }
}

// Auto-instantiate when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  window.dataDetectiveEngine = new DataDetectiveEngine();
});
