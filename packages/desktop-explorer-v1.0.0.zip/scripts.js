// ==========================================================================
// TeachIT Educational Game: Desktop Explorer (À la découverte du bureau)
// Simulated Desktop Environment, In-Memory File System & Educational Engine
// ==========================================================================

(function (global) {
  'use strict';

  // ==========================================================================
  // 1. BILINGUAL TRANSLATIONS & VOCABULARY DICTIONARY (French & Arabic)
  // ==========================================================================
  const TRANSLATIONS = {
    fr: {
      appName: 'Desktop Explorer',
      appSubtitle: 'À la découverte du bureau',
      offlineMode: 'Mode Hors-Ligne',
      categoryBadge: 'Bureautique',
      studentLabel: 'Élève :',
      guestStudent: 'Invité',
      btnExit: 'Quitter',
      btnStart: "Commencer l'exploration",
      btnBackLauncher: 'Retourner à TeachIT',
      btnReplay: "Rejouer l'exploration",
      btnHint: 'Indice',
      btnPrev: 'Défi précédent',
      btnNext: 'Défi suivant',
      btnReset: 'Réinitialiser',
      scoreLabel: 'Score :',
      attemptsLabel: 'Tentatives :',
      understoodBtn: 'Compris !',
      challengePill: 'Défi',
      stepPill: 'Étape',

      // Desktop Elements for Challenge 1
      elemDesktop: 'Le bureau',
      elemDesktopDesc:
        "C'est la surface de travail principale qui apparaît à l'écran. Tous les fichiers, dossiers et fenêtres s'y affichent.",
      elemIcons: 'Les icônes',
      elemIconsDesc:
        'Ce sont de petits symboles graphiques représentant des logiciels, des dossiers ou des documents pour les ouvrir facilement.',
      elemTaskbar: 'La barre des tâches',
      elemTaskbarDesc:
        'Elle est située en bas de l’écran. Elle permet d’accéder aux applications ouvertes et de passer rapidement d’une fenêtre à une autre.',
      elemStartMenu: 'Le menu Démarrer',
      elemStartMenuDesc:
        'C’est le point de départ de l’ordinateur. Il regroupe toutes les applications installées et les options du système.',
      elemTrash: 'La corbeille',
      elemTrashDesc:
        'C’est l’endroit où sont stockés temporairement les fichiers supprimés avant leur effacement définitif.',
      elemWallpaper: 'Le fond d’écran',
      elemWallpaperDesc:
        'C’est l’image ou la couleur d’arrière-plan qui personnalise l’espace de travail du bureau.',

      // Windows Vocabulary (Challenge 2)
      vocabApp: 'Une application',
      vocabWindow: 'Une fenêtre',
      vocabTitlebar: 'La barre de titre',
      vocabMinimize: 'Réduire',
      vocabMaximize: 'Agrandir',
      vocabRestore: 'Restaurer',
      vocabClose: 'Fermer',

      // Folder & Document Vocabulary (Challenges 3 & 4)
      vocabFolder: 'Un dossier',
      vocabFile: 'Un fichier',
      vocabDocument: 'Un document',
      vocabEditor: 'Éditeur de texte',
      vocabSave: 'Enregistrer',
      vocabSaveAs: 'Enregistrer sous',
      vocabExtension: 'Extension (.txt)',

      // Completion & Telemetry
      finalSuccessTitle: 'Félicitations !',
      finalSuccessSubtitle:
        'Vous avez découvert les éléments du bureau et appris à créer, enregistrer et organiser vos premiers documents.',
      statScore: 'Score final',
      statChallenges: 'Défis réussis',
      statActions: 'Actions réussies',
      statAttempts: 'Tentatives',
      statDuration: 'Durée totale',
      savingStatus: 'Enregistrement dans votre profil TeachIT...',
      savedSuccess: '✓ Progression enregistrée dans le profil TeachIT',
      guestStatus: 'Progression validée (Mode invité sans profil)',
    },
    ar: {
      appName: 'مستكشف سطح المكتب',
      appSubtitle: 'اكتشاف بيئة سطح المكتب',
      offlineMode: 'وضع غير متصل',
      categoryBadge: 'المكتبية والملفات',
      studentLabel: 'التلميذ:',
      guestStudent: 'ضيف',
      btnExit: 'خروج',
      btnStart: 'بدء الاستكشاف',
      btnBackLauncher: 'العودة إلى TeachIT',
      btnReplay: 'إعادة الاستكشاف',
      btnHint: 'تلميح',
      btnPrev: 'التحدي السابق',
      btnNext: 'التحدي التالي',
      btnReset: 'إعادة التحدي',
      scoreLabel: 'النقاط:',
      attemptsLabel: 'المحاولات:',
      understoodBtn: 'فهمت!',
      challengePill: 'التحدي',
      stepPill: 'المرحلة',

      elemDesktop: 'سطح المكتب',
      elemDesktopDesc:
        'هو مساحة العمل الرئيسية التي تظهر على الشاشة. تظهر عليه جميع الملفات والمجلدات والنوافذ.',
      elemIcons: 'الأيقونات',
      elemIconsDesc:
        'هي رموز ورسوم توضيحية صغيرة تمثل البرامج أو المجلدات أو المستندات لفتحها بسهولة.',
      elemTaskbar: 'شريط المهام',
      elemTaskbarDesc:
        'يقع أسفل الشاشة، ويسمح بالوصول إلى البرامج المفتوحة والتنقل السريع بين النوافذ.',
      elemStartMenu: 'قائمة ابدأ',
      elemStartMenuDesc:
        'هي نقطة الانطلاق في الحاسوب، وتحتوي على جميع البرامج المثبتة وخيارات النظام.',
      elemTrash: 'سلة المحذوفات',
      elemTrashDesc:
        'هو المكان الذي توضع فيه العناصر والملفات المحذوفة مؤقتاً قبل إتلافها نهائياً.',
      elemWallpaper: 'خلفية الشاشة',
      elemWallpaperDesc:
        'هي الصورة أو اللون الخلفي الذي يزين مساحة العمل على سطح المكتب.',

      vocabApp: 'تطبيق / برنامج',
      vocabWindow: 'نافذة',
      vocabTitlebar: 'شريط العنوان',
      vocabMinimize: 'تصغير',
      vocabMaximize: 'تكبير',
      vocabRestore: 'استعادة الحجم',
      vocabClose: 'إغلاق',

      vocabFolder: 'مجلد',
      vocabFile: 'ملف',
      vocabDocument: 'مستند نصي',
      vocabEditor: 'محرر النصوص',
      vocabSave: 'حفظ',
      vocabSaveAs: 'حفظ باسم',
      vocabExtension: 'امتداد الملف (.txt)',

      finalSuccessTitle: 'ألف مبروك!',
      finalSuccessSubtitle:
        'لقد اكتشفت عناصر سطح المكتب وتعلمت كيفية إنشاء الملفات والمجلدات وتنظيمها وحفظها.',
      statScore: 'النتيجة النهائية',
      statChallenges: 'التحديات المنجزة',
      statActions: 'العمليات الناجحة',
      statAttempts: 'المحاولات',
      statDuration: 'الوقت المستغرق',
      savingStatus: 'جاري حفظ التقدم في ملف التلميذ TeachIT...',
      savedSuccess: '✓ تم حفظ التقدم بنجاح في ملف التلميذ',
      guestStatus: 'تم إنهاء النشاط بنجاح (حساب ضيف)',
    },
  };

  // ==========================================================================
  // 2. DESKTOP ELEMENTS DEFINITION (Challenge 1)
  // ==========================================================================
  const DESKTOP_ELEMENTS = [
    {
      id: 'bureau',
      nameFr: 'Le bureau',
      nameAr: 'سطح المكتب',
      icon: '🪟',
      descFr:
        "Le bureau est l'espace de travail principal qui s'affiche à l'écran. C'est ici que tu peux déposer des dossiers, des documents et ouvrir tes logiciels.",
      descAr:
        'سطح المكتب هو مساحة العمل الأساسية التي تظهر على الشاشة وتوضع عليها النوافذ والملفات.',
      selector: '#simulatedDesktop',
    },
    {
      id: 'icones',
      nameFr: 'Les icônes',
      nameAr: 'الأيقونات',
      icon: '📁',
      descFr:
        'Une icône est une petite image cliquable qui représente un programme, un dossier ou un document pour l’ouvrir rapidement.',
      descAr: 'الأيقونة هي رمز بياني صغير يمكنك النقر عليه لفتح البرامج أو المجلدات أو الملفات.',
      selector: '#desktopIconsArea',
    },
    {
      id: 'barre-taches',
      nameFr: 'La barre des tâches',
      nameAr: 'شريط المهام',
      icon: '📊',
      descFr:
        'Elle est située en bas de l’écran. Elle permet d’accéder aux applications ouvertes et de basculer d’une fenêtre à une autre en un clic.',
      descAr: 'الشريط السفلي الذي يعرض التطبيقات النشطة ويتيح التبديل السهل بين النوافذ المفتوحة.',
      selector: '#simulatedTaskbar',
    },
    {
      id: 'menu-demarrer',
      nameFr: 'Le menu Démarrer',
      nameAr: 'قائمة ابدأ',
      icon: '🔘',
      descFr:
        'Le menu Démarrer permet d’accéder à toutes les applications de l’ordinateur et aux commandes du système.',
      descAr: 'القائمة الرئيسية للوصول إلى كافة البرامج المثبتة وإعدادات النظام.',
      selector: '#btnStartMenu',
    },
    {
      id: 'corbeille',
      nameFr: 'La corbeille',
      nameAr: 'سلة المحذوفات',
      icon: '🗑️',
      descFr:
        'La corbeille stocke temporairement les fichiers et dossiers que tu supprimes, pour pouvoir les récupérer en cas d’erreur.',
      descAr: 'تحتفظ بالملفات والمجلدات المحذوفة مؤقتاً لتتمكن من استرجاعها إذا حذفتها بالخطأ.',
      selector: '#icon-trash',
    },
    {
      id: 'fond-ecran',
      nameFr: 'Le fond d’écran',
      nameAr: 'خلفية الشاشة',
      icon: '🎨',
      descFr:
        'C’est l’image ou le décor visuel situé sous les icônes qui habille l’espace de travail de l’utilisateur.',
      descAr: 'الصورة أو الرسم الفني الذي يزين شاشة الحاسوب ويظهر خلف الأيقونات والنوافذ.',
      selector: '#desktopWallpaperArt',
    },
  ];

  // ==========================================================================
  // 3. CHALLENGES CONFIGURATION
  // ==========================================================================
  const CHALLENGES_CONFIG = [
    {
      id: 'challenge-1-desktop',
      titleFr: 'Défi 1 : Découvrir le bureau',
      titleAr: 'التحدي 1 : اكتشاف سطح المكتب',
      icon: '🪟',
      vocabFr: 'Le bureau & les icônes',
      vocabAr: 'سطح المكتب والأيقونات',
      instructionsFr:
        'Repère et clique sur les 6 éléments fondamentaux du bureau pour comprendre leur utilité.',
      instructionsAr: 'انقر على العناصر الستة الرئيسية في سطح المكتب لمعرفة أسمائها وأدوارها.',
    },
    {
      id: 'challenge-2-windows',
      titleFr: 'Défi 2 : Fenêtres et applications',
      titleAr: 'التحدي 2 : النوافذ والتطبيقات',
      icon: '🗖',
      vocabFr: 'Fenêtre, Réduire, Agrandir, Fermer',
      vocabAr: 'النافذة، تصغير، تكبير، إغلاق',
      instructionsFr:
        'Ouvre une application et apprends à manipuler sa fenêtre avec les boutons Réduire, Agrandir, Restaurer et Fermer.',
      instructionsAr:
        'افتح تطبيقاً وتعلم كيفية التحكم في نافذته عبر أزرار التصغير والتكبير والاستعادة والإغلاق.',
    },
    {
      id: 'challenge-3-folders',
      titleFr: 'Défi 3 : Créer et organiser des dossiers',
      titleAr: 'التحدي 3 : إنشاء المجلدات وتنظيمها',
      icon: '📁',
      vocabFr: 'Dossier, Nouveau, Renommer',
      vocabAr: 'المجلد، جديد، إعادة التسمية',
      instructionsFr:
        'Fais un clic droit pour créer un dossier nommé « Informatique », ouvre-le puis renomme-le en « Mon cours d’informatique ».',
      instructionsAr:
        'أنشئ مجلداً جديداً باسم « Informatique » عبر النقر الأيمن، وافتحه ثم أعد تسميته إلى « Mon cours d’informatique ».',
    },
    {
      id: 'challenge-4-documents',
      titleFr: 'Défi 4 : Créer et enregistrer un document texte',
      titleAr: 'التحدي 4 : إنشاء وحفظ مستند نصي',
      icon: '📝',
      vocabFr: 'Document texte, Enregistrer, .txt',
      vocabAr: 'مستند نصي، حفظ، .txt',
      instructionsFr:
        'Ouvre l’éditeur de texte, écris une phrase et enregistre le fichier sous le nom « Mon premier document ».',
      instructionsAr:
        'افتح محرر النصوص واكتب جملة ثم احفظ المستند باسم « Mon premier document ».',
    },
    {
      id: 'challenge-5-mission',
      titleFr: 'Défi 5 : Mission finale — Organiser son espace',
      titleAr: 'التحدي 5 : المهمة الختامية لتنظيم العمل',
      icon: '🏆',
      vocabFr: 'Organisation, Rangement de fichiers',
      vocabAr: 'تنظيم وترتيب الملفات',
      instructionsFr:
        'Crée un dossier « Informatique », enregistre un document « Mon premier document » et range-le à l’intérieur !',
      instructionsAr:
        'أنشئ مجلداً باسم « Informatique » واحفظ مستنداً نصياً وضعه داخل المجلد للتأكد من حسن التنظيم!',
    },
  ];

  // ==========================================================================
  // 4. IN-MEMORY SIMULATED FILE SYSTEM
  // ==========================================================================
  class SimulatedFileSystem {
    constructor() {
      this.items = new Map();
      this.init();
    }

    init() {
      this.items.clear();

      // Root desktop container
      this.items.set('desktop', {
        id: 'desktop',
        name: 'Bureau',
        type: 'folder',
        parentId: null,
        isSystem: true,
        icon: '🪟',
        createdAt: Date.now(),
      });

      // System Trash
      this.items.set('trash', {
        id: 'trash',
        name: 'Corbeille',
        type: 'folder',
        parentId: 'desktop',
        isSystem: true,
        icon: '🗑️',
        createdAt: Date.now(),
      });
    }

    reset() {
      this.init();
    }

    serialize() {
      const arr = [];
      for (const item of this.items.values()) {
        arr.push({ ...item });
      }
      return arr;
    }

    deserialize(arr) {
      if (!Array.isArray(arr) || arr.length === 0) return;
      this.items.clear();
      this.init();
      for (const item of arr) {
        if (item && item.id) {
          this.items.set(item.id, item);
        }
      }
    }

    createFolder(parentId, name) {
      const cleanName = (name || 'Nouveau dossier').trim();
      const id = 'folder-' + Math.random().toString(36).substring(2, 9);
      const folder = {
        id,
        name: cleanName,
        type: 'folder',
        parentId: parentId || 'desktop',
        isSystem: false,
        icon: '📁',
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      this.items.set(id, folder);
      return folder;
    }

    createFile(parentId, name, content = '', extension = 'txt') {
      const baseName = (name || 'Nouveau document').trim();
      const fileName = baseName.endsWith(`.${extension}`) ? baseName : `${baseName}.${extension}`;
      const id = 'file-' + Math.random().toString(36).substring(2, 9);
      const file = {
        id,
        name: fileName,
        baseName: baseName.replace(new RegExp(`\\.${extension}$`), ''),
        extension,
        type: 'file',
        parentId: parentId || 'desktop',
        content,
        icon: '📄',
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      this.items.set(id, file);
      return file;
    }

    renameItem(id, newName) {
      const item = this.items.get(id);
      if (!item || item.isSystem) return false;
      const clean = (newName || '').trim();
      if (!clean) return false;

      if (item.type === 'file' && item.extension) {
        item.baseName = clean.replace(new RegExp(`\\.${item.extension}$`), '');
        item.name = `${item.baseName}.${item.extension}`;
      } else {
        item.name = clean;
      }
      item.updatedAt = Date.now();
      return true;
    }

    moveItem(id, newParentId) {
      const item = this.items.get(id);
      const targetParent = this.items.get(newParentId);
      if (!item || !targetParent || targetParent.type !== 'folder') return false;
      if (item.id === newParentId) return false; // Cannot move into itself

      item.parentId = newParentId;
      item.updatedAt = Date.now();
      return true;
    }

    deleteItem(id) {
      const item = this.items.get(id);
      if (!item || item.isSystem) return false;
      // In the simulation, deleting moves the item to trash
      item.parentId = 'trash';
      item.updatedAt = Date.now();
      return true;
    }

    getItem(id) {
      return this.items.get(id) || null;
    }

    findByName(name, parentId = 'desktop') {
      const cleanTarget = name.trim().toLowerCase();
      for (const item of this.items.values()) {
        if (item.parentId === parentId) {
          if (
            item.name.toLowerCase() === cleanTarget ||
            (item.baseName && item.baseName.toLowerCase() === cleanTarget)
          ) {
            return item;
          }
        }
      }
      return null;
    }

    getChildren(parentId) {
      const results = [];
      for (const item of this.items.values()) {
        if (item.parentId === parentId) {
          results.push(item);
        }
      }
      return results;
    }
  }

  // ==========================================================================
  // 5. SIMULATED WINDOW MANAGER
  // ==========================================================================
  class SimulatedWindowManager {
    constructor() {
      this.windows = {
        editor: {
          id: 'editor',
          title: 'Éditeur de texte',
          icon: '📝',
          isOpen: false,
          isMinimized: false,
          isMaximized: false,
          zIndex: 20,
        },
        explorer: {
          id: 'explorer',
          title: 'Explorateur de fichiers',
          icon: '📁',
          isOpen: false,
          isMinimized: false,
          isMaximized: false,
          currentFolderId: 'desktop',
          zIndex: 20,
        },
        trash: {
          id: 'trash',
          title: 'Corbeille',
          icon: '🗑️',
          isOpen: false,
          isMinimized: false,
          isMaximized: false,
          zIndex: 20,
        },
        taskmgr: {
          id: 'taskmgr',
          title: 'Gestionnaire des tâches',
          icon: '📊',
          isOpen: false,
          isMinimized: false,
          isMaximized: false,
          zIndex: 20,
        },
      };
      this.activeWindowId = null;
      this.topZIndex = 25;
    }

    openWindow(appId) {
      const win = this.windows[appId];
      if (!win) return null;
      win.isOpen = true;
      win.isMinimized = false;
      this.bringToFront(appId);
      return win;
    }

    closeWindow(appId) {
      const win = this.windows[appId];
      if (!win) return null;
      win.isOpen = false;
      win.isMinimized = false;
      win.isMaximized = false;
      if (this.activeWindowId === appId) {
        this.activeWindowId = null;
      }
      return win;
    }

    minimizeWindow(appId) {
      const win = this.windows[appId];
      if (!win) return null;
      win.isMinimized = true;
      if (this.activeWindowId === appId) {
        this.activeWindowId = null;
      }
      return win;
    }

    restoreWindow(appId) {
      const win = this.windows[appId];
      if (!win) return null;
      win.isOpen = true;
      win.isMinimized = false;
      this.bringToFront(appId);
      return win;
    }

    maximizeWindow(appId) {
      const win = this.windows[appId];
      if (!win) return null;
      win.isMaximized = true;
      this.bringToFront(appId);
      return win;
    }

    unmaximizeWindow(appId) {
      const win = this.windows[appId];
      if (!win) return null;
      win.isMaximized = false;
      this.bringToFront(appId);
      return win;
    }

    toggleMaximize(appId) {
      const win = this.windows[appId];
      if (!win) return null;
      win.isMaximized = !win.isMaximized;
      this.bringToFront(appId);
      return win;
    }

    bringToFront(appId) {
      const win = this.windows[appId];
      if (!win) return;
      this.topZIndex++;
      win.zIndex = this.topZIndex;
      this.activeWindowId = appId;
    }
  }

  // ==========================================================================
  // 6. EDUCATIONAL ENGINE FOR PROGRESSION & TRACKING
  // ==========================================================================
  class DesktopExplorerEngine {
    constructor() {
      this.currentLang = 'fr';
      this.currentChallengeIndex = 0;
      this.unlockedChallenges = new Set([0]);
      this.completedChallenges = new Set();
      this.score = 0;
      this.attemptsPerChallenge = [0, 0, 0, 0, 0];
      this.successesPerChallenge = [0, 0, 0, 0, 0];
      this.startTime = Date.now();
      this.sessionReported = false;
      this.sessionInfo = null;

      // In-Memory Simulation
      this.fs = new SimulatedFileSystem();
      this.wm = new SimulatedWindowManager();

      // Challenge 1 state
      this.discoveredElements = new Set();

      // Challenge 2 state (sequential window manipulation steps)
      // 0: open app, 1: inspect titlebar, 2: minimize, 3: restore, 4: maximize, 5: unmaximize, 6: close
      this.c2Step = 0;

      // Challenge 3 state
      // 0: context menu, 1: create folder, 2: name 'Informatique', 3: open folder, 4: close explorer, 5: rename 'Mon cours d'informatique'
      this.c3Step = 0;

      // Challenge 4 state
      // 0: open editor, 1: write text, 2: open save dialog, 3: save 'Mon premier document'
      this.c4Step = 0;

      // Challenge 5 state (Mission checklist completed items)
      this.c5Tasks = {
        folderCreated: false,
        editorOpened: false,
        textWritten: false,
        docSaved: false,
        docMoved: false,
        folderOpened: false,
        docVerified: false,
        contentChecked: false,
      };

      // Context menu selection state
      this.selectedDesktopItemId = null;
      this.cmenuTargetType = 'desktop'; // 'desktop', 'item', or 'taskbar'
      this.clipboardItem = null; // { id, mode: 'cut' | 'copy' }
      this.desktopIconSize = 'medium'; // 'small', 'medium', 'large'
      this.desktopSortBy = 'default';
    }

    start() {
      this.startTime = Date.now();
      this.currentChallengeIndex = 0;
      this.unlockedChallenges = new Set([0]);
      this.completedChallenges = new Set();
      this.score = 0;
      this.attemptsPerChallenge = [0, 0, 0, 0, 0];
      this.successesPerChallenge = [0, 0, 0, 0, 0];
      this.sessionReported = false;
      this.resetChallengeState(0);
    }

    resetChallengeState(cIdx) {
      if (cIdx === 0) {
        this.discoveredElements.clear();
      } else if (cIdx === 1) {
        this.c2Step = 0;
        this.wm.closeWindow('editor');
      } else if (cIdx === 2) {
        this.c3Step = 0;
        this.fs.reset();
        this.wm.closeWindow('explorer');
      } else if (cIdx === 3) {
        this.c4Step = 0;
        this.fs.reset();
        this.wm.closeWindow('editor');
      } else if (cIdx === 4) {
        this.fs.reset();
        this.wm.closeWindow('editor');
        this.wm.closeWindow('explorer');
        this.c5Tasks = {
          folderCreated: false,
          editorOpened: false,
          textWritten: false,
          docSaved: false,
          docMoved: false,
          folderOpened: false,
          docVerified: false,
          contentChecked: false,
        };
      }
    }

    recordAttempt(cIdx) {
      if (cIdx >= 0 && cIdx < 5) {
        this.attemptsPerChallenge[cIdx]++;
      }
    }

    recordSuccess(cIdx, points = 20) {
      if (cIdx >= 0 && cIdx < 5) {
        this.successesPerChallenge[cIdx]++;
        this.score += points;
        this.saveToStorage();
      }
    }

    goToChallenge(index) {
      if (this.unlockedChallenges.has(index)) {
        this.currentChallengeIndex = index;
        this.saveToStorage();
        return true;
      }
      return false;
    }

    completeCurrentChallenge() {
      const idx = this.currentChallengeIndex;
      this.completedChallenges.add(idx);
      this.score += 20; // Bonus on challenge completion

      let res;
      if (idx + 1 < CHALLENGES_CONFIG.length) {
        this.unlockedChallenges.add(idx + 1);
        res = { isChallengeComplete: true, isGameComplete: false, nextIndex: idx + 1 };
      } else {
        res = { isChallengeComplete: true, isGameComplete: true };
      }
      this.saveToStorage();
      return res;
    }

    getStorageKey() {
      const studentId = this.sessionInfo?.studentId || 'guest';
      return `teachit_desktop_explorer_${studentId}`;
    }

    saveToStorage() {
      try {
        if (typeof localStorage === 'undefined') return;
        const state = {
          currentChallengeIndex: this.currentChallengeIndex,
          unlockedChallenges: Array.from(this.unlockedChallenges),
          completedChallenges: Array.from(this.completedChallenges),
          score: this.score,
          attemptsPerChallenge: this.attemptsPerChallenge,
          successesPerChallenge: this.successesPerChallenge,
          discoveredElements: Array.from(this.discoveredElements),
          c2Step: this.c2Step,
          c3Step: this.c3Step,
          c4Step: this.c4Step,
          c5Tasks: this.c5Tasks,
          fsItems: this.fs.serialize(),
          savedAt: Date.now(),
        };
        localStorage.setItem(this.getStorageKey(), JSON.stringify(state));
      } catch {
        // Safe fallback in restricted or sandboxed environments
      }
    }

    loadFromStorage() {
      try {
        if (typeof localStorage === 'undefined') return false;
        const raw = localStorage.getItem(this.getStorageKey());
        if (!raw) return false;
        const state = JSON.parse(raw);
        if (Array.isArray(state.unlockedChallenges) && state.unlockedChallenges.length > 0) {
          this.unlockedChallenges = new Set(state.unlockedChallenges);
        }
        if (Array.isArray(state.completedChallenges)) {
          this.completedChallenges = new Set(state.completedChallenges);
        }
        if (typeof state.score === 'number') {
          this.score = state.score;
        }
        if (Array.isArray(state.attemptsPerChallenge)) {
          this.attemptsPerChallenge = state.attemptsPerChallenge;
        }
        if (Array.isArray(state.successesPerChallenge)) {
          this.successesPerChallenge = state.successesPerChallenge;
        }
        if (Array.isArray(state.discoveredElements)) {
          this.discoveredElements = new Set(state.discoveredElements);
        }
        if (typeof state.c2Step === 'number') this.c2Step = state.c2Step;
        if (typeof state.c3Step === 'number') this.c3Step = state.c3Step;
        if (typeof state.c4Step === 'number') this.c4Step = state.c4Step;
        if (state.c5Tasks && typeof state.c5Tasks === 'object') {
          this.c5Tasks = { ...this.c5Tasks, ...state.c5Tasks };
        }
        if (Array.isArray(state.fsItems) && state.fsItems.length > 0) {
          this.fs.deserialize(state.fsItems);
        }
        if (
          typeof state.currentChallengeIndex === 'number' &&
          this.unlockedChallenges.has(state.currentChallengeIndex)
        ) {
          this.currentChallengeIndex = state.currentChallengeIndex;
        } else {
          const maxUnlocked = Math.max(...Array.from(this.unlockedChallenges));
          this.currentChallengeIndex = maxUnlocked >= 0 ? maxUnlocked : 0;
        }
        return true;
      } catch {
        return false;
      }
    }

    hasSavedProgress() {
      return this.completedChallenges.size > 0 || this.unlockedChallenges.size > 1;
    }

    resetAllProgress() {
      try {
        if (typeof localStorage !== 'undefined') {
          localStorage.removeItem(this.getStorageKey());
        }
      } catch {
        // Safe fallback
      }
      this.currentChallengeIndex = 0;
      this.unlockedChallenges = new Set([0]);
      this.completedChallenges = new Set();
      this.score = 0;
      this.attemptsPerChallenge = [0, 0, 0, 0, 0];
      this.successesPerChallenge = [0, 0, 0, 0, 0];
      this.discoveredElements.clear();
      this.c2Step = 0;
      this.c3Step = 0;
      this.c4Step = 0;
      this.c5Tasks = {
        folderCreated: false,
        editorOpened: false,
        textWritten: false,
        docSaved: false,
        docMoved: false,
        folderOpened: false,
        docVerified: false,
        contentChecked: false,
      };
      this.fs.reset();
      this.wm.closeWindow('editor');
      this.wm.closeWindow('explorer');
      this.wm.closeWindow('trash');
      this.wm.closeWindow('taskmgr');
    }

    getTotalAttempts() {
      return this.attemptsPerChallenge.reduce((sum, a) => sum + a, 0);
    }

    getTotalSuccesses() {
      return this.successesPerChallenge.reduce((sum, s) => sum + s, 0);
    }

    getDurationSeconds() {
      return Math.max(1, Math.round((Date.now() - this.startTime) / 1000));
    }

    getSummary() {
      const durationSeconds = this.getDurationSeconds();
      const mins = Math.floor(durationSeconds / 60);
      const secs = durationSeconds % 60;
      const formattedDuration = `${mins < 10 ? '0' : ''}${mins}:${secs < 10 ? '0' : ''}${secs}`;

      return {
        score: this.score,
        maxScore: 500,
        completedChallenges: this.completedChallenges.size,
        totalChallenges: 5,
        totalAttempts: this.getTotalAttempts(),
        successfulActions: this.getTotalSuccesses(),
        durationSeconds,
        formattedDuration,
        challengeDetails: CHALLENGES_CONFIG.map((c, i) => ({
          id: c.id,
          title: this.currentLang === 'ar' ? c.titleAr : c.titleFr,
          vocab: this.currentLang === 'ar' ? c.vocabAr : c.vocabFr,
          completed: this.completedChallenges.has(i),
          attempts: this.attemptsPerChallenge[i],
          successes: this.successesPerChallenge[i],
        })),
      };
    }
  }

  // ==========================================================================
  // 7. TEACHIT IPC BRIDGE & INTEGRATION
  // ==========================================================================
  function getTeachit() {
    return typeof window !== 'undefined' && window.teachit ? window.teachit : null;
  }

  // ==========================================================================
  // 8. UI CONTROLLER & EVENT ORCHESTRATION
  // ==========================================================================
  const engine = new DesktopExplorerEngine();

  // Screen elements
  const screenWelcome = document.getElementById('screenWelcome');
  const screenGame = document.getElementById('screenGame');
  const screenResults = document.getElementById('screenResults');

  // Navigation & Header elements
  const challengeBadge = document.getElementById('challengeBadge');
  const stepBadge = document.getElementById('stepBadge');
  const instructionTitle = document.getElementById('instructionTitle');
  const instructionSub = document.getElementById('instructionSub');
  const challengeProgressFill = document.getElementById('challengeProgressFill');
  const scoreValue = document.getElementById('scoreValue');
  const btnToggleLang = document.getElementById('btnToggleLang');
  const langBtnText = document.getElementById('langBtnText');
  const sessionBadge = document.getElementById('sessionBadge');
  const sessionStudentName = document.getElementById('sessionStudentName');
  const btnExitHeader = document.getElementById('btnExitHeader');
  const btnStartGame = document.getElementById('btnStartGame');
  const btnExitWelcome = document.getElementById('btnExitWelcome');
  const btnHint = document.getElementById('btnHint');
  const btnContextMenuHelper = document.getElementById('btnContextMenuHelper');
  const feedbackBanner = document.getElementById('feedbackBanner');
  const feedbackIcon = document.getElementById('feedbackIcon');
  const feedbackText = document.getElementById('feedbackText');

  // Desktop Simulation elements
  const simulatedDesktop = document.getElementById('simulatedDesktop');
  const desktopIconsArea = document.getElementById('desktopIconsArea');
  const simulatedTaskbar = document.getElementById('simulatedTaskbar');
  const btnStartMenu = document.getElementById('btnStartMenu');
  const startMenuPopover = document.getElementById('startMenuPopover');
  const taskbarApps = document.getElementById('taskbarApps');
  const desktopContextMenu = document.getElementById('desktopContextMenu');

  // Explainer Card elements
  const eduExplainerCard = document.getElementById('eduExplainerCard');
  const explainerBadge = document.getElementById('explainerBadge');
  const explainerTitle = document.getElementById('explainerTitle');
  const explainerDesc = document.getElementById('explainerDesc');
  const elementsChecklist = document.getElementById('elementsChecklist');
  const missionChecklist = document.getElementById('missionChecklist');
  const btnExplainerClose = document.getElementById('btnExplainerClose');
  const btnExplainerNext = document.getElementById('btnExplainerNext');

  // Windows elements
  const windowEditor = document.getElementById('windowEditor');
  const winEditorTitlebar = document.getElementById('winEditorTitlebar');
  const winEditorTitle = document.getElementById('winEditorTitle');
  const btnEditorMinimize = document.getElementById('btnEditorMinimize');
  const btnEditorMaximize = document.getElementById('btnEditorMaximize');
  const btnEditorClose = document.getElementById('btnEditorClose');
  const editorTextarea = document.getElementById('editorTextarea');
  const btnEditorSave = document.getElementById('btnEditorSave');
  const btnEditorSaveAs = document.getElementById('btnEditorSaveAs');
  const btnInsertSuggestedText = document.getElementById('btnInsertSuggestedText');

  const windowExplorer = document.getElementById('windowExplorer');
  const _winExplorerTitlebar = document.getElementById('winExplorerTitlebar');
  const winExplorerTitle = document.getElementById('winExplorerTitle');
  const btnExplorerMinimize = document.getElementById('btnExplorerMinimize');
  const btnExplorerMaximize = document.getElementById('btnExplorerMaximize');
  const btnExplorerClose = document.getElementById('btnExplorerClose');
  const btnExplorerUp = document.getElementById('btnExplorerUp');
  const explorerAddressPath = document.getElementById('explorerAddressPath');
  const explorerGrid = document.getElementById('explorerGrid');
  const explorerStatusCount = document.getElementById('explorerStatusCount');

  const windowTrash = document.getElementById('windowTrash');
  const _winTrashTitlebar = document.getElementById('winTrashTitlebar');
  const btnTrashMinimize = document.getElementById('btnTrashMinimize');
  const btnTrashMaximize = document.getElementById('btnTrashMaximize');
  const btnTrashClose = document.getElementById('btnTrashClose');

  // Dialog elements
  const dialogSaveAs = document.getElementById('dialogSaveAs');
  const inputDocName = document.getElementById('inputDocName');
  const saveFolderSelect = document.getElementById('saveFolderSelect');
  const btnDialogSaveConfirm = document.getElementById('btnDialogSaveConfirm');
  const btnDialogSaveCancel = document.getElementById('btnDialogSaveCancel');
  const btnDialogCancelAction = document.getElementById('btnDialogCancelAction');

  // Footer Navigation
  const btnPrevChallenge = document.getElementById('btnPrevChallenge');
  const btnResetChallenge = document.getElementById('btnResetChallenge');
  const btnNextChallenge = document.getElementById('btnNextChallenge');
  const vocabHighlight = document.getElementById('vocabHighlight');

  // Results elements
  const resTotalScore = document.getElementById('resTotalScore');
  const resCompletedChallenges = document.getElementById('resCompletedChallenges');
  const resSuccessfulActions = document.getElementById('resSuccessfulActions');
  const resTotalAttempts = document.getElementById('resTotalAttempts');
  const resDuration = document.getElementById('resDuration');
  const resultsBreakdownList = document.getElementById('resultsBreakdownList');
  const saveStatusBox = document.getElementById('saveStatusBox');
  const saveStatusMsg = document.getElementById('saveStatusMsg');
  const saveStatusIcon = document.getElementById('saveStatusIcon');
  const btnReplay = document.getElementById('btnReplay');
  const btnExitResults = document.getElementById('btnExitResults');

  // Screen Switcher
  function showScreen(screenId) {
    [screenWelcome, screenGame, screenResults].forEach((s) => {
      if (s) s.classList.remove('active');
    });

    if (screenId === 'welcome' && screenWelcome) screenWelcome.classList.add('active');
    if (screenId === 'game' && screenGame) screenGame.classList.add('active');
    if (screenId === 'results' && screenResults) screenResults.classList.add('active');
  }

  // Feedback Toast Helper
  let feedbackTimer = null;
  function showFeedback(text, type = 'info', icon = '💡', autoHideMs = 3500) {
    if (!feedbackBanner) return;
    if (feedbackTimer) clearTimeout(feedbackTimer);

    feedbackBanner.className = `feedback-banner ${type}`;
    if (feedbackIcon) feedbackIcon.textContent = icon;
    if (feedbackText) feedbackText.textContent = text;
    feedbackBanner.style.display = 'flex';

    if (autoHideMs > 0) {
      feedbackTimer = setTimeout(() => {
        feedbackBanner.style.display = 'none';
      }, autoHideMs);
    }
  }

  function hideFeedback() {
    if (feedbackBanner) feedbackBanner.style.display = 'none';
  }

  function updateWelcomeButtonState() {
    if (!btnStartGame) return;
    const btnTextSpan = document.getElementById('btnStartText');
    const btnRestartFresh = document.getElementById('btnRestartFresh');
    if (engine.hasSavedProgress()) {
      const targetChallenge = engine.currentChallengeIndex + 1;
      const label =
        engine.currentLang === 'ar'
          ? `متابعة الاستكشاف (التحدي ${targetChallenge})`
          : `Reprendre la partie (Défi ${targetChallenge})`;
      if (btnTextSpan) btnTextSpan.textContent = label;
      else btnStartGame.textContent = label;
      if (btnRestartFresh) btnRestartFresh.style.display = 'inline-flex';
    } else {
      const label =
        engine.currentLang === 'ar' ? 'بدء الاستكشاف' : "Commencer l'exploration";
      if (btnTextSpan) btnTextSpan.textContent = label;
      else btnStartGame.textContent = label;
      if (btnRestartFresh) btnRestartFresh.style.display = 'none';
    }
  }

  // Update Challenge Navigation Tabs
  function updateTabs() {
    for (let i = 0; i < 5; i++) {
      const tab = document.getElementById(`tab${i}`);
      if (!tab) continue;

      tab.classList.remove('active', 'completed', 'locked');
      if (i === engine.currentChallengeIndex) {
        tab.classList.add('active');
      }
      if (engine.completedChallenges.has(i)) {
        tab.classList.add('completed');
      }
      if (!engine.unlockedChallenges.has(i)) {
        tab.classList.add('locked');
      }
    }
    updateWelcomeButtonState();
  }

  // Bilingual Language Application
  function applyLanguage(lang) {
    engine.currentLang = lang;
    const t = TRANSLATIONS[lang] || TRANSLATIONS.fr;

    if (typeof document !== 'undefined') {
      document.documentElement.lang = lang;
      document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    }

    if (langBtnText) langBtnText.textContent = lang === 'fr' ? 'العربية' : 'Français';
    const appBrandTitle = document.getElementById('appBrandTitle');
    if (appBrandTitle) appBrandTitle.textContent = t.appName;
    const badgeOffline = document.getElementById('badgeOffline');
    if (badgeOffline) badgeOffline.textContent = t.offlineMode;
    const badgeCategory = document.getElementById('badgeCategory');
    if (badgeCategory) badgeCategory.textContent = t.categoryBadge;

    const btnExitText = document.getElementById('btnExitText');
    if (btnExitText) btnExitText.textContent = t.btnExit;

    const btnStartText = document.getElementById('btnStartText');
    if (btnStartText) btnStartText.textContent = t.btnStart;

    const btnBackLauncherText = document.getElementById('btnBackLauncherText');
    if (btnBackLauncherText) btnBackLauncherText.textContent = t.btnBackLauncher;

    const hintBtnText = document.getElementById('hintBtnText');
    if (hintBtnText) hintBtnText.textContent = t.btnHint;

    const btnPrevText = document.getElementById('btnPrevText');
    if (btnPrevText) btnPrevText.textContent = t.btnPrev;

    const btnResetText = document.getElementById('btnResetText');
    if (btnResetText) btnResetText.textContent = t.btnReset;

    const btnNextText = document.getElementById('btnNextText');
    if (btnNextText) btnNextText.textContent = t.btnNext;

    const scoreLabel = document.getElementById('scoreLabel');
    if (scoreLabel) scoreLabel.textContent = t.scoreLabel;

    const startMenuLabel = document.getElementById('startMenuLabel');
    if (startMenuLabel) startMenuLabel.textContent = lang === 'ar' ? 'ابدأ' : 'Démarrer';

    renderCurrentChallenge();
  }

  // ==========================================================================
  // 9. SIMULATED DESKTOP RENDERING
  // ==========================================================================
  function renderDesktopIcons() {
    if (!desktopIconsArea) return;
    desktopIconsArea.innerHTML = '';

    // Standard Desktop App Icons
    const defaultApps = [
      {
        id: 'icon-editor',
        name: engine.currentLang === 'ar' ? 'محرر النصوص' : 'Éditeur de texte',
        icon: '📝',
        type: 'app',
        action: () => openApp('editor'),
      },
      {
        id: 'icon-explorer',
        name: engine.currentLang === 'ar' ? 'المستكشف' : 'Explorateur',
        icon: '📁',
        type: 'app',
        action: () => openApp('explorer'),
      },
      {
        id: 'icon-trash',
        name: engine.currentLang === 'ar' ? 'سلة المحذوفات' : 'Corbeille',
        icon: '🗑️',
        type: 'app',
        action: () => openApp('trash'),
      },
    ];

    defaultApps.forEach((app) => {
      const el = createDesktopIconElement(app.id, app.name, app.icon, app.action);
      desktopIconsArea.appendChild(el);
    });

    // In-memory files and folders on desktop
    let desktopItems = engine.fs.getChildren('desktop');

    // Apply sorting
    if (engine.desktopSortBy === 'name') {
      desktopItems.sort((a, b) => a.name.localeCompare(b.name));
    } else if (engine.desktopSortBy === 'size') {
      desktopItems.sort((a, b) => (b.content?.length || 0) - (a.content?.length || 0));
    } else if (engine.desktopSortBy === 'type') {
      desktopItems.sort((a, b) => a.type.localeCompare(b.type));
    }

    desktopItems.forEach((item) => {
      if (item.id === 'trash') return; // Trash is already rendered as system icon
      const el = createDesktopIconElement(item.id, item.name, item.icon, () => {
        if (item.type === 'folder') {
          openFolder(item.id);
        } else if (item.type === 'file') {
          openFileInEditor(item.id);
        }
      });
      desktopIconsArea.appendChild(el);
    });

    // Populate Save As destination dropdown
    if (saveFolderSelect) {
      saveFolderSelect.innerHTML = `<option value="desktop">Bureau (Desktop)</option>`;
      desktopItems.forEach((item) => {
        if (item.type === 'folder' && item.id !== 'trash') {
          const opt = document.createElement('option');
          opt.value = item.id;
          opt.textContent = `📁 ${item.name}`;
          saveFolderSelect.appendChild(opt);
        }
      });
    }
  }

  function createDesktopIconElement(id, name, icon, onDblClick) {
    const el = document.createElement('div');
    const sizeClass = `size-${engine.desktopIconSize || 'medium'}`;
    el.className = `desktop-icon ${sizeClass}`;
    el.id = id;
    el.tabIndex = 0;
    el.setAttribute('role', 'button');
    el.setAttribute('aria-label', name);

    // If item is currently cut, dim it
    if (engine.clipboardItem?.mode === 'cut' && engine.clipboardItem?.id === id) {
      el.style.opacity = '0.45';
    }

    el.innerHTML = `
      <span class="desktop-icon-img" aria-hidden="true">${icon}</span>
      <span class="desktop-icon-label" id="label-${id}">${name}</span>
    `;

    const fsItem = engine.fs.getItem(id);

    // HTML5 Drag Support for User Files & Folders
    if (fsItem && !fsItem.isSystem) {
      el.setAttribute('draggable', 'true');
      el.addEventListener('dragstart', (e) => {
        e.dataTransfer.setData('text/plain', id);
        e.dataTransfer.effectAllowed = 'move';
        el.classList.add('is-dragging');
        engine.selectedDesktopItemId = id;
      });
      el.addEventListener('dragend', () => {
        el.classList.remove('is-dragging');
        document
          .querySelectorAll('.drag-target-hover')
          .forEach((node) => node.classList.remove('drag-target-hover'));
      });
    }

    // Drop Target Support for Folders and Trash
    if (id === 'icon-trash' || fsItem?.type === 'folder') {
      el.addEventListener('dragover', (e) => {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        el.classList.add('drag-target-hover');
      });
      el.addEventListener('dragleave', (e) => {
        if (!el.contains(e.relatedTarget)) {
          el.classList.remove('drag-target-hover');
        }
      });
      el.addEventListener('drop', (e) => {
        e.preventDefault();
        e.stopPropagation();
        el.classList.remove('drag-target-hover');
        const draggedId = e.dataTransfer.getData('text/plain');
        if (!draggedId || draggedId === id) return;

        if (id === 'icon-trash') {
          const draggedItem = engine.fs.getItem(draggedId);
          if (draggedItem && !draggedItem.isSystem) {
            engine.fs.deleteItem(draggedId);
            renderDesktopIcons();
            if (engine.wm.windows.explorer.isOpen) {
              renderExplorerContent(engine.wm.windows.explorer.currentFolderId);
            }
            showFeedback(`« ${draggedItem.name} » déplacé vers la corbeille.`, 'info', '🗑️', 1500);
            engine.saveToStorage();
          }
          return;
        }

        // Drop into folder
        const draggedItem = engine.fs.getItem(draggedId);
        const targetFolder = engine.fs.getItem(id);
        if (draggedItem && targetFolder && targetFolder.type === 'folder') {
          engine.fs.moveItem(draggedId, id);
          renderDesktopIcons();
          if (engine.wm.windows.explorer.isOpen) {
            renderExplorerContent(engine.wm.windows.explorer.currentFolderId);
          }
          showFeedback(
            `« ${draggedItem.name} » déplacé dans le dossier « ${targetFolder.name} ».`,
            'success',
            '📦',
            2000,
          );
          engine.saveToStorage();

          if (
            engine.currentChallengeIndex === 4 &&
            targetFolder.name.toLowerCase().includes('informatique')
          ) {
            if (draggedItem.name.includes('Mon premier document')) {
              engine.c5Tasks.docMoved = true;
              checkChallenge5Progress();
            }
          }
        }
      });
    }

    // Selection
    el.addEventListener('click', (e) => {
      e.stopPropagation();
      document
        .querySelectorAll('.desktop-icon')
        .forEach((iconEl) => iconEl.classList.remove('selected'));
      el.classList.add('selected');
      engine.selectedDesktopItemId = id;

      // In Challenge 1, clicking an icon discovers it
      if (engine.currentChallengeIndex === 0) {
        if (id === 'icon-trash') {
          handleDiscoverElement('corbeille');
        } else {
          handleDiscoverElement('icones');
        }
      }

      // In Challenge 3, if student clicks on the Informatique folder while at step 1 or 2
      if (engine.currentChallengeIndex === 2 && engine.c3Step < 3) {
        const item = engine.fs.getItem(id);
        if (item?.type === 'folder' && item.name.toLowerCase().includes('informatique')) {
          advanceChallenge3Step(3);
        }
      }

      // In Challenge 4, clicking the editor icon also opens the editor and advances to step 1
      if (engine.currentChallengeIndex === 3 && engine.c4Step === 0 && id === 'icon-editor') {
        openApp('editor');
      }
    });

    // Double click to open
    el.addEventListener('dblclick', (e) => {
      e.stopPropagation();
      if (typeof onDblClick === 'function') {
        onDblClick();
      }
    });

    // Right click context menu
    el.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      e.stopPropagation();
      engine.selectedDesktopItemId = id;
      openContextMenu(e.clientX, e.clientY, 'item');
    });

    return el;
  }

  // ==========================================================================
  // 10. WINDOWS & TASKBAR SYNCHRONIZATION
  // ==========================================================================
  function updateWindowsUI() {
    // 1. Editor Window
    const winEd = engine.wm.windows.editor;
    if (windowEditor) {
      if (winEd.isOpen && !winEd.isMinimized) {
        windowEditor.style.display = 'flex';
        windowEditor.style.zIndex = String(winEd.zIndex);
        if (winEd.isMaximized) {
          windowEditor.classList.add('maximized');
          if (btnEditorMaximize) btnEditorMaximize.textContent = '🗗';
        } else {
          windowEditor.classList.remove('maximized');
          if (btnEditorMaximize) btnEditorMaximize.textContent = '🗖';
        }
        if (engine.wm.activeWindowId === 'editor') {
          windowEditor.classList.add('active-window');
        } else {
          windowEditor.classList.remove('active-window');
        }
      } else {
        windowEditor.style.display = 'none';
      }
    }

    // 2. Explorer Window
    const winEx = engine.wm.windows.explorer;
    if (windowExplorer) {
      if (winEx.isOpen && !winEx.isMinimized) {
        windowExplorer.style.display = 'flex';
        windowExplorer.style.zIndex = String(winEx.zIndex);
        if (winEx.isMaximized) {
          windowExplorer.classList.add('maximized');
          if (btnExplorerMaximize) btnExplorerMaximize.textContent = '🗗';
        } else {
          windowExplorer.classList.remove('maximized');
          if (btnExplorerMaximize) btnExplorerMaximize.textContent = '🗖';
        }
        if (engine.wm.activeWindowId === 'explorer') {
          windowExplorer.classList.add('active-window');
        } else {
          windowExplorer.classList.remove('active-window');
        }
      } else {
        windowExplorer.style.display = 'none';
      }
    }

    // 3. Trash Window
    const winTr = engine.wm.windows.trash;
    if (windowTrash) {
      if (winTr.isOpen && !winTr.isMinimized) {
        windowTrash.style.display = 'flex';
        windowTrash.style.zIndex = String(winTr.zIndex);
      } else {
        windowTrash.style.display = 'none';
      }
    }

    // 4. Task Manager Window
    const winTm = engine.wm.windows.taskmgr;
    const windowTaskManager = document.getElementById('windowTaskManager');
    if (windowTaskManager) {
      if (winTm.isOpen && !winTm.isMinimized) {
        windowTaskManager.style.display = 'flex';
        windowTaskManager.style.zIndex = String(winTm.zIndex);
        if (engine.wm.activeWindowId === 'taskmgr') {
          windowTaskManager.classList.add('active-window');
        } else {
          windowTaskManager.classList.remove('active-window');
        }
      } else {
        windowTaskManager.style.display = 'none';
      }
    }

    // 5. Taskbar App Pills
    if (taskbarApps) {
      taskbarApps.innerHTML = '';
      Object.values(engine.wm.windows).forEach((w) => {
        if (!w.isOpen) return;
        const pill = document.createElement('button');
        pill.type = 'button';
        pill.className = `taskbar-app-btn ${engine.wm.activeWindowId === w.id && !w.isMinimized ? 'active' : ''}`;
        pill.id = `taskbar-pill-${w.id}`;
        pill.innerHTML = `<span>${w.icon}</span> <span>${w.title}</span>`;

        pill.addEventListener('click', (e) => {
          e.stopPropagation();
          if (w.isMinimized) {
            engine.wm.restoreWindow(w.id);
            if (engine.currentChallengeIndex === 1 && engine.c2Step === 3) {
              advanceChallenge2Step(4);
            }
          } else if (engine.wm.activeWindowId === w.id) {
            engine.wm.minimizeWindow(w.id);
          } else {
            engine.wm.bringToFront(w.id);
          }
          updateWindowsUI();
        });

        taskbarApps.appendChild(pill);
      });
    }
  }

  function openApp(appId) {
    engine.wm.openWindow(appId);
    updateWindowsUI();

    if (engine.currentChallengeIndex === 1 && engine.c2Step === 0 && appId === 'editor') {
      advanceChallenge2Step(1);
    }
    if (engine.currentChallengeIndex === 3 && engine.c4Step === 0 && appId === 'editor') {
      advanceChallenge4Step(1);
    }
    if (engine.currentChallengeIndex === 4 && appId === 'editor') {
      engine.c5Tasks.editorOpened = true;
      checkChallenge5Progress();
    }
  }

  function openFolder(folderId) {
    const folder = engine.fs.getItem(folderId);
    if (!folder) return;

    engine.wm.windows.explorer.currentFolderId = folderId;
    engine.wm.openWindow('explorer');
    renderExplorerContent(folderId);
    updateWindowsUI();

    if (engine.currentChallengeIndex === 2 && engine.c3Step <= 3) {
      if (folder.name.toLowerCase().includes('informatique')) {
        advanceChallenge3Step(4);
      }
    }

    if (engine.currentChallengeIndex === 4) {
      if (folder.name.toLowerCase().includes('informatique')) {
        engine.c5Tasks.folderOpened = true;
        checkChallenge5Progress();
      }
    }
  }

  function openFileInEditor(fileId) {
    const file = engine.fs.getItem(fileId);
    if (!file) return;

    if (editorTextarea) editorTextarea.value = file.content;
    if (winEditorTitle) winEditorTitle.textContent = `${file.name} — Éditeur de texte`;

    engine.wm.openWindow('editor');
    updateWindowsUI();

    showFeedback(`Document ouvert : ${file.name}`, 'info', '📄', 1500);

    if (engine.currentChallengeIndex === 4) {
      engine.c5Tasks.contentChecked = true;
      checkChallenge5Progress();
    }
  }

  function renderExplorerContent(folderId) {
    if (!explorerGrid) return;
    explorerGrid.innerHTML = '';

    const folder = engine.fs.getItem(folderId);
    const folderName = folder ? folder.name : 'Bureau';
    if (explorerAddressPath) explorerAddressPath.textContent = `Bureau > ${folderName}`;
    if (winExplorerTitle)
      winExplorerTitle.textContent = `Explorateur de fichiers — ${folderName}`;

    const children = engine.fs.getChildren(folderId);
    if (explorerStatusCount) {
      explorerStatusCount.textContent = `${children.length} élément(s)`;
    }

    if (children.length === 0) {
      const emptyMsg = document.createElement('div');
      emptyMsg.className = 'explorer-empty-msg';
      emptyMsg.textContent = 'Ce dossier est vide.';
      explorerGrid.appendChild(emptyMsg);
      return;
    }

    children.forEach((item) => {
      const itemEl = document.createElement('div');
      itemEl.className = 'desktop-icon';
      itemEl.id = `exp-${item.id}`;
      itemEl.setAttribute('draggable', 'true');
      itemEl.setAttribute('role', 'button');
      itemEl.setAttribute('tabindex', '0');
      itemEl.innerHTML = `
        <span class="desktop-icon-img" aria-hidden="true">${item.icon}</span>
        <span class="desktop-icon-label">${item.name}</span>
      `;

      itemEl.addEventListener('dragstart', (e) => {
        e.dataTransfer.setData('text/plain', item.id);
        e.dataTransfer.effectAllowed = 'move';
        itemEl.classList.add('is-dragging');
        engine.selectedDesktopItemId = item.id;
      });

      itemEl.addEventListener('dragend', () => {
        itemEl.classList.remove('is-dragging');
        document
          .querySelectorAll('.drag-target-hover')
          .forEach((node) => node.classList.remove('drag-target-hover'));
      });

      itemEl.addEventListener('click', (e) => {
        e.stopPropagation();
        explorerGrid
          .querySelectorAll('.desktop-icon')
          .forEach((i) => i.classList.remove('selected'));
        itemEl.classList.add('selected');
        engine.selectedDesktopItemId = item.id;
      });

      itemEl.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        e.stopPropagation();
        engine.selectedDesktopItemId = item.id;
        openContextMenu(e.clientX, e.clientY, 'item');
      });

      itemEl.addEventListener('dblclick', () => {
        if (item.type === 'folder') {
          openFolder(item.id);
        } else if (item.type === 'file') {
          openFileInEditor(item.id);
        }
      });

      explorerGrid.appendChild(itemEl);

      // In Challenge 5, verify document inside folder
      if (engine.currentChallengeIndex === 4 && item.name.includes('Mon premier document')) {
        engine.c5Tasks.docVerified = true;
        checkChallenge5Progress();
      }
    });
  }

  // ==========================================================================
  // 11. CONTEXT MENUS & ACCESSIBLE CREATION
  // ==========================================================================
  const EXPLAINER_POSITIONS = ['pos-tr', 'pos-br', 'pos-bl', 'pos-tl'];
  let explainerPosIndex = 0;

  function cycleExplainerPosition() {
    if (!eduExplainerCard) return;
    eduExplainerCard.classList.remove(...EXPLAINER_POSITIONS);
    explainerPosIndex = (explainerPosIndex + 1) % EXPLAINER_POSITIONS.length;
    eduExplainerCard.classList.add(EXPLAINER_POSITIONS[explainerPosIndex]);
    showFeedback("Panneau d'aide déplacé.", 'info', '⇄', 1000);
  }

  function setupWindowDraggable(winEl, titlebarEl, appId) {
    if (!winEl || !titlebarEl) return;
    let isDragging = false;
    let startX = 0;
    let startY = 0;
    let origLeft = 0;
    let origTop = 0;

    titlebarEl.addEventListener('pointerdown', (e) => {
      if (e.target.closest('.win-btn') || e.target.closest('.menu-item-btn')) return;
      if (e.button !== 0) return;

      engine.wm.bringToFront(appId);
      updateWindowsUI();

      isDragging = true;
      titlebarEl.classList.add('dragging');
      titlebarEl.setPointerCapture(e.pointerId);

      const winRect = winEl.getBoundingClientRect();
      const desktopRect = simulatedDesktop.getBoundingClientRect();

      if (engine.wm.windows[appId]?.isMaximized) {
        engine.wm.unmaximizeWindow(appId);
        updateWindowsUI();
        const restoredRect = winEl.getBoundingClientRect();
        origLeft = Math.max(0, e.clientX - desktopRect.left - restoredRect.width / 2);
        origTop = Math.max(0, e.clientY - desktopRect.top - 18);
        winEl.style.left = `${origLeft}px`;
        winEl.style.top = `${origTop}px`;
        if (engine.currentChallengeIndex === 1 && engine.c2Step === 5) {
          advanceChallenge2Step(6);
        }
      } else {
        origLeft = winRect.left - desktopRect.left;
        origTop = winRect.top - desktopRect.top;
      }

      startX = e.clientX;
      startY = e.clientY;
    });

    titlebarEl.addEventListener('pointermove', (e) => {
      if (!isDragging) return;

      const desktopRect = simulatedDesktop.getBoundingClientRect();
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;

      let newLeft = origLeft + dx;
      let newTop = origTop + dy;

      newLeft = Math.max(0, Math.min(newLeft, desktopRect.width - 150));
      newTop = Math.max(0, Math.min(newTop, desktopRect.height - 44 - 36));

      winEl.style.left = `${newLeft}px`;
      winEl.style.top = `${newTop}px`;

      // Check if dragged to top to maximize
      const snapPreview = document.getElementById('windowSnapPreview');
      if (snapPreview) {
        if (e.clientY <= desktopRect.top + 16) {
          snapPreview.classList.add('active');
        } else {
          snapPreview.classList.remove('active');
        }
      }
    });

    const onPointerUp = (e) => {
      if (!isDragging) return;
      isDragging = false;
      titlebarEl.classList.remove('dragging');
      try {
        titlebarEl.releasePointerCapture(e.pointerId);
      } catch {
        // safe
      }

      const snapPreview = document.getElementById('windowSnapPreview');
      if (snapPreview) snapPreview.classList.remove('active');

      const desktopRect = simulatedDesktop.getBoundingClientRect();
      if (e.clientY <= desktopRect.top + 16) {
        engine.wm.maximizeWindow(appId);
        updateWindowsUI();
        showFeedback('Fenêtre agrandie au maximum !', 'info', '🗖', 1200);

        if (engine.currentChallengeIndex === 1 && engine.c2Step === 4) {
          advanceChallenge2Step(5);
        }
      }
    };

    titlebarEl.addEventListener('pointerup', onPointerUp);
    titlebarEl.addEventListener('pointercancel', onPointerUp);

    // Double-click on titlebar to toggle maximize
    titlebarEl.addEventListener('dblclick', (e) => {
      if (e.target.closest('.win-btn') || e.target.closest('.menu-item-btn')) return;
      const win = engine.wm.windows[appId];
      if (win) {
        engine.wm.toggleMaximize(appId);
        updateWindowsUI();
        if (engine.currentChallengeIndex === 1) {
          if (win.isMaximized && engine.c2Step === 4) advanceChallenge2Step(5);
          else if (!win.isMaximized && engine.c2Step === 5) advanceChallenge2Step(6);
        }
      }
    });
  }

  function openContextMenu(clientX, clientY, targetType = 'desktop') {
    if (!desktopContextMenu || !simulatedDesktop) return;

    engine.cmenuTargetType = targetType;
    const desktopRect = simulatedDesktop.getBoundingClientRect();
    const menuWidth = 210;
    const menuHeight = targetType === 'desktop' ? 260 : targetType === 'taskbar' ? 140 : 220;

    let relX = clientX - desktopRect.left;
    let relY = clientY - desktopRect.top;

    if (relX + menuWidth > desktopRect.width) {
      relX = desktopRect.width - menuWidth - 8;
    }
    if (relY + menuHeight > desktopRect.height) {
      relY = desktopRect.height - menuHeight - 8;
    }

    desktopContextMenu.style.left = `${Math.max(8, relX)}px`;
    desktopContextMenu.style.top = `${Math.max(8, relY)}px`;
    desktopContextMenu.classList.add('active');

    const cmenuDesktopSection = document.getElementById('cmenuDesktopSection');
    const cmenuItemSection = document.getElementById('cmenuItemSection');
    const cmenuTaskbarSection = document.getElementById('cmenuTaskbarSection');
    const cmenuExplorerSection = document.getElementById('cmenuExplorerSection');
    const cmenuPaste = document.getElementById('cmenuPaste');
    const cmenuItemPaste = document.getElementById('cmenuItemPaste');
    const cmenuExplorerPaste = document.getElementById('cmenuExplorerPaste');

    if (cmenuDesktopSection) cmenuDesktopSection.style.display = targetType === 'desktop' ? 'block' : 'none';
    if (cmenuItemSection) cmenuItemSection.style.display = targetType === 'item' ? 'block' : 'none';
    if (cmenuTaskbarSection) cmenuTaskbarSection.style.display = targetType === 'taskbar' ? 'block' : 'none';
    if (cmenuExplorerSection) cmenuExplorerSection.style.display = targetType === 'explorer' ? 'block' : 'none';

    // Show paste on folder items if item is copied/cut
    if (cmenuItemPaste) {
      const selectedItem = engine.fs.getItem(engine.selectedDesktopItemId);
      if (selectedItem?.type === 'folder') {
        cmenuItemPaste.style.display = 'flex';
        if (engine.clipboardItem) {
          cmenuItemPaste.classList.remove('disabled');
        } else {
          cmenuItemPaste.classList.add('disabled');
        }
      } else {
        cmenuItemPaste.style.display = 'none';
      }
    }

    if (cmenuPaste) {
      if (engine.clipboardItem) {
        cmenuPaste.classList.remove('disabled');
      } else {
        cmenuPaste.classList.add('disabled');
      }
    }

    if (cmenuExplorerPaste) {
      if (engine.clipboardItem) {
        cmenuExplorerPaste.classList.remove('disabled');
      } else {
        cmenuExplorerPaste.classList.add('disabled');
      }
    }
  }

  function executePaste(targetFolderId = 'desktop') {
    closeContextMenu();
    if (!engine.clipboardItem) {
      showFeedback('Rien à coller. Copie ou coupe d’abord un élément.', 'info', '📋', 1500);
      return;
    }

    const item = engine.fs.getItem(engine.clipboardItem.id);
    if (!item) {
      engine.clipboardItem = null;
      return;
    }

    const folder = targetFolderId === 'desktop' ? { name: 'le bureau' } : engine.fs.getItem(targetFolderId);
    const folderName = folder ? folder.name : 'le dossier';

    if (engine.clipboardItem.mode === 'cut') {
      engine.fs.moveItem(item.id, targetFolderId);
      engine.clipboardItem = null;
      showFeedback(`« ${item.name} » déplacé dans ${folderName}.`, 'success', '✂️', 2000);
    } else {
      if (item.type === 'file') {
        const copyName =
          item.parentId === targetFolderId
            ? `Copie de ${item.baseName || item.name}`
            : item.baseName || item.name;
        engine.fs.createFile(targetFolderId, copyName, item.content, item.extension);
      } else {
        const copyName =
          item.parentId === targetFolderId ? `Copie de ${item.name}` : item.name;
        engine.fs.createFolder(targetFolderId, copyName);
      }
      showFeedback(`« ${item.name} » collé dans ${folderName}.`, 'success', '📋', 2000);
    }

    renderDesktopIcons();
    if (engine.wm.windows.explorer.isOpen) {
      renderExplorerContent(engine.wm.windows.explorer.currentFolderId);
    }
    engine.saveToStorage();

    // Challenge 5 verification
    if (engine.currentChallengeIndex === 4) {
      const infoFolder = engine.fs.findByName('Informatique');
      if (infoFolder && targetFolderId === infoFolder.id) {
        if (item.name.includes('Mon premier document')) {
          engine.c5Tasks.docMoved = true;
          checkChallenge5Progress();
        }
      }
    }
  }

  function closeContextMenu() {
    if (desktopContextMenu) {
      desktopContextMenu.classList.remove('active');
    }
  }

  function handleCreateFolder() {
    closeContextMenu();

    // If in Challenge 3 and an Informatique folder already exists on the desktop
    if (engine.currentChallengeIndex === 2) {
      const existingFolder = engine.fs.getChildren('desktop').find(
        (it) => it.type === 'folder' && it.name.toLowerCase().includes('informatique'),
      );
      if (existingFolder) {
        if (engine.c3Step < 3) {
          advanceChallenge3Step(3);
        }
        showFeedback(
          'Le dossier « Informatique » est prêt ! Double-clique dessus pour l’ouvrir.',
          'info',
          '📁',
          2500,
        );
        return;
      }
    }

    const folder = engine.fs.createFolder('desktop', 'Nouveau dossier');
    renderDesktopIcons();

    showFeedback('Nouveau dossier créé sur le bureau.', 'success', '📁', 1500);

    // If in Challenge 3
    if (engine.currentChallengeIndex === 2) {
      if (engine.c3Step <= 1) {
        advanceChallenge3Step(2);
      }
      promptRenameFolder(folder.id, 'Informatique');
    } else if (engine.currentChallengeIndex === 4) {
      promptRenameFolder(folder.id, 'Informatique');
    } else {
      promptRenameFolder(folder.id);
    }
  }

  function promptRenameFolder(folderId, autoFocusSuggested = '') {
    const labelEl = document.getElementById(`label-${folderId}`);
    if (!labelEl) return;

    const currentName = labelEl.textContent;
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'desktop-icon-label-input';
    input.value = autoFocusSuggested || currentName;

    labelEl.replaceWith(input);
    input.focus();
    input.select();

    let committed = false;
    const commitRename = () => {
      if (committed) return;
      committed = true;
      const val = input.value.trim() || currentName;
      engine.fs.renameItem(folderId, val);
      renderDesktopIcons();

      // Check validation for Challenge 3
      if (engine.currentChallengeIndex === 2) {
        if (engine.c3Step <= 2 && val.toLowerCase().includes('informatique')) {
          advanceChallenge3Step(3);
        } else if (
          (engine.c3Step === 5 || engine.c3Step === 4) &&
          (val.toLowerCase().includes('mon cours') || val.toLowerCase().includes('cours'))
        ) {
          advanceChallenge3Step(6);
        }
      }

      // Check validation for Challenge 5
      if (engine.currentChallengeIndex === 4) {
        if (val.toLowerCase().includes('informatique')) {
          engine.c5Tasks.folderCreated = true;
          checkChallenge5Progress();
        }
      }
    };

    input.addEventListener('blur', commitRename);
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        commitRename();
      } else if (e.key === 'Escape') {
        input.value = currentName;
        commitRename();
      }
    });
  }

  // ==========================================================================
  // 12. CHALLENGE PROGRESSION & VALIDATION ENGINE
  // ==========================================================================

  function renderCurrentChallenge() {
    hideFeedback();
    closeContextMenu();
    updateTabs();

    const cIdx = engine.currentChallengeIndex;
    const config = CHALLENGES_CONFIG[cIdx];
    const isAr = engine.currentLang === 'ar';

    if (challengeBadge) challengeBadge.textContent = `Défi ${cIdx + 1}/5`;
    if (instructionTitle) instructionTitle.textContent = isAr ? config.titleAr : config.titleFr;
    if (instructionSub)
      instructionSub.textContent = isAr ? config.instructionsAr : config.instructionsFr;
    if (vocabHighlight) vocabHighlight.textContent = isAr ? config.vocabAr : config.vocabFr;
    if (scoreValue) scoreValue.textContent = String(engine.score);

    const pct = ((cIdx + 1) / 5) * 100;
    if (challengeProgressFill) challengeProgressFill.style.width = `${pct}%`;

    if (btnNextChallenge) btnNextChallenge.style.display = 'none';

    renderDesktopIcons();
    updateWindowsUI();

    switch (cIdx) {
      case 0:
        renderChallenge1();
        break;
      case 1:
        renderChallenge2();
        break;
      case 2:
        renderChallenge3();
        break;
      case 3:
        renderChallenge4();
        break;
      case 4:
        renderChallenge5();
        break;
    }
  }

  // --------------------------------------------------------------------------
  // Challenge 1 : Découvrir le bureau
  // --------------------------------------------------------------------------
  function renderChallenge1() {
    if (stepBadge) stepBadge.textContent = `${engine.discoveredElements.size}/6 découverts`;
    if (elementsChecklist) {
      elementsChecklist.style.display = 'grid';
      elementsChecklist.innerHTML = DESKTOP_ELEMENTS.map((el) => {
        const isDone = engine.discoveredElements.has(el.id);
        const name = engine.currentLang === 'ar' ? el.nameAr : el.nameFr;
        return `
          <div class="check-item ${isDone ? 'done' : ''}">
            <span>${isDone ? '✅' : '⚪'}</span>
            <span>${name}</span>
          </div>
        `;
      }).join('');
    }
    if (missionChecklist) missionChecklist.style.display = 'none';

    // Show educational card prompt
    showExplainerCard(
      'DÉCOUVRIR',
      'Bienvenue sur le bureau !',
      "Clique sur les différents éléments visibles à l'écran (le fond, les icônes, la barre des tâches, le bouton Démarrer, la corbeille) pour apprendre leur nom et leur utilité.",
    );
  }

  function handleDiscoverElement(elemId) {
    const elem = DESKTOP_ELEMENTS.find((e) => e.id === elemId);
    if (!elem) return;

    engine.discoveredElements.add(elemId);
    engine.recordSuccess(0, 15);
    scoreValue.textContent = String(engine.score);

    if (stepBadge) stepBadge.textContent = `${engine.discoveredElements.size}/6 découverts`;

    showExplainerCard(
      'COMPRENDRE',
      engine.currentLang === 'ar' ? elem.nameAr : elem.nameFr,
      engine.currentLang === 'ar' ? elem.descAr : elem.descFr,
    );

    showFeedback(
      `Élément identifié : ${engine.currentLang === 'ar' ? elem.nameAr : elem.nameFr}`,
      'success',
      '✨',
      2000,
    );

    // Update checklist in card
    renderChallenge1();

    if (engine.discoveredElements.size === 6) {
      engine.completeCurrentChallenge();
      showFeedback(
        'Bravo ! Tu as découvert tous les éléments fondamentaux du bureau !',
        'success',
        '🎉',
        3000,
      );
      if (btnNextChallenge) btnNextChallenge.style.display = 'inline-flex';
    }
    engine.saveToStorage();
  }

  // --------------------------------------------------------------------------
  // Challenge 2 : Découvrir les fenêtres et les applications
  // --------------------------------------------------------------------------
  const C2_STEPS = [
    {
      step: 0,
      titleFr: "1/7 : Ouvrir l'application",
      instructionFr:
        "Double-clique sur l'icône de l'Éditeur de texte sur le bureau pour ouvrir l'application.",
      vocabFr: 'Une application',
    },
    {
      step: 1,
      titleFr: '2/7 : La barre de titre',
      instructionFr:
        "Observe la barre de titre en haut de la fenêtre. Clique sur la barre de titre pour l'inspecter.",
      vocabFr: 'La barre de titre',
    },
    {
      step: 2,
      titleFr: '3/7 : Réduire la fenêtre',
      instructionFr:
        'Clique sur le bouton Réduire (—) pour masquer la fenêtre dans la barre des tâches.',
      vocabFr: 'Réduire (—)',
    },
    {
      step: 3,
      titleFr: '4/7 : Restaurer depuis la barre des tâches',
      instructionFr:
        'La fenêtre a disparu du bureau mais l’application reste ouverte. Clique sur son icône dans la barre des tâches.',
      vocabFr: 'Restaurer',
    },
    {
      step: 4,
      titleFr: '5/7 : Agrandir la fenêtre',
      instructionFr:
        'Clique sur le bouton Agrandir (🗖) pour que la fenêtre occupe tout l’espace de l’écran.',
      vocabFr: 'Agrandir (🗖)',
    },
    {
      step: 5,
      titleFr: '6/7 : Restaurer la taille',
      instructionFr:
        'Clique sur le bouton Restaurer (🗗) pour redonner à la fenêtre sa taille normale.',
      vocabFr: 'Restaurer (🗗)',
    },
    {
      step: 6,
      titleFr: '7/7 : Fermer la fenêtre',
      instructionFr:
        'Clique sur le bouton Fermer (✕) pour quitter l’application.',
      vocabFr: 'Fermer (✕)',
    },
  ];

  function renderChallenge2() {
    const stepInfo = C2_STEPS[engine.c2Step] || C2_STEPS[0];
    if (stepBadge) stepBadge.textContent = stepInfo.titleFr;
    if (instructionSub) instructionSub.textContent = stepInfo.instructionFr;
    if (vocabHighlight) vocabHighlight.textContent = stepInfo.vocabFr;
    if (elementsChecklist) elementsChecklist.style.display = 'none';

    showExplainerCard(
      'FENÊTRES',
      stepInfo.vocabFr,
      stepInfo.instructionFr,
    );
  }

  function advanceChallenge2Step(targetStep) {
    engine.c2Step = targetStep;
    engine.recordSuccess(1, 20);
    scoreValue.textContent = String(engine.score);

    if (engine.c2Step >= 7) {
      // Completed Challenge 2
      engine.completeCurrentChallenge();
      showFeedback(
        'Excellent ! Tu maîtrises parfaitement la manipulation des fenêtres d’applications.',
        'success',
        '🏆',
        3000,
      );
      if (btnNextChallenge) btnNextChallenge.style.display = 'inline-flex';
    } else {
      renderChallenge2();
    }
    engine.saveToStorage();
  }

  // --------------------------------------------------------------------------
  // Challenge 3 : Créer et organiser des dossiers
  // --------------------------------------------------------------------------
  const C3_STEPS = [
    {
      step: 0,
      titleFr: '1/6 : Clic droit sur le bureau',
      descFr:
        'Fais un clic droit sur un endroit vide du bureau (ou clique sur le bouton « Menu contextuel » en haut).',
      vocabFr: 'Menu contextuel',
    },
    {
      step: 1,
      titleFr: '2/6 : Choisir Nouveau > Dossier',
      descFr: 'Dans le menu contextuel, choisis « Nouveau » puis clique sur « Dossier ».',
      vocabFr: 'Nouveau dossier',
    },
    {
      step: 2,
      titleFr: '3/6 : Nommer le dossier',
      descFr: 'Tape le nom « Informatique » pour le dossier puis appuie sur la touche Entrée.',
      vocabFr: 'Nommer un dossier',
    },
    {
      step: 3,
      titleFr: '4/6 : Ouvrir le dossier',
      descFr: 'Double-clique sur le dossier « Informatique » pour l’ouvrir dans l’explorateur.',
      vocabFr: 'Ouvrir un dossier',
    },
    {
      step: 4,
      titleFr: '5/6 : Revenir au bureau',
      descFr: 'Ferme la fenêtre de l’explorateur pour revenir au bureau.',
      vocabFr: 'Fermer l’explorateur',
    },
    {
      step: 5,
      titleFr: '6/6 : Renommer le dossier',
      descFr:
        'Fais un clic droit sur le dossier « Informatique », choisis « Renommer » et nomme-le : « Mon cours d’informatique ».',
      vocabFr: 'Renommer',
    },
  ];

  function renderChallenge3() {
    // If student already has an Informatique folder on desktop
    if (engine.c3Step < 3) {
      const hasInformatique = engine.fs.getChildren('desktop').some(
        (it) => it.type === 'folder' && it.name.toLowerCase().includes('informatique'),
      );
      if (hasInformatique) {
        engine.c3Step = 3;
      }
    }

    const stepInfo = C3_STEPS[engine.c3Step] || C3_STEPS[0];
    if (stepBadge) stepBadge.textContent = stepInfo.titleFr;
    if (instructionSub) instructionSub.textContent = stepInfo.descFr;
    if (vocabHighlight) vocabHighlight.textContent = stepInfo.vocabFr;

    showExplainerCard(
      'DOSSIERS',
      'Un dossier',
      "Un dossier permet de regrouper et d'organiser des fichiers, comme un classeur pour des feuilles de papier. Un dossier contient des fichiers, tandis qu'un fichier contient des informations.",
    );
  }

  function advanceChallenge3Step(targetStep) {
    engine.c3Step = targetStep;
    engine.recordSuccess(2, 25);
    scoreValue.textContent = String(engine.score);

    if (engine.c3Step >= 6) {
      engine.completeCurrentChallenge();
      showFeedback(
        'Félicitations ! Tu sais créer, ouvrir et renommer des dossiers d’ordinateur.',
        'success',
        '📁',
        3000,
      );
      if (btnNextChallenge) btnNextChallenge.style.display = 'inline-flex';
    } else {
      renderChallenge3();
    }
    engine.saveToStorage();
  }

  // --------------------------------------------------------------------------
  // Challenge 4 : Créer et enregistrer un document texte
  // --------------------------------------------------------------------------
  const C4_STEPS = [
    {
      step: 0,
      titleFr: "1/4 : Ouvrir l'éditeur",
      descFr: "Double-clique sur l'Éditeur de texte pour lancer l'application d'écriture.",
      vocabFr: 'Éditeur de texte',
    },
    {
      step: 1,
      titleFr: '2/4 : Écrire une phrase',
      descFr:
        "Écris une phrase dans la zone de texte (par exemple : « Je découvre l'informatique. »).",
      vocabFr: 'Écrire un texte',
    },
    {
      step: 2,
      titleFr: '3/4 : Enregistrer sous',
      descFr: 'Clique sur le bouton « Enregistrer » (ou « Enregistrer sous... »).',
      vocabFr: 'Enregistrer',
    },
    {
      step: 3,
      titleFr: '4/4 : Nommer le document',
      descFr:
        "Dans la boîte de dialogue, donne le nom « Mon premier document » puis valide avec « Enregistrer ».",
      vocabFr: 'Extension (.txt)',
    },
  ];

  function renderChallenge4() {
    // If the editor is already open on entering Challenge 4, advance past step 0
    if (engine.c4Step === 0 && engine.wm.windows.editor?.isOpen && !engine.wm.windows.editor?.isMinimized) {
      engine.c4Step = 1;
    }

    const stepInfo = C4_STEPS[engine.c4Step] || C4_STEPS[0];
    if (stepBadge) stepBadge.textContent = stepInfo.titleFr;
    if (instructionSub) instructionSub.textContent = stepInfo.descFr;
    if (vocabHighlight) vocabHighlight.textContent = stepInfo.vocabFr;

    showExplainerCard(
      'DOCUMENTS',
      'Un document texte',
      "Un document est un fichier qui contient du texte rédigé. Pour ne pas perdre ton travail, il faut toujours l'enregistrer dans un dossier ou sur le bureau.",
    );
  }

  function advanceChallenge4Step(targetStep) {
    engine.c4Step = targetStep;
    engine.recordSuccess(3, 25);
    scoreValue.textContent = String(engine.score);

    if (engine.c4Step >= 4) {
      engine.completeCurrentChallenge();
      showFeedback(
        'Bravo ! Ton premier document texte a été rédigé et enregistré avec succès !',
        'success',
        '📝',
        3000,
      );
      if (btnNextChallenge) btnNextChallenge.style.display = 'inline-flex';
    } else {
      renderChallenge4();
    }
    engine.saveToStorage();
  }

  // --------------------------------------------------------------------------
  // Challenge 5 : Mission finale autonome
  // --------------------------------------------------------------------------
  function renderChallenge5() {
    if (stepBadge) stepBadge.textContent = 'Mission autonome';
    if (instructionSub) {
      instructionSub.textContent =
        'Organise ton espace de travail en autonomie selon les 8 étapes de la mission ci-contre.';
    }
    if (vocabHighlight) vocabHighlight.textContent = 'Organisation du bureau';

    if (missionChecklist) {
      missionChecklist.style.display = 'flex';
      const tasks = [
        { key: 'folderCreated', label: '1. Créer un dossier nommé « Informatique »' },
        { key: 'editorOpened', label: "2. Ouvrir l'éditeur de texte" },
        { key: 'textWritten', label: '3. Écrire une phrase sur ce que tu as appris' },
        { key: 'docSaved', label: '4. Enregistrer sous le nom « Mon premier document »' },
        { key: 'docMoved', label: '5. Placer le document dans le dossier « Informatique »' },
        { key: 'folderOpened', label: '6. Ouvrir le dossier « Informatique »' },
        { key: 'docVerified', label: '7. Vérifier que le document se trouve à l’intérieur' },
        { key: 'contentChecked', label: '8. Ouvrir le document pour vérifier son contenu' },
      ];

      missionChecklist.innerHTML = tasks
        .map((t) => {
          const isDone = engine.c5Tasks[t.key];
          return `
            <div class="mission-task ${isDone ? 'done' : ''}">
              <span class="mission-task-check">${isDone ? '✅' : '⚪'}</span>
              <span>${t.label}</span>
            </div>
          `;
        })
        .join('');
    }

    showExplainerCard(
      'MISSION',
      'Mission finale',
      "Applique tout ce que tu as appris en totale autonomie ! Si tu as un doute, clique sur le bouton « Indice » en haut pour obtenir une suggestion.",
    );
  }

  function checkChallenge5Progress() {
    // Check actual simulated file system state!
    const folder = engine.fs.findByName('Informatique');
    if (folder) {
      engine.c5Tasks.folderCreated = true;
    }

    const doc = engine.fs.findByName('Mon premier document');
    if (doc) {
      engine.c5Tasks.docSaved = true;
      if (doc.content && doc.content.length > 5) {
        engine.c5Tasks.textWritten = true;
      }
      if (folder && doc.parentId === folder.id) {
        engine.c5Tasks.docMoved = true;
      }
    }

    renderChallenge5();

    const allTasksDone = Object.values(engine.c5Tasks).every(Boolean);
    if (allTasksDone) {
      engine.completeCurrentChallenge();
      showResultsScreen();
    }
  }

  // Helper Explainer Card
  function showExplainerCard(badge, title, desc) {
    if (!eduExplainerCard) return;
    if (explainerBadge) explainerBadge.textContent = badge;
    if (explainerTitle) explainerTitle.textContent = title;
    if (explainerDesc) explainerDesc.textContent = desc;
    eduExplainerCard.style.display = 'flex';
  }

  // ==========================================================================
  // 13. RESULTS & TELEMETRY PERSISTENCE
  // ==========================================================================
  function showResultsScreen() {
    showScreen('results');
    const summary = engine.getSummary();

    if (resTotalScore) resTotalScore.textContent = String(summary.score);
    if (resCompletedChallenges)
      resCompletedChallenges.textContent = `${summary.completedChallenges} / 5`;
    if (resSuccessfulActions)
      resSuccessfulActions.textContent = String(summary.successfulActions);
    if (resTotalAttempts) resTotalAttempts.textContent = String(summary.totalAttempts);
    if (resDuration) resDuration.textContent = summary.formattedDuration;

    if (resultsBreakdownList) {
      resultsBreakdownList.innerHTML = summary.challengeDetails
        .map(
          (c) => `
          <li class="breakdown-item">
            <span class="breakdown-name">
              <span>${c.completed ? '✅' : '⚪'}</span>
              <span>${c.title} (<strong>${c.vocab}</strong>)</span>
            </span>
            <span class="breakdown-status">
              ${c.completed ? `Réussi (${c.attempts} tent.)` : 'En cours'}
            </span>
          </li>
        `,
        )
        .join('');
    }

    reportProgressToTeachit(true);
  }

  function reportProgressToTeachit(isComplete = true) {
    if (engine.sessionReported) return;
    engine.sessionReported = true;

    const teachit = getTeachit();
    if (!teachit || typeof teachit.reportProgress !== 'function') {
      if (saveStatusMsg) {
        saveStatusMsg.textContent = TRANSLATIONS[engine.currentLang].guestStatus;
      }
      return;
    }

    if (saveStatusMsg) {
      saveStatusMsg.textContent = TRANSLATIONS[engine.currentLang].savingStatus;
      if (saveStatusIcon) saveStatusIcon.textContent = '⏳';
    }

    const summary = engine.getSummary();
    const isSuccess = isComplete && summary.completedChallenges >= 5;
    const eventType = isSuccess ? 'activity_completed' : 'score_recorded';

    teachit
      .reportProgress({
        activityId: 'desktop-explorer-complete',
        eventType,
        payload: {
          score: summary.score,
          maxScore: 500,
          durationSeconds: summary.durationSeconds,
          success: isSuccess,
          metrics: {
            completedChallenges: summary.completedChallenges,
            totalChallenges: 5,
            totalAttempts: summary.totalAttempts,
            successfulActions: summary.successfulActions,
            durationSeconds: summary.durationSeconds,
            status: isSuccess ? 'completed' : 'abandoned',
            challenge1_desktop: engine.completedChallenges.has(0),
            challenge2_windows: engine.completedChallenges.has(1),
            challenge3_folders: engine.completedChallenges.has(2),
            challenge4_documents: engine.completedChallenges.has(3),
            challenge5_mission: engine.completedChallenges.has(4),
          },
        },
      })
      .then((res) => {
        if (res && res.success) {
          if (saveStatusMsg) {
            saveStatusMsg.textContent = TRANSLATIONS[engine.currentLang].savedSuccess;
          }
          if (saveStatusIcon) saveStatusIcon.textContent = '✅';
          if (saveStatusBox) saveStatusBox.classList.add('saved');
        } else {
          if (saveStatusMsg) {
            saveStatusMsg.textContent = res?.error || TRANSLATIONS[engine.currentLang].guestStatus;
          }
        }
      })
      .catch((err) => {
        if (saveStatusMsg) {
          saveStatusMsg.textContent = `Erreur : ${String(err)}`;
        }
      });
  }

  function handleExitGame() {
    if (engine.completedChallenges.size < 5 && !engine.sessionReported) {
      reportProgressToTeachit(false);
    }

    const teachit = getTeachit();
    if (teachit && typeof teachit.exitGame === 'function') {
      teachit.exitGame().catch(() => {
        window.close();
      });
    } else {
      window.close();
    }
  }

  // ==========================================================================
  // 14. EVENT LISTENERS SETUP
  // ==========================================================================
  function setupListeners() {
    // Language Toggle
    if (btnToggleLang) {
      btnToggleLang.addEventListener('click', () => {
        const next = engine.currentLang === 'fr' ? 'ar' : 'fr';
        applyLanguage(next);
      });
    }

    // Start & Exit Buttons
    if (btnStartGame) {
      btnStartGame.addEventListener('click', () => {
        if (!engine.hasSavedProgress()) {
          engine.start();
        }
        showScreen('game');
        renderCurrentChallenge();
      });
    }

    const btnRestartFresh = document.getElementById('btnRestartFresh');
    if (btnRestartFresh) {
      btnRestartFresh.addEventListener('click', () => {
        engine.resetAllProgress();
        updateTabs();
        showFeedback('Progression réinitialisée.', 'info', '🔄', 1500);
      });
    }

    if (btnExitWelcome) btnExitWelcome.addEventListener('click', handleExitGame);
    if (btnExitHeader) btnExitHeader.addEventListener('click', handleExitGame);
    if (btnExitResults) btnExitResults.addEventListener('click', handleExitGame);

    // Replay Button
    if (btnReplay) {
      btnReplay.addEventListener('click', () => {
        engine.start();
        showScreen('game');
        renderCurrentChallenge();
      });
    }

    // Navigation Tabs
    for (let i = 0; i < 5; i++) {
      const tab = document.getElementById(`tab${i}`);
      if (tab) {
        tab.addEventListener('click', () => {
          if (engine.unlockedChallenges.has(i)) {
            engine.goToChallenge(i);
            showScreen('game');
            renderCurrentChallenge();
          } else {
            showFeedback(
              'Ce défi est verrouillé. Termine les défis précédents pour le débloquer !',
              'info',
              '🔒',
            );
          }
        });
      }
    }

    // Previous / Next / Reset Footer Buttons
    if (btnPrevChallenge) {
      btnPrevChallenge.addEventListener('click', () => {
        if (engine.currentChallengeIndex > 0) {
          engine.goToChallenge(engine.currentChallengeIndex - 1);
          renderCurrentChallenge();
        }
      });
    }

    if (btnResetChallenge) {
      btnResetChallenge.addEventListener('click', () => {
        engine.recordAttempt(engine.currentChallengeIndex);
        engine.resetChallengeState(engine.currentChallengeIndex);
        renderCurrentChallenge();
        showFeedback('Défi réinitialisé.', 'info', '🔄', 1200);
      });
    }

    if (btnNextChallenge) {
      btnNextChallenge.addEventListener('click', () => {
        if (engine.currentChallengeIndex + 1 < 5) {
          engine.goToChallenge(engine.currentChallengeIndex + 1);
          renderCurrentChallenge();
        } else {
          showResultsScreen();
        }
      });
    }

    // Hint Button
    if (btnHint) {
      btnHint.addEventListener('click', () => {
        engine.recordAttempt(engine.currentChallengeIndex);
        let hintMsg = '';
        if (engine.currentChallengeIndex === 0) {
          hintMsg =
            'Clique sur le fond d’écran, les icônes, la barre des tâches en bas ou le bouton Démarrer !';
        } else if (engine.currentChallengeIndex === 1) {
          hintMsg =
            'Regarde les 3 boutons en haut à droite de la fenêtre : Réduire (—), Agrandir (🗖) et Fermer (✕).';
        } else if (engine.currentChallengeIndex === 2) {
          hintMsg =
            'Fais un clic droit dans une zone vide du bureau, choisis Nouveau > Dossier et nomme-le Informatique.';
        } else if (engine.currentChallengeIndex === 3) {
          hintMsg =
            'Tape une phrase dans l’éditeur puis clique sur Enregistrer sous pour sauvegarder ton fichier .txt.';
        } else if (engine.currentChallengeIndex === 4) {
          hintMsg =
            'Crée le dossier Informatique, écris dans l’éditeur, enregistre le document puis déplace-le dans le dossier !';
        }
        showFeedback(hintMsg, 'info', '💡', 5000);
      });
    }

    // Context Menu Helper Button (Accessible alternative to right click)
    if (btnContextMenuHelper) {
      btnContextMenuHelper.addEventListener('click', (e) => {
        e.stopPropagation();
        openContextMenu(200, 180, 'desktop');
        if (engine.currentChallengeIndex === 2 && engine.c3Step === 0) {
          advanceChallenge3Step(1);
        }
      });
    }

    // Desktop Click: Selection & Discovery
    if (simulatedDesktop) {
      simulatedDesktop.addEventListener('click', (e) => {
        closeContextMenu();
        if (startMenuPopover) startMenuPopover.classList.remove('active');

        // Check if desktop background clicked
        if (e.target === simulatedDesktop || e.target.id === 'desktopWallpaperArt') {
          if (engine.currentChallengeIndex === 0) {
            handleDiscoverElement('bureau');
            handleDiscoverElement('fond-ecran');
          }
        }
      });

      // Genuine Right Click on Desktop
      simulatedDesktop.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        openContextMenu(e.clientX, e.clientY, 'desktop');
        if (engine.currentChallengeIndex === 2 && engine.c3Step === 0) {
          advanceChallenge3Step(1);
        }
      });

      // Drop onto Desktop (e.g. dragging item from File Explorer to Desktop)
      simulatedDesktop.addEventListener('dragover', (e) => {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
      });

      simulatedDesktop.addEventListener('drop', (e) => {
        if (e.target.closest('.desktop-icon') || e.target.closest('.simulated-window')) return;
        e.preventDefault();
        const draggedId = e.dataTransfer.getData('text/plain');
        if (!draggedId) return;

        const draggedItem = engine.fs.getItem(draggedId);
        if (draggedItem && draggedItem.parentId !== 'desktop') {
          engine.fs.moveItem(draggedId, 'desktop');
          renderDesktopIcons();
          if (engine.wm.windows.explorer.isOpen) {
            renderExplorerContent(engine.wm.windows.explorer.currentFolderId);
          }
          showFeedback(`« ${draggedItem.name} » déplacé sur le bureau.`, 'info', '🖥️', 1500);
          engine.saveToStorage();
        }
      });
    }

    // Start Button
    if (btnStartMenu) {
      btnStartMenu.addEventListener('click', (e) => {
        e.stopPropagation();
        if (startMenuPopover) {
          startMenuPopover.classList.toggle('active');
        }
        if (engine.currentChallengeIndex === 0) {
          handleDiscoverElement('menu-demarrer');
        }
      });
    }

    // Taskbar Right Click
    if (simulatedTaskbar) {
      simulatedTaskbar.addEventListener('click', () => {
        if (engine.currentChallengeIndex === 0) {
          handleDiscoverElement('barre-taches');
        }
      });

      simulatedTaskbar.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        e.stopPropagation();
        openContextMenu(e.clientX, e.clientY, 'taskbar');
      });
    }

    // Start Menu Item Clicks
    const startItemEditor = document.getElementById('startItemEditor');
    if (startItemEditor) {
      startItemEditor.addEventListener('click', () => {
        if (startMenuPopover) startMenuPopover.classList.remove('active');
        openApp('editor');
      });
    }

    const startItemExplorer = document.getElementById('startItemExplorer');
    if (startItemExplorer) {
      startItemExplorer.addEventListener('click', () => {
        if (startMenuPopover) startMenuPopover.classList.remove('active');
        openApp('explorer');
      });
    }

    const startItemTrash = document.getElementById('startItemTrash');
    if (startItemTrash) {
      startItemTrash.addEventListener('click', () => {
        if (startMenuPopover) startMenuPopover.classList.remove('active');
        openApp('trash');
      });
    }

    // -------------------------------------------------------------
    // CONTEXT MENU HANDLERS
    // -------------------------------------------------------------

    // Desktop Context Menu: View icon sizes
    const cmenuViewLarge = document.getElementById('cmenuViewLarge');
    if (cmenuViewLarge) {
      cmenuViewLarge.addEventListener('click', (e) => {
        e.stopPropagation();
        closeContextMenu();
        engine.desktopIconSize = 'large';
        renderDesktopIcons();
        showFeedback('Affichage : Grandes icônes', 'info', '👁️', 1200);
      });
    }

    const cmenuViewMedium = document.getElementById('cmenuViewMedium');
    if (cmenuViewMedium) {
      cmenuViewMedium.addEventListener('click', (e) => {
        e.stopPropagation();
        closeContextMenu();
        engine.desktopIconSize = 'medium';
        renderDesktopIcons();
        showFeedback('Affichage : Moyennes icônes', 'info', '👁️', 1200);
      });
    }

    const cmenuViewSmall = document.getElementById('cmenuViewSmall');
    if (cmenuViewSmall) {
      cmenuViewSmall.addEventListener('click', (e) => {
        e.stopPropagation();
        closeContextMenu();
        engine.desktopIconSize = 'small';
        renderDesktopIcons();
        showFeedback('Affichage : Petites icônes', 'info', '👁️', 1200);
      });
    }

    // Desktop Context Menu: Sort
    const cmenuSortName = document.getElementById('cmenuSortName');
    if (cmenuSortName) {
      cmenuSortName.addEventListener('click', (e) => {
        e.stopPropagation();
        closeContextMenu();
        engine.desktopSortBy = 'name';
        renderDesktopIcons();
        showFeedback('Tri par nom appliqué.', 'info', '🔃', 1200);
      });
    }

    const cmenuSortSize = document.getElementById('cmenuSortSize');
    if (cmenuSortSize) {
      cmenuSortSize.addEventListener('click', (e) => {
        e.stopPropagation();
        closeContextMenu();
        engine.desktopSortBy = 'size';
        renderDesktopIcons();
        showFeedback('Tri par taille appliqué.', 'info', '🔃', 1200);
      });
    }

    const cmenuSortType = document.getElementById('cmenuSortType');
    if (cmenuSortType) {
      cmenuSortType.addEventListener('click', (e) => {
        e.stopPropagation();
        closeContextMenu();
        engine.desktopSortBy = 'type';
        renderDesktopIcons();
        showFeedback("Tri par type d'élément appliqué.", 'info', '🔃', 1200);
      });
    }

    // Desktop Context Menu: Refresh
    const cmenuRefresh = document.getElementById('cmenuRefresh');
    if (cmenuRefresh) {
      cmenuRefresh.addEventListener('click', (e) => {
        e.stopPropagation();
        closeContextMenu();
        renderDesktopIcons();
        showFeedback('Bureau actualisé.', 'info', '🔄', 800);
      });
    }

    // Desktop Context Menu: Paste
    const cmenuPaste = document.getElementById('cmenuPaste');
    if (cmenuPaste) {
      cmenuPaste.addEventListener('click', (e) => {
        e.stopPropagation();
        executePaste('desktop');
      });
    }

    // Folder Context Menu: Paste directly into that folder
    const cmenuItemPaste = document.getElementById('cmenuItemPaste');
    if (cmenuItemPaste) {
      cmenuItemPaste.addEventListener('click', (e) => {
        e.stopPropagation();
        executePaste(engine.selectedDesktopItemId);
      });
    }

    // Explorer Context Menu: Paste into current folder
    const cmenuExplorerPaste = document.getElementById('cmenuExplorerPaste');
    if (cmenuExplorerPaste) {
      cmenuExplorerPaste.addEventListener('click', (e) => {
        e.stopPropagation();
        executePaste(engine.wm.windows.explorer.currentFolderId || 'desktop');
      });
    }

    const cmenuExplorerNewFolder = document.getElementById('cmenuExplorerNewFolder');
    if (cmenuExplorerNewFolder) {
      cmenuExplorerNewFolder.addEventListener('click', (e) => {
        e.stopPropagation();
        closeContextMenu();
        const currentFolderId = engine.wm.windows.explorer.currentFolderId || 'desktop';
        engine.fs.createFolder(currentFolderId, 'Nouveau dossier');
        renderExplorerContent(currentFolderId);
        showFeedback('Nouveau dossier créé.', 'success', '📁', 1500);
        engine.saveToStorage();
      });
    }

    const cmenuExplorerRefresh = document.getElementById('cmenuExplorerRefresh');
    if (cmenuExplorerRefresh) {
      cmenuExplorerRefresh.addEventListener('click', (e) => {
        e.stopPropagation();
        closeContextMenu();
        const currentFolderId = engine.wm.windows.explorer.currentFolderId || 'desktop';
        renderExplorerContent(currentFolderId);
        showFeedback('Dossier actualisé.', 'info', '🔄', 800);
      });
    }

    // Desktop Context Menu: Display & Personalize
    const cmenuDisplaySettings = document.getElementById('cmenuDisplaySettings');
    if (cmenuDisplaySettings) {
      cmenuDisplaySettings.addEventListener('click', (e) => {
        e.stopPropagation();
        closeContextMenu();
        showFeedback('Affichage : Résolution standard 1920x1080 (Simulation)', 'info', '🖥️', 2000);
      });
    }

    const cmenuPersonalize = document.getElementById('cmenuPersonalize');
    if (cmenuPersonalize) {
      cmenuPersonalize.addEventListener('click', (e) => {
        e.stopPropagation();
        closeContextMenu();
        showFeedback('Personnalisation : Thème sombre TeachIT OS', 'info', '🎨', 2000);
      });
    }

    // Item Context Menu: Cut & Copy
    const cmenuCut = document.getElementById('cmenuCut');
    if (cmenuCut) {
      cmenuCut.addEventListener('click', (e) => {
        e.stopPropagation();
        closeContextMenu();
        if (engine.selectedDesktopItemId) {
          engine.clipboardItem = { id: engine.selectedDesktopItemId, mode: 'cut' };
          renderDesktopIcons();
          showFeedback('Élément coupé. Fais un clic droit pour le coller.', 'info', '✂️', 1500);
        }
      });
    }

    const cmenuCopy = document.getElementById('cmenuCopy');
    if (cmenuCopy) {
      cmenuCopy.addEventListener('click', (e) => {
        e.stopPropagation();
        closeContextMenu();
        if (engine.selectedDesktopItemId) {
          engine.clipboardItem = { id: engine.selectedDesktopItemId, mode: 'copy' };
          renderDesktopIcons();
          showFeedback('Élément copié. Fais un clic droit pour le coller.', 'info', '📋', 1500);
        }
      });
    }

    // Item Context Menu: Properties
    const cmenuProperties = document.getElementById('cmenuProperties');
    if (cmenuProperties) {
      cmenuProperties.addEventListener('click', (e) => {
        e.stopPropagation();
        closeContextMenu();
        if (engine.selectedDesktopItemId) {
          const item = engine.fs.getItem(engine.selectedDesktopItemId);
          if (item) {
            const dialogProperties = document.getElementById('dialogProperties');
            const dialogPropTitle = document.getElementById('dialogPropTitle');
            const dialogPropBody = document.getElementById('dialogPropBody');
            if (dialogPropTitle) dialogPropTitle.textContent = `Propriétés — ${item.name}`;
            if (dialogPropBody) {
              const sizeStr = item.type === 'folder'
                ? `${engine.fs.getChildren(item.id).length} élément(s)`
                : `${item.content ? item.content.length : 0} octets`;
              dialogPropBody.innerHTML = `
                <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 8px;">
                  <span style="font-size: 2.2rem;">${item.icon}</span>
                  <div>
                    <strong>${item.name}</strong>
                    <div style="font-size: 0.8rem; color: var(--text-muted);">${item.type === 'folder' ? 'Dossier de fichiers' : 'Document texte (.txt)'}</div>
                  </div>
                </div>
                <div class="context-menu-divider"></div>
                <p><strong>Emplacement :</strong> Bureau</p>
                <p><strong>Taille :</strong> ${sizeStr}</p>
                <p><strong>Date de création :</strong> ${new Date(item.createdAt || Date.now()).toLocaleDateString('fr-FR')}</p>
                <p><strong>Attributs :</strong> Lecture et écriture</p>
              `;
            }
            if (dialogProperties) dialogProperties.classList.add('active');
          }
        }
      });
    }

    const btnDialogPropClose = document.getElementById('btnDialogPropClose');
    const btnDialogPropOk = document.getElementById('btnDialogPropOk');
    const dialogProperties = document.getElementById('dialogProperties');
    const closePropDialog = () => {
      if (dialogProperties) dialogProperties.classList.remove('active');
    };
    if (btnDialogPropClose) btnDialogPropClose.addEventListener('click', closePropDialog);
    if (btnDialogPropOk) btnDialogPropOk.addEventListener('click', closePropDialog);

    // Taskbar Context Menu Items
    const cmenuTaskMgr = document.getElementById('cmenuTaskMgr');
    if (cmenuTaskMgr) {
      cmenuTaskMgr.addEventListener('click', (e) => {
        e.stopPropagation();
        closeContextMenu();
        openApp('taskmgr');
      });
    }

    const cmenuTaskbarSettings = document.getElementById('cmenuTaskbarSettings');
    if (cmenuTaskbarSettings) {
      cmenuTaskbarSettings.addEventListener('click', (e) => {
        e.stopPropagation();
        closeContextMenu();
        showFeedback('Barre des tâches : Position en bas, taille standard (Windows)', 'info', '⚙️', 2000);
      });
    }

    const cmenuLockTaskbar = document.getElementById('cmenuLockTaskbar');
    if (cmenuLockTaskbar) {
      cmenuLockTaskbar.addEventListener('click', (e) => {
        e.stopPropagation();
        closeContextMenu();
        showFeedback('La barre des tâches est verrouillée.', 'info', '🔒', 1500);
      });
    }

    const cmenuShowDesktop = document.getElementById('cmenuShowDesktop');
    if (cmenuShowDesktop) {
      cmenuShowDesktop.addEventListener('click', (e) => {
        e.stopPropagation();
        closeContextMenu();
        Object.keys(engine.wm.windows).forEach((id) => engine.wm.minimizeWindow(id));
        updateWindowsUI();
        showFeedback('Affichage du bureau.', 'info', '🪟', 1200);
      });
    }

    // Task Manager Window Close
    const btnTaskMgrClose = document.getElementById('btnTaskMgrClose');
    if (btnTaskMgrClose) {
      btnTaskMgrClose.addEventListener('click', (e) => {
        e.stopPropagation();
        engine.wm.closeWindow('taskmgr');
        updateWindowsUI();
      });
    }

    // Context Menu Creation Actions
    const cmenuNewFolder = document.getElementById('cmenuNewFolder');
    if (cmenuNewFolder) {
      cmenuNewFolder.addEventListener('click', (e) => {
        e.stopPropagation();
        handleCreateFolder();
      });
    }

    const cmenuNewDoc = document.getElementById('cmenuNewDoc');
    if (cmenuNewDoc) {
      cmenuNewDoc.addEventListener('click', (e) => {
        e.stopPropagation();
        closeContextMenu();
        const doc = engine.fs.createFile('desktop', 'Nouveau document', '', 'txt');
        renderDesktopIcons();
        promptRenameFolder(doc.id);
      });
    }

    const cmenuOpen = document.getElementById('cmenuOpen');
    if (cmenuOpen) {
      cmenuOpen.addEventListener('click', (e) => {
        e.stopPropagation();
        closeContextMenu();
        if (engine.selectedDesktopItemId) {
          const item = engine.fs.getItem(engine.selectedDesktopItemId);
          if (item?.type === 'folder') openFolder(item.id);
          else if (item?.type === 'file') openFileInEditor(item.id);
        }
      });
    }

    const cmenuRename = document.getElementById('cmenuRename');
    if (cmenuRename) {
      cmenuRename.addEventListener('click', (e) => {
        e.stopPropagation();
        closeContextMenu();
        if (engine.selectedDesktopItemId) {
          if (engine.currentChallengeIndex === 2 && engine.c3Step === 5) {
            promptRenameFolder(engine.selectedDesktopItemId, "Mon cours d'informatique");
          } else {
            promptRenameFolder(engine.selectedDesktopItemId);
          }
        }
      });
    }

    const cmenuMove = document.getElementById('cmenuMove');
    if (cmenuMove) {
      cmenuMove.addEventListener('click', (e) => {
        e.stopPropagation();
        closeContextMenu();
        if (engine.selectedDesktopItemId) {
          const item = engine.fs.getItem(engine.selectedDesktopItemId);
          const folder = engine.fs.findByName('Informatique');
          if (item && folder) {
            engine.fs.moveItem(item.id, folder.id);
            renderDesktopIcons();
            showFeedback(`Déplacé dans ${folder.name}`, 'success', '📦', 1500);

            if (engine.currentChallengeIndex === 4) {
              engine.c5Tasks.docMoved = true;
              checkChallenge5Progress();
            }
          } else {
            showFeedback("Crée d'abord un dossier « Informatique » pour y ranger ce fichier.", 'info', '💡');
          }
        }
      });
    }

    const cmenuDelete = document.getElementById('cmenuDelete');
    if (cmenuDelete) {
      cmenuDelete.addEventListener('click', (e) => {
        e.stopPropagation();
        closeContextMenu();
        if (engine.selectedDesktopItemId) {
          engine.fs.deleteItem(engine.selectedDesktopItemId);
          renderDesktopIcons();
          showFeedback('Élément déplacé vers la corbeille.', 'info', '🗑️', 1500);
        }
      });
    }

    // Window Controls: Editor
    if (winEditorTitlebar) {
      winEditorTitlebar.addEventListener('click', () => {
        if (engine.currentChallengeIndex === 1 && engine.c2Step === 1) {
          advanceChallenge2Step(2);
        }
      });
    }

    if (btnEditorMinimize) {
      btnEditorMinimize.addEventListener('click', (e) => {
        e.stopPropagation();
        engine.wm.minimizeWindow('editor');
        updateWindowsUI();
        if (engine.currentChallengeIndex === 1 && engine.c2Step === 2) {
          advanceChallenge2Step(3);
        }
      });
    }

    if (btnEditorMaximize) {
      btnEditorMaximize.addEventListener('click', (e) => {
        e.stopPropagation();
        const win = engine.wm.windows.editor;
        if (win.isMaximized) {
          engine.wm.unmaximizeWindow('editor');
          updateWindowsUI();
          if (engine.currentChallengeIndex === 1 && engine.c2Step === 5) {
            advanceChallenge2Step(6);
          }
        } else {
          engine.wm.maximizeWindow('editor');
          updateWindowsUI();
          if (engine.currentChallengeIndex === 1 && engine.c2Step === 4) {
            advanceChallenge2Step(5);
          }
        }
      });
    }

    if (btnEditorClose) {
      btnEditorClose.addEventListener('click', (e) => {
        e.stopPropagation();
        engine.wm.closeWindow('editor');
        updateWindowsUI();
        if (engine.currentChallengeIndex === 1 && engine.c2Step === 6) {
          advanceChallenge2Step(7);
        }
      });
    }

    // Window Controls: Explorer
    if (btnExplorerMinimize) {
      btnExplorerMinimize.addEventListener('click', (e) => {
        e.stopPropagation();
        engine.wm.minimizeWindow('explorer');
        updateWindowsUI();
      });
    }

    if (btnExplorerMaximize) {
      btnExplorerMaximize.addEventListener('click', (e) => {
        e.stopPropagation();
        engine.wm.toggleMaximize('explorer');
        updateWindowsUI();
      });
    }

    if (btnExplorerClose) {
      btnExplorerClose.addEventListener('click', (e) => {
        e.stopPropagation();
        engine.wm.closeWindow('explorer');
        updateWindowsUI();
        if (engine.currentChallengeIndex === 2 && (engine.c3Step === 3 || engine.c3Step === 4)) {
          advanceChallenge3Step(5);
        }
      });
    }

    if (btnExplorerUp) {
      btnExplorerUp.addEventListener('click', () => {
        openFolder('desktop');
      });
    }

    const winExplorer = document.getElementById('windowExplorer');
    if (winExplorer) {
      winExplorer.addEventListener('dragover', (e) => {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        winExplorer.querySelector('.window-body')?.classList.add('drag-target-hover');
      });
      winExplorer.addEventListener('dragleave', (e) => {
        if (!winExplorer.contains(e.relatedTarget)) {
          winExplorer.querySelector('.window-body')?.classList.remove('drag-target-hover');
        }
      });
      winExplorer.addEventListener('drop', (e) => {
        e.preventDefault();
        winExplorer.querySelector('.window-body')?.classList.remove('drag-target-hover');
        const draggedId = e.dataTransfer.getData('text/plain');
        if (!draggedId) return;

        const currentFolderId = engine.wm.windows.explorer.currentFolderId || 'desktop';
        const draggedItem = engine.fs.getItem(draggedId);
        const currentFolder = engine.fs.getItem(currentFolderId);

        if (
          draggedItem &&
          currentFolderId !== draggedItem.parentId &&
          currentFolderId !== draggedItem.id
        ) {
          engine.fs.moveItem(draggedId, currentFolderId);
          renderDesktopIcons();
          renderExplorerContent(currentFolderId);
          showFeedback(
            `« ${draggedItem.name} » déplacé dans le dossier « ${currentFolder?.name || 'Explorateur'} ».`,
            'success',
            '📦',
            2000,
          );
          engine.saveToStorage();

          if (
            engine.currentChallengeIndex === 4 &&
            currentFolder?.name.toLowerCase().includes('informatique')
          ) {
            if (draggedItem.name.includes('Mon premier document')) {
              engine.c5Tasks.docMoved = true;
              checkChallenge5Progress();
            }
          }
        }
      });
    }

    if (explorerGrid) {
      explorerGrid.addEventListener('contextmenu', (e) => {
        if (e.target !== explorerGrid && !e.target.classList.contains('explorer-empty-msg')) return;
        e.preventDefault();
        e.stopPropagation();
        openContextMenu(e.clientX, e.clientY, 'explorer');
      });
    }

    // Window Controls: Trash
    if (btnTrashMinimize) btnTrashMinimize.addEventListener('click', () => engine.wm.minimizeWindow('trash'));
    if (btnTrashMaximize) btnTrashMaximize.addEventListener('click', () => engine.wm.toggleMaximize('trash'));
    if (btnTrashClose) {
      btnTrashClose.addEventListener('click', (e) => {
        e.stopPropagation();
        engine.wm.closeWindow('trash');
        updateWindowsUI();
      });
    }

    // Text Editor Buttons
    if (btnInsertSuggestedText && editorTextarea) {
      btnInsertSuggestedText.addEventListener('click', () => {
        editorTextarea.value = "Je découvre l'informatique.";
        if (engine.currentChallengeIndex === 3 && (engine.c4Step === 0 || engine.c4Step === 1)) {
          advanceChallenge4Step(2);
        }
        if (engine.currentChallengeIndex === 4) {
          engine.c5Tasks.textWritten = true;
          checkChallenge5Progress();
        }
      });
    }

    if (editorTextarea) {
      editorTextarea.addEventListener('input', () => {
        if (editorTextarea.value.trim().length > 0) {
          if (engine.currentChallengeIndex === 3 && (engine.c4Step === 0 || engine.c4Step === 1)) {
            advanceChallenge4Step(2);
          }
          if (engine.currentChallengeIndex === 4) {
            engine.c5Tasks.textWritten = true;
            checkChallenge5Progress();
          }
        }
      });
    }

    const openSaveDialog = () => {
      if (dialogSaveAs) dialogSaveAs.classList.add('active');
      if (inputDocName) {
        inputDocName.value = 'Mon premier document';
        inputDocName.focus();
        inputDocName.select();
      }
      if (engine.currentChallengeIndex === 3 && (engine.c4Step === 1 || engine.c4Step === 2)) {
        advanceChallenge4Step(3);
      }
    };

    if (btnEditorSave) btnEditorSave.addEventListener('click', openSaveDialog);
    if (btnEditorSaveAs) btnEditorSaveAs.addEventListener('click', openSaveDialog);
    const menuEditorFile = document.getElementById('menuEditorFile');
    if (menuEditorFile) menuEditorFile.addEventListener('click', openSaveDialog);

    // Save As Dialog
    if (btnDialogSaveCancel) {
      btnDialogSaveCancel.addEventListener('click', () => {
        if (dialogSaveAs) dialogSaveAs.classList.remove('active');
      });
    }

    if (btnDialogCancelAction) {
      btnDialogCancelAction.addEventListener('click', () => {
        if (dialogSaveAs) dialogSaveAs.classList.remove('active');
      });
    }

    if (inputDocName) {
      inputDocName.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          btnDialogSaveConfirm?.click();
        }
      });
    }

    if (btnDialogSaveConfirm) {
      btnDialogSaveConfirm.addEventListener('click', () => {
        const docName = (inputDocName?.value || 'Mon premier document').trim();
        const targetFolder = saveFolderSelect?.value || 'desktop';
        const content = editorTextarea?.value || "Je découvre l'informatique.";

        const file = engine.fs.createFile(targetFolder, docName, content, 'txt');
        if (dialogSaveAs) dialogSaveAs.classList.remove('active');
        renderDesktopIcons();

        showFeedback(`Document « ${file.name} » enregistré avec succès !`, 'success', '💾', 2000);

        if (engine.currentChallengeIndex === 3 && (engine.c4Step === 2 || engine.c4Step === 3)) {
          advanceChallenge4Step(4);
        }

        if (engine.currentChallengeIndex === 4) {
          engine.c5Tasks.docSaved = true;
          checkChallenge5Progress();
        }
      });
    }

    // Explainer Card Placement & Dismissal
    const btnExplainerMove = document.getElementById('btnExplainerMove');
    if (btnExplainerMove) {
      btnExplainerMove.addEventListener('click', (e) => {
        e.stopPropagation();
        cycleExplainerPosition();
      });
    }

    const explainerHeader = document.getElementById('explainerHeader');
    if (explainerHeader) {
      explainerHeader.addEventListener('click', (e) => {
        if (e.target.closest('#btnExplainerClose')) return;
        cycleExplainerPosition();
      });
    }

    if (eduExplainerCard) {
      eduExplainerCard.addEventListener('click', (e) => {
        if (e.target === eduExplainerCard || e.target.id === 'explainerTitle' || e.target.id === 'explainerDesc') {
          cycleExplainerPosition();
        }
      });
    }

    if (btnExplainerClose) {
      btnExplainerClose.addEventListener('click', (e) => {
        e.stopPropagation();
        if (eduExplainerCard) eduExplainerCard.style.display = 'none';
      });
    }

    if (btnExplainerNext) {
      btnExplainerNext.addEventListener('click', (e) => {
        e.stopPropagation();
        if (eduExplainerCard) eduExplainerCard.style.display = 'none';
      });
    }

    // Window Draggable Setup (Titlebar dragging, drag-to-top to maximize)
    setupWindowDraggable(windowEditor, winEditorTitlebar, 'editor');
    setupWindowDraggable(windowExplorer, document.getElementById('winExplorerTitlebar'), 'explorer');
    setupWindowDraggable(windowTrash, document.getElementById('winTrashTitlebar'), 'trash');
    setupWindowDraggable(document.getElementById('windowTaskManager'), document.getElementById('winTaskMgrTitlebar'), 'taskmgr');

    // Keyboard Accessibility & Shortcuts (Esc, Ctrl+C, Ctrl+X, Ctrl+V, Delete)
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        closeContextMenu();
        if (dialogSaveAs) dialogSaveAs.classList.remove('active');
        if (startMenuPopover) startMenuPopover.classList.remove('active');
        return;
      }

      // Do not intercept typing inside input fields or textareas
      const activeTag = document.activeElement?.tagName;
      if (activeTag === 'INPUT' || activeTag === 'TEXTAREA') return;

      const isCtrl = e.ctrlKey || e.metaKey;
      if (isCtrl && (e.key === 'c' || e.key === 'C')) {
        if (engine.selectedDesktopItemId) {
          const item = engine.fs.getItem(engine.selectedDesktopItemId);
          if (item) {
            engine.clipboardItem = { id: engine.selectedDesktopItemId, mode: 'copy' };
            renderDesktopIcons();
            showFeedback(
              `« ${item.name} » copié. Fais un clic droit pour coller ou utilise Ctrl+V.`,
              'info',
              '📋',
              1500,
            );
          }
        }
      } else if (isCtrl && (e.key === 'x' || e.key === 'X')) {
        if (engine.selectedDesktopItemId) {
          const item = engine.fs.getItem(engine.selectedDesktopItemId);
          if (item && !item.isSystem) {
            engine.clipboardItem = { id: engine.selectedDesktopItemId, mode: 'cut' };
            renderDesktopIcons();
            showFeedback(
              `« ${item.name} » coupé. Fais un clic droit pour coller ou utilise Ctrl+V.`,
              'info',
              '✂️',
              1500,
            );
          }
        }
      } else if (isCtrl && (e.key === 'v' || e.key === 'V')) {
        if (engine.wm.windows.explorer.isOpen && engine.wm.activeWindowId === 'explorer') {
          executePaste(engine.wm.windows.explorer.currentFolderId || 'desktop');
        } else {
          executePaste('desktop');
        }
      } else if (e.key === 'Delete') {
        if (engine.selectedDesktopItemId) {
          const item = engine.fs.getItem(engine.selectedDesktopItemId);
          if (item && !item.isSystem) {
            engine.fs.deleteItem(item.id);
            renderDesktopIcons();
            if (engine.wm.windows.explorer.isOpen) {
              renderExplorerContent(engine.wm.windows.explorer.currentFolderId);
            }
            showFeedback(`« ${item.name} » déplacé vers la corbeille.`, 'info', '🗑️', 1500);
            engine.saveToStorage();
          }
        }
      }
    });

    // Real-time clock simulation
    const systemClock = document.getElementById('systemClock');
    if (systemClock) {
      const updateClock = () => {
        const now = new Date();
        const h = String(now.getHours()).padStart(2, '0');
        const m = String(now.getMinutes()).padStart(2, '0');
        systemClock.textContent = `${h}:${m}`;
      };
      updateClock();
      setInterval(updateClock, 30000);
    }
  }

  // Session Info Initialization from TeachIT IPC
  async function initSession() {
    const teachit = getTeachit();
    if (!teachit || typeof teachit.getSessionInfo !== 'function') return;

    try {
      const info = await teachit.getSessionInfo();
      if (info) {
        engine.sessionInfo = info;
        if (info.studentId && sessionBadge && sessionStudentName) {
          sessionBadge.style.display = 'inline-flex';
          sessionStudentName.textContent = info.studentId.substring(0, 8) + '...';
        }
        if (engine.loadFromStorage()) {
          updateTabs();
        }
      }
    } catch {
      // Standalone mode fallback
    }
  }

  // Init on DOM Ready
  function init() {
    engine.loadFromStorage();
    setupListeners();
    initSession();
    applyLanguage('fr');
    updateTabs();
  }

  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', init);
    } else {
      init();
    }
  }

  // Expose engine class & data for Vitest unit testing and modular inspection
  const exportTarget = typeof exports !== 'undefined' ? exports : global;
  exportTarget.DesktopExplorerEngine = DesktopExplorerEngine;
  exportTarget.SimulatedFileSystem = SimulatedFileSystem;
  exportTarget.SimulatedWindowManager = SimulatedWindowManager;
  exportTarget.DESKTOP_ELEMENTS = DESKTOP_ELEMENTS;
  exportTarget.CHALLENGES_CONFIG = CHALLENGES_CONFIG;
  exportTarget.TRANSLATIONS = TRANSLATIONS;
})(typeof window !== 'undefined' ? window : globalThis);
