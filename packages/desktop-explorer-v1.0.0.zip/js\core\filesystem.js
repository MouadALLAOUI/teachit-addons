// ============================================================================
// TeachIT Educational Game: Desktop Explorer
// File: js/core/filesystem.js
// Purpose: In-memory simulated file system with folder/file hierarchy & serialization
// Dependencies: window.DX.config
// ============================================================================

window.DX = window.DX || {};

(function (DX) {
  'use strict';

  const FORBIDDEN_CHARS = /[\\/:*?"<>|]/;

  class SimulatedFileSystem {
    constructor() {
      this.items = new Map();
      this.init();
    }

    init() {
      this.items.clear();

      // Root desktop container
      this.items.set('desktop', {
        id: 'desktop',
        name: 'Bureau',
        type: 'folder',
        parentId: null,
        isSystem: true,
        icon: 'assets/icons/desktop.svg',
        createdAt: Date.now(),
      });

      // System Trash folder
      this.items.set('trash', {
        id: 'trash',
        name: 'Corbeille',
        type: 'folder',
        parentId: 'desktop',
        isSystem: true,
        icon: 'assets/icons/trash.svg',
        createdAt: Date.now(),
      });
    }

    reset() {
      this.init();
    }

    serialize() {
      const arr = [];
      for (const item of this.items.values()) {
        arr.push({ ...item });
      }
      return arr;
    }

    deserialize(arr) {
      if (!Array.isArray(arr) || arr.length === 0) return;
      this.items.clear();
      this.init();
      for (const item of arr) {
        if (item && item.id) {
          this.items.set(item.id, item);
        }
      }
    }

    validateName(name) {
      const clean = (name || '').trim();
      if (!clean) {
        return { valid: false, errorKey: 'sim.errorEmptyName' };
      }
      if (FORBIDDEN_CHARS.test(clean)) {
        return { valid: false, errorKey: 'sim.errorInvalidChars' };
      }
      return { valid: true, cleanName: clean };
    }

    createFolder(parentId, name) {
      const cleanName = (name || 'Nouveau dossier').trim();
      const id = 'folder-' + Math.random().toString(36).substring(2, 9);
      const folder = {
        id,
        name: cleanName,
        type: 'folder',
        parentId: parentId || 'desktop',
        isSystem: false,
        icon: 'assets/icons/folder.svg',
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      this.items.set(id, folder);
      return folder;
    }

    createFile(parentId, name, content = '', extension = 'txt') {
      const baseName = (name || 'Nouveau document').trim();
      const fileName = baseName.endsWith(`.${extension}`) ? baseName : `${baseName}.${extension}`;
      const id = 'file-' + Math.random().toString(36).substring(2, 9);
      const file = {
        id,
        name: fileName,
        baseName: baseName.replace(new RegExp(`\\.${extension}$`), ''),
        extension,
        type: 'file',
        parentId: parentId || 'desktop',
        content,
        icon: 'assets/icons/document.svg',
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      this.items.set(id, file);
      return file;
    }

    renameItem(id, newName) {
      const item = this.items.get(id);
      if (!item || item.isSystem) return false;
      const validation = this.validateName(newName);
      if (!validation.valid) return false;
      const clean = validation.cleanName;

      if (item.type === 'file' && item.extension) {
        item.baseName = clean.replace(new RegExp(`\\.${item.extension}$`), '');
        item.name = `${item.baseName}.${item.extension}`;
      } else {
        item.name = clean;
      }
      item.updatedAt = Date.now();
      return true;
    }

    moveItem(id, newParentId) {
      const item = this.items.get(id);
      const targetParent = this.items.get(newParentId);
      if (!item || !targetParent || targetParent.type !== 'folder') return false;
      if (item.id === newParentId) return false; // Cannot move folder into itself

      item.parentId = newParentId;
      item.updatedAt = Date.now();
      return true;
    }

    deleteItem(id) {
      const item = this.items.get(id);
      if (!item || item.isSystem) return false;
      item.previousParentId = item.parentId || 'desktop';
      item.parentId = 'trash';
      item.updatedAt = Date.now();
      return true;
    }

    restoreItem(id) {
      const item = this.items.get(id);
      if (!item || item.parentId !== 'trash') return false;
      const targetParent = this.items.get(item.previousParentId);
      item.parentId = targetParent && targetParent.type === 'folder' ? item.previousParentId : 'desktop';
      delete item.previousParentId;
      item.updatedAt = Date.now();
      return true;
    }

    emptyTrash() {
      for (const [id, item] of this.items.entries()) {
        if (item.parentId === 'trash' && !item.isSystem) {
          this.items.delete(id);
        }
      }
    }

    copyItem(id, targetParentId) {
      const item = this.items.get(id);
      if (!item || item.isSystem) return null;
      let newName = item.name;
      const existing = this.getChildren(targetParentId);
      if (existing.some((i) => i.name.toLowerCase() === newName.toLowerCase())) {
        if (item.type === 'file') {
          newName = `${item.baseName} - Copie.${item.extension}`;
        } else {
          newName = `${item.name} - Copie`;
        }
      }
      if (item.type === 'folder') {
        const newFolder = this.createFolder(targetParentId, newName);
        this.getChildren(item.id).forEach((child) => this.copyItem(child.id, newFolder.id));
        return newFolder;
      }
      return this.createFile(targetParentId, newName, item.content, item.extension);
    }

    setClipboard(op, itemId) {
      if (!['copy', 'cut'].includes(op) || !this.items.has(itemId)) {
        this.clipboard = null;
        return null;
      }
      this.clipboard = { op, itemId };
      return this.clipboard;
    }

    getClipboard() {
      return this.clipboard;
    }

    clearClipboard() {
      this.clipboard = null;
    }

    executePaste(targetParentId) {
      if (!this.clipboard) return null;
      const { op, itemId } = this.clipboard;
      const item = this.items.get(itemId);
      if (!item) {
        this.clearClipboard();
        return null;
      }
      let result = null;
      if (op === 'cut') {
        if (this.moveItem(itemId, targetParentId)) {
          result = item;
        }
        this.clearClipboard();
      } else if (op === 'copy') {
        result = this.copyItem(itemId, targetParentId);
      }
      return result;
    }

    getItemProperties(id) {
      const item = this.items.get(id);
      if (!item) return null;
      const parent = item.parentId ? this.items.get(item.parentId) : null;
      const path = parent ? (parent.id === 'desktop' ? 'C:\\Bureau' : `C:\\Bureau\\${parent.name}`) : 'C:\\';
      let sizeBytes = item.type === 'folder' ? 0 : (item.content || '').length * 2;
      if (item.type === 'folder') {
        sizeBytes = this.getChildren(item.id).length * 1024;
      }
      return {
        id: item.id,
        name: item.name,
        type: item.type === 'folder' ? 'Dossier de fichiers' : 'Document texte (.txt)',
        location: path,
        size: `${Math.max(1, Math.round(sizeBytes / 1024))} Ko`,
        createdAt: new Date(item.createdAt || Date.now()).toLocaleDateString(),
      };
    }

    matchesName(name, candidateList) {
      if (!name || !Array.isArray(candidateList)) return false;
      const clean = name.trim().toLowerCase();
      return candidateList.some((c) => {
        const cleanC = c.trim().toLowerCase();
        return clean === cleanC || clean.startsWith(cleanC);
      });
    }

    getItem(id) {
      return this.items.get(id) || null;
    }

    findByName(name, parentId = 'desktop') {
      const cleanTarget = name.trim().toLowerCase();
      for (const item of this.items.values()) {
        if (item.parentId === parentId) {
          if (
            item.name.toLowerCase() === cleanTarget ||
            (item.baseName && item.baseName.toLowerCase() === cleanTarget)
          ) {
            return item;
          }
        }
      }
      return null;
    }

    getChildren(parentId) {
      const results = [];
      for (const item of this.items.values()) {
        if (item.parentId === parentId) results.push(item);
      }
      return results;
    }

    getAll() {
      return Array.from(this.items.values());
    }
  }

  DX.SimulatedFileSystem = SimulatedFileSystem;
  // Shared global instance
  DX.fs = new SimulatedFileSystem();
})(window.DX);
