// ============================================================================
// TeachIT Educational Game: Desktop Explorer
// File: js/levels/02-windows.js
// Purpose: Level 2 — Windows & applications manipulation via real Windows actions
// Dependencies: window.DX.levels, window.DX.desktopSim, window.DX.wm
// ============================================================================

window.DX = window.DX || {};

(function (DX) {
  'use strict';

  const OBJECTIVES = [
    { id: 'openApp', labelKey: 'level.windows.task1', hintKey: 'level.windows.hint1' },
    { id: 'dragWindow', labelKey: 'level.windows.task2', hintKey: 'level.windows.hint2' },
    { id: 'maximize', labelKey: 'level.windows.task3', hintKey: 'level.windows.hint3' },
    { id: 'minimizeRestore', labelKey: 'level.windows.task4', hintKey: 'level.windows.hint4' },
    { id: 'multiWindows', labelKey: 'level.windows.task5', hintKey: 'level.windows.hint5' },
    { id: 'closeWindow', labelKey: 'level.windows.task6', hintKey: 'level.windows.hint6' },
  ];

  let currentCtx = null;
  let completedTasks = new Set();
  let wasMinimized = false;
  const cleanupFns = [];

  function mount(container, ctx) {
    currentCtx = ctx;

    const save = ctx.storage.loadGame() || {};
    const existing = save.levelData?.windows?.completedTasks;
    completedTasks = Array.isArray(existing) ? new Set(existing) : new Set();

    container.innerHTML = `
      <div class="level-banner" id="l2Banner">
        <div class="banner-info">
          <span class="banner-badge">${ctx.t('level.term')} 2 / 5</span>
          <span class="banner-step" id="l2StepBadge">${completedTasks.size} / ${OBJECTIVES.length} ${ctx.t('levels.statusCompleted')}</span>
          <h2 class="banner-instruction">${ctx.t('level.windows.desc')}</h2>
        </div>
        <div class="banner-actions">
          <button type="button" class="btn btn-secondary btn-sm" id="l2BtnMissions">📋 ${ctx.t('levels.missionsBtn')}</button>
          <button type="button" class="btn btn-secondary btn-sm" id="l2BtnHint">💡 ${ctx.t('header.hint')}</button>
        </div>
      </div>

      <div class="level-checklist-panel" id="l2ChecklistPanel">
        <div class="checklist-header">
          <h3 class="checklist-title">${ctx.t('level.windows.short')} — Objectifs</h3>
          <button type="button" class="checklist-close-btn" id="l2BtnCloseChecklist" aria-label="Close">✕</button>
        </div>
        <div class="checklist-grid" id="l2ChecklistGrid"></div>
        <div class="checklist-hint-box" id="l2HintBox" style="display:none; margin-top:10px; font-size:12px; color:var(--border-highlight);"></div>
      </div>
    `;

    DX.tipsPanel?.attach?.(document.getElementById('l2ChecklistPanel'));
    renderChecklist();
    setupListeners();
  }

  function renderChecklist() {
    const grid = document.getElementById('l2ChecklistGrid');
    const badge = document.getElementById('l2StepBadge');
    if (!grid || !currentCtx) return;

    if (badge) {
      badge.textContent = `${completedTasks.size} / ${OBJECTIVES.length} ${currentCtx.t('levels.statusCompleted')}`;
    }

    grid.innerHTML = OBJECTIVES.map((obj) => {
      const isDone = completedTasks.has(obj.id);
      return `
        <div class="check-item ${isDone ? 'done' : ''}" data-obj="${obj.id}">
          <img src="${isDone ? 'assets/icons/check.svg' : 'assets/icons/lock.svg'}" class="check-item-icon" alt="" />
          <span>${currentCtx.t(obj.labelKey)}</span>
        </div>
      `;
    }).join('');
  }

  function markDone(objId) {
    if (!currentCtx || completedTasks.has(objId)) return;
    completedTasks.add(objId);
    currentCtx.audio?.playClick?.();
    renderChecklist();

    const save = currentCtx.storage.loadGame() || {};
    save.levelData = save.levelData || {};
    save.levelData.windows = { completedTasks: Array.from(completedTasks) };
    currentCtx.storage.saveGame(save);

    if (completedTasks.size >= OBJECTIVES.length) {
      setTimeout(() => {
        currentCtx.complete({ scoreBonus: 50 });
      }, 700);
    }
  }

  function setupListeners() {
    const onOpenApp = () => {
      markDone('openApp');
      checkMultiWindows();
    };

    const checkMultiWindows = () => {
      const openCount = Object.values(DX.desktopSim?.wm?.windows || {}).filter((w) => w.isOpen).length;
      if (openCount >= 2) markDone('multiWindows');
    };

    const onWindowSnapped = () => markDone('maximize');
    const onMaximize = (data) => {
      if (data?.isMax) markDone('maximize');
    };

    const onMinimize = () => {
      wasMinimized = true;
    };

    const onRestore = () => {
      if (wasMinimized) {
        markDone('minimizeRestore');
        wasMinimized = false;
      }
    };

    const onClose = () => markDone('closeWindow');
    const onTaskEnded = () => markDone('closeWindow');
    const onWindowMoved = () => markDone('dragWindow');

    DX.desktopSim?.on('openApp', onOpenApp);
    DX.desktopSim?.wm?.on('windowSnapped', onWindowSnapped);
    DX.desktopSim?.wm?.on('windowMaximized', onMaximize);
    DX.desktopSim?.wm?.on('windowMinimized', onMinimize);
    DX.desktopSim?.wm?.on('windowRestored', onRestore);
    DX.desktopSim?.on('windowClosed', onClose);
    DX.desktopSim?.on('taskEnded', onTaskEnded);
    DX.desktopSim?.wm?.on('windowMoved', onWindowMoved);

    // Missions toggle button & close button
    const btnMissions = document.getElementById('l2BtnMissions');
    const btnCloseChecklist = document.getElementById('l2BtnCloseChecklist');
    btnMissions?.addEventListener('click', () => DX.tipsPanel?.toggle?.());
    btnCloseChecklist?.addEventListener('click', () => DX.tipsPanel?.hide?.());

    // Also observe drag events on windows
    const onTitlebarMove = (e) => {
      if (e.buttons === 1) markDone('dragWindow');
    };
    document.querySelectorAll('.window-titlebar').forEach((tb) => {
      tb.addEventListener('pointermove', onTitlebarMove);
    });

    cleanupFns.push(() => {
      DX.desktopSim?.off('openApp', onOpenApp);
      DX.desktopSim?.wm?.listeners?.delete('windowSnapped');
      DX.desktopSim?.wm?.listeners?.delete('windowMaximized');
      DX.desktopSim?.wm?.listeners?.delete('windowMinimized');
      DX.desktopSim?.wm?.listeners?.delete('windowRestored');
      DX.desktopSim?.off('windowClosed', onClose);
      DX.desktopSim?.off('taskEnded', onTaskEnded);
      document.querySelectorAll('.window-titlebar').forEach((tb) => {
        tb.removeEventListener('pointermove', onTitlebarMove);
      });
    });

    document.getElementById('l2BtnHint')?.addEventListener('click', () => {
      currentCtx?.audio?.playClick?.();
      const next = OBJECTIVES.find((o) => !completedTasks.has(o.id));
      const hintBox = document.getElementById('l2HintBox');
      if (next && hintBox) {
        hintBox.textContent = `💡 Indice : ${currentCtx.t(next.hintKey)}`;
        hintBox.style.display = 'block';
      }
    });
  }

  function onLanguageChange() {
    if (!currentCtx) return;
    renderChecklist();
    const instruction = document.querySelector('#l2Banner .banner-instruction');
    if (instruction) instruction.textContent = currentCtx.t('level.windows.desc');
    const badge = document.querySelector('#l2Banner .banner-badge');
    if (badge) badge.textContent = `${currentCtx.t('level.term')} 2 / 5`;
    const title = document.querySelector('#l2ChecklistPanel .checklist-title');
    if (title) title.textContent = `${currentCtx.t('level.windows.short')} — Objectifs`;
    const btnM = document.getElementById('l2BtnMissions');
    if (btnM) btnM.textContent = `📋 ${currentCtx.t('levels.missionsBtn')}`;
    const hintBtn = document.getElementById('l2BtnHint');
    if (hintBtn) hintBtn.textContent = `💡 ${currentCtx.t('header.hint')}`;
  }

  function start() {
    renderChecklist();
  }

  function destroy() {
    while (cleanupFns.length > 0) {
      const fn = cleanupFns.pop();
      try { fn(); } catch (err) { console.error('[Level 2] Cleanup error:', err); }
    }
  }

  DX.levels = DX.levels || { register: () => {} };
  DX.levels.register({
    id: 'windows',
    order: 2,
    titleKey: 'level.windows.title',
    descKey: 'level.windows.desc',
    icon: 'assets/icons/window.svg',
    mount,
    start,
    destroy,
    onLanguageChange,
  });
})(window.DX);
