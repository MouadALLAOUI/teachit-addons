// ============================================================================
// TeachIT Educational Game: Desktop Explorer
// File: js/core/context-menu.js
// Purpose: Context menu engine with submenus, boundary flipping, and target dispatch
// Dependencies: window.DX.desktopSim, window.DX.fs, window.DX.i18n, window.DX.audio
// ============================================================================

window.DX = window.DX || {};

(function (DX) {
  'use strict';

  class ContextMenuManager {
    constructor() {
      this.menuEl = null;
      this.activeTarget = null; // { type: 'desktop'|'item'|'folder'|'taskbar', itemId?: string, folderId?: string }
      this.isOpen = false;
    }

    init() {
      this.menuEl = document.getElementById('desktopContextMenu');
      this.setupGlobalDismiss();
    }

    setupGlobalDismiss() {
      document.addEventListener('click', (e) => {
        if (!this.isOpen) return;
        if (!e.target.closest('#desktopContextMenu')) {
          this.close();
        }
      });
      window.addEventListener('keydown', (e) => {
        if (this.isOpen && e.key === 'Escape') {
          this.close();
        }
      });
    }

    open(clientX, clientY, type, targetData = {}) {
      const desktop = document.getElementById('simulatedDesktop');
      if (!this.menuEl || !desktop) return;

      this.activeTarget = { type, ...targetData };
      this.buildMenuMarkup();

      this.menuEl.style.display = 'flex';
      this.menuEl.classList.add('active');
      this.isOpen = true;

      // Position & edge clamping / flipping
      const deskRect = desktop.getBoundingClientRect();
      const menuRect = this.menuEl.getBoundingClientRect();

      let x = clientX - deskRect.left;
      let y = clientY - deskRect.top;

      // Flip submenus to the left if near right edge
      if (x + 200 + 175 > deskRect.width) {
        this.menuEl.classList.add('flip-submenus-left');
      } else {
        this.menuEl.classList.remove('flip-submenus-left');
      }

      // Flip left if near right edge
      if (x + menuRect.width > deskRect.width - 10) {
        x = Math.max(10, x - menuRect.width);
      }
      // Flip up if near bottom (taskbar is 48px)
      if (y + menuRect.height > deskRect.height - 52) {
        y = Math.max(10, y - menuRect.height);
      }

      this.menuEl.style.left = `${Math.round(x)}px`;
      this.menuEl.style.top = `${Math.round(y)}px`;

      DX.desktopSim?.emit('contextMenuOpened', { type, ...targetData });
    }

    close() {
      if (!this.isOpen || !this.menuEl) return;
      this.menuEl.classList.remove('active');
      this.menuEl.style.display = 'none';
      this.isOpen = false;
      this.activeTarget = null;
    }

    buildMenuMarkup() {
      if (!this.menuEl || !this.activeTarget) return;
      const { type, itemId, folderId } = this.activeTarget;
      const clipboard = DX.fs?.getClipboard?.();
      const hasClipboard = Boolean(clipboard);
      const iconSize = DX.desktopSim?.iconSize || 'medium';

      if (type === 'desktop' || type === 'folder') {
        const targetParentId = type === 'folder' ? (folderId || 'desktop') : 'desktop';
        this.menuEl.innerHTML = `
          <div class="cmenu-item has-submenu" data-submenu="view">
            <span>👁️ ${DX.i18n.t('sim.cmenuView')}</span>
            <span class="submenu-arrow">▶</span>
            <div class="cmenu-submenu">
              <button type="button" class="cmenu-item ${iconSize === 'large' ? 'checked' : ''}" data-act="view-large">
                <span>${iconSize === 'large' ? '✓ ' : ''}${DX.i18n.t('sim.cmenuLarge')}</span>
              </button>
              <button type="button" class="cmenu-item ${iconSize === 'medium' ? 'checked' : ''}" data-act="view-medium">
                <span>${iconSize === 'medium' ? '✓ ' : ''}${DX.i18n.t('sim.cmenuMedium')}</span>
              </button>
              <button type="button" class="cmenu-item ${iconSize === 'small' ? 'checked' : ''}" data-act="view-small">
                <span>${iconSize === 'small' ? '✓ ' : ''}${DX.i18n.t('sim.cmenuSmall')}</span>
              </button>
            </div>
          </div>

          <div class="cmenu-item has-submenu" data-submenu="sort">
            <span>⇅ ${DX.i18n.t('sim.cmenuSort')}</span>
            <span class="submenu-arrow">▶</span>
            <div class="cmenu-submenu">
              <button type="button" class="cmenu-item" data-act="sort-name">
                <span>${DX.i18n.t('sim.cmenuSortName')}</span>
              </button>
              <button type="button" class="cmenu-item" data-act="sort-size">
                <span>${DX.i18n.t('sim.cmenuSortSize')}</span>
              </button>
            </div>
          </div>

          <button type="button" class="cmenu-item" data-act="refresh">
            <span>🔄 ${DX.i18n.t('sim.cmenuRefresh')}</span>
          </button>

          <div class="cmenu-divider"></div>

          <button type="button" class="cmenu-item ${!hasClipboard ? 'disabled' : ''}" data-act="paste" ${!hasClipboard ? 'disabled' : ''}>
            <span>📋 ${DX.i18n.t('sim.cmenuPaste')}</span>
          </button>

          <div class="cmenu-divider"></div>

          <div class="cmenu-item has-submenu" data-submenu="new">
            <span>➕ ${DX.i18n.t('sim.cmenuNew')}</span>
            <span class="submenu-arrow">▶</span>
            <div class="cmenu-submenu">
              <button type="button" class="cmenu-item" data-act="new-folder" data-parent="${targetParentId}">
                <span>📁 ${DX.i18n.t('sim.cmenuFolder')}</span>
              </button>
              <button type="button" class="cmenu-item" data-act="new-doc" data-parent="${targetParentId}">
                <span>📄 ${DX.i18n.t('sim.cmenuDoc')}</span>
              </button>
            </div>
          </div>

          ${type === 'desktop' ? `
            <div class="cmenu-divider"></div>
            <button type="button" class="cmenu-item" data-act="personalize">
              <span>🎨 ${DX.i18n.t('sim.cmenuPersonalize')}</span>
            </button>
          ` : ''}
        `;
      } else if (type === 'item') {
        const item = DX.fs?.getItem?.(itemId);
        const isTrash = item?.parentId === 'trash';
        if (isTrash) {
          this.menuEl.innerHTML = `
            <button type="button" class="cmenu-item" data-act="restore" data-id="${itemId}">
              <span>♻️ ${DX.i18n.t('sim.cmenuRestore')}</span>
            </button>
            <button type="button" class="cmenu-item" data-act="delete-perm" data-id="${itemId}">
              <span>🗑️ ${DX.i18n.t('sim.cmenuDelete')}</span>
            </button>
          `;
        } else {
          this.menuEl.innerHTML = `
            <button type="button" class="cmenu-item bold" data-act="open" data-id="${itemId}">
              <span>⚡ ${DX.i18n.t('sim.cmenuOpen')}</span>
            </button>
            <div class="cmenu-divider"></div>
            <button type="button" class="cmenu-item" data-act="cut" data-id="${itemId}">
              <span>✂️ ${DX.i18n.t('sim.cmenuCut')}</span>
            </button>
            <button type="button" class="cmenu-item" data-act="copy" data-id="${itemId}">
              <span>📄 ${DX.i18n.t('sim.cmenuCopy')}</span>
            </button>
            <div class="cmenu-divider"></div>
            <button type="button" class="cmenu-item" data-act="rename" data-id="${itemId}">
              <span>✏️ ${DX.i18n.t('sim.cmenuRename')} (F2)</span>
            </button>
            <button type="button" class="cmenu-item" data-act="delete" data-id="${itemId}">
              <span>🗑️ ${DX.i18n.t('sim.cmenuDelete')} (Suppr)</span>
            </button>
            <div class="cmenu-divider"></div>
            <button type="button" class="cmenu-item" data-act="properties" data-id="${itemId}">
              <span>ℹ️ ${DX.i18n.t('sim.cmenuProps')}</span>
            </button>
          `;
        }
      } else if (type === 'taskbar') {
        this.menuEl.innerHTML = `
          <button type="button" class="cmenu-item" data-act="taskmgr">
            <span>📊 ${DX.i18n.t('sim.cmenuTaskmgr')}</span>
          </button>
          <button type="button" class="cmenu-item" data-act="settings">
            <span>⚙️ ${DX.i18n.t('sim.appSettings')}</span>
          </button>
        `;
      }

      this.attachActionListeners();
    }

    attachActionListeners() {
      this.menuEl.querySelectorAll('[data-act]').forEach((btn) => {
        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          const act = btn.getAttribute('data-act');
          const id = btn.getAttribute('data-id');
          const parent = btn.getAttribute('data-parent') || 'desktop';
          this.handleAction(act, id, parent);
          this.close();
        });
      });
    }

    handleAction(action, itemId, parentId) {
      DX.audio?.playClick?.();
      switch (action) {
        case 'view-large':
        case 'view-medium':
        case 'view-small': {
          const size = action.replace('view-', '');
          DX.desktopSim?.setIconSize?.(size);
          DX.desktopSim?.emit('viewChanged', size);
          break;
        }
        case 'sort-name':
          DX.desktopSim?.setSortBy?.('name');
          DX.desktopSim?.emit('sortChanged', 'name');
          break;
        case 'sort-size':
          DX.desktopSim?.setSortBy?.('size');
          DX.desktopSim?.emit('sortChanged', 'size');
          break;
        case 'refresh':
          DX.desktopSim?.render?.();
          DX.desktopSim?.emit('refreshClicked');
          break;
        case 'personalize':
          DX.desktopSim?.openApp?.('settings');
          DX.desktopSim?.emit('personalizeOpened');
          break;
        case 'paste':
          DX.desktopSim?.pasteClipboard?.(parentId);
          break;
        case 'new-folder':
          DX.desktopSim?.createNewFolderInline?.(parentId);
          break;
        case 'new-doc':
          DX.desktopSim?.createNewDocInline?.(parentId);
          break;
        case 'open':
          DX.desktopSim?.openItemById?.(itemId);
          break;
        case 'cut':
          DX.fs?.setClipboard?.('cut', itemId);
          DX.desktopSim?.render?.();
          DX.desktopSim?.emit('itemCut', itemId);
          break;
        case 'copy':
          DX.fs?.setClipboard?.('copy', itemId);
          DX.desktopSim?.emit('itemCopied', itemId);
          break;
        case 'rename':
          DX.desktopSim?.startRenameInline?.(itemId);
          break;
        case 'delete':
          DX.fs?.deleteItem?.(itemId);
          DX.desktopSim?.render?.();
          DX.desktopSim?.emit('itemDeleted', itemId);
          break;
        case 'restore':
          DX.fs?.restoreItem?.(itemId);
          DX.desktopSim?.render?.();
          DX.desktopSim?.emit('itemRestored', itemId);
          break;
        case 'properties':
          DX.desktopSim?.openPropertiesWindow?.(itemId);
          break;
        case 'taskmgr':
          DX.desktopSim?.openApp?.('taskmgr');
          break;
        case 'settings':
          DX.desktopSim?.openApp?.('settings');
          break;
      }
    }
  }

  DX.ContextMenuManager = ContextMenuManager;
  DX.contextMenu = new ContextMenuManager();
})(window.DX);
