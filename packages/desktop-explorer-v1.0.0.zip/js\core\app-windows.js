// ============================================================================
// TeachIT Educational Game: Desktop Explorer
// File: js/core/app-windows.js
// Purpose: Built-in desktop apps: Notepad Editor, Explorer, Trash, Task Manager, Settings, Props
// Dependencies: window.DX.desktopSim, window.DX.fs, window.DX.i18n, window.DX.audio
// ============================================================================

window.DX = window.DX || {};

(function (DX) {
  'use strict';

  class AppWindowsManager {
    constructor() {
      this.currentEditorFileId = null;
      this.editorIsDirty = false;
    }

    init() {
      this.setupEditor();
      this.setupExplorer();
      this.setupTrash();
      this.setupTaskManager();
      this.setupSettingsApp();
    }

    setupEditor() {
      const textarea = document.getElementById('editorTextarea');
      textarea?.addEventListener('input', () => {
        this.editorIsDirty = true;
        DX.desktopSim?.emit('editorInput', textarea.value);
      });

      document.getElementById('btnEditorSave')?.addEventListener('click', () => this.saveEditorDocument());
      document.getElementById('btnEditorSaveAs')?.addEventListener('click', () => this.openSaveAsDialog());
      document.getElementById('btnInsertSuggestedText')?.addEventListener('click', () => {
        if (!textarea) return;
        textarea.value = DX.i18n.t('sim.editorSuggestedText');
        this.editorIsDirty = true;
        DX.desktopSim?.emit('editorInput', textarea.value);
      });

      document.getElementById('btnDialogSaveCancel')?.addEventListener('click', () => {
        document.getElementById('dialogSaveAs')?.classList.remove('active');
      });
      document.getElementById('btnDialogSaveConfirm')?.addEventListener('click', () => {
        this.confirmSaveAsDialog();
      });
    }

    saveEditorDocument() {
      if (this.currentEditorFileId) {
        const file = DX.fs.getItem(this.currentEditorFileId);
        const textarea = document.getElementById('editorTextarea');
        if (file && textarea) {
          file.content = textarea.value;
          this.editorIsDirty = false;
          DX.audio?.playClick?.();
          DX.desktopSim?.emit('documentSaved', file);
          DX.desktopSim?.emit('fileSaved', file);
          return;
        }
      }
      this.openSaveAsDialog();
    }

    openSaveAsDialog() {
      const overlay = document.getElementById('dialogSaveAs');
      const select = document.getElementById('saveFolderSelect');
      if (!overlay) return;
      if (select) {
        select.innerHTML = '<option value="desktop">Bureau</option>';
        const folders = Array.from(DX.fs.items.values()).filter((i) => i.type === 'folder' && i.id !== 'desktop' && i.parentId !== 'trash');
        folders.forEach((f) => {
          select.innerHTML += `<option value="${f.id}">${f.name}</option>`;
        });
      }
      overlay.classList.add('active');
    }

    confirmSaveAsDialog() {
      const input = document.getElementById('inputDocName');
      const select = document.getElementById('saveFolderSelect');
      const textarea = document.getElementById('editorTextarea');
      const name = (input?.value || 'Mon premier document').trim();
      const parentId = select?.value || 'desktop';
      const content = textarea?.value || '';

      const doc = DX.fs.createFile(parentId, name, content, 'txt');
      this.currentEditorFileId = doc.id;
      this.editorIsDirty = false;
      document.getElementById('dialogSaveAs')?.classList.remove('active');
      DX.audio?.playClick?.();
      DX.desktopSim?.render();
      DX.desktopSim?.emit('documentSaved', doc);
      DX.desktopSim?.emit('fileSaved', doc);
    }

    setupExplorer() {
      const winExplorer = document.getElementById('windowExplorer');
      const grid = document.getElementById('explorerGrid');

      winExplorer?.addEventListener('dragover', (e) => {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        winExplorer.querySelector('.window-body')?.classList.add('drag-target-hover');
      });
      winExplorer?.addEventListener('dragleave', (e) => {
        if (!winExplorer.contains(e.relatedTarget)) {
          winExplorer.querySelector('.window-body')?.classList.remove('drag-target-hover');
        }
      });
      winExplorer?.addEventListener('drop', (e) => {
        e.preventDefault();
        e.stopPropagation();
        winExplorer.querySelector('.window-body')?.classList.remove('drag-target-hover');
        const draggedId = e.dataTransfer.getData('text/plain');
        const currentFolderId = DX.desktopSim?.wm?.windows?.explorer?.currentFolderId || 'desktop';
        if (draggedId && draggedId !== currentFolderId) {
          DX.fs.moveItem(draggedId, currentFolderId);
          DX.audio?.playClick?.();
          DX.desktopSim?.render();
          this.renderExplorerContent(currentFolderId);
          DX.desktopSim?.emit('itemMoved', { id: draggedId, targetId: currentFolderId });
        }
      });

      grid?.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const icon = e.target.closest('.desktop-icon');
        const folderId = DX.desktopSim?.wm?.windows?.explorer?.currentFolderId || 'desktop';
        if (icon) {
          const id = icon.id.replace(/^exp-/, '');
          DX.selection?.selectItem(id);
          DX.contextMenu?.open(e.clientX, e.clientY, 'item', { itemId: id });
        } else {
          DX.selection?.clearSelection();
          DX.contextMenu?.open(e.clientX, e.clientY, 'folder', { folderId });
        }
      });
    }

    renderExplorerContent(folderId) {
      const grid = document.getElementById('explorerGrid');
      const pathEl = document.getElementById('explorerAddressPath');
      if (!grid) return;
      grid.innerHTML = '';
      const folder = DX.fs.getItem(folderId);
      const name = folder ? folder.name : DX.i18n.t('sim.desktop');
      if (pathEl) pathEl.textContent = `${DX.i18n.t('sim.desktop')} > ${name}`;

      const items = DX.fs.getChildren(folderId);
      if (items.length === 0) {
        grid.innerHTML = `<div class="explorer-empty-msg">${DX.i18n.t('sim.emptyFolder')}</div>`;
        return;
      }

      items.forEach((item) => {
        const iconSrc = item.type === 'folder' ? 'assets/icons/folder.svg' : 'assets/icons/document.svg';
        const el = DX.desktopSim?.createIconElement(item.id, item.name, iconSrc, () => {
          if (item.type === 'folder') DX.desktopSim?.openFolder(item.id);
          else DX.desktopSim?.openFile(item.id);
        });
        if (el) grid.appendChild(el);
      });
    }

    setupTrash() {
      document.getElementById('btnEmptyTrash')?.addEventListener('click', () => {
        DX.fs.emptyTrash();
        DX.audio?.playClick?.();
        this.renderTrashContent();
        DX.desktopSim?.emit('trashEmptied');
      });
      document.getElementById('btnRestoreTrashItem')?.addEventListener('click', () => {
        const selected = DX.selection?.getSelectedIds() || [];
        if (selected[0]) {
          DX.fs.restoreItem(selected[0]);
          DX.audio?.playClick?.();
          this.renderTrashContent();
          DX.desktopSim?.render();
          DX.desktopSim?.emit('itemRestored', selected[0]);
        }
      });
    }

    renderTrashContent() {
      const body = document.querySelector('#windowTrash .window-body');
      if (!body) return;
      const items = DX.fs.getChildren('trash');
      if (items.length === 0) {
        body.innerHTML = `<div class="explorer-empty-msg">${DX.i18n.t('sim.trashEmpty')}</div>`;
        return;
      }
      body.innerHTML = '<div class="explorer-grid" id="trashGrid"></div>';
      const grid = document.getElementById('trashGrid');
      items.forEach((item) => {
        const iconSrc = item.type === 'folder' ? 'assets/icons/folder.svg' : 'assets/icons/document.svg';
        const el = DX.desktopSim?.createIconElement(`trash-${item.id}`, item.name, iconSrc, () => {});
        if (!el) return;
        el.addEventListener('contextmenu', (e) => {
          e.preventDefault();
          e.stopPropagation();
          DX.contextMenu?.open(e.clientX, e.clientY, 'item', { itemId: item.id });
        });
        grid?.appendChild(el);
      });
    }

    setupTaskManager() {
      document.getElementById('btnEndTask')?.addEventListener('click', () => {
        const selectedRow = document.querySelector('.taskmgr-row.selected');
        const appId = selectedRow?.getAttribute('data-app');
        if (appId) {
          DX.audio?.playWindowClose?.();
          DX.desktopSim?.wm?.closeWindow(appId);
          DX.desktopSim?.updateWindowsUI();
          this.renderTaskManagerContent();
          DX.desktopSim?.emit('taskEnded', appId);
        }
      });
    }

    renderTaskManagerContent() {
      const container = document.getElementById('taskmgrAppsList');
      if (!container) return;
      container.innerHTML = '';
      const openWins = Object.values(DX.desktopSim?.wm?.windows || {}).filter((w) => w.isOpen && w.id !== 'taskmgr');
      if (openWins.length === 0) {
        container.innerHTML = '<div class="taskmgr-empty">Aucune application active.</div>';
        return;
      }
      openWins.forEach((w) => {
        const row = document.createElement('div');
        row.className = 'taskmgr-row';
        row.setAttribute('data-app', w.id);
        row.innerHTML = `<img src="${w.icon}" class="taskmgr-icon" alt="" /><span>${DX.i18n.t(w.titleKey)}</span>`;
        row.addEventListener('click', () => {
          container.querySelectorAll('.taskmgr-row').forEach((r) => r.classList.remove('selected'));
          row.classList.add('selected');
        });
        container.appendChild(row);
      });
    }

    setupSettingsApp() {
      document.querySelectorAll('[data-wallpaper]').forEach((btn) => {
        btn.addEventListener('click', () => {
          const wp = btn.getAttribute('data-wallpaper');
          DX.desktopSim?.setWallpaper(wp);
        });
      });
      document.querySelectorAll('[data-iconsize]').forEach((btn) => {
        btn.addEventListener('click', () => {
          const sz = btn.getAttribute('data-iconsize');
          DX.desktopSim?.setIconSize(sz);
        });
      });
    }

    openPropertiesWindow(itemId) {
      const props = DX.fs.getItemProperties(itemId);
      if (!props) return;
      const setTxt = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
      setTxt('propValName', props.name);
      setTxt('propValType', props.type);
      setTxt('propValLocation', props.location);
      setTxt('propValSize', props.size);
      setTxt('propValDate', props.createdAt);
      DX.desktopSim?.openApp?.('properties');
      DX.desktopSim?.emit('propertiesOpened', itemId);
    }
  }

  DX.AppWindowsManager = AppWindowsManager;
  DX.appWindows = new AppWindowsManager();
})(window.DX);
