// ============================================================================
// TeachIT Educational Game: Desktop Explorer
// File: js/screens/about.js
// Purpose: About screen displaying game metadata, TeachIT suite details, and student ID
// Dependencies: window.DX.config, window.DX.app, window.DX.i18n, window.DX.screens
// ============================================================================

window.DX = window.DX || {};

(function (DX) {
  'use strict';

  function render() {
    const titleEl = document.getElementById('aboutGameTitle');
    const versionEl = document.getElementById('aboutGameVersion');
    const studentEl = document.getElementById('aboutStudentId');

    if (titleEl) titleEl.textContent = DX.config?.name || 'Desktop Explorer';
    if (versionEl) versionEl.textContent = `v${DX.config?.version || '1.0.0'}`;

    if (studentEl) {
      const studentId = DX.app?.sessionInfo?.studentId || 'Mode Invité (Guest)';
      studentEl.textContent = studentId;
    }
  }

  function setupEvents() {
    document.getElementById('btnAboutBack')?.addEventListener('click', () => {
      DX.audio?.playBack?.();
      DX.screens.show('menu');
    });

    DX.i18n.onChange(() => {
      if (DX.screens.getCurrent() === 'about') {
        render();
      }
    });
  }

  DX.aboutScreen = {
    render,
    setupEvents,
  };

  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', setupEvents);
    } else {
      setupEvents();
    }
  }
})(window.DX);
