// ============================================================================
// TeachIT Educational Game: Desktop Explorer
// File: js/core/audio.js
// Purpose: WebAudio procedural synthesizer for ambient music & sound effects
// Dependencies: window.DX.storage
// ============================================================================

window.DX = window.DX || {};

(function (DX) {
  'use strict';

  let ctx = null;
  let musicGainNode = null;
  let sfxGainNode = null;
  let musicTimer = null;
  let hasInteracted = false;
  let isWindowVisible = true;

  const settings = DX.storage.getSettings();
  let sfxEnabled = settings.sfxEnabled;
  let musicEnabled = settings.musicEnabled;
  let sfxVolume = settings.sfxVolume;
  let musicVolume = settings.musicVolume;

  function getAudioContext() {
    if (!ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) {
        ctx = new AudioCtx();
        musicGainNode = ctx.createGain();
        sfxGainNode = ctx.createGain();
        musicGainNode.gain.setValueAtTime(musicEnabled ? musicVolume : 0, ctx.currentTime);
        sfxGainNode.gain.setValueAtTime(sfxEnabled ? sfxVolume : 0, ctx.currentTime);
        musicGainNode.connect(ctx.destination);
        sfxGainNode.connect(ctx.destination);
      }
    }
    if (ctx && ctx.state === 'suspended' && hasInteracted) {
      ctx.resume().catch(() => {});
    }
    return ctx;
  }

  function playTone(freq, type = 'sine', duration = 0.1, gainVal = 0.3) {
    if (!sfxEnabled) return;
    const ac = getAudioContext();
    if (!ac) return;
    try {
      const osc = ac.createOscillator();
      const gain = ac.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, ac.currentTime);
      gain.gain.setValueAtTime(gainVal, ac.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ac.currentTime + duration);
      osc.connect(gain);
      gain.connect(sfxGainNode);
      osc.start();
      osc.stop(ac.currentTime + duration);
    } catch { /* safe */ }
  }

  function playClick() { playTone(520, 'triangle', 0.05, 0.2); }
  function playConfirm() {
    if (!sfxEnabled) return;
    [440, 554, 659].forEach((freq, idx) => setTimeout(() => playTone(freq, 'sine', 0.12, 0.25), idx * 55));
  }
  function playBack() {
    if (!sfxEnabled) return;
    [480, 360].forEach((freq, idx) => setTimeout(() => playTone(freq, 'triangle', 0.1, 0.2), idx * 60));
  }
  function playDialogOpen() { playTone(380, 'sine', 0.15, 0.2); }
  function playWin() {
    if (!sfxEnabled) return;
    [523, 659, 784, 1046].forEach((freq, idx) => setTimeout(() => playTone(freq, 'sine', 0.25, 0.35), idx * 90));
  }
  function playWindowOpen() { playTone(400, 'sine', 0.08, 0.18); }
  function playWindowClose() { playTone(280, 'sine', 0.08, 0.18); }
  function playFolderCreated() {
    if (!sfxEnabled) return;
    [320, 480].forEach((freq, idx) => setTimeout(() => playTone(freq, 'triangle', 0.1, 0.22), idx * 60));
  }
  function playDocSaved() {
    if (!sfxEnabled) return;
    [400, 500, 600].forEach((freq, idx) => setTimeout(() => playTone(freq, 'sine', 0.12, 0.25), idx * 70));
  }

  // Calm Looping Ambient Music
  const CHORDS = [
    [130.81, 196.0, 261.63, 329.63],
    [110.0, 164.81, 220.0, 261.63],
    [146.83, 220.0, 293.66, 349.23],
    [98.0, 146.83, 196.0, 246.94],
  ];
  let chordIndex = 0;

  function playAmbientChord() {
    if (!musicEnabled || !isWindowVisible) return;
    const ac = getAudioContext();
    if (!ac) return;

    const chord = CHORDS[chordIndex % CHORDS.length];
    chordIndex++;
    const now = ac.currentTime;
    const chordDuration = 3.8;

    chord.forEach((freq, i) => {
      try {
        const osc = ac.createOscillator();
        const filter = ac.createBiquadFilter();
        const gain = ac.createGain();
        osc.type = i === 0 ? 'sine' : 'triangle';
        osc.frequency.setValueAtTime(freq, now);
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(550, now);
        gain.gain.setValueAtTime(0.001, now);
        gain.gain.linearRampToValueAtTime(0.07 / chord.length, now + 1.2);
        gain.gain.linearRampToValueAtTime(0.001, now + chordDuration);
        osc.connect(filter);
        filter.connect(gain);
        gain.connect(musicGainNode);
        osc.start(now);
        osc.stop(now + chordDuration);
      } catch { /* safe */ }
    });
    musicTimer = setTimeout(playAmbientChord, 3500);
  }

  function startMusic() {
    if (!hasInteracted || !musicEnabled || musicTimer) return;
    playAmbientChord();
  }

  function stopMusic() {
    if (musicTimer) { clearTimeout(musicTimer); musicTimer = null; }
  }

  function handleFirstInteraction() {
    if (hasInteracted) return;
    hasInteracted = true;
    const ac = getAudioContext();
    if (ac && ac.state === 'suspended') {
      ac.resume().then(() => { if (musicEnabled && isWindowVisible) startMusic(); });
    } else if (musicEnabled && isWindowVisible) {
      startMusic();
    }
    window.removeEventListener('pointerdown', handleFirstInteraction);
    window.removeEventListener('keydown', handleFirstInteraction);
  }

  window.addEventListener('pointerdown', handleFirstInteraction, { passive: true });
  window.addEventListener('keydown', handleFirstInteraction, { passive: true });

  document.addEventListener('visibilitychange', () => {
    isWindowVisible = !document.hidden;
    if (document.hidden) {
      stopMusic();
      if (ctx && ctx.state === 'running') ctx.suspend().catch(() => {});
    } else {
      if (ctx && ctx.state === 'suspended' && hasInteracted) ctx.resume().catch(() => {});
      if (musicEnabled && hasInteracted) startMusic();
    }
  });

  function setSfxEnabled(val) {
    sfxEnabled = Boolean(val);
    if (sfxGainNode && ctx) sfxGainNode.gain.setValueAtTime(sfxEnabled ? sfxVolume : 0, ctx.currentTime);
    persistSettings();
  }

  function setMusicEnabled(val) {
    musicEnabled = Boolean(val);
    if (musicGainNode && ctx) musicGainNode.gain.setValueAtTime(musicEnabled ? musicVolume : 0, ctx.currentTime);
    if (musicEnabled) startMusic();
    else stopMusic();
    persistSettings();
  }

  function setSfxVolume(vol) {
    sfxVolume = Math.max(0, Math.min(1, vol));
    if (sfxGainNode && ctx && sfxEnabled) sfxGainNode.gain.setValueAtTime(sfxVolume, ctx.currentTime);
    persistSettings();
  }

  function setMusicVolume(vol) {
    musicVolume = Math.max(0, Math.min(1, vol));
    if (musicGainNode && ctx && musicEnabled) musicGainNode.gain.setValueAtTime(musicVolume, ctx.currentTime);
    persistSettings();
  }

  function persistSettings() {
    DX.storage.saveSettings({ sfxEnabled, musicEnabled, sfxVolume, musicVolume });
  }

  DX.audio = {
    playClick, playConfirm, playBack, playDialogOpen, playWin,
    playWindowOpen, playWindowClose, playFolderCreated, playDocSaved,
    startMusic, stopMusic,
    getSfxEnabled: () => sfxEnabled, setSfxEnabled,
    getMusicEnabled: () => musicEnabled, setMusicEnabled,
    getSfxVolume: () => sfxVolume, setSfxVolume,
    getMusicVolume: () => musicVolume, setMusicVolume,
  };
})(window.DX);
