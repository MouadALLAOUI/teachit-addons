// ============================================================================
// TeachIT Educational Game: Desktop Explorer
// File: js/levels/05-final.js
// Purpose: Level 5 — Final mission validated strictly from simulated file system state
// Dependencies: window.DX.levels, window.DX.fs, window.DX.desktopSim
// ============================================================================

window.DX = window.DX || {};

(function (DX) {
  'use strict';

  const FOLDER_NAMES = ['informatique', 'cours', 'حاسوب', 'معلوميات', 'computer', 'informatics', 'dossier', 'folder'];
  const DOC_NAMES = ['mon premier document', 'document', 'premier', 'مستندي الأول', 'مستند', 'my first document', 'texte', 'txt'];

  const OBJECTIVES = [
    { id: 'folderCreated', labelKey: 'level.final.task1' },
    { id: 'docCreated', labelKey: 'level.final.task2' },
    { id: 'docMoved', labelKey: 'level.final.task3' },
    { id: 'trashCleaned', labelKey: 'level.final.task4' },
  ];

  let currentCtx = null;
  let taskState = {
    folderCreated: false,
    docCreated: false,
    docMoved: false,
    trashCleaned: false,
  };
  const cleanupFns = [];

  function getAllItems() {
    if (!DX.fs) return [];
    if (typeof DX.fs.getAll === 'function') return DX.fs.getAll();
    return Array.from(DX.fs.items?.values?.() || []);
  }

  function mount(container, ctx) {
    currentCtx = ctx;

    const save = ctx.storage.loadGame() || {};
    taskState = Object.assign(taskState, save.levelData?.final?.tasks || {});

    container.innerHTML = `
      <div class="level-banner" id="l5Banner">
        <div class="banner-info">
          <span class="banner-badge">${ctx.t('level.term')} 5 / 5</span>
          <span class="banner-step" id="l5StepBadge">Mission Finale</span>
          <h2 class="banner-instruction">${ctx.t('level.final.desc')}</h2>
        </div>
        <div class="banner-actions">
          <button type="button" class="btn btn-secondary btn-sm" id="l5BtnMissions">📋 ${ctx.t('levels.missionsBtn')}</button>
          <button type="button" class="btn btn-secondary btn-sm" id="l5BtnHint">💡 ${ctx.t('header.hint')}</button>
        </div>
      </div>

      <div class="level-checklist-panel" id="l5ChecklistPanel">
        <div class="checklist-header">
          <h3 class="checklist-title">${ctx.t('level.final.short')} — Objectifs</h3>
          <button type="button" class="checklist-close-btn" id="l5BtnCloseChecklist" aria-label="Close">✕</button>
        </div>
        <div class="mission-tasks-grid" id="l5TasksGrid"></div>
      </div>
    `;

    DX.tipsPanel?.attach?.(document.getElementById('l5ChecklistPanel'));
    renderTasks();
    setupListeners();
    checkFileSystemState();
  }

  function renderTasks() {
    const grid = document.getElementById('l5TasksGrid');
    if (!grid || !currentCtx) return;

    grid.innerHTML = OBJECTIVES.map((t) => {
      const isDone = Boolean(taskState[t.id]);
      return `
        <div class="mission-task-row ${isDone ? 'done' : ''}">
          <img src="${isDone ? 'assets/icons/check.svg' : 'assets/icons/lock.svg'}" class="task-check-icon" alt="" />
          <span>${currentCtx.t(t.labelKey)}</span>
        </div>
      `;
    }).join('');
  }

  function checkFileSystemState() {
    if (!currentCtx || !DX.fs) return;
    try {
      const all = getAllItems();

      const infoFolder = all.find(
        (i) => i.type === 'folder' && i.id !== 'desktop' && i.id !== 'trash' && i.parentId !== 'trash' && FOLDER_NAMES.some((n) => i.name.toLowerCase().includes(n)),
      ) || all.find((i) => i.type === 'folder' && i.id !== 'desktop' && i.id !== 'trash' && i.parentId !== 'trash');
      taskState.folderCreated = Boolean(infoFolder);

      const docFile = all.find(
        (i) => (i.type === 'file' || i.extension === 'txt') && i.parentId !== 'trash' && DOC_NAMES.some((n) => i.name.toLowerCase().includes(n)),
      ) || all.find((i) => (i.type === 'file' || i.extension === 'txt') && i.parentId !== 'trash');
      taskState.docCreated = Boolean(docFile);

      if (infoFolder && docFile && (docFile.parentId === infoFolder.id || (docFile.parentId !== 'desktop' && docFile.parentId !== 'trash'))) {
        taskState.docMoved = true;
      }

      const trashChildren = DX.fs.getChildren ? DX.fs.getChildren('trash') : [];
      taskState.trashCleaned = trashChildren.length === 0;

      renderTasks();

      const save = currentCtx.storage.loadGame() || {};
      save.levelData = save.levelData || {};
      save.levelData.final = { tasks: taskState };
      save.fsItems = DX.fs.serialize();
      currentCtx.storage.saveGame(save);

      const allDone = OBJECTIVES.every((t) => taskState[t.id]);
      if (allDone) {
        setTimeout(() => {
          currentCtx.complete({ scoreBonus: 100 });
        }, 800);
      }
    } catch (err) {
      console.error('[Level 5] Error checking file system state:', err);
    }
  }

  function setupListeners() {
    const onFsChange = () => checkFileSystemState();

    DX.desktopSim?.on('folderCreated', onFsChange);
    DX.desktopSim?.on('documentSaved', onFsChange);
    DX.desktopSim?.on('documentCreated', onFsChange);
    DX.desktopSim?.on('fileSaved', onFsChange);
    DX.desktopSim?.on('itemMoved', onFsChange);
    DX.desktopSim?.on('itemDeleted', onFsChange);
    DX.desktopSim?.on('itemRestored', onFsChange);
    DX.desktopSim?.on('itemPasted', onFsChange);
    DX.desktopSim?.on('trashEmptied', onFsChange);
    DX.desktopSim?.on('itemRenamed', onFsChange);

    // Missions button toggle & close button
    const btnMissions = document.getElementById('l5BtnMissions');
    const btnCloseChecklist = document.getElementById('l5BtnCloseChecklist');
    btnMissions?.addEventListener('click', () => DX.tipsPanel?.toggle?.());
    btnCloseChecklist?.addEventListener('click', () => DX.tipsPanel?.hide?.());

    cleanupFns.push(() => {
      DX.desktopSim?.off('folderCreated', onFsChange);
      DX.desktopSim?.off('documentSaved', onFsChange);
      DX.desktopSim?.off('documentCreated', onFsChange);
      DX.desktopSim?.off('fileSaved', onFsChange);
      DX.desktopSim?.off('itemMoved', onFsChange);
      DX.desktopSim?.off('itemDeleted', onFsChange);
      DX.desktopSim?.off('itemRestored', onFsChange);
      DX.desktopSim?.off('itemPasted', onFsChange);
      DX.desktopSim?.off('trashEmptied', onFsChange);
      DX.desktopSim?.off('itemRenamed', onFsChange);
    });

    document.getElementById('l5BtnHint')?.addEventListener('click', () => {
      currentCtx?.audio?.playClick?.();
      checkFileSystemState();
    });
  }

  function onLanguageChange() {
    if (!currentCtx) return;
    renderTasks();
    const instruction = document.querySelector('#l5Banner .banner-instruction');
    if (instruction) instruction.textContent = currentCtx.t('level.final.desc');
    const badge = document.querySelector('#l5Banner .banner-badge');
    if (badge) badge.textContent = `${currentCtx.t('level.term')} 5 / 5`;
    const title = document.querySelector('#l5ChecklistPanel .checklist-title');
    if (title) title.textContent = `${currentCtx.t('level.final.short')} — Objectifs`;
    const btnM = document.getElementById('l5BtnMissions');
    if (btnM) btnM.textContent = `📋 ${currentCtx.t('levels.missionsBtn')}`;
    const hintBtn = document.getElementById('l5BtnHint');
    if (hintBtn) hintBtn.textContent = `💡 ${currentCtx.t('header.hint')}`;
  }

  function start() {
    checkFileSystemState();
  }

  function destroy() {
    while (cleanupFns.length > 0) {
      const fn = cleanupFns.pop();
      try { fn(); } catch (err) { console.error('[Level 5] Cleanup error:', err); }
    }
  }

  DX.levels = DX.levels || { register: () => {} };
  DX.levels.register({
    id: 'final',
    order: 5,
    titleKey: 'level.final.title',
    descKey: 'level.final.desc',
    icon: 'assets/icons/mission.svg',
    mount,
    start,
    destroy,
    onLanguageChange,
  });
})(window.DX);
