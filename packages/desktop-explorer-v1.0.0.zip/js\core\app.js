// ============================================================================
// TeachIT Educational Game: Desktop Explorer
// File: js/core/app.js
// Purpose: Main game orchestrator, level registry, exit handler & background canvas
// Dependencies: window.DX.config, window.DX.screens, window.DX.dialog, window.DX.audio
// ============================================================================

window.DX = window.DX || {};

(function (DX) {
  'use strict';

  // --- Level Registry ---
  const registeredLevels = new Map();
  let currentLevel = null;

  const levels = {
    register(levelDef) {
      if (levelDef?.id) registeredLevels.set(levelDef.id, levelDef);
    },
    getAll() {
      const order = DX.config?.levelOrder || [];
      const list = Array.from(registeredLevels.values());
      list.sort((a, b) => {
        const idxA = order.indexOf(a.id);
        const idxB = order.indexOf(b.id);
        if (idxA !== -1 && idxB !== -1) return idxA - idxB;
        return (a.order || 0) - (b.order || 0);
      });
      return list;
    },
    get(id) { return registeredLevels.get(id) || null; },
    getCurrent() { return currentLevel; },
    async launch(levelId) {
      const level = registeredLevels.get(levelId);
      if (!level) return;

      if (currentLevel && typeof currentLevel.destroy === 'function') {
        try { currentLevel.destroy(); } catch (err) { console.error('[DX.levels] Destroy error:', err); }
      }

      currentLevel = level;
      DX.screens.show('game');

      const container = document.getElementById('levelGameplayContainer');
      if (container) container.innerHTML = '';

      const ctx = {
        t: DX.i18n.t,
        audio: DX.audio,
        storage: DX.storage,
        filesystem: DX.fs,
        desktopSim: DX.desktopSim,
        goToMenu: () => DX.screens.show('menu'),
        complete: (data) => app.completeLevel(level.id, data),
      };

      if (typeof level.mount === 'function') level.mount(container, ctx);
      if (typeof level.start === 'function') level.start();

      const save = DX.storage.loadGame() || {};
      save.currentLevelId = levelId;
      DX.storage.saveGame(save);
      DX.screens.updateHeaderTabs();
    },
  };

  // --- App Orchestrator ---
  const app = {
    sessionInfo: null,
    async init() {
      DX.screens.init();
      DX.desktopSim.init();
      this.initBackgroundCanvas();
      await this.initSession();

      document.getElementById('btnHeaderMenu')?.addEventListener('click', () => {
        DX.audio?.playClick?.();
        DX.screens.show('menu');
      });
      document.getElementById('btnHeaderSettings')?.addEventListener('click', () => {
        DX.audio?.playClick?.();
        DX.screens.show('settings');
      });
      document.getElementById('btnHeaderExit')?.addEventListener('click', () => {
        this.confirmExit();
      });

      DX.i18n?.onChange?.((lang) => {
        DX.screens.updateHeaderTabs();
        DX.desktopSim?.render?.();
        DX.desktopSim?.updateWindowsUI?.();
        if (currentLevel && typeof currentLevel.onLanguageChange === 'function') {
          currentLevel.onLanguageChange(lang);
        }
      });

      DX.screens.show('menu');
    },

    async initSession() {
      const teachit = window.teachit;
      if (teachit && typeof teachit.getSessionInfo === 'function') {
        try { this.sessionInfo = await teachit.getSessionInfo(); } catch { /* standalone */ }
      }
    },

    completeLevel(levelId, data = {}) {
      DX.audio?.playWin?.();
      const save = DX.storage.loadGame() || { unlockedLevelIds: ['desktop'], completedLevelIds: [] };
      const completed = new Set(save.completedLevelIds || []);
      completed.add(levelId);
      save.completedLevelIds = Array.from(completed);

      const all = levels.getAll();
      const currentIdx = all.findIndex((l) => l.id === levelId);
      if (currentIdx !== -1 && currentIdx + 1 < all.length) {
        const nextLevel = all[currentIdx + 1];
        const unlocked = new Set(save.unlockedLevelIds || ['desktop']);
        unlocked.add(nextLevel.id);
        save.unlockedLevelIds = Array.from(unlocked);
      }

      save.score = (save.score || 0) + (data.scoreBonus || 50);
      DX.storage.saveGame(save);

      const allCompleted = all.length > 0 && all.every((l) => completed.has(l.id));
      if (allCompleted) {
        this.reportProgress(true);
        DX.screens.show('results');
      } else if (currentIdx !== -1 && currentIdx + 1 < all.length) {
        levels.launch(all[currentIdx + 1].id);
      } else {
        DX.screens.show('levels');
      }
    },

    reportProgress(isCompleted = false) {
      const teachit = window.teachit;
      if (!teachit || typeof teachit.reportProgress !== 'function') return;
      const save = DX.storage.loadGame() || {};
      const completedCount = save.completedLevelIds?.length || 0;
      const allLevels = levels.getAll();

      teachit.reportProgress({
        activityId: 'desktop-explorer-complete',
        eventType: isCompleted ? 'activity_completed' : 'score_recorded',
        payload: {
          score: save.score || 400,
          maxScore: 500,
          durationSeconds: 180,
          success: isCompleted,
          metrics: {
            completedChallenges: completedCount,
            totalChallenges: allLevels.length || 5,
            status: isCompleted ? 'completed' : 'in_progress',
          },
        },
      }).catch(() => {});
    },

    async confirmExit() {
      DX.audio?.playDialogOpen?.();
      const confirmed = await DX.dialog.confirm({
        title: DX.i18n.t('dialog.confirmExitTitle'),
        message: DX.i18n.t('dialog.confirmExitMsg'),
        confirmText: DX.i18n.t('dialog.confirmExitLeave'),
        cancelText: DX.i18n.t('dialog.confirmExitStay'),
        defaultButton: 'cancel',
        confirmDanger: true,
      });
      if (confirmed) this.exitApp();
    },

    exitApp() {
      if (window.teachit && typeof window.teachit.exit === 'function') {
        window.teachit.exit();
      } else if (window.teachit && typeof window.teachit.exitGame === 'function') {
        window.teachit.exitGame();
      } else if (typeof history !== 'undefined' && history.length > 1) {
        history.back();
      } else {
        window.close();
      }
    },

    initBackgroundCanvas() {
      const canvas = document.getElementById('menuBackgroundCanvas');
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      let width = (canvas.width = window.innerWidth);
      let height = (canvas.height = window.innerHeight);

      window.addEventListener('resize', () => {
        width = canvas.width = window.innerWidth;
        height = canvas.height = window.innerHeight;
      });

      const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      const silhouettes = [
        { type: 'window', x: width * 0.15, y: height * 0.25, size: 70, vx: 0.12, vy: -0.08, rot: 0.05 },
        { type: 'folder', x: width * 0.75, y: height * 0.2, size: 55, vx: -0.1, vy: 0.09, rot: -0.04 },
        { type: 'document', x: width * 0.82, y: height * 0.7, size: 50, vx: -0.09, vy: -0.07, rot: 0.08 },
        { type: 'cursor', x: width * 0.25, y: height * 0.75, size: 40, vx: 0.08, vy: 0.08, rot: -0.05 },
      ];

      function draw() {
        ctx.clearRect(0, 0, width, height);
        ctx.strokeStyle = 'rgba(99, 102, 241, 0.035)';
        ctx.lineWidth = 1;
        const gridSize = 48;
        for (let x = 0; x < width; x += gridSize) {
          ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, height); ctx.stroke();
        }
        for (let y = 0; y < height; y += gridSize) {
          ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(width, y); ctx.stroke();
        }

        ctx.fillStyle = 'rgba(129, 140, 248, 0.045)';
        ctx.strokeStyle = 'rgba(129, 140, 248, 0.09)';
        ctx.lineWidth = 2;

        silhouettes.forEach((s) => {
          ctx.save();
          ctx.translate(s.x, s.y);
          ctx.rotate(s.rot);
          if (s.type === 'window') {
            ctx.strokeRect(-s.size / 2, -s.size / 3, s.size, s.size * 0.7);
            ctx.beginPath(); ctx.moveTo(-s.size / 2, -s.size / 3 + 12); ctx.lineTo(s.size / 2, -s.size / 3 + 12); ctx.stroke();
          } else if (s.type === 'folder') {
            ctx.strokeRect(-s.size / 2, -s.size / 3, s.size, s.size * 0.65);
          } else if (s.type === 'document') {
            ctx.strokeRect(-s.size / 3, -s.size / 2, s.size * 0.66, s.size);
          } else if (s.type === 'cursor') {
            ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(s.size * 0.6, s.size * 0.4); ctx.lineTo(s.size * 0.35, s.size * 0.45); ctx.lineTo(s.size * 0.5, s.size * 0.8); ctx.closePath(); ctx.stroke();
          }
          ctx.restore();

          if (!prefersReducedMotion && !document.hidden) {
            s.x += s.vx; s.y += s.vy;
            if (s.x < -100) s.x = width + 100;
            if (s.x > width + 100) s.x = -100;
            if (s.y < -100) s.y = height + 100;
            if (s.y > height + 100) s.y = -100;
          }
        });

        if (!prefersReducedMotion && !document.hidden) {
          requestAnimationFrame(draw);
        }
      }

      draw();
      document.addEventListener('visibilitychange', () => {
        if (!document.hidden && !prefersReducedMotion) requestAnimationFrame(draw);
      });
    },
  };

  DX.levels = levels;
  DX.app = app;
})(window.DX);
