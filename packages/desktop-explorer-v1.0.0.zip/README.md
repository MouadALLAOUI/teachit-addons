# Desktop Explorer — Educational Game for TeachIT

Desktop Explorer is an offline-first Windows educational game designed for TeachIT to teach computer fundamentals (_informatique_) to teenage students in Morocco. Students explore an authentic simulated desktop environment, master window controls, create and organize folders, write text documents, and practice genuine Windows workflows.

---

## 1. Project Structure & Conventions

```text
desktop-explorer/
├── game.json                 # TeachIT GameManifest metadata
├── index.html                # Markup and ordered script/link tags only
├── WINDOWS-SIM-AUDIT.md      # Shell features & level interaction audit
├── LEVELS-REPORT.md          # Post-rework objective & detection report
├── README.md                 # Technical documentation & extension guides
├── CHANGELOG.md              # Migration log & architectural details
├── assets/
│   ├── icons/                # Clean SVG vector icons (no remote fonts/emojis)
│   ├── images/               # Local static images
│   ├── wallpapers/           # Desktop backgrounds
│   └── fonts/                # Local font fallbacks
├── css/
│   ├── base.css              # Global tokens, typography & canvas background
│   ├── ui.css                # Buttons, dialogs, header & language switcher
│   ├── menu.css              # Full-screen classic PC game menu
│   ├── levels-screen.css     # High-contrast 2-column + featured card levels screen
│   ├── desktop-sim.css       # Simulated desktop, windows, taskbar, context menu
│   ├── windows-shell.css     # Snapping, marquee, submenus, peek, apps
│   └── levels/
│       ├── 01-desktop.css    # Level 1 specific styles
│       ├── 02-windows.css    # Level 2 specific styles
│       ├── 03-folders.css    # Level 3 specific styles
│       ├── 04-documents.css  # Level 4 specific styles
│       └── 05-final.css      # Level 5 specific styles
└── js/
    ├── config.js             # Game name, version, level order & storage key
    ├── core/
    │   ├── i18n.js           # Translation resolver & RTL document handler
    │   ├── storage.js        # LocalStorage persistence & legacy save migration
    │   ├── audio.js          # WebAudio ambient music & procedural sound effects
    │   ├── dialog.js         # Accessible modal dialogs (confirm, alert)
    │   ├── screens.js        # Screen router & slim header synchronization
    │   ├── filesystem.js     # Virtual filesystem, clipboard, restore, properties
    │   ├── window-manager.js # Window lifecycle, dragging, top snap, z-order
    │   ├── selection.js      # Single, Ctrl+click multi-select, rubber-band marquee
    │   ├── shortcuts.js      # Scoped keyboard shortcuts (F2, Del, Ctrl+C/X/V/S, etc.)
    │   ├── context-menu.js   # Dynamic context menus with submenus & boundary flipping
    │   ├── taskbar.js        # Taskbar window tabs, live clock, Show Desktop peek
    │   ├── tips-panel.js     # Interactive tips panel (50% hover opacity, 4 corners)
    │   ├── app-windows.js    # Built-in apps: Notepad, Explorer, Trash, Task Manager, Settings
    │   ├── desktop-sim.js    # Desktop orchestrator (icons, wallpaper, rename)
    │   └── app.js            # Main orchestrator, level registry, exit handling
    ├── screens/
    │   ├── menu.js           # Main menu controller & compact learning path
    │   ├── levels.js         # Levels selection screen controller
    │   ├── settings.js       # Audio volume, language, and reset progress screen
    │   └── about.js          # Game details, version, and student profile ID
    ├── levels/
    │   ├── 01-desktop.js     # Level 1: Discover the desktop
    │   ├── 02-windows.js     # Level 2: Windows and applications
    │   ├── 03-folders.js     # Level 3: Folders and organization
    │   ├── 04-documents.js   # Level 4: Documents authoring and saving
    │   └── 05-final.js       # Level 5: Final autonomous mission
    └── i18n/
        ├── fr.js             # French dictionary (Source of Truth)
        ├── ar.js             # Arabic dictionary (RTL)
        └── en.js             # English dictionary
```

---

## 2. Windows Shell Architecture & Core Modules

The simulated desktop behaves like Windows through dedicated, single-responsibility modules:
1. **Window Manager (`window-manager.js`)**: Coordinates window boundaries, z-order, titlebar dragging clamped strictly above the taskbar, top-edge snap maximize, dragging a maximized window down to restore geometry, and titlebar double-click.
2. **Taskbar Manager (`taskbar.js`)**: Manages the persistent bottom bar, start menu button, task buttons with active highlight and focus/minimize toggle, system clock, and the "Show Desktop" peek button.
3. **Context Menu (`context-menu.js`)**: Provides target-sensitive context menus (Desktop, File/Folder, Explorer canvas, Taskbar) with submenus (`View >`, `Sort by >`, `New >`), boundary collision flipping, and dismissal on click outside or Esc.
4. **Selection & Shortcuts (`selection.js`, `shortcuts.js`)**: Implements single selection, `Ctrl+click` multi-selection, rubber-band box marquee selection, and scoped shortcuts (`F2` rename, `Delete`, `Ctrl+C`, `Ctrl+X`, `Ctrl+V`, `Ctrl+S`, `Enter`, Arrow keys).
5. **App Windows (`app-windows.js`)**: Hosts Notepad (with Save As dialog, Ctrl+S, dirty state close warning), File Explorer, Recycle Bin (with restore & empty), Task Manager (with live "End task" termination), Settings (wallpapers & icon sizes), and Properties dialog.
6. **Tips Panel (`tips-panel.js`)**: Interactive guidance card with smooth 50% opacity on hover and click-to-cycle positioning across screen corners.

---

## 3. Extension Guides

### How to Add a New Application
1. Add window markup in `index.html` inside `#windowsContainer`:
   ```html
   <div class="simulated-window" id="windowCalculator" role="dialog" aria-modal="false">
     <div class="window-titlebar" id="winCalculatorTitlebar">
       <span class="window-title">Calculatrice</span>
       <button type="button" class="win-btn btn-close" id="btnCalculatorClose">✕</button>
     </div>
     <div class="window-body">...</div>
   </div>
   ```
2. Register the window in `js/core/window-manager.js` constructor:
   ```javascript
   this.windows.calculator = {
     id: 'calculator',
     titleKey: 'sim.appCalculator',
     icon: 'assets/icons/calculator.svg',
     isOpen: false, isMinimized: false, isMaximized: false,
     zIndex: 20, x: 240, y: 100, w: 320, h: 420
   };
   ```
3. Add a launcher button in `index.html` inside `#startMenuPopover`:
   ```html
   <button type="button" class="context-menu-item" id="startItemCalc">
     <span>🔢 Calculatrice</span>
   </button>
   ```
4. Map the button in `js/core/desktop-sim.js` in `setupStartMenuApps`:
   ```javascript
   const map = { startItemCalc: 'calculator', ... };
   ```

### How to Add a Context Menu Entry
1. Open `js/core/context-menu.js`.
2. In `buildMenuMarkup()`, add your button to the corresponding target section (`desktop`, `item`, `folder`, or `taskbar`):
   ```html
   <button type="button" class="cmenu-item" data-act="my-custom-action" data-id="${itemId}">
     <span>⚡ Action Personnalisée</span>
   </button>
   ```
3. In `handleAction(action, itemId, parentId)`:
   ```javascript
   case 'my-custom-action':
     // Execute your custom logic or emit an event
     DX.desktopSim?.emit('myCustomAction', itemId);
     break;
   ```

### How to Add a New Level
1. Create `css/levels/06-my-level.css`.
2. Create `js/levels/06-my-level.js`:
   ```javascript
   window.DX = window.DX || {};
   window.DX.levels.register({
     id: 'mylevel',
     order: 6,
     titleKey: 'level.mylevel.title',
     descKey: 'level.mylevel.desc',
     icon: 'assets/icons/star.svg',
     mount(container, ctx) {
       container.innerHTML = `<div class="level-banner"><h2>${ctx.t('level.mylevel.title')}</h2></div>`;
     },
     start() {},
     destroy() {}
   });
   ```
3. Add entry to `js/config.js` `levels` array.
4. Add translation keys to `fr.js`, `ar.js`, and `en.js`.
5. Link the script and style tags in `index.html`.

### How to Add a New Language
1. Create `js/i18n/<code>.js` with the key dictionary matching `fr.js`.
2. Register the language in `js/config.js` `supportedLocales`.
3. Add language button in `index.html` to `#headerLangSwitcher` and `#menuLangSwitcher`.
4. Include `<script src="./js/i18n/<code>.js"></script>` in `index.html`.
