// ============================================================================
// TeachIT Educational Game: Desktop Explorer
// File: js/core/dialog.js
// Purpose: Accessible modal dialogs (Confirm, Alert) with keyboard support
// Dependencies: window.DX.audio, window.DX.i18n
// ============================================================================

window.DX = window.DX || {};

(function (DX) {
  'use strict';

  let dialogContainer = null;
  let previousActiveElement = null;

  function ensureContainer() {
    if (!dialogContainer) {
      dialogContainer = document.getElementById('dxGlobalDialog');
      if (!dialogContainer) {
        dialogContainer = document.createElement('div');
        dialogContainer.id = 'dxGlobalDialog';
        dialogContainer.className = 'dx-dialog-overlay';
        dialogContainer.setAttribute('role', 'dialog');
        dialogContainer.setAttribute('aria-modal', 'true');
        dialogContainer.setAttribute('tabindex', '-1');
        document.body.appendChild(dialogContainer);
      }
    }
    return dialogContainer;
  }

  function confirm(options) {
    const {
      title = DX.i18n?.t('dialog.confirmStartTitle') || 'Confirmation',
      message = '',
      confirmText = DX.i18n?.t('dialog.confirmStartOk') || 'Confirmer',
      cancelText = DX.i18n?.t('dialog.confirmStartCancel') || 'Annuler',
      defaultButton = 'cancel', // 'cancel' or 'confirm'
      confirmDanger = false,
    } = options;

    return new Promise((resolve) => {
      previousActiveElement = document.activeElement;

      const overlay = ensureContainer();
      DX.audio?.playDialogOpen?.();

      overlay.innerHTML = `
        <div class="dx-dialog-box" role="document">
          <div class="dx-dialog-header">
            <h3 class="dx-dialog-title">${title}</h3>
            <button type="button" class="dx-dialog-close-btn" id="dxDialogBtnClose" aria-label="Fermer">✕</button>
          </div>
          <div class="dx-dialog-body">
            <p class="dx-dialog-message">${message}</p>
          </div>
          <div class="dx-dialog-footer">
            <button type="button" class="btn btn-secondary dx-dialog-cancel" id="dxDialogBtnCancel">${cancelText}</button>
            <button type="button" class="btn ${confirmDanger ? 'btn-danger' : 'btn-primary'} dx-dialog-confirm" id="dxDialogBtnConfirm">${confirmText}</button>
          </div>
        </div>
      `;

      overlay.classList.add('active');

      const btnCancel = document.getElementById('dxDialogBtnCancel');
      const btnConfirm = document.getElementById('dxDialogBtnConfirm');
      const btnClose = document.getElementById('dxDialogBtnClose');

      const closeWithResult = (res) => {
        overlay.classList.remove('active');
        overlay.innerHTML = '';
        document.removeEventListener('keydown', handleKey);

        if (previousActiveElement && typeof previousActiveElement.focus === 'function') {
          previousActiveElement.focus();
        }

        if (res) {
          DX.audio?.playConfirm?.();
        } else {
          DX.audio?.playBack?.();
        }
        resolve(res);
      };

      const handleKey = (e) => {
        if (e.key === 'Escape') {
          e.preventDefault();
          closeWithResult(false);
        } else if (e.key === 'Tab') {
          const focusable = overlay.querySelectorAll('button');
          if (focusable.length === 0) return;
          const first = focusable[0];
          const last = focusable[focusable.length - 1];

          if (e.shiftKey && document.activeElement === first) {
            e.preventDefault();
            last.focus();
          } else if (!e.shiftKey && document.activeElement === last) {
            e.preventDefault();
            first.focus();
          }
        }
      };

      document.addEventListener('keydown', handleKey);

      btnCancel?.addEventListener('click', () => closeWithResult(false));
      btnConfirm?.addEventListener('click', () => closeWithResult(true));
      btnClose?.addEventListener('click', () => closeWithResult(false));

      // Focus default button
      setTimeout(() => {
        if (defaultButton === 'confirm') {
          btnConfirm?.focus();
        } else {
          btnCancel?.focus();
        }
      }, 30);
    });
  }

  function alert(options) {
    const {
      title = 'Information',
      message = '',
      okText = DX.i18n?.t('sim.btnOk') || 'OK',
    } = options;

    return new Promise((resolve) => {
      previousActiveElement = document.activeElement;
      const overlay = ensureContainer();
      DX.audio?.playDialogOpen?.();

      overlay.innerHTML = `
        <div class="dx-dialog-box" role="document">
          <div class="dx-dialog-header">
            <h3 class="dx-dialog-title">${title}</h3>
            <button type="button" class="dx-dialog-close-btn" id="dxDialogBtnClose" aria-label="Fermer">✕</button>
          </div>
          <div class="dx-dialog-body">
            <p class="dx-dialog-message">${message}</p>
          </div>
          <div class="dx-dialog-footer">
            <button type="button" class="btn btn-primary" id="dxDialogBtnOk">${okText}</button>
          </div>
        </div>
      `;

      overlay.classList.add('active');

      const btnOk = document.getElementById('dxDialogBtnOk');
      const btnClose = document.getElementById('dxDialogBtnClose');

      const close = () => {
        overlay.classList.remove('active');
        overlay.innerHTML = '';
        document.removeEventListener('keydown', handleKey);
        if (previousActiveElement && typeof previousActiveElement.focus === 'function') {
          previousActiveElement.focus();
        }
        DX.audio?.playClick?.();
        resolve();
      };

      const handleKey = (e) => {
        if (e.key === 'Escape' || e.key === 'Enter') {
          e.preventDefault();
          close();
        }
      };

      document.addEventListener('keydown', handleKey);
      btnOk?.addEventListener('click', close);
      btnClose?.addEventListener('click', close);

      setTimeout(() => btnOk?.focus(), 30);
    });
  }

  DX.dialog = {
    confirm,
    alert,
  };
})(window.DX);
