// ============================================================================
// TeachIT Educational Game: Desktop Explorer
// File: js/levels/03-folders.js
// Purpose: Level 3 — Creating, renaming, exploring, and organizing folders
// Dependencies: window.DX.levels, window.DX.fs, window.DX.desktopSim
// ============================================================================

window.DX = window.DX || {};

(function (DX) {
  'use strict';

  const TARGET_NAMES = ['informatique', 'cours', 'dossier', 'حاسوب', 'معلوميات', 'computer', 'informatics'];

  const OBJECTIVES = [
    { id: 'createFolder', labelKey: 'level.folders.task1' },
    { id: 'renameFolder', labelKey: 'level.folders.task2' },
    { id: 'openFolder', labelKey: 'level.folders.task3' },
    { id: 'createSubfolder', labelKey: 'level.folders.task4' },
    { id: 'deleteRestore', labelKey: 'level.folders.task5' },
    { id: 'viewProps', labelKey: 'level.folders.task6' },
  ];

  let currentCtx = null;
  let completedTasks = new Set();
  let hasDeleted = false;
  const cleanupFns = [];

  function mount(container, ctx) {
    currentCtx = ctx;

    const save = ctx.storage.loadGame() || {};
    const existing = save.levelData?.folders?.completedTasks;
    completedTasks = Array.isArray(existing) ? new Set(existing) : new Set();

    container.innerHTML = `
      <div class="level-banner" id="l3Banner">
        <div class="banner-info">
          <span class="banner-badge">${ctx.t('level.term')} 3 / 5</span>
          <span class="banner-step" id="l3StepBadge">${completedTasks.size} / ${OBJECTIVES.length} ${ctx.t('levels.statusCompleted')}</span>
          <h2 class="banner-instruction">${ctx.t('level.folders.desc')}</h2>
        </div>
        <div class="banner-actions">
          <button type="button" class="btn btn-secondary btn-sm" id="l3BtnMissions">📋 ${ctx.t('levels.missionsBtn')}</button>
          <button type="button" class="btn btn-secondary btn-sm" id="l3BtnHint">💡 ${ctx.t('header.hint')}</button>
        </div>
      </div>

      <div class="level-checklist-panel" id="l3ChecklistPanel">
        <div class="checklist-header">
          <h3 class="checklist-title">${ctx.t('level.folders.short')} — Objectifs</h3>
          <button type="button" class="checklist-close-btn" id="l3BtnCloseChecklist" aria-label="Close">✕</button>
        </div>
        <div class="checklist-grid" id="l3ChecklistGrid"></div>
        <div class="checklist-hint-box" id="l3HintBox" style="display:none; margin-top:10px; font-size:12px; color:var(--border-highlight);"></div>
      </div>
    `;

    DX.tipsPanel?.attach?.(document.getElementById('l3ChecklistPanel'));
    renderChecklist();
    setupListeners();
    checkExistingFolderState();
  }

  function checkExistingFolderState() {
    if (!DX.fs) return;
    const all = typeof DX.fs.getAll === 'function' ? DX.fs.getAll() : Array.from(DX.fs.items?.values?.() || []);
    const desktopFolders = all.filter((i) => i.type === 'folder' && i.parentId === 'desktop' && i.id !== 'trash');
    const namedFolder = desktopFolders.find((f) => TARGET_NAMES.some((t) => f.name.toLowerCase().includes(t)));
    const subfolders = all.filter((i) => i.type === 'folder' && i.parentId !== 'desktop' && i.parentId !== 'trash');

    if (desktopFolders.length > 0) markDone('createFolder');
    if (namedFolder) markDone('renameFolder');
    if (subfolders.length > 0) markDone('createSubfolder');
    if (DX.desktopSim?.wm?.windows?.explorer?.isOpen && DX.desktopSim.wm.windows.explorer.currentFolderId !== 'desktop') {
      markDone('openFolder');
    }
  }

  function renderChecklist() {
    const grid = document.getElementById('l3ChecklistGrid');
    const badge = document.getElementById('l3StepBadge');
    if (!grid || !currentCtx) return;

    if (badge) {
      badge.textContent = `${completedTasks.size} / ${OBJECTIVES.length} ${currentCtx.t('levels.statusCompleted')}`;
    }

    grid.innerHTML = OBJECTIVES.map((obj) => {
      const isDone = completedTasks.has(obj.id);
      return `
        <div class="check-item ${isDone ? 'done' : ''}" data-obj="${obj.id}">
          <img src="${isDone ? 'assets/icons/check.svg' : 'assets/icons/lock.svg'}" class="check-item-icon" alt="" />
          <span>${currentCtx.t(obj.labelKey)}</span>
        </div>
      `;
    }).join('');
  }

  function markDone(objId) {
    if (!currentCtx || completedTasks.has(objId)) return;
    completedTasks.add(objId);
    currentCtx.audio?.playClick?.();
    renderChecklist();

    const save = currentCtx.storage.loadGame() || {};
    save.levelData = save.levelData || {};
    save.levelData.folders = { completedTasks: Array.from(completedTasks) };
    save.fsItems = DX.fs.serialize();
    currentCtx.storage.saveGame(save);

    if (completedTasks.size >= OBJECTIVES.length) {
      setTimeout(() => {
        currentCtx.complete({ scoreBonus: 50 });
      }, 700);
    }
  }

  function setupListeners() {
    const onFolderCreated = (folder) => {
      if (folder.parentId === 'desktop') {
        markDone('createFolder');
      } else {
        markDone('createSubfolder');
      }
    };

    const onRenamed = (data) => {
      const name = (data.newName || '').toLowerCase();
      if (TARGET_NAMES.some((t) => name.includes(t))) {
        markDone('renameFolder');
      }
    };

    const onOpenFolder = (folderId) => {
      if (folderId && folderId !== 'desktop') {
        markDone('openFolder');
      }
    };

    const onItemDeleted = () => {
      hasDeleted = true;
    };
    const onItemRestored = () => {
      if (hasDeleted) markDone('deleteRestore');
    };

    const onProps = () => markDone('viewProps');

    DX.desktopSim?.on('folderCreated', onFolderCreated);
    DX.desktopSim?.on('itemRenamed', onRenamed);
    DX.desktopSim?.on('openFolder', onOpenFolder);
    DX.desktopSim?.on('itemDeleted', onItemDeleted);
    DX.desktopSim?.on('itemRestored', onItemRestored);
    DX.desktopSim?.on('propertiesOpened', onProps);

    // Missions button toggle & close button
    const btnMissions = document.getElementById('l3BtnMissions');
    const btnCloseChecklist = document.getElementById('l3BtnCloseChecklist');
    btnMissions?.addEventListener('click', () => DX.tipsPanel?.toggle?.());
    btnCloseChecklist?.addEventListener('click', () => DX.tipsPanel?.hide?.());

    cleanupFns.push(() => {
      DX.desktopSim?.off('folderCreated', onFolderCreated);
      DX.desktopSim?.off('itemRenamed', onRenamed);
      DX.desktopSim?.off('openFolder', onOpenFolder);
      DX.desktopSim?.off('itemDeleted', onItemDeleted);
      DX.desktopSim?.off('itemRestored', onItemRestored);
      DX.desktopSim?.off('propertiesOpened', onProps);
    });

    document.getElementById('l3BtnHint')?.addEventListener('click', () => {
      currentCtx?.audio?.playClick?.();
      const next = OBJECTIVES.find((o) => !completedTasks.has(o.id));
      const hintBox = document.getElementById('l3HintBox');
      if (next && hintBox) {
        hintBox.textContent = `💡 Indice : ${currentCtx.t(next.labelKey)}`;
        hintBox.style.display = 'block';
      }
    });
  }

  function onLanguageChange() {
    if (!currentCtx) return;
    renderChecklist();
    const instruction = document.querySelector('#l3Banner .banner-instruction');
    if (instruction) instruction.textContent = currentCtx.t('level.folders.desc');
    const badge = document.querySelector('#l3Banner .banner-badge');
    if (badge) badge.textContent = `${currentCtx.t('level.term')} 3 / 5`;
    const title = document.querySelector('#l3ChecklistPanel .checklist-title');
    if (title) title.textContent = `${currentCtx.t('level.folders.short')} — Objectifs`;
    const btnM = document.getElementById('l3BtnMissions');
    if (btnM) btnM.textContent = `📋 ${currentCtx.t('levels.missionsBtn')}`;
    const hintBtn = document.getElementById('l3BtnHint');
    if (hintBtn) hintBtn.textContent = `💡 ${currentCtx.t('header.hint')}`;
  }

  function start() {
    renderChecklist();
    checkExistingFolderState();
  }

  function destroy() {
    while (cleanupFns.length > 0) {
      const fn = cleanupFns.pop();
      try { fn(); } catch (err) { console.error('[Level 3] Cleanup error:', err); }
    }
  }

  DX.levels = DX.levels || { register: () => {} };
  DX.levels.register({
    id: 'folders',
    order: 3,
    titleKey: 'level.folders.title',
    descKey: 'level.folders.desc',
    icon: 'assets/icons/folder.svg',
    mount,
    start,
    destroy,
    onLanguageChange,
  });
})(window.DX);
