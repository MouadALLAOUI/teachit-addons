// ============================================================================
// TeachIT Educational Game: Desktop Explorer
// File: js/screens/menu.js
// Purpose: Main Game Menu screen with classic PC game layout & learning path
// Dependencies: window.DX.config, window.DX.storage, window.DX.levels, window.DX.dialog
// ============================================================================

window.DX = window.DX || {};

(function (DX) {
  'use strict';

  function render() {
    const titleEl = document.getElementById('menuGameTitle');
    const versionEl = document.getElementById('menuGameVersion');
    if (titleEl) titleEl.textContent = DX.config?.name || 'Desktop Explorer';
    if (versionEl) versionEl.textContent = `v${DX.config?.version || '1.0.0'}`;

    const save = DX.storage.loadGame() || {};
    const hasExistingSave = DX.storage.hasSave();
    const completedIds = new Set(save.completedLevelIds || []);
    const allLevels = DX.levels.getAll();

    // Strict sequential unlocking
    const unlockedIds = new Set();
    allLevels.forEach((l, idx) => {
      if (idx === 0 || completedIds.has(allLevels[idx - 1].id)) {
        unlockedIds.add(l.id);
      }
    });

    const allCompleted = allLevels.length > 0 && allLevels.every((l) => completedIds.has(l.id));

    // Determine target level for "Continue"
    let continueLevelId = save.currentLevelId || 'desktop';
    let continueLevelIdx = allLevels.findIndex((l) => l.id === continueLevelId);
    if (continueLevelIdx === -1) continueLevelIdx = 0;

    // Continue button configuration
    const btnContinue = document.getElementById('menuBtnContinue');
    const continueSub = document.getElementById('menuContinueSub');
    if (btnContinue) {
      if (hasExistingSave) {
        btnContinue.disabled = false;
        btnContinue.classList.remove('btn-disabled');
        if (continueSub) {
          if (allCompleted) {
            continueSub.textContent = DX.i18n.t('menu.allCompleted');
          } else {
            continueSub.textContent = DX.i18n.t('menu.continueSub', { level: continueLevelIdx + 1 });
          }
        }
      } else {
        btnContinue.disabled = true;
        btnContinue.classList.add('btn-disabled');
        if (continueSub) continueSub.textContent = '';
      }
    }

    // Render Compact Learning Path (Right side of menu)
    renderLearningPath(allLevels, completedIds, unlockedIds, continueLevelId, allCompleted);

    // Render Language Switcher on menu
    renderLangSwitcher();
  }

  function renderLearningPath(allLevels, completedIds, unlockedIds, activeLevelId, allCompleted) {
    const container = document.getElementById('menuLearningPathList');
    if (!container) return;
    container.innerHTML = '';

    allLevels.forEach((lvl, idx) => {
      const isCompleted = completedIds.has(lvl.id);
      const isCurrent = !allCompleted && activeLevelId === lvl.id;
      const isLocked = !isCompleted && !unlockedIds.has(lvl.id);

      let statusClass = 'locked';
      let statusIcon = 'assets/icons/lock.svg';
      let statusText = DX.i18n.t('levels.statusLocked');

      if (isCompleted) {
        statusClass = 'completed';
        statusIcon = 'assets/icons/check.svg';
        statusText = DX.i18n.t('levels.statusCompleted');
      } else if (isCurrent) {
        statusClass = 'current';
        statusIcon = 'assets/icons/play.svg';
        statusText = DX.i18n.t('levels.statusCurrent');
      }

      const item = document.createElement('div');
      item.className = `learning-path-step ${statusClass}`;
      item.innerHTML = `
        <div class="step-badge-wrap">
          <span class="step-order">${idx + 1}</span>
          <img src="${statusIcon}" class="step-status-icon" alt="" aria-hidden="true" />
        </div>
        <div class="step-info">
          <div class="step-title">${DX.i18n.t(lvl.shortKey || lvl.titleKey)}</div>
          <div class="step-status">${statusText}</div>
        </div>
      `;

      if (!isLocked) {
        item.tabIndex = 0;
        item.setAttribute('role', 'button');
        item.title = `${DX.i18n.t('levels.play')} ${idx + 1}`;
        item.addEventListener('click', () => {
          DX.audio?.playClick?.();
          DX.levels.launch(lvl.id);
        });
        item.addEventListener('keydown', (e) => {
          if (e.key === 'Enter') {
            DX.levels.launch(lvl.id);
          }
        });
      }

      container.appendChild(item);
    });
  }

  function renderLangSwitcher() {
    const container = document.getElementById('menuLangSwitcher');
    if (!container) return;
    const current = DX.i18n.getLanguage();

    const langs = [
      { code: 'ar', label: 'العربية', title: 'العربية (Arabic)' },
      { code: 'fr', label: 'Français', title: 'Français (French)' },
      { code: 'en', label: 'English', title: 'English' },
    ];

    container.innerHTML = langs
      .map(
        (l) => `
        <button type="button" class="lang-seg-btn ${current === l.code ? 'active' : ''}" data-lang="${l.code}" title="${l.title}">
          ${l.label}
        </button>
      `,
      )
      .join('');

    container.querySelectorAll('.lang-seg-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const lang = btn.getAttribute('data-lang');
        DX.audio?.playClick?.();
        DX.i18n.setLanguage(lang);
      });
    });
  }

  function setupEvents() {
    // Continue
    document.getElementById('menuBtnContinue')?.addEventListener('click', () => {
      DX.audio?.playClick?.();
      const save = DX.storage.loadGame() || {};
      const allLevels = DX.levels.getAll();
      const completedIds = new Set(save.completedLevelIds || []);
      const allCompleted = allLevels.length > 0 && allLevels.every((l) => completedIds.has(l.id));

      if (allCompleted) {
        DX.screens.show('levels');
      } else {
        const targetId = save.currentLevelId || 'desktop';
        DX.levels.launch(targetId);
      }
    });

    // Start
    document.getElementById('menuBtnStart')?.addEventListener('click', async () => {
      DX.audio?.playClick?.();
      if (DX.storage.hasSave()) {
        const confirmed = await DX.dialog.confirm({
          title: DX.i18n.t('dialog.confirmStartTitle'),
          message: DX.i18n.t('dialog.confirmStartMsg'),
          confirmText: DX.i18n.t('dialog.confirmStartOk'),
          cancelText: DX.i18n.t('dialog.confirmStartCancel'),
          defaultButton: 'cancel',
          confirmDanger: true,
        });
        if (!confirmed) return;
      }

      // Reset progress & file system for clean start
      DX.storage.clearGame();
      DX.fs.reset();
      const allLevels = DX.levels.getAll();
      const firstId = allLevels[0]?.id || 'desktop';
      DX.levels.launch(firstId);
    });

    // Levels
    document.getElementById('menuBtnLevels')?.addEventListener('click', () => {
      DX.audio?.playClick?.();
      DX.screens.show('levels');
    });

    // Settings
    document.getElementById('menuBtnSettings')?.addEventListener('click', () => {
      DX.audio?.playClick?.();
      DX.screens.show('settings');
    });

    // About
    document.getElementById('menuBtnAbout')?.addEventListener('click', () => {
      DX.audio?.playClick?.();
      DX.screens.show('about');
    });

    // Exit
    document.getElementById('menuBtnExit')?.addEventListener('click', () => {
      DX.app.confirmExit();
    });

    // Language change subscriber
    DX.i18n.onChange(() => {
      if (DX.screens.getCurrent() === 'menu') {
        render();
      }
    });

    // Keyboard navigation (Up/Down in menu buttons)
    const menuButtons = document.getElementById('menuButtonStack');
    if (menuButtons) {
      menuButtons.addEventListener('keydown', (e) => {
        const buttons = Array.from(menuButtons.querySelectorAll('button:not([disabled])'));
        const idx = buttons.indexOf(document.activeElement);
        if (e.key === 'ArrowDown') {
          e.preventDefault();
          const next = (idx + 1) % buttons.length;
          buttons[next]?.focus();
        } else if (e.key === 'ArrowUp') {
          e.preventDefault();
          const prev = (idx - 1 + buttons.length) % buttons.length;
          buttons[prev]?.focus();
        }
      });
    }
  }

  DX.menuScreen = {
    render,
    setupEvents,
  };

  // Init when DOM is loaded
  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', setupEvents);
    } else {
      setupEvents();
    }
  }
})(window.DX);
