# LEVELS-REPORT.md — Desktop Explorer Levels Rework Report

**Project:** TeachIT Educational Game Launcher — Desktop Explorer  
**Module:** `apps/launcher/games/desktop-explorer`  
**Date:** October 31, 2026  

---

## 1. Overview of Pedagogical Overhaul

The game has been upgraded from artificial step counters and helper buttons to an **authentic Windows observation model**. Students interact directly with the simulated operating system using standard Windows workflows (mouse, touch, and keyboard). The level monitors the live state of the simulated shell, file system, active windows, selection, and clipboard, checking off objectives in real time.

---

## 2. Level-by-Level Rework Details

### Level 1: "Le Bureau" (Discover the Desktop)
- **Learning Goal:** Identify the primary components of a PC desktop operating system.
- **What Changed:** Removed passive click listeners and hardcoded sequence. Replaced with an interactive discovery of 6 authentic desktop areas.
- **Final Checklist of Objectives:**
  1. `wallpaper`: Click on an empty area of the desktop wallpaper.
  2. `icon`: Select any desktop icon (or double-click to open).
  3. `startMenu`: Open the Start menu from the taskbar.
  4. `clock`: Click on the system clock or taskbar.
  5. `viewSort`: Customize desktop view (change icon size via `View > Small/Medium/Large` or `Sort by`).
  6. `refresh`: Refresh the desktop via right-click context menu.
- **How Detected:**
  - `onWallpaperClick` on `#simulatedDesktop` / `#desktopWallpaperArt`.
  - `DX.desktopSim.on('select')`.
  - `DX.desktopSim.on('startMenuToggled', true)`.
  - Click on `#systemClock` or `#simulatedTaskbar`.
  - `DX.desktopSim.on('viewChanged')` / `DX.desktopSim.on('sortChanged')`.
  - `DX.desktopSim.on('refreshClicked')`.
- **Accepted Alternative Ways:**
  - Icons can be selected with mouse single-click, touch tap, or Arrow keys.
  - Start menu can be toggled via Start button click or touch.
  - View can be changed to Small, Medium, or Large; Sort can be by Name or Size.

---

### Level 2: "Fenêtres" (Windows and Applications)
- **Learning Goal:** Master window states (open, drag, maximize, restore, minimize, close) and multi-tasking.
- **What Changed:** Removed artificial sequential buttons. Replaced with live detection of window geometry, snap preview, and taskbar integration.
- **Final Checklist of Objectives:**
  1. `openApp`: Open an application (Notepad, File Explorer, Trash, or Task Manager).
  2. `dragWindow`: Drag any window by its titlebar across the desktop.
  3. `maximize`: Maximize a window (snap to top edge, titlebar double-click, or 🗖 button).
  4. `minimizeRestore`: Minimize a window to the taskbar, then restore it by clicking its taskbar button.
  5. `multiWindows`: Open a second application so two windows exist simultaneously.
  6. `closeWindow`: Close a window (via titlebar ✕ or Task Manager "Fin de tâche").
- **How Detected:**
  - `DX.desktopSim.on('openApp')`.
  - Pointer movement during window drag (`DX.desktopSim.wm.on('windowMoved')` or `pointermove`).
  - `DX.desktopSim.wm.on('windowSnapped')` or `DX.desktopSim.wm.on('windowMaximized', isMax=true)`.
  - `DX.desktopSim.wm.on('windowMinimized')` followed by `DX.desktopSim.wm.on('windowRestored')`.
  - Querying `openWins.length >= 2`.
  - `DX.desktopSim.on('windowClosed')` or `DX.desktopSim.on('taskEnded')`.
- **Accepted Alternative Ways:**
  - Open via desktop icon double-click, Enter key on selected icon, or Start menu.
  - Maximize via drag-to-top snap, titlebar double-click, or window control button.
  - Close via window titlebar ✕ button or selecting the app in Task Manager and clicking "Fin de tâche".

---

### Level 3: "Dossiers" (Folders and Organization)
- **Learning Goal:** Folder lifecycle: creation, renaming, hierarchy, navigation, trash, and properties.
- **What Changed:** Removed the fake helper button (`#l3BtnHelper`). Added real right-click context menu creation, `F2` keyboard shortcut, real Recycle Bin restoration, and properties dialog.
- **Final Checklist of Objectives:**
  1. `createFolder`: Create a new folder on the desktop.
  2. `renameFolder`: Rename the folder to "Informatique" (or Arabic/English equivalent).
  3. `openFolder`: Double-click the folder to open it in File Explorer.
  4. `createSubfolder`: Create a subfolder inside the open folder.
  5. `deleteRestore`: Delete an item to Recycle Bin, then restore it.
  6. `viewProps`: Inspect folder Properties.
- **How Detected:**
  - `DX.desktopSim.on('folderCreated')` with `parentId === 'desktop'`.
  - `DX.desktopSim.on('itemRenamed')` matching multilingual candidates.
  - `DX.desktopSim.on('openFolder')`.
  - `DX.desktopSim.on('folderCreated')` with `parentId !== 'desktop'`.
  - `DX.desktopSim.on('itemDeleted')` followed by `DX.desktopSim.on('itemRestored')`.
  - `DX.desktopSim.on('propertiesOpened')`.
- **Accepted Alternative Ways:**
  - Create folder via right-click on desktop canvas or inside explorer window.
  - Rename via context menu "Renommer" or pressing `F2`.
  - Delete via context menu "Supprimer" or `Delete` keyboard key.
  - Restore via context menu "Restaurer" or toolbar button in Recycle Bin window.
  - Multilingual names accepted: `Informatique`, `حاسوب`, `معلوميات`, `Computer`, `Informatics`.

---

### Level 4: "Documents" (Text Creation and Saving)
- **Learning Goal:** Document authoring, text editing, saving to disk with Save As dialog, and reopening.
- **What Changed:** Removed step-by-step locks. Allows typing at any time, saving via `Ctrl+S` or toolbar button, picking destination folder in Save As modal, and reopening from Explorer.
- **Final Checklist of Objectives:**
  1. `openEditor`: Open the Text Editor (Notepad).
  2. `typeText`: Type text into the editor.
  3. `saveDocument`: Save the document as "Mon premier document" (or Arabic/English equivalent).
  4. `closeEditor`: Close the editor window.
  5. `reopenVerify`: Reopen the saved document and verify content.
- **How Detected:**
  - `DX.desktopSim.on('openApp', 'editor')`.
  - `DX.desktopSim.on('editorInput')` with string length > 4 characters.
  - `DX.desktopSim.on('documentSaved')`.
  - `DX.desktopSim.on('windowClosed', 'editor')`.
  - `DX.desktopSim.on('openFile')`.
- **Accepted Alternative Ways:**
  - Open from desktop icon, Start menu, or right-click > New > Text document.
  - Type manually or click "Insérer texte suggéré".
  - Save via `Ctrl+S` keyboard shortcut or clicking "Enregistrer" / "Enregistrer sous...".
  - Multilingual names accepted: `Mon premier document`, `مستندي الأول`, `My first document`.

---

### Level 5: "Mission finale" (Autonomous Organization Mission)
- **Learning Goal:** Autonomous computer management: create directory structures, author documents, organize files, and manage the system without guidance.
- **What Changed:** Validation is now **100% decoupled from action sequences** and is computed directly from the in-memory simulated file system state (`DX.fs.items`).
- **Final Checklist of Objectives:**
  1. `folderCreated`: Create folder "Informatique" (or `حاسوب` / `Computer`).
  2. `docCreated`: Create document "Mon premier document" (or `مستندي الأول` / `My first document`).
  3. `hasContent`: Write content inside the document.
  4. `docMoved`: Place the document inside the "Informatique" folder.
  5. `trashCleaned`: Send temporary file to Recycle Bin or clean the system.
- **How Detected:**
  - Direct file system graph query: `DX.fs.items` scan finding folder matching candidate names.
  - Document query finding file matching candidate names and checking `doc.content.trim().length > 3`.
  - Hierarchy query verifying `doc.parentId === folder.id`.
  - Trash query checking `DX.fs.getChildren('trash').length > 0` or trash emptied event.
- **Accepted Alternative Ways:**
  - Moving document into folder can be done via drag-and-drop, Cut/Paste (`Ctrl+X` -> `Ctrl+V`), or direct Save As targeting the folder in the dropdown.
  - Language switching mid-level does not invalidate completion: names in French, Arabic, and English are concurrently recognized.
