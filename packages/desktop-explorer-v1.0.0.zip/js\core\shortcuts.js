// ============================================================================
// TeachIT Educational Game: Desktop Explorer
// File: js/core/shortcuts.js
// Purpose: Scoped keyboard shortcuts (F2, Del, Ctrl+C/X/V, Ctrl+S, Esc, Arrows, Enter)
// Dependencies: window.DX.desktopSim, window.DX.selection, window.DX.fs
// ============================================================================

window.DX = window.DX || {};

(function (DX) {
  'use strict';

  class ShortcutsManager {
    constructor() {
      this.enabled = true;
    }

    init() {
      const desktop = document.getElementById('simulatedDesktop');
      if (!desktop) return;

      desktop.addEventListener('keydown', (e) => {
        if (!this.enabled) return;

        // If typing inside an input or textarea, let normal typing pass
        const tag = (e.target.tagName || '').toLowerCase();
        const isEditing = tag === 'input' || tag === 'textarea';

        // Escape always closes dialogs and menus
        if (e.key === 'Escape') {
          DX.contextMenu?.close();
          document.getElementById('startMenuPopover')?.classList.remove('active');
          document.getElementById('dialogSaveAs')?.classList.remove('active');
          return;
        }

        // Ctrl+S: Save editor document
        if ((e.ctrlKey || e.metaKey) && (e.key === 's' || e.key === 'S')) {
          e.preventDefault();
          e.stopPropagation();
          DX.desktopSim?.saveEditorDocument?.();
          return;
        }

        if (isEditing) return;

        const selectedIds = DX.selection?.getSelectedIds() || [];
        const activeId = selectedIds[0];

        // F2: Rename selected item
        if (e.key === 'F2') {
          if (activeId && !['icon-editor', 'icon-explorer', 'icon-trash'].includes(activeId)) {
            e.preventDefault();
            DX.desktopSim?.startRenameInline?.(activeId);
          }
          return;
        }

        // Delete: Move selected to trash
        if (e.key === 'Delete') {
          if (selectedIds.length > 0) {
            e.preventDefault();
            selectedIds.forEach((id) => {
              if (!['icon-editor', 'icon-explorer', 'icon-trash'].includes(id)) {
                DX.fs?.deleteItem?.(id);
              }
            });
            DX.selection?.clearSelection();
            DX.desktopSim?.render();
            DX.desktopSim?.emit('itemsDeleted', selectedIds);
          }
          return;
        }

        // Ctrl+C: Copy
        if ((e.ctrlKey || e.metaKey) && (e.key === 'c' || e.key === 'C')) {
          if (activeId && !['icon-editor', 'icon-explorer', 'icon-trash'].includes(activeId)) {
            e.preventDefault();
            DX.fs?.setClipboard?.('copy', activeId);
            DX.desktopSim?.emit('itemCopied', activeId);
          }
          return;
        }

        // Ctrl+X: Cut
        if ((e.ctrlKey || e.metaKey) && (e.key === 'x' || e.key === 'X')) {
          if (activeId && !['icon-editor', 'icon-explorer', 'icon-trash'].includes(activeId)) {
            e.preventDefault();
            DX.fs?.setClipboard?.('cut', activeId);
            DX.desktopSim?.render();
            DX.desktopSim?.emit('itemCut', activeId);
          }
          return;
        }

        // Ctrl+V: Paste
        if ((e.ctrlKey || e.metaKey) && (e.key === 'v' || e.key === 'V')) {
          e.preventDefault();
          const explorerFolder = DX.desktopSim?.wm?.windows?.explorer?.isOpen
            ? DX.desktopSim?.wm?.windows?.explorer?.currentFolderId
            : 'desktop';
          DX.desktopSim?.pasteClipboard?.(explorerFolder || 'desktop');
          return;
        }

        // Enter: Open selected item
        if (e.key === 'Enter') {
          if (activeId) {
            e.preventDefault();
            DX.desktopSim?.openItemById?.(activeId);
          }
          return;
        }

        // Arrow keys navigation across icons
        if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
          e.preventDefault();
          this.navigateIcons(e.key, activeId);
        }
      });
    }

    navigateIcons(direction, currentId) {
      const icons = Array.from(document.querySelectorAll('.desktop-icons-area .desktop-icon'));
      if (icons.length === 0) return;

      let idx = icons.findIndex((el) => el.id === currentId);
      if (idx === -1) {
        icons[0].focus();
        DX.selection?.selectItem(icons[0].id);
        return;
      }

      if (direction === 'ArrowDown') idx = (idx + 1) % icons.length;
      else if (direction === 'ArrowUp') idx = (idx - 1 + icons.length) % icons.length;
      else if (direction === 'ArrowRight' || direction === 'ArrowLeft') idx = (idx + 1) % icons.length;

      const next = icons[idx];
      if (next) {
        next.focus();
        DX.selection?.selectItem(next.id);
      }
    }
  }

  DX.ShortcutsManager = ShortcutsManager;
  DX.shortcuts = new ShortcutsManager();
})(window.DX);
