// ============================================================================
// TeachIT Educational Game: Desktop Explorer
// File: js/core/taskbar.js
// Purpose: Windows taskbar manager (start button, window tabs, clock, show-desktop)
// Dependencies: window.DX.desktopSim, window.DX.i18n, window.DX.audio
// ============================================================================

window.DX = window.DX || {};

(function (DX) {
  'use strict';

  class TaskbarManager {
    constructor() {
      this.minimizedBeforeShowDesktop = new Set();
      this.clockTimer = null;
    }

    init() {
      this.setupStartButton();
      this.setupShowDesktop();
      this.setupClock();
      this.setupTaskbarContextMenu();
    }

    setupStartButton() {
      const btnStart = document.getElementById('btnStartMenu');
      const popover = document.getElementById('startMenuPopover');
      if (btnStart && popover) {
        btnStart.addEventListener('click', (e) => {
          e.stopPropagation();
          DX.audio?.playClick?.();
          const isActive = popover.classList.toggle('active');
          DX.desktopSim?.emit('startMenuToggled', isActive);
        });

        // Close start menu when clicking outside
        document.addEventListener('click', (e) => {
          if (!e.target.closest('#startMenuPopover') && !e.target.closest('#btnStartMenu')) {
            if (popover.classList.contains('active')) {
              popover.classList.remove('active');
              DX.desktopSim?.emit('startMenuToggled', false);
            }
          }
        });
      }
    }

    setupShowDesktop() {
      const btnPeek = document.getElementById('btnShowDesktop');
      if (!btnPeek) return;

      btnPeek.addEventListener('click', (e) => {
        e.stopPropagation();
        DX.audio?.playClick?.();
        const wm = DX.desktopSim?.wm;
        if (!wm) return;

        const openWins = Object.values(wm.windows).filter((w) => w.isOpen && !w.isMinimized);

        if (openWins.length > 0) {
          // Minimize all visible windows
          this.minimizedBeforeShowDesktop.clear();
          openWins.forEach((w) => {
            this.minimizedBeforeShowDesktop.add(w.id);
            wm.minimizeWindow(w.id);
          });
          DX.desktopSim.emit('showDesktopActivated', true);
        } else {
          // Restore previously minimized windows
          this.minimizedBeforeShowDesktop.forEach((id) => {
            wm.restoreWindow(id);
          });
          this.minimizedBeforeShowDesktop.clear();
          DX.desktopSim.emit('showDesktopActivated', false);
        }
        DX.desktopSim.updateWindowsUI();
      });
    }

    setupClock() {
      const clock = document.getElementById('systemClock');
      if (!clock) return;
      const update = () => {
        const now = new Date();
        const h = String(now.getHours()).padStart(2, '0');
        const m = String(now.getMinutes()).padStart(2, '0');
        clock.textContent = `${h}:${m}`;
      };
      update();
      if (this.clockTimer) clearInterval(this.clockTimer);
      this.clockTimer = setInterval(update, 30000);
    }

    setupTaskbarContextMenu() {
      const bar = document.getElementById('simulatedTaskbar');
      if (!bar) return;
      bar.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        e.stopPropagation();
        DX.contextMenu?.open(e.clientX, e.clientY, 'taskbar');
      });
    }

    renderWindowPills(windows, activeWindowId) {
      const container = document.getElementById('taskbarApps');
      if (!container) return;
      container.innerHTML = '';

      Object.values(windows).forEach((w) => {
        if (!w.isOpen) return;
        const pill = document.createElement('button');
        pill.type = 'button';
        const isActive = activeWindowId === w.id && !w.isMinimized;
        pill.className = `taskbar-app-btn ${isActive ? 'active' : ''} ${w.isMinimized ? 'minimized' : ''}`;
        pill.setAttribute('aria-label', DX.i18n.t(w.titleKey));
        pill.innerHTML = `
          <img src="${w.icon}" class="taskbar-btn-icon" alt="" aria-hidden="true" />
          <span class="taskbar-btn-title" dir="auto">${DX.i18n.t(w.titleKey)}</span>
        `;

        pill.addEventListener('click', (e) => {
          e.stopPropagation();
          DX.audio?.playClick?.();
          const wm = DX.desktopSim?.wm;
          if (!wm) return;

          if (w.isMinimized) {
            wm.restoreWindow(w.id);
          } else if (wm.activeWindowId === w.id) {
            wm.minimizeWindow(w.id);
          } else {
            wm.bringToFront(w.id);
          }
          DX.desktopSim.updateWindowsUI();
        });

        container.appendChild(pill);
      });
    }
  }

  DX.TaskbarManager = TaskbarManager;
  DX.taskbar = new TaskbarManager();
})(window.DX);
