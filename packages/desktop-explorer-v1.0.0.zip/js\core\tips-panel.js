// ============================================================================
// TeachIT Educational Game: Desktop Explorer
// File: js/core/tips-panel.js
// Purpose: Interactive tips & checklist panel manager
// Dependencies: None (window.DX)
// ============================================================================

window.DX = window.DX || {};

(function (DX) {
  'use strict';

  class TipsPanelManager {
    constructor() {
      this.panelEl = null;
      this.isVisible = true;
    }

    init() {
      this.panelEl = document.querySelector('.level-checklist-panel');
    }

    attach(panelEl) {
      this.panelEl = panelEl;
      if (!this.panelEl) return;
      this.isVisible = true;
      this.panelEl.style.display = 'block';

      // Setup close button on panel if present
      const btnClose = this.panelEl.querySelector('.checklist-close-btn');
      if (btnClose) {
        btnClose.onclick = (e) => {
          e.stopPropagation();
          this.hide();
        };
      }
    }

    toggle() {
      if (!this.panelEl) this.panelEl = document.querySelector('.level-checklist-panel');
      if (!this.panelEl) return;
      this.isVisible = !this.isVisible;
      this.panelEl.style.display = this.isVisible ? 'block' : 'none';
      DX.audio?.playClick?.();
    }

    show() {
      if (!this.panelEl) this.panelEl = document.querySelector('.level-checklist-panel');
      if (!this.panelEl) return;
      this.isVisible = true;
      this.panelEl.style.display = 'block';
    }

    hide() {
      if (!this.panelEl) this.panelEl = document.querySelector('.level-checklist-panel');
      if (!this.panelEl) return;
      this.isVisible = false;
      this.panelEl.style.display = 'none';
    }

    showHint(message) {
      const hintText = document.getElementById('tipsHintText');
      const hintBox = document.getElementById('tipsHintBox');
      if (hintText && hintBox && message) {
        hintText.textContent = message;
        hintBox.style.display = 'block';
      }
    }

    hideHint() {
      const hintBox = document.getElementById('tipsHintBox');
      if (hintBox) hintBox.style.display = 'none';
    }
  }

  DX.TipsPanelManager = TipsPanelManager;
  DX.tipsPanel = new TipsPanelManager();
})(window.DX);
