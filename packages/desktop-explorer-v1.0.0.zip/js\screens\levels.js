// ============================================================================
// TeachIT Educational Game: Desktop Explorer
// File: js/screens/levels.js
// Purpose: High-contrast, accessible Levels selection screen
// Dependencies: window.DX.levels, window.DX.storage, window.DX.screens, window.DX.i18n
// ============================================================================

window.DX = window.DX || {};

(function (DX) {
  'use strict';

  function render() {
    const grid = document.getElementById('levelsGridContainer');
    if (!grid) return;
    grid.innerHTML = '';

    const allLevels = DX.levels.getAll();
    const save = DX.storage.loadGame() || {};
    const completedIds = new Set(save.completedLevelIds || []);
    const activeLevelId = save.currentLevelId || 'desktop';

    // Strict sequential unlocking
    const unlockedIds = new Set();
    allLevels.forEach((l, idx) => {
      if (idx === 0 || completedIds.has(allLevels[idx - 1].id)) {
        unlockedIds.add(l.id);
      }
    });

    allLevels.forEach((lvl, idx) => {
      const isCompleted = completedIds.has(lvl.id);
      const isUnlocked = unlockedIds.has(lvl.id);
      const isCurrent = activeLevelId === lvl.id && !isCompleted;
      const isFeatured = idx === allLevels.length - 1 && allLevels.length % 2 === 1;

      let stateClass = 'state-locked';
      let stateBadge = `
        <span class="level-status-pill pill-locked">
          <img src="assets/icons/lock.svg" class="pill-icon" alt="" aria-hidden="true" />
          <span>${DX.i18n.t('levels.statusLocked')}</span>
        </span>
      `;

      if (isCompleted) {
        stateClass = 'state-completed';
        stateBadge = `
          <span class="level-status-pill pill-completed">
            <img src="assets/icons/check.svg" class="pill-icon" alt="" aria-hidden="true" />
            <span>${DX.i18n.t('levels.statusCompleted')}</span>
          </span>
        `;
      } else if (isCurrent || isUnlocked) {
        stateClass = 'state-current';
        stateBadge = `
          <span class="level-status-pill pill-current">
            <img src="assets/icons/play.svg" class="pill-icon" alt="" aria-hidden="true" />
            <span>${DX.i18n.t('levels.statusCurrent')}</span>
          </span>
        `;
      }

      const card = document.createElement('div');
      card.className = `level-card ${stateClass} ${isFeatured ? 'level-card-featured' : ''}`;
      card.setAttribute('data-level-id', lvl.id);

      const title = DX.i18n.t(lvl.titleKey);
      const desc = DX.i18n.t(lvl.descKey);
      const iconSrc = lvl.icon || 'assets/icons/desktop.svg';

      card.innerHTML = `
        <div class="level-card-header">
          <div class="level-card-icon-wrap">
            <img src="${iconSrc}" class="level-card-icon" alt="" aria-hidden="true" />
          </div>
          <div class="level-card-meta">
            <span class="level-number-label">${DX.i18n.t('level.term')} ${idx + 1}</span>
            <h2 class="level-card-title">${title}</h2>
          </div>
          <div class="level-card-status">
            ${stateBadge}
          </div>
        </div>

        <div class="level-card-body">
          <p class="level-card-desc">${desc}</p>
        </div>

        <div class="level-card-footer">
          <button type="button" class="btn ${isCompleted ? 'btn-secondary' : 'btn-primary'} level-action-btn" ${!isUnlocked ? 'disabled' : ''}>
            ${!isUnlocked ? DX.i18n.t('levels.statusLocked') : isCompleted ? DX.i18n.t('levels.replay') : DX.i18n.t('levels.play')}
          </button>
        </div>
      `;

      if (isUnlocked) {
        card.tabIndex = 0;
        card.setAttribute('role', 'button');
        card.title = `${isCompleted ? DX.i18n.t('levels.replay') : DX.i18n.t('levels.play')} ${title}`;

        const handleLaunch = () => {
          DX.audio?.playClick?.();
          DX.levels.launch(lvl.id);
        };

        card.addEventListener('click', handleLaunch);
        card.addEventListener('keydown', (e) => {
          if (e.key === 'Enter') handleLaunch();
        });
      } else {
        card.setAttribute('aria-disabled', 'true');
        card.title = DX.i18n.t('levels.lockedTooltip');
      }

      grid.appendChild(card);
    });
  }

  function setupEvents() {
    document.getElementById('btnLevelsBack')?.addEventListener('click', () => {
      DX.audio?.playBack?.();
      DX.screens.show('menu');
    });

    DX.i18n.onChange(() => {
      if (DX.screens.getCurrent() === 'levels') {
        render();
      }
    });
  }

  DX.levelsScreen = {
    render,
    setupEvents,
  };

  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', setupEvents);
    } else {
      setupEvents();
    }
  }
})(window.DX);
