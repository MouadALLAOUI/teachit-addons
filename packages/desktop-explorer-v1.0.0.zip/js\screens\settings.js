// ============================================================================
// TeachIT Educational Game: Desktop Explorer
// File: js/screens/settings.js
// Purpose: Settings screen (Audio controls, immediate language picker, reset progress)
// Dependencies: window.DX.audio, window.DX.i18n, window.DX.storage, window.DX.dialog
// ============================================================================

window.DX = window.DX || {};

(function (DX) {
  'use strict';

  function render() {
    // Sound FX
    const sfxToggle = document.getElementById('settingToggleSfx');
    const sfxSlider = document.getElementById('settingVolumeSfx');
    if (sfxToggle) sfxToggle.checked = DX.audio.getSfxEnabled();
    if (sfxSlider) sfxSlider.value = String(Math.round(DX.audio.getSfxVolume() * 100));

    // Music
    const musicToggle = document.getElementById('settingToggleMusic');
    const musicSlider = document.getElementById('settingVolumeMusic');
    if (musicToggle) musicToggle.checked = DX.audio.getMusicEnabled();
    if (musicSlider) musicSlider.value = String(Math.round(DX.audio.getMusicVolume() * 100));

    // Language Segmented Control
    renderSettingsLang();
  }

  function renderSettingsLang() {
    const container = document.getElementById('settingsLangContainer');
    if (!container) return;
    const current = DX.i18n.getLanguage();

    const langs = [
      { code: 'ar', label: 'العربية' },
      { code: 'fr', label: 'Français' },
      { code: 'en', label: 'English' },
    ];

    container.innerHTML = langs
      .map(
        (l) => `
        <button type="button" class="lang-picker-btn ${current === l.code ? 'active' : ''}" data-lang="${l.code}">
          ${l.label}
        </button>
      `,
      )
      .join('');

    container.querySelectorAll('.lang-picker-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const lang = btn.getAttribute('data-lang');
        DX.audio.playClick();
        DX.i18n.setLanguage(lang);
      });
    });
  }

  function setupEvents() {
    // SFX controls
    document.getElementById('settingToggleSfx')?.addEventListener('change', (e) => {
      DX.audio.setSfxEnabled(e.target.checked);
      if (e.target.checked) DX.audio.playClick();
    });

    document.getElementById('settingVolumeSfx')?.addEventListener('input', (e) => {
      DX.audio.setSfxVolume(Number(e.target.value) / 100);
    });

    // Music controls
    document.getElementById('settingToggleMusic')?.addEventListener('change', (e) => {
      DX.audio.setMusicEnabled(e.target.checked);
    });

    document.getElementById('settingVolumeMusic')?.addEventListener('input', (e) => {
      DX.audio.setMusicVolume(Number(e.target.value) / 100);
    });

    // Reset Progress
    document.getElementById('btnSettingsReset')?.addEventListener('click', async () => {
      DX.audio.playDialogOpen();
      const confirmed = await DX.dialog.confirm({
        title: DX.i18n.t('dialog.confirmResetTitle'),
        message: DX.i18n.t('dialog.confirmResetMsg'),
        confirmText: DX.i18n.t('dialog.confirmResetOk'),
        cancelText: DX.i18n.t('dialog.confirmResetCancel'),
        defaultButton: 'cancel',
        confirmDanger: true,
      });

      if (confirmed) {
        DX.storage.clearGame();
        DX.fs.reset();
        await DX.dialog.alert({
          title: DX.i18n.t('dialog.confirmResetTitle'),
          message: DX.i18n.t('settings.progressResetSuccess'),
        });
      }
    });

    // Back button
    document.getElementById('btnSettingsBack')?.addEventListener('click', () => {
      DX.audio.playBack();
      DX.screens.show('menu');
    });

    DX.i18n.onChange(() => {
      if (DX.screens.getCurrent() === 'settings') {
        render();
      }
    });
  }

  DX.settingsScreen = {
    render,
    setupEvents,
  };

  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', setupEvents);
    } else {
      setupEvents();
    }
  }
})(window.DX);
