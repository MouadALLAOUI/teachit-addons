// ============================================================================
// TeachIT Educational Game: Desktop Explorer
// File: js/levels/01-desktop.js
// Purpose: Level 1 — Discovering the 6 fundamental desktop elements
// Dependencies: window.DX.levels, window.DX.desktopSim, window.DX.selection
// ============================================================================

window.DX = window.DX || {};

(function (DX) {
  'use strict';

  const OBJECTIVES = [
    { id: 'bureau', labelKey: 'sim.elem.bureau', descKey: 'sim.elem.bureau.desc' },
    { id: 'icones', labelKey: 'sim.elem.icones', descKey: 'sim.elem.icones.desc' },
    { id: 'barre-taches', labelKey: 'sim.elem.barre-taches', descKey: 'sim.elem.barre-taches.desc' },
    { id: 'menu-demarrer', labelKey: 'sim.elem.menu-demarrer', descKey: 'sim.elem.menu-demarrer.desc' },
    { id: 'corbeille', labelKey: 'sim.elem.corbeille', descKey: 'sim.elem.corbeille.desc' },
    { id: 'fond-ecran', labelKey: 'sim.elem.fond-ecran', descKey: 'sim.elem.fond-ecran.desc' },
  ];

  let currentCtx = null;
  let completedTasks = new Set();
  const cleanupFns = [];

  function mount(container, ctx) {
    currentCtx = ctx;

    const save = ctx.storage.loadGame() || {};
    const existing = save.levelData?.desktop?.discoveredElements || save.levelData?.desktop?.completedTasks;
    completedTasks = Array.isArray(existing) ? new Set(existing) : new Set();

    container.innerHTML = `
      <div class="level-banner" id="l1Banner">
        <div class="banner-info">
          <span class="banner-badge">${ctx.t('level.term')} 1 / 5</span>
          <span class="banner-step" id="l1StepBadge">${completedTasks.size} / ${OBJECTIVES.length} ${ctx.t('levels.statusCompleted')}</span>
          <h2 class="banner-instruction">${ctx.t('level.desktop.desc')}</h2>
        </div>
        <div class="banner-actions">
          <button type="button" class="btn btn-secondary btn-sm" id="l1BtnMissions">📋 ${ctx.t('levels.missionsBtn')}</button>
          <button type="button" class="btn btn-secondary btn-sm" id="l1BtnHint">💡 ${ctx.t('header.hint')}</button>
        </div>
      </div>

      <div class="level-checklist-panel" id="l1ChecklistPanel">
        <div class="checklist-header">
          <h3 class="checklist-title">${ctx.t('level.desktop.short')} : 6 éléments à repérer</h3>
          <button type="button" class="checklist-close-btn" id="l1BtnCloseChecklist" aria-label="Close">✕</button>
        </div>
        <div class="checklist-grid" id="l1ChecklistGrid"></div>
        <div class="checklist-hint-box" id="l1HintBox" style="display:none; margin-top:10px; font-size:12px; color:var(--border-highlight);"></div>
      </div>
    `;

    DX.tipsPanel?.attach?.(document.getElementById('l1ChecklistPanel'));
    renderChecklist();
    setupListeners();
  }

  function renderChecklist() {
    const grid = document.getElementById('l1ChecklistGrid');
    const badge = document.getElementById('l1StepBadge');
    if (!grid || !currentCtx) return;

    if (badge) {
      badge.textContent = `${completedTasks.size} / ${OBJECTIVES.length} ${currentCtx.t('levels.statusCompleted')}`;
    }

    grid.innerHTML = OBJECTIVES.map((obj) => {
      const isDone = completedTasks.has(obj.id);
      return `
        <div class="check-item ${isDone ? 'done' : ''}" data-obj="${obj.id}">
          <img src="${isDone ? 'assets/icons/check.svg' : 'assets/icons/lock.svg'}" class="check-item-icon" alt="" />
          <span>${currentCtx.t(obj.labelKey)}</span>
        </div>
      `;
    }).join('');
  }

  function showExplainer(obj) {
    if (!currentCtx || !obj) return;
    const card = document.getElementById('eduExplainerCard');
    const title = document.getElementById('explainerTitle');
    const desc = document.getElementById('explainerDesc');
    const badge = document.getElementById('explainerBadge');

    if (card && title && desc) {
      if (badge) badge.textContent = 'INFO';
      title.textContent = currentCtx.t(obj.labelKey);
      desc.textContent = currentCtx.t(obj.descKey);
      card.style.display = 'flex';
    }
  }

  function markDone(objId) {
    if (!currentCtx) return;
    const isNew = !completedTasks.has(objId);
    completedTasks.add(objId);

    const obj = OBJECTIVES.find((o) => o.id === objId);
    if (obj) showExplainer(obj);

    if (isNew) {
      currentCtx.audio?.playClick?.();
      renderChecklist();

      const save = currentCtx.storage.loadGame() || {};
      save.levelData = save.levelData || {};
      save.levelData.desktop = {
        discoveredElements: Array.from(completedTasks),
        completedTasks: Array.from(completedTasks),
      };
      currentCtx.storage.saveGame(save);

      if (completedTasks.size >= OBJECTIVES.length) {
        currentCtx.audio?.playWin?.();
        setTimeout(() => {
          currentCtx.complete({ scoreBonus: 50 });
        }, 700);
      }
    }
  }

  function setupListeners() {
    const desktop = document.getElementById('simulatedDesktop');
    const wallpaper = document.getElementById('desktopWallpaperArt');
    const taskbar = document.getElementById('simulatedTaskbar');
    const startBtn = document.getElementById('btnStartMenu');
    const clock = document.getElementById('systemClock');

    // 1. Wallpaper & Desktop Click -> discovers bureau and fond-ecran
    const onWallpaperClick = (e) => {
      if (e.target === desktop || e.target === wallpaper) {
        markDone('bureau');
        markDone('fond-ecran');
      }
    };

    // 2. Icon Select -> discovers icones or corbeille
    const onSelectIcon = (itemId) => {
      if (itemId === 'trash' || itemId === 'icon-trash') {
        markDone('corbeille');
      } else {
        markDone('icones');
      }
    };

    // 3. Start Menu Toggle -> discovers menu-demarrer
    const onStartMenu = (active) => {
      if (active) markDone('menu-demarrer');
    };
    const onStartBtnClick = () => {
      markDone('menu-demarrer');
    };

    // 4. Taskbar Click -> discovers barre-taches
    const onTaskbarClick = (e) => {
      if (!e.target.closest('#btnStartMenu')) {
        markDone('barre-taches');
      }
    };

    // Missions toggle button & close button
    const btnMissions = document.getElementById('l1BtnMissions');
    const btnCloseChecklist = document.getElementById('l1BtnCloseChecklist');
    btnMissions?.addEventListener('click', () => DX.tipsPanel?.toggle?.());
    btnCloseChecklist?.addEventListener('click', () => DX.tipsPanel?.hide?.());

    // Explainer Close Button
    const btnExplainerClose = document.getElementById('btnExplainerClose');
    const onCloseExplainer = (e) => {
      e?.stopPropagation?.();
      const card = document.getElementById('eduExplainerCard');
      if (card) card.style.display = 'none';
    };
    btnExplainerClose?.addEventListener('click', onCloseExplainer);

    desktop?.addEventListener('click', onWallpaperClick);
    taskbar?.addEventListener('click', onTaskbarClick);
    startBtn?.addEventListener('click', onStartBtnClick);
    clock?.addEventListener('click', onTaskbarClick);

    DX.desktopSim?.on('select', onSelectIcon);
    DX.desktopSim?.on('startMenuToggled', onStartMenu);

    cleanupFns.push(() => {
      desktop?.removeEventListener('click', onWallpaperClick);
      taskbar?.removeEventListener('click', onTaskbarClick);
      startBtn?.removeEventListener('click', onStartBtnClick);
      clock?.removeEventListener('click', onTaskbarClick);
      btnExplainerClose?.removeEventListener('click', onCloseExplainer);
      DX.desktopSim?.off('select', onSelectIcon);
      DX.desktopSim?.off('startMenuToggled', onStartMenu);
      const card = document.getElementById('eduExplainerCard');
      if (card) card.style.display = 'none';
    });

    // Hint button
    document.getElementById('l1BtnHint')?.addEventListener('click', () => {
      currentCtx?.audio?.playClick?.();
      const next = OBJECTIVES.find((o) => !completedTasks.has(o.id));
      const hintBox = document.getElementById('l1HintBox');
      if (next && hintBox) {
        hintBox.textContent = `💡 Indice : ${currentCtx.t(next.labelKey)} — ${currentCtx.t(next.descKey)}`;
        hintBox.style.display = 'block';
      }
    });
  }

  function onLanguageChange() {
    if (!currentCtx) return;
    renderChecklist();
    const instruction = document.querySelector('#l1Banner .banner-instruction');
    if (instruction) instruction.textContent = currentCtx.t('level.desktop.desc');
    const badge = document.querySelector('#l1Banner .banner-badge');
    if (badge) badge.textContent = `${currentCtx.t('level.term')} 1 / 5`;
    const title = document.querySelector('#l1ChecklistPanel .checklist-title');
    if (title) title.textContent = `${currentCtx.t('level.desktop.short')} : 6 éléments à repérer`;
    const btnM = document.getElementById('l1BtnMissions');
    if (btnM) btnM.textContent = `📋 ${currentCtx.t('levels.missionsBtn')}`;
    const hintBtn = document.getElementById('l1BtnHint');
    if (hintBtn) hintBtn.textContent = `💡 ${currentCtx.t('header.hint')}`;
  }

  function start() {
    renderChecklist();
  }

  function destroy() {
    while (cleanupFns.length > 0) {
      const fn = cleanupFns.pop();
      try { fn(); } catch (err) { console.error('[Level 1] Cleanup error:', err); }
    }
  }

  DX.levels = DX.levels || { register: () => {} };
  DX.levels.register({
    id: 'desktop',
    order: 1,
    titleKey: 'level.desktop.title',
    descKey: 'level.desktop.desc',
    icon: 'assets/icons/desktop.svg',
    mount,
    start,
    destroy,
    onLanguageChange,
  });
})(window.DX);
