// ============================================================================
// TeachIT Educational Game: Desktop Explorer
// File: js/core/window-manager.js
// Purpose: Windows lifecycle, dragging, top-edge snap, titlebar dblclick, z-order
// Dependencies: None (window.DX)
// ============================================================================

window.DX = window.DX || {};

(function (DX) {
  'use strict';

  class SimulatedWindowManager {
    constructor() {
      this.windows = {
        editor: { id: 'editor', titleKey: 'sim.appEditor', icon: 'assets/icons/document.svg', isOpen: false, isMinimized: false, isMaximized: false, zIndex: 20, x: 120, y: 50, w: 580, h: 400 },
        explorer: { id: 'explorer', titleKey: 'sim.appExplorer', icon: 'assets/icons/folder.svg', isOpen: false, isMinimized: false, isMaximized: false, currentFolderId: 'desktop', zIndex: 20, x: 180, y: 80, w: 600, h: 420 },
        trash: { id: 'trash', titleKey: 'sim.appTrash', icon: 'assets/icons/trash.svg', isOpen: false, isMinimized: false, isMaximized: false, zIndex: 20, x: 220, y: 110, w: 540, h: 380 },
        taskmgr: { id: 'taskmgr', titleKey: 'sim.appTaskmgr', icon: 'assets/icons/taskmgr.svg', isOpen: false, isMinimized: false, isMaximized: false, zIndex: 20, x: 260, y: 130, w: 420, h: 340 },
        settings: { id: 'settings', titleKey: 'sim.appSettings', icon: 'assets/icons/gear.svg', isOpen: false, isMinimized: false, isMaximized: false, zIndex: 20, x: 200, y: 90, w: 460, h: 360 },
        properties: { id: 'properties', titleKey: 'sim.cmenuProps', icon: 'assets/icons/info.svg', isOpen: false, isMinimized: false, isMaximized: false, zIndex: 25, x: 280, y: 120, w: 380, h: 360 },
      };
      this.activeWindowId = null;
      this.topZIndex = 30;
      this.dragState = null;
      this.listeners = new Map();
    }

    on(event, cb) {
      if (!this.listeners.has(event)) this.listeners.set(event, new Set());
      this.listeners.get(event).add(cb);
    }

    emit(event, data) {
      if (this.listeners.has(event)) {
        this.listeners.get(event).forEach((cb) => {
          try { cb(data); } catch (e) { console.error(`[DX.wm] Error in ${event}:`, e); }
        });
      }
    }

    openWindow(appId) {
      const win = this.windows[appId];
      if (!win) return null;
      win.isOpen = true;
      win.isMinimized = false;
      this.bringToFront(appId);
      this.emit('windowOpened', appId);
      return win;
    }

    closeWindow(appId) {
      const win = this.windows[appId];
      if (!win) return null;
      win.isOpen = false;
      win.isMinimized = false;
      if (this.activeWindowId === appId) {
        this.activeWindowId = null;
        // Focus top-most open remaining window
        const openWins = Object.values(this.windows).filter((w) => w.isOpen && !w.isMinimized);
        if (openWins.length > 0) {
          openWins.sort((a, b) => b.zIndex - a.zIndex);
          this.bringToFront(openWins[0].id);
        }
      }
      this.emit('windowClosed', appId);
      return win;
    }

    minimizeWindow(appId) {
      const win = this.windows[appId];
      if (!win) return null;
      win.isMinimized = true;
      if (this.activeWindowId === appId) {
        this.activeWindowId = null;
        const openWins = Object.values(this.windows).filter((w) => w.isOpen && !w.isMinimized);
        if (openWins.length > 0) {
          openWins.sort((a, b) => b.zIndex - a.zIndex);
          this.bringToFront(openWins[0].id);
        }
      }
      this.emit('windowMinimized', appId);
      return win;
    }

    restoreWindow(appId) {
      const win = this.windows[appId];
      if (!win) return null;
      win.isOpen = true;
      win.isMinimized = false;
      this.bringToFront(appId);
      this.emit('windowRestored', appId);
      return win;
    }

    maximizeWindow(appId) {
      const win = this.windows[appId];
      if (!win) return null;
      win.isMaximized = true;
      this.bringToFront(appId);
      this.emit('windowMaximized', { id: appId, isMax: true });
      return win;
    }

    unmaximizeWindow(appId) {
      const win = this.windows[appId];
      if (!win) return null;
      win.isMaximized = false;
      this.bringToFront(appId);
      this.emit('windowMaximized', { id: appId, isMax: false });
      return win;
    }

    toggleMaximize(appId) {
      const win = this.windows[appId];
      if (!win) return null;
      if (win.isMaximized) return this.unmaximizeWindow(appId);
      return this.maximizeWindow(appId);
    }

    bringToFront(appId) {
      const win = this.windows[appId];
      if (!win) return;
      this.topZIndex += 1;
      win.zIndex = this.topZIndex;
      this.activeWindowId = appId;
      this.emit('focusChanged', appId);
    }

    setupDragging(desktopEl) {
      if (!desktopEl) return;
      const onPointerMove = (e) => {
        if (!this.dragState) return;
        const { id, startX, startY, origX, origY, isMax } = this.dragState;
        const dx = e.clientX - startX;
        const dy = e.clientY - startY;
        const win = this.windows[id];
        const el = document.getElementById(`window${id.charAt(0).toUpperCase() + id.slice(1)}`);
        const snap = document.getElementById('windowSnapPreview');
        const deskRect = desktopEl.getBoundingClientRect();

        // If dragging while maximized: restore size and center window around pointer
        if (isMax && (Math.abs(dx) > 10 || dy > 10)) {
          win.isMaximized = false;
          this.dragState.isMax = false;
          el.classList.remove('maximized');
          const restoreW = win.w || 560;
          this.dragState.origX = e.clientX - deskRect.left - restoreW / 2;
          this.dragState.origY = e.clientY - deskRect.top - 18;
          this.dragState.startX = e.clientX;
          this.dragState.startY = e.clientY;
          return;
        }

        let newX = origX + dx;
        let newY = origY + dy;

        // Clamp inside desktop (above taskbar: 48px)
        const maxX = Math.max(0, deskRect.width - (win.w || 300) / 3);
        const maxY = Math.max(0, deskRect.height - 48 - 40);
        newX = Math.max(-100, Math.min(newX, maxX));
        newY = Math.max(0, Math.min(newY, maxY));

        win.x = newX;
        win.y = newY;
        el.style.left = `${newX}px`;
        el.style.top = `${newY}px`;

        // Top snap preview detection
        if (e.clientY <= deskRect.top + 10) {
          snap?.classList.add('active');
          this.dragState.canSnap = true;
        } else {
          snap?.classList.remove('active');
          this.dragState.canSnap = false;
        }
      };

      const onPointerUp = () => {
        if (!this.dragState) return;
        const { id, canSnap } = this.dragState;
        const snap = document.getElementById('windowSnapPreview');
        snap?.classList.remove('active');
        if (canSnap) {
          this.maximizeWindow(id);
          this.emit('windowSnapped', id);
        }
        this.dragState = null;
        window.removeEventListener('pointermove', onPointerMove);
        window.removeEventListener('pointerup', onPointerUp);
      };

      Object.keys(this.windows).forEach((id) => {
        const capital = id.charAt(0).toUpperCase() + id.slice(1);
        const winEl = document.getElementById(`window${capital}`);
        const titlebar = document.getElementById(`win${capital}Titlebar`);
        if (!winEl || !titlebar) return;

        titlebar.addEventListener('pointerdown', (e) => {
          if (e.target.closest('.win-btn') || e.button !== 0) return;
          this.bringToFront(id);
          const win = this.windows[id];
          const deskRect = desktopEl.getBoundingClientRect();
          const winRect = winEl.getBoundingClientRect();

          this.dragState = {
            id,
            startX: e.clientX,
            startY: e.clientY,
            origX: winRect.left - deskRect.left,
            origY: winRect.top - deskRect.top,
            isMax: win.isMaximized,
            canSnap: false,
          };
          window.addEventListener('pointermove', onPointerMove);
          window.addEventListener('pointerup', onPointerUp);
        });

        // Double-click on titlebar to maximize / restore
        titlebar.addEventListener('dblclick', (e) => {
          if (e.target.closest('.win-btn')) return;
          this.toggleMaximize(id);
        });

        // Click anywhere in window brings to front
        winEl.addEventListener('pointerdown', () => this.bringToFront(id));
      });
    }
  }

  DX.SimulatedWindowManager = SimulatedWindowManager;
})(window.DX);
