// ============================================================================
// TeachIT Educational Game: Desktop Explorer
// File: js/levels/04-documents.js
// Purpose: Level 4 — Creating, editing, and saving text documents via real Windows actions
// Dependencies: window.DX.levels, window.DX.fs, window.DX.desktopSim
// ============================================================================

window.DX = window.DX || {};

(function (DX) {
  'use strict';

  const TARGET_DOC_NAMES = ['mon premier document', 'document', 'premier', 'texte', 'مستند', 'مستندي', 'first', 'my first document'];

  const OBJECTIVES = [
    { id: 'openEditor', labelKey: 'level.docs.task1' },
    { id: 'typeText', labelKey: 'level.docs.task2' },
    { id: 'saveDocument', labelKey: 'level.docs.task3' },
    { id: 'closeEditor', labelKey: 'level.docs.task4' },
    { id: 'reopenVerify', labelKey: 'level.docs.task5' },
  ];

  let currentCtx = null;
  let completedTasks = new Set();
  const cleanupFns = [];

  function mount(container, ctx) {
    currentCtx = ctx;

    const save = ctx.storage.loadGame() || {};
    const existing = save.levelData?.documents?.completedTasks;
    completedTasks = Array.isArray(existing) ? new Set(existing) : new Set();

    container.innerHTML = `
      <div class="level-banner" id="l4Banner">
        <div class="banner-info">
          <span class="banner-badge">${ctx.t('level.term')} 4 / 5</span>
          <span class="banner-step" id="l4StepBadge">${completedTasks.size} / ${OBJECTIVES.length} ${ctx.t('levels.statusCompleted')}</span>
          <h2 class="banner-instruction">${ctx.t('level.documents.desc')}</h2>
        </div>
        <div class="banner-actions">
          <button type="button" class="btn btn-secondary btn-sm" id="l4BtnMissions">📋 ${ctx.t('levels.missionsBtn')}</button>
          <button type="button" class="btn btn-secondary btn-sm" id="l4BtnHint">💡 ${ctx.t('header.hint')}</button>
        </div>
      </div>

      <div class="level-checklist-panel" id="l4ChecklistPanel">
        <div class="checklist-header">
          <h3 class="checklist-title">${ctx.t('level.documents.short')} — Objectifs</h3>
          <button type="button" class="checklist-close-btn" id="l4BtnCloseChecklist" aria-label="Close">✕</button>
        </div>
        <div class="checklist-grid" id="l4ChecklistGrid"></div>
        <div class="checklist-hint-box" id="l4HintBox" style="display:none; margin-top:10px; font-size:12px; color:var(--border-highlight);"></div>
      </div>
    `;

    DX.tipsPanel?.attach?.(document.getElementById('l4ChecklistPanel'));
    renderChecklist();
    setupListeners();
    checkExistingState();
  }

  function checkExistingState() {
    if (!DX.fs) return;
    const all = typeof DX.fs.getAll === 'function' ? DX.fs.getAll() : Array.from(DX.fs.items?.values?.() || []);
    const docs = all.filter((i) => i.type === 'file' || i.extension === 'txt');
    const textarea = document.getElementById('editorTextarea');

    if (DX.desktopSim?.wm?.windows?.editor?.isOpen) {
      markDone('openEditor');
    }
    if ((textarea && textarea.value && textarea.value.trim().length > 2) || docs.some((d) => d.content && d.content.trim().length > 0)) {
      markDone('typeText');
    }
    if (docs.length > 0) {
      markDone('saveDocument');
      markDone('closeEditor');
    }
  }

  function renderChecklist() {
    const grid = document.getElementById('l4ChecklistGrid');
    const badge = document.getElementById('l4StepBadge');
    if (!grid || !currentCtx) return;

    if (badge) {
      badge.textContent = `${completedTasks.size} / ${OBJECTIVES.length} ${currentCtx.t('levels.statusCompleted')}`;
    }

    grid.innerHTML = OBJECTIVES.map((obj) => {
      const isDone = completedTasks.has(obj.id);
      return `
        <div class="check-item ${isDone ? 'done' : ''}" data-obj="${obj.id}">
          <img src="${isDone ? 'assets/icons/check.svg' : 'assets/icons/lock.svg'}" class="check-item-icon" alt="" />
          <span>${currentCtx.t(obj.labelKey)}</span>
        </div>
      `;
    }).join('');
  }

  function markDone(objId) {
    if (!currentCtx || completedTasks.has(objId)) return;
    completedTasks.add(objId);
    currentCtx.audio?.playClick?.();
    renderChecklist();

    const save = currentCtx.storage.loadGame() || {};
    save.levelData = save.levelData || {};
    save.levelData.documents = { completedTasks: Array.from(completedTasks) };
    save.fsItems = DX.fs.serialize();
    currentCtx.storage.saveGame(save);

    if (completedTasks.size >= OBJECTIVES.length) {
      setTimeout(() => {
        currentCtx.complete({ scoreBonus: 50 });
      }, 700);
    }
  }

  function setupListeners() {
    const onOpenApp = (appId) => {
      if (appId === 'editor') markDone('openEditor');
    };

    const onEditorInput = (val) => {
      const text = typeof val === 'string' ? val : (val?.target?.value || '');
      if (text.trim().length > 2) markDone('typeText');
    };
    const textarea = document.getElementById('editorTextarea');
    textarea?.addEventListener('input', onEditorInput);

    const onDocSaved = (file) => {
      markDone('saveDocument');
      markDone('closeEditor');
      if (file?.content || file?.id) markDone('typeText');
    };

    const onSelect = (itemId) => {
      const item = DX.fs?.getItem?.(itemId);
      if (item && (item.type === 'file' || item.extension === 'txt')) {
        markDone('saveDocument');
        markDone('closeEditor');
      }
    };

    const onClose = (appId) => {
      if (appId === 'editor') {
        const all = DX.fs ? DX.fs.getAll() : [];
        if (completedTasks.has('saveDocument') || all.some((i) => i.type === 'file' || i.extension === 'txt')) {
          markDone('saveDocument');
          markDone('closeEditor');
        }
      }
    };

    const onOpenFile = (file) => {
      const name = (file?.name || '').toLowerCase();
      if (completedTasks.has('closeEditor') || TARGET_DOC_NAMES.some((t) => name.includes(t))) {
        markDone('reopenVerify');
      }
    };

    DX.desktopSim?.on('openApp', onOpenApp);
    DX.desktopSim?.on('documentSaved', onDocSaved);
    DX.desktopSim?.on('fileSaved', onDocSaved);
    DX.desktopSim?.on('documentCreated', onDocSaved);
    DX.desktopSim?.on('editorInput', onEditorInput);
    DX.desktopSim?.on('select', onSelect);
    DX.desktopSim?.on('windowClosed', onClose);
    DX.desktopSim?.on('openFile', onOpenFile);

    // Missions button toggle & close button
    const btnMissions = document.getElementById('l4BtnMissions');
    const btnCloseChecklist = document.getElementById('l4BtnCloseChecklist');
    btnMissions?.addEventListener('click', () => DX.tipsPanel?.toggle?.());
    btnCloseChecklist?.addEventListener('click', () => DX.tipsPanel?.hide?.());

    cleanupFns.push(() => {
      textarea?.removeEventListener('input', onEditorInput);
      DX.desktopSim?.off('openApp', onOpenApp);
      DX.desktopSim?.off('documentSaved', onDocSaved);
      DX.desktopSim?.off('fileSaved', onDocSaved);
      DX.desktopSim?.off('documentCreated', onDocSaved);
      DX.desktopSim?.off('editorInput', onEditorInput);
      DX.desktopSim?.off('select', onSelect);
      DX.desktopSim?.off('windowClosed', onClose);
      DX.desktopSim?.off('openFile', onOpenFile);
    });

    document.getElementById('l4BtnHint')?.addEventListener('click', () => {
      currentCtx?.audio?.playClick?.();
      const next = OBJECTIVES.find((o) => !completedTasks.has(o.id));
      const hintBox = document.getElementById('l4HintBox');
      if (next && hintBox) {
        hintBox.textContent = `💡 Indice : ${currentCtx.t(next.labelKey)}`;
        hintBox.style.display = 'block';
      }
    });
  }

  function onLanguageChange() {
    if (!currentCtx) return;
    renderChecklist();
    const instruction = document.querySelector('#l4Banner .banner-instruction');
    if (instruction) instruction.textContent = currentCtx.t('level.documents.desc');
    const badge = document.querySelector('#l4Banner .banner-badge');
    if (badge) badge.textContent = `${currentCtx.t('level.term')} 4 / 5`;
    const title = document.querySelector('#l4ChecklistPanel .checklist-title');
    if (title) title.textContent = `${currentCtx.t('level.documents.short')} — Objectifs`;
    const btnM = document.getElementById('l4BtnMissions');
    if (btnM) btnM.textContent = `📋 ${currentCtx.t('levels.missionsBtn')}`;
    const hintBtn = document.getElementById('l4BtnHint');
    if (hintBtn) hintBtn.textContent = `💡 ${currentCtx.t('header.hint')}`;
  }

  function start() {
    renderChecklist();
    checkExistingState();
  }

  function destroy() {
    while (cleanupFns.length > 0) {
      const fn = cleanupFns.pop();
      try { fn(); } catch (err) { console.error('[Level 4] Cleanup error:', err); }
    }
  }

  DX.levels = DX.levels || { register: () => {} };
  DX.levels.register({
    id: 'documents',
    order: 4,
    titleKey: 'level.documents.title',
    descKey: 'level.documents.desc',
    icon: 'assets/icons/document.svg',
    mount,
    start,
    destroy,
    onLanguageChange,
  });
})(window.DX);
