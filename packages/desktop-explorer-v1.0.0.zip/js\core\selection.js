// ============================================================================
// TeachIT Educational Game: Desktop Explorer
// File: js/core/selection.js
// Purpose: Single selection, multi-selection (Ctrl+click) & rubber-band marquee
// Dependencies: None (window.DX)
// ============================================================================

window.DX = window.DX || {};

(function (DX) {
  'use strict';

  class SelectionManager {
    constructor() {
      this.selectedIds = new Set();
      this.marqueeEl = null;
      this.dragStart = null;
      this.listeners = new Map();
    }

    on(event, cb) {
      if (!this.listeners.has(event)) this.listeners.set(event, new Set());
      this.listeners.get(event).add(cb);
    }

    emit(event, data) {
      if (this.listeners.has(event)) {
        this.listeners.get(event).forEach((cb) => {
          try { cb(data); } catch (e) { console.error(`[DX.selection] Error in ${event}:`, e); }
        });
      }
    }

    init() {
      this.marqueeEl = document.getElementById('selectionMarquee');
      this.setupMarqueeDrag();
    }

    selectItem(id, isMulti = false) {
      if (!isMulti) {
        this.selectedIds.clear();
      }
      if (id) {
        if (isMulti && this.selectedIds.has(id)) {
          this.selectedIds.delete(id);
        } else {
          this.selectedIds.add(id);
        }
      }
      this.syncVisuals();
      this.emit('selectionChanged', Array.from(this.selectedIds));
    }

    clearSelection() {
      if (this.selectedIds.size === 0) return;
      this.selectedIds.clear();
      this.syncVisuals();
      this.emit('selectionChanged', []);
    }

    getSelectedIds() {
      return Array.from(this.selectedIds);
    }

    syncVisuals() {
      document.querySelectorAll('.desktop-icon').forEach((icon) => {
        const id = icon.id.replace(/^exp-/, '');
        if (this.selectedIds.has(id)) {
          icon.classList.add('selected');
        } else {
          icon.classList.remove('selected');
        }
      });
    }

    setupMarqueeDrag() {
      const desktop = document.getElementById('simulatedDesktop');
      if (!desktop) return;

      const onPointerMove = (e) => {
        if (!this.dragStart) return;
        const deskRect = desktop.getBoundingClientRect();
        const curX = e.clientX - deskRect.left;
        const curY = e.clientY - deskRect.top;

        const left = Math.min(this.dragStart.x, curX);
        const top = Math.min(this.dragStart.y, curY);
        const width = Math.abs(curX - this.dragStart.x);
        const height = Math.abs(curY - this.dragStart.y);

        if (width > 6 || height > 6) {
          if (this.marqueeEl) {
            this.marqueeEl.style.display = 'block';
            this.marqueeEl.style.left = `${left}px`;
            this.marqueeEl.style.top = `${top}px`;
            this.marqueeEl.style.width = `${width}px`;
            this.marqueeEl.style.height = `${height}px`;
          }

          // Check collisions with desktop icons
          const marqueeRect = { left, top, right: left + width, bottom: top + height };
          const icons = desktop.querySelectorAll('.desktop-icons-area .desktop-icon');
          this.selectedIds.clear();

          icons.forEach((icon) => {
            const iRect = {
              left: icon.offsetLeft,
              top: icon.offsetTop,
              right: icon.offsetLeft + icon.offsetWidth,
              bottom: icon.offsetTop + icon.offsetHeight,
            };
            const intersects = !(
              marqueeRect.right < iRect.left ||
              marqueeRect.left > iRect.right ||
              marqueeRect.bottom < iRect.top ||
              marqueeRect.top > iRect.bottom
            );
            if (intersects) {
              this.selectedIds.add(icon.id);
            }
          });
          this.syncVisuals();
        }
      };

      const onPointerUp = () => {
        if (!this.dragStart) return;
        if (this.marqueeEl) {
          this.marqueeEl.style.display = 'none';
        }
        if (this.selectedIds.size > 0) {
          this.emit('selectionChanged', Array.from(this.selectedIds));
        }
        this.dragStart = null;
        window.removeEventListener('pointermove', onPointerMove);
        window.removeEventListener('pointerup', onPointerUp);
      };

      desktop.addEventListener('pointerdown', (e) => {
        // Only start marquee if clicking empty desktop background
        if (e.button !== 0) return;
        if (
          e.target.closest('.desktop-icon') ||
          e.target.closest('.simulated-window') ||
          e.target.closest('.simulated-taskbar') ||
          e.target.closest('.custom-context-menu') ||
          e.target.closest('.level-checklist-panel')
        ) {
          return;
        }

        this.clearSelection();
        const deskRect = desktop.getBoundingClientRect();
        this.dragStart = {
          x: e.clientX - deskRect.left,
          y: e.clientY - deskRect.top,
        };

        window.addEventListener('pointermove', onPointerMove);
        window.addEventListener('pointerup', onPointerUp);
      });
    }
  }

  DX.SelectionManager = SelectionManager;
  DX.selection = new SelectionManager();
})(window.DX);
