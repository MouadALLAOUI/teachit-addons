# WINDOWS-SIM-AUDIT.md — Desktop Explorer Simulation Audit

**Project:** TeachIT Educational Game Launcher — Desktop Explorer  
**Auditor:** Senior Front-End Developer  
**Date:** October 31, 2026  
**Scope:** Evaluation of the current simulated desktop against native Windows shell behavior and educational learning goals for Moroccan students.

---

## 1. Windows Shell Features Audit Matrix

| # | Windows Shell Feature | Status | Current Implementation Analysis | Missing / Required Enhancements |
|---|----------------------|--------|----------------------------------|----------------------------------|
| **1** | **Taskbar at bottom** | **Partial** | Fixed at bottom (`48px`), has Start button, window tabs, clock. Prevents windows from going beneath taskbar via height calculation. | Missing: "Show Desktop" button (bottom-right peek button), window active highlight state synchronization, audio/touch feedback. |
| **2** | **Window Lifecycle & Manipulation** | **Partial** | Basic open/close/minimize/maximize via `window-manager.js`. Visual active window border exists. | Missing: Dragging titlebar with pointer/touch clamped to desktop viewport, drag-to-top edge snap preview & maximize, drag down to restore previous geometry, titlebar double-click to toggle maximize/restore, distinct visual styling for active vs inactive titlebars, edge/corner resizing. |
| **3** | **Selection & Opening** | **Partial** | Single click selects icon; double-click opens application or folder; Enter key on focused icon opens it. | Missing: `Ctrl+click` multi-selection, rubber-band (marquee) drag selection on desktop and folder grid, click outside on empty canvas to cleanly deselect all items. |
| **4** | **Simulated Keyboard Shortcuts** | **Missing** | Only `Enter` was handled on individual icons. | Missing: `F2` (inline rename), `Delete` (recycle), `Ctrl+C` / `Ctrl+X` / `Ctrl+V` (clipboard), `Ctrl+S` (save document in editor), `Esc` (dismiss menus/popups/selection), Arrow keys navigation across desktop grid. Must be scoped exclusively to simulated desktop. |
| **5** | **Context Menus** | **Partial** | Single desktop context menu with hardcoded sections (`cmenuDesktopSection`, `cmenuItemSection`). Clamps roughly inside desktop bounds. | Missing: Context-sensitive targets (distinct menus for: File, Folder, Desktop empty canvas, Explorer folder canvas, Taskbar). Missing submenus opening sideways (`View > Small/Medium/Large`, `Sort by > Name/Size`, `New > Folder/Document`). Disabled paste when clipboard empty. Taskbar context menu (Task Manager, Settings). Edge-flip detection. |
| **6** | **Simulated File System Operations** | **Partial** | `filesystem.js` supports folder/file creation, rename, move, delete to trash, serialization. | Missing: Real copy/cut/paste execution where cut items dim and move upon paste; Recycle Bin "Empty Recycle Bin" and "Restore"; file/folder Properties modal dialog (type, location, size, date); Windows-compliant duplicate name detection (`Informatique (2)`). |
| **7** | **Start Menu Application Launcher** | **Partial** | Simple popover with 3 static items (Editor, Explorer, Trash). | Missing: Real app launch menu containing: File Explorer, Text Editor (Notepad), Settings, Task Manager. Clean keyboard navigation and flyout styling. |
| **8** | **System Utility Windows** | **Missing** | Task Manager existed as empty static window; Settings window did not exist inside simulation. | Missing: Functional Task Manager window listing open windows with live "End task" action; functional in-simulation Settings window (wallpaper selection, icon size toggles). |
| **9** | **Tips / Educational Explainer Panel** | **Partial** | `.edu-explainer-card` positioned at bottom-right. | Missing: Hover opacity reduction to `50%` (smooth transition, interactive); click-to-cycle placement across corners (`top-right`, `bottom-right`, `bottom-left`, `top-left`) clamped strictly above taskbar. |
| **10** | **Text Editor (Notepad) & Save Workflow** | **Partial** | Basic textarea, Save and Save As buttons open static overlay modal. | Missing: Genuine `File > Save` / `File > Save As` workflow, first-time save triggering Save As modal with simulated folder target selector, subsequent `Ctrl+S` saving silently in-place, dirty tracking with "Do you want to save changes?" confirmation dialog on close. |
| **11** | **System Visual & Audio Feedback** | **Partial** | Sound effects exist for click, window open, close, error. Basic hover styles. | Missing: Windows-like pressed/active states, smooth open/close/snap animations respecting `prefers-reduced-motion`, gentle toast/sound feedback for invalid actions. |
| **12** | **Multilingual Text & RTL Handling** | **Implemented** | `dir="auto"` on inputs; AR/FR/EN dictionaries; desktop remains strictly LTR while labels translate. | Enhance: Multi-language name matching for Level 5 tasks (accepting Arabic, French, and English equivalents so changing language never breaks task validation). |

---

## 2. Level-by-Level Learning Goals & Current State

### Level 1: "Le Bureau" (Discover the Desktop)
- **Educational Learning Goal:** Familiarize beginner students with the foundational elements of a graphical user interface (Desktop surface, icons, taskbar, Start menu, system clock, Recycle Bin, wallpaper).
- **Current Tasks / Steps:** 6 elements to discover: `bureau`, `icones`, `barre-taches`, `menu-demarrer`, `corbeille`, `fond-ecran`.
- **How Student Currently Performs Them:** Clicks anywhere on the desktop surface, clicks taskbar, clicks start button, selects trash icon.
- **How Completion is Validated:** `discoveredElements.size >= 6` triggers `currentCtx.complete()`.
- **Gaps vs Real Windows Interaction:** Relies on passive clicks rather than authentic Windows desktop interactions (e.g. opening the Start menu, changing icon size via `View > Large icons`, refreshing the desktop, sorting icons by name).

---

### Level 2: "Fenêtres" (Windows and Applications)
- **Educational Learning Goal:** Understand window management: opening an application, inspecting titlebars, minimizing, restoring from the taskbar, maximizing, unmaximizing, dragging, and closing.
- **Current Tasks / Steps:**
  1. Double-click Text Editor icon.
  2. Click titlebar.
  3. Click minimize button.
  4. Restore from taskbar.
  5. Click maximize button.
  6. Click restore button.
  7. Click close button.
- **How Student Currently Performs Them:** Follows a strict linear step counter (`currentStep` 0 to 6).
- **How Completion is Validated:** Discrete event callbacks (`onOpenApp`, `onTitlebar`, `onMinimize`, `onRestore`, `onMaximize`, `onClose`) increment `currentStep` sequentially.
- **Gaps vs Real Windows Interaction:** Student cannot perform actions out-of-order or use alternative valid paths (e.g. double-clicking titlebar to maximize, dragging window to the top edge to snap-maximize, switching between multiple open windows, or closing via Task Manager).

---

### Level 3: "Dossiers" (Folders and Organization)
- **Educational Learning Goal:** Learn folder creation, renaming, entering folders, hierarchical navigation, copying/moving files, and deleting to the Recycle Bin.
- **Current Tasks / Steps:**
  1. Right-click desktop.
  2. Click New > Folder.
  3. Rename folder to "Informatique".
  4. Double-click folder to open in File Explorer.
  5. Close File Explorer.
  6. Rename folder to "Mon cours d'informatique".
- **How Student Currently Performs Them:** Has an artificial helper button (`#l3BtnHelper` "🖱️ Menu contextuel") in the header banner. Rigid step counter `0` through `5`.
- **How Completion is Validated:** Sequential step increments.
- **Gaps vs Real Windows Interaction:** The helper button short-circuits learning real right-clicking; renaming relies on a custom inline prompt rather than standard Windows `F2` or context menu "Renommer"; does not cover copying/cutting, restoring from Recycle Bin, or inspecting folder properties.

---

### Level 4: "Documents" (Text Creation and Saving)
- **Educational Learning Goal:** Launch a productivity application, write content, understand persistent storage, and execute the standard "Save As..." dialog workflow.
- **Current Tasks / Steps:**
  1. Open Text Editor.
  2. Type text into editor textarea.
  3. Click Save button in window toolbar.
  4. Fill out Save As modal with "Mon premier document" and submit.
- **How Student Currently Performs Them:** Linear step counter; toolbar buttons inside the window.
- **How Completion is Validated:** Step advances from 0 to 3 based on input events.
- **Gaps vs Real Windows Interaction:** Student cannot use standard `Ctrl+S` or `File > Save`; Save As dialog does not allow choosing subfolders from the real simulated file tree; no warning when closing with unsaved text.

---

### Level 5: "Mission finale" (Autonomous Organization Mission)
- **Educational Learning Goal:** Combine all learned computer-science skills autonomously: create folders, create documents, organize documents inside folders, verify contents, and manage the system.
- **Current Tasks / Steps:**
  1. Create folder "Informatique".
  2. Open text editor.
  3. Write text in document.
  4. Save as "Mon premier document".
  5. Move document into "Informatique".
  6. Open folder "Informatique".
  7. Verify document is inside.
  8. Open document to verify content.
- **How Student Currently Performs Them:** Observes partial file system state but uses rigid string matching.
- **How Completion is Validated:** Checks `DX.fs.findByName('Informatique')` and `doc.parentId === folder.id`.
- **Gaps vs Real Windows Interaction:** If student switches language to Arabic or English, folder names in French fail validation; drag-and-drop or Cut/Paste moves were incomplete; no Recycle Bin clean-up task.

---

## 3. Architecture Blueprint for Upgrade

1. **Modular Core Architecture:**
   - `js/core/taskbar.js`: Taskbar lifecycle, window pills, clock, Show Desktop peek button.
   - `js/core/context-menu.js`: Full context menu engine with submenus, boundary flipping, and target dispatch.
   - `js/core/window-manager.js`: Enhanced with window dragging, top-edge snap preview, titlebar double-click, z-order, focus state.
   - `js/core/selection.js`: Single-click, multi-select (`Ctrl+click`), rubber-band selection box, empty space deselection.
   - `js/core/shortcuts.js`: Keyboard shortcuts scoped strictly to the simulated desktop container.
   - `js/core/tips-panel.js`: Educational tips/checklist panel with hover opacity and 4-corner cycling.
   - `js/core/apps/`: Task Manager window and Settings window mini-apps.
2. **Real-Action Level Observers:**
   - Rework all 5 level scripts to observe live simulated state (file system hierarchy, open windows, clipboard, selection) rather than relying on artificial step buttons.
   - Support multi-lingual name acceptance (`Informatique` / `حاسوب` / `Computer`).
3. **No File Exceeding ~300 Lines:**
   - Keep scripts modular and focused.
