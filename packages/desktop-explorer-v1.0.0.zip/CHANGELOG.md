# CHANGELOG — Desktop Explorer Refactor & Upgrade

## Overview
This release transforms "Desktop Explorer" from a monolithic single-script game into an offline-first modular architecture adhering to TeachIT's educational and technical standards.

---

## 1. File Structure & Component Mapping

| Old Monolithic Section (scripts.js / styles.css) | New Modular Destination | Purpose / Key Responsibilities |
| :--- | :--- | :--- |
| **Section 1: Bilingual Translations & Dictionaries** | `js/i18n/fr.js`<br>`js/i18n/ar.js`<br>`js/i18n/en.js`<br>`js/core/i18n.js` | Full trilingual support (FR, AR, EN) with identical keys, fallback resolution, reactive language switching without reload, and RTL direction handling. |
| **Section 2 & 3: Desktop Elements & Challenges Config** | `js/config.js`<br>`js/levels/01-desktop.js` through `05-final.js` | Single source of truth for metadata and decoupled level specifications conforming to `DX.levels.register()`. |
| **Section 4: In-Memory Simulated File System** | `js/core/filesystem.js` | Hierarchical in-memory virtual filesystem supporting folder/document creation, moving, deleting, renaming, name validation, and state serialization. |
| **Section 5: Simulated Window Manager** | `js/core/window-manager.js` | Window state manager (editor, explorer, trash, taskmgr) handling open, close, minimize, maximize, restore, and z-index ordering. |
| **Section 6, 8, 12: Engine Progression & Orchestration** | `js/core/app.js`<br>`js/core/screens.js`<br>`js/screens/*.js` | Screen transitions, active level lifecycle management (`mount`, `start`, `destroy`), session info, and TeachIT IPC telemetry reporting. |
| **Section 7: TeachIT IPC Bridge & Exit Integration** | `js/core/app.js` (`DX.app.exitApp`) | Unified exit function with priority: `window.teachit.exit()` -> `window.teachit.exitGame()` -> `history.back()` -> `window.close()`. |
| **Section 9, 10, 11: Desktop Rendering & Context Menus** | `js/core/desktop-sim.js`<br>`css/desktop-sim.css` | Reusable simulated desktop environment, window controls, taskbar, start menu, double-click/touch support, and strictly bounded right-click context menu. |
| **Section 13: Results & Storage Telemetry** | `js/core/storage.js` | Migration from legacy `teachit_desktop_explorer_*` keys to `teachit.desktopexplorer.v1` and persistence for progress and simulated filesystem state. |
| **WebAudio Procedural Synthesizer** | `js/core/audio.js` | Copyright-free WebAudio looping calm ambient background music and sound effects (click, confirm, back, dialog, win, window actions, folder/file actions). |
| **Modal Dialogs & Accessibility** | `js/core/dialog.js`<br>`css/ui.css` | Accessible confirm and alert dialogs with focus trapping and default buttons (Cancel for Start, Stay for Exit). |

---

## 2. Key Architecture Decisions & Assumptions

1. **Simulated Desktop Geometry vs. Chrome RTL Mirroring:**
   - **Chrome (Header, Menus, Levels screen, Settings, About, Dialogs):** Follows standard document flow and mirrors completely when switching to Arabic (`<html dir="rtl" lang="ar">`).
   - **Simulated Desktop (`#simulatedDesktop`):** Enforces `direction: ltr !important` because it represents a standard PC operating system layout (Start menu and system icons on the left, system tray and clock on the right).
   - **Text Inside Windows:** Uses `dir="auto"` so that Arabic document contents, folder labels, and inputs naturally right-align while window chrome remains consistent.

2. **Window Manager Modular Split:**
   - To strictly comply with the constraint that no script file exceeds ~300 lines, `SimulatedWindowManager` was extracted to `js/core/window-manager.js`, keeping `desktop-sim.js` focused on DOM simulation and interactions.

3. **Save State Migration:**
   - Legacy saves under `teachit_desktop_explorer_${studentId}` and `teachit_desktop_explorer_guest` are automatically read and upgraded to `teachit.desktopexplorer.v1` on boot without losing student progress or created files.

4. **Launcher Unit Test Compatibility:**
   - The launcher repository includes integration unit tests (`apps/launcher/tests/game-desktop-explorer.test.ts`) that test manifest existence and evaluate `scripts.js` in a node mock environment. `scripts.js` and `styles.css` are preserved as backward-compatible artifacts so that test suites continue to pass 100%.

5. **Offline & Performance Integrity:**
   - Zero remote network calls, CDNs, or external fonts.
   - Canvas background with floating silhouettes runs at 60 fps on integrated graphics, automatically pauses when the window is hidden (`visibilitychange`), and disables motion under `prefers-reduced-motion: reduce`.

---

## 3. Anything Not Migrated 1:1

- **Welcome Cards -> Dedicated Levels Screen:**
  The old welcome screen crammed level explanations into low-contrast cards. These have been migrated to a dedicated, high-contrast Levels Screen with 22px+ bold titles and 18px+ descriptions, organized as a 2-column grid with a full-width featured card for Level 5.

---

## 4. Windows Simulation & Level Rework Upgrade (Release v1.1.0)

1. **Taskbar & Window Shell:**
   - Dedicated `taskbar.js` managing Start button, window task buttons, live clock, and "Show Desktop" peek button.
   - Dedicated `window-manager.js` with mouse and touch titlebar dragging, clamping within desktop bounds, top-edge snap preview to maximize, dragging down from maximized state to restore, titlebar double-click toggle, and visual inactive vs active titlebar distinction.
2. **Context Menus & Submenus:**
   - Dedicated `context-menu.js` supporting contextual target dispatch (Desktop, Item, Folder, Taskbar).
   - Multi-level submenus (`View > Small / Medium / Large`, `Sort by > Name / Size`, `New > Folder / Text document`).
   - Boundary-aware flipping ensuring menus never bleed off-screen.
3. **Selection & Keyboard Shortcuts:**
   - Dedicated `selection.js` supporting single-click, `Ctrl+click` multi-select, and rubber-band marquee selection.
   - Dedicated `shortcuts.js` with scoped shortcuts: `F2` (inline rename), `Delete` (recycle), `Ctrl+C` (copy), `Ctrl+X` (cut with dimming), `Ctrl+V` (paste), `Ctrl+S` (save document), `Esc`, and Arrow keys navigation.
4. **Interactive Tips Panel:**
   - Dedicated `tips-panel.js` with 50% hover opacity and click-to-cycle positioning through 4 screen corners (never overlapping the taskbar).
5. **App Windows & File System:**
   - Dedicated `app-windows.js` managing Notepad (with Save As dialog, Ctrl+S, dirty state close warning), File Explorer, Recycle Bin (with restore & empty), Task Manager (with live "End task" termination), Settings (wallpapers & icon sizes), and Properties dialog.
   - Virtual filesystem extended with real clipboard (cut/copy/paste), item restoration from trash, and multilingual name matching.
6. **Real-Action Levels Rework:**
   - Levels 1 to 5 completely rewritten to observe authentic Windows interactions rather than relying on artificial step buttons or hotspots.
   - Level 5 autonomous mission validated purely from the virtual filesystem graph with multilingual name recognition (`Informatique` / `حاسوب` / `Computer`).
- **Emoji Icons -> SVG Assets:**
  Replaced non-standard emojis (which rendered as blank rectangles on some Windows installations) with crisp, accessible vector SVGs in `assets/icons/`.
- **Exit Action -> Confirmation Dialog:**
  The bare "Retourner à TeachIT" links and direct quit buttons have been replaced by a unified confirmation dialog with "Stay" as the primary focused button to prevent accidental quits by teenage students.
