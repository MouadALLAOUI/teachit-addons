// ============================================================================
// TeachIT Educational Game: Desktop Explorer
// File: js/core/screens.js
// Purpose: Screen manager (Menu, Levels, Settings, About, Game, Results) & header sync
// Dependencies: window.DX.audio, window.DX.i18n
// ============================================================================

window.DX = window.DX || {};

(function (DX) {
  'use strict';

  let currentScreen = 'menu';
  const screenElements = {};

  function init() {
    const screens = ['menu', 'levels', 'settings', 'about', 'game', 'results'];
    screens.forEach((id) => {
      screenElements[id] = document.getElementById(`screen-${id}`);
    });
  }

  function show(screenId, _options = {}) {
    init();
    if (!screenElements[screenId]) {
      console.warn(`[DX.screens] Screen not found: "${screenId}"`);
      return;
    }

    currentScreen = screenId;

    // Toggle screen visibility
    Object.keys(screenElements).forEach((id) => {
      const el = screenElements[id];
      if (el) {
        if (id === screenId) {
          el.classList.add('active');
          el.removeAttribute('aria-hidden');
        } else {
          el.classList.remove('active');
          el.setAttribute('aria-hidden', 'true');
        }
      }
    });

    // Slim header visibility
    const header = document.getElementById('dxAppHeader');
    if (header) {
      if (screenId === 'menu') {
        header.classList.add('header-hidden');
      } else {
        header.classList.remove('header-hidden');
      }
    }

    // Background Canvas visibility:
    // Menu background canvas runs on menu, levels, settings, about
    const bgCanvas = document.getElementById('menuBackgroundCanvas');
    if (bgCanvas) {
      if (screenId === 'game') {
        bgCanvas.classList.add('bg-dimmed');
      } else {
        bgCanvas.classList.remove('bg-dimmed');
      }
    }

    // Call screen-specific renderers if available
    if (screenId === 'menu' && DX.menuScreen?.render) {
      DX.menuScreen.render();
    } else if (screenId === 'levels' && DX.levelsScreen?.render) {
      DX.levelsScreen.render();
    } else if (screenId === 'settings' && DX.settingsScreen?.render) {
      DX.settingsScreen.render();
    } else if (screenId === 'about' && DX.aboutScreen?.render) {
      DX.aboutScreen.render();
    }

    // Update level progression tabs in header
    updateHeaderTabs();

    window.scrollTo(0, 0);
  }

  function updateHeaderTabs() {
    const container = document.getElementById('headerLevelTabs');
    if (!container || !DX.levels) return;

    const allLevels = DX.levels.getAll();
    const save = DX.storage?.loadGame() || {};
    const completedIds = new Set(save.completedLevelIds || []);
    const activeLevelId = DX.levels.getCurrent()?.id;

    // Strict sequential unlocking
    const unlockedIds = new Set();
    allLevels.forEach((l, idx) => {
      if (idx === 0 || completedIds.has(allLevels[idx - 1].id)) {
        unlockedIds.add(l.id);
      }
    });

    container.innerHTML = '';
    allLevels.forEach((lvl, idx) => {
      const isCompleted = completedIds.has(lvl.id);
      const isCurrent = activeLevelId === lvl.id;
      const isUnlocked = unlockedIds.has(lvl.id);

      let stateClass = 'locked';
      let stateIcon = '<img src="assets/icons/lock.svg" class="tab-icon" alt="" aria-hidden="true" />';
      if (isCurrent) {
        stateClass = 'active';
        stateIcon = `<span class="tab-num">${idx + 1}</span>`;
      } else if (isCompleted) {
        stateClass = 'completed';
        stateIcon = '<img src="assets/icons/check.svg" class="tab-icon" alt="" aria-hidden="true" />';
      } else if (isUnlocked) {
        stateClass = 'unlocked';
        stateIcon = `<span class="tab-num">${idx + 1}</span>`;
      }

      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `level-tab-btn ${stateClass}`;
      btn.setAttribute('data-level', lvl.id);
      btn.title = !isUnlocked
        ? DX.i18n.t('levels.lockedTooltip')
        : `${DX.i18n.t('level.term')} ${idx + 1} : ${DX.i18n.t(lvl.titleKey)}`;

      const shortTitle = DX.i18n.t(lvl.shortKey || lvl.titleKey);
      btn.innerHTML = `
        ${stateIcon}
        <span class="tab-label">${shortTitle}</span>
      `;

      if (isUnlocked) {
        btn.addEventListener('click', () => {
          DX.audio?.playClick?.();
          DX.levels.launch(lvl.id);
        });
      } else {
        btn.disabled = true;
      }

      container.appendChild(btn);
    });
  }

  function getCurrent() {
    return currentScreen;
  }

  DX.screens = {
    init,
    show,
    getCurrent,
    updateHeaderTabs,
  };
})(window.DX);
