// ============================================================================
// TeachIT Educational Game: Desktop Explorer
// File: js/config.js
// Purpose: Single source of truth for game metadata, storage key, and level order
// Dependencies: None (Initializes window.DX)
// ============================================================================

window.DX = window.DX || {};

window.DX.config = {
  id: 'desktop-explorer',
  name: 'Desktop Explorer',
  version: '1.0.0',
  storageKey: 'teachit.desktopexplorer.v1',
  legacyStoragePrefix: 'teachit_desktop_explorer_',
  defaultLocale: 'fr',
  supportedLocales: ['fr', 'ar', 'en'],
  levelOrder: ['desktop', 'windows', 'folders', 'documents', 'final'],
  audio: {
    musicDefaultEnabled: true,
    sfxDefaultEnabled: true,
    musicDefaultVolume: 0.35,
    sfxDefaultVolume: 0.6,
  },
};
