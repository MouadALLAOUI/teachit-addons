// ============================================================================
// TeachIT Educational Game: Desktop Explorer
// File: js/core/storage.js
// Purpose: Persistence layer with schema migration from legacy TeachIT save format
// Dependencies: window.DX.config
// ============================================================================

window.DX = window.DX || {};

(function (DX) {
  'use strict';

  const SAVE_KEY = DX.config?.storageKey || 'teachit.desktopexplorer.v1';
  const SETTINGS_KEY = 'teachit.desktopexplorer.settings.v1';
  const LEGACY_PREFIX = DX.config?.legacyStoragePrefix || 'teachit_desktop_explorer_';

  const LEVEL_IDS = DX.config?.levelOrder || ['desktop', 'windows', 'folders', 'documents', 'final'];

  function indexToLevelId(idx) {
    return LEVEL_IDS[idx] || LEVEL_IDS[0];
  }

  function levelIdToIndex(id) {
    const idx = LEVEL_IDS.indexOf(id);
    return idx >= 0 ? idx : 0;
  }

  function computeUnlockedLevelIds(completedIds) {
    const unlocked = [LEVEL_IDS[0] || 'desktop'];
    for (let i = 0; i < LEVEL_IDS.length - 1; i++) {
      const currentId = LEVEL_IDS[i];
      const nextId = LEVEL_IDS[i + 1];
      if (completedIds.includes(currentId)) {
        unlocked.push(nextId);
      } else {
        break; // STRICT: Level N+1 is locked until Level N is completed
      }
    }
    return unlocked;
  }

  /**
   * Migrate legacy localStorage saves (teachit_desktop_explorer_*) if present.
   */
  function migrateLegacySaveIfNeeded() {
    try {
      if (typeof localStorage === 'undefined') return null;
      if (localStorage.getItem(SAVE_KEY)) {
        return null; // Already migrated or fresh save exists
      }

      // Look for legacy keys
      let foundLegacyKey = null;
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && k.startsWith(LEGACY_PREFIX)) {
          foundLegacyKey = k;
          break;
        }
      }

      if (!foundLegacyKey) return null;

      const raw = localStorage.getItem(foundLegacyKey);
      if (!raw) return null;

      const oldState = JSON.parse(raw);
      if (!oldState || typeof oldState !== 'object') return null;

      // Map numerical challenge indices to modern level IDs
      const rawCompleted = Array.isArray(oldState.completedChallenges)
        ? oldState.completedChallenges.map(indexToLevelId)
        : [];

      // Validate sequential completion
      const completedIds = [];
      for (const id of LEVEL_IDS) {
        if (rawCompleted.includes(id)) {
          completedIds.push(id);
        } else {
          break;
        }
      }

      const unlockedIds = computeUnlockedLevelIds(completedIds);
      const currentLevelId = indexToLevelId(oldState.currentChallengeIndex || 0);

      const migrated = {
        version: 1,
        currentLevelId,
        unlockedLevelIds: unlockedIds,
        completedLevelIds: completedIds,
        score: typeof oldState.score === 'number' ? oldState.score : 0,
        fsItems: Array.isArray(oldState.fsItems) ? oldState.fsItems : [],
        levelData: {
          desktop: {
            discoveredElements: Array.isArray(oldState.discoveredElements) ? oldState.discoveredElements : [],
          },
          windows: { step: oldState.c2Step || 0 },
          folders: { step: oldState.c3Step || 0 },
          documents: { step: oldState.c4Step || 0 },
          final: { tasks: oldState.c5Tasks || {} },
        },
        attempts: oldState.attemptsPerChallenge || [0, 0, 0, 0, 0],
        successes: oldState.successesPerChallenge || [0, 0, 0, 0, 0],
        savedAt: oldState.savedAt || Date.now(),
        migratedFrom: foundLegacyKey,
      };

      localStorage.setItem(SAVE_KEY, JSON.stringify(migrated));
      return migrated;
    } catch (err) {
      console.warn('[DX.storage] Legacy migration error:', err);
      return null;
    }
  }

  function hasSave() {
    try {
      if (typeof localStorage === 'undefined') return false;
      migrateLegacySaveIfNeeded();
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return false;
      const parsed = JSON.parse(raw);
      return !!parsed && (parsed.completedLevelIds?.length > 0 || parsed.currentLevelId !== 'desktop' || parsed.fsItems?.length > 2);
    } catch {
      return false;
    }
  }

  function loadGame() {
    try {
      if (typeof localStorage === 'undefined') return null;
      migrateLegacySaveIfNeeded();
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return null;
      const data = JSON.parse(raw);
      if (data && typeof data === 'object') {
        const completed = Array.isArray(data.completedLevelIds) ? data.completedLevelIds : [];
        data.unlockedLevelIds = computeUnlockedLevelIds(completed);
      }
      return data;
    } catch (err) {
      console.error('[DX.storage] Failed to load game:', err);
      return null;
    }
  }

  function saveGame(state) {
    try {
      if (typeof localStorage === 'undefined') return;
      const completed = Array.isArray(state.completedLevelIds) ? state.completedLevelIds : [];
      const unlocked = computeUnlockedLevelIds(completed);
      const payload = {
        version: 1,
        currentLevelId: state.currentLevelId || 'desktop',
        unlockedLevelIds: unlocked,
        completedLevelIds: completed,
        score: state.score || 0,
        fsItems: state.fsItems || [],
        levelData: state.levelData || {},
        attempts: state.attempts || [0, 0, 0, 0, 0],
        successes: state.successes || [0, 0, 0, 0, 0],
        savedAt: Date.now(),
      };
      localStorage.setItem(SAVE_KEY, JSON.stringify(payload));
    } catch (err) {
      console.error('[DX.storage] Failed to save game:', err);
    }
  }

  function clearGame() {
    try {
      if (typeof localStorage === 'undefined') return;
      localStorage.removeItem(SAVE_KEY);
      // Clean up legacy keys if any remain
      for (let i = localStorage.length - 1; i >= 0; i--) {
        const k = localStorage.key(i);
        if (k && k.startsWith(LEGACY_PREFIX)) {
          localStorage.removeItem(k);
        }
      }
    } catch (err) {
      console.error('[DX.storage] Failed to clear game save:', err);
    }
  }

  function getSettings() {
    const defaults = {
      sfxEnabled: DX.config?.audio?.sfxDefaultEnabled ?? true,
      musicEnabled: DX.config?.audio?.musicDefaultEnabled ?? true,
      sfxVolume: DX.config?.audio?.sfxDefaultVolume ?? 0.6,
      musicVolume: DX.config?.audio?.musicDefaultVolume ?? 0.35,
    };
    try {
      if (typeof localStorage === 'undefined') return defaults;
      const raw = localStorage.getItem(SETTINGS_KEY);
      if (!raw) return defaults;
      return { ...defaults, ...JSON.parse(raw) };
    } catch {
      return defaults;
    }
  }

  function saveSettings(settings) {
    try {
      if (typeof localStorage === 'undefined') return;
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch (err) {
      console.error('[DX.storage] Failed to save settings:', err);
    }
  }

  DX.storage = {
    SAVE_KEY,
    hasSave,
    loadGame,
    saveGame,
    clearGame,
    getSettings,
    saveSettings,
    indexToLevelId,
    levelIdToIndex,
  };
})(window.DX);
