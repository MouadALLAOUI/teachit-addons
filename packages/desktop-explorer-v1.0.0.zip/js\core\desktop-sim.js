// ============================================================================
// TeachIT Educational Game: Desktop Explorer
// File: js/core/desktop-sim.js
// Purpose: Simulated Windows desktop orchestrator (icons, apps, rename, clipboard)
// Dependencies: window.DX.SimulatedWindowManager, window.DX.fs, window.DX.taskbar, window.DX.contextMenu, window.DX.selection, window.DX.shortcuts, window.DX.tipsPanel, window.DX.appWindows
// ============================================================================

window.DX = window.DX || {};

(function (DX) {
  'use strict';

  class DesktopSimulator {
    constructor() {
      this.wm = new DX.SimulatedWindowManager();
      this.iconSize = 'medium';
      this.sortBy = 'default';
      this.wallpaper = 'classic';
      this.listeners = new Map();
      this.initialized = false;
    }

    on(event, cb) {
      if (!this.listeners.has(event)) this.listeners.set(event, new Set());
      this.listeners.get(event).add(cb);
    }

    emit(event, data) {
      if (this.listeners.has(event)) {
        this.listeners.get(event).forEach((cb) => {
          try { cb(data); } catch (e) { console.error(`[DX.desktopSim] Error in ${event}:`, e); }
        });
      }
    }

    init() {
      if (this.initialized) return;
      this.initialized = true;
      this.wm.setupDragging(document.getElementById('simulatedDesktop'));
      DX.taskbar?.init?.();
      DX.contextMenu?.init?.();
      DX.selection?.init?.();
      DX.shortcuts?.init?.();
      DX.tipsPanel?.init?.();
      DX.appWindows?.init?.();
      this.setupDesktopEvents();
      this.setupWindowControls();
      this.setupStartMenuApps();
      this.render();
    }

    render() {
      this.renderDesktopIcons();
      this.updateWindowsUI();
      if (this.wm.windows.explorer.isOpen) DX.appWindows?.renderExplorerContent(this.wm.windows.explorer.currentFolderId || 'desktop');
      if (this.wm.windows.trash.isOpen) DX.appWindows?.renderTrashContent();
      if (this.wm.windows.taskmgr.isOpen) DX.appWindows?.renderTaskManagerContent();
    }

    setupDesktopEvents() {
      const desktop = document.getElementById('simulatedDesktop');
      desktop?.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        const icon = e.target.closest('.desktop-icon');
        if (icon) {
          const id = icon.id.replace(/^exp-/, '');
          DX.selection?.selectItem(id);
          DX.contextMenu?.open(e.clientX, e.clientY, 'item', { itemId: id });
        } else if (!e.target.closest('.simulated-window') && !e.target.closest('.simulated-taskbar')) {
          DX.selection?.clearSelection();
          DX.contextMenu?.open(e.clientX, e.clientY, 'desktop');
        }
      });
      desktop?.addEventListener('dragover', (e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; });
      desktop?.addEventListener('drop', (e) => {
        if (e.target.closest('.desktop-icon') || e.target.closest('.simulated-window')) return;
        e.preventDefault();
        const draggedId = e.dataTransfer.getData('text/plain');
        const item = draggedId ? DX.fs.getItem(draggedId) : null;
        if (item && item.parentId !== 'desktop') {
          DX.fs.moveItem(draggedId, 'desktop');
          DX.audio?.playClick?.();
          this.render();
          this.emit('itemMoved', { id: draggedId, targetId: 'desktop' });
        }
      });
    }

    renderDesktopIcons() {
      const container = document.getElementById('desktopIconsArea');
      if (!container) return;
      container.innerHTML = '';
      const clipboard = DX.fs?.getClipboard?.();

      const systemApps = [
        { id: 'icon-editor', nameKey: 'sim.appEditor', icon: 'assets/icons/document.svg', action: () => this.openApp('editor') },
        { id: 'icon-explorer', nameKey: 'sim.appExplorer', icon: 'assets/icons/folder.svg', action: () => this.openApp('explorer') },
        { id: 'icon-trash', nameKey: 'sim.appTrash', icon: 'assets/icons/trash.svg', action: () => this.openApp('trash') },
      ];
      systemApps.forEach((app) => container.appendChild(this.createIconElement(app.id, DX.i18n.t(app.nameKey), app.icon, app.action)));

      let items = DX.fs.getChildren('desktop');
      if (this.sortBy === 'name') items.sort((a, b) => a.name.localeCompare(b.name));
      else if (this.sortBy === 'size') items.sort((a, b) => (b.content?.length || 0) - (a.content?.length || 0));

      items.forEach((item) => {
        if (item.id === 'trash') return;
        const iconSrc = item.type === 'folder' ? 'assets/icons/folder.svg' : 'assets/icons/document.svg';
        const isCut = clipboard?.op === 'cut' && clipboard.itemId === item.id;
        const el = this.createIconElement(item.id, item.name, iconSrc, () => item.type === 'folder' ? this.openFolder(item.id) : this.openFile(item.id));
        if (isCut) el.classList.add('item-cut');
        container.appendChild(el);
      });
      DX.selection?.syncVisuals();
    }

    createIconElement(id, name, iconSrc, onDblClick) {
      const el = document.createElement('div');
      el.className = `desktop-icon size-${this.iconSize}`;
      el.id = id;
      el.tabIndex = 0;
      el.setAttribute('role', 'button');
      el.setAttribute('aria-label', name);
      el.innerHTML = `<img class="desktop-icon-img" src="${iconSrc}" alt="" aria-hidden="true" /><span class="desktop-icon-label" id="label-${id}" dir="auto">${name}</span>`;

      const rawId = id.replace(/^exp-/, '').replace(/^trash-/, '');
      const fsItem = DX.fs.getItem(rawId);
      this.setupIconDragDrop(el, rawId, fsItem);

      let lastTap = 0;
      el.addEventListener('click', (e) => {
        e.stopPropagation();
        DX.selection?.selectItem(id, e.ctrlKey || e.metaKey);
        this.emit('select', id);
        const now = Date.now();
        if (now - lastTap < 350) { onDblClick?.(); lastTap = 0; }
        else lastTap = now;
      });
      return el;
    }

    setupIconDragDrop(el, rawId, fsItem) {
      if (fsItem && !fsItem.isSystem) {
        el.setAttribute('draggable', 'true');
        el.addEventListener('dragstart', (e) => { e.dataTransfer.setData('text/plain', rawId); e.dataTransfer.effectAllowed = 'move'; el.classList.add('is-dragging'); });
        el.addEventListener('dragend', () => { el.classList.remove('is-dragging'); document.querySelectorAll('.drag-target-hover').forEach((t) => t.classList.remove('drag-target-hover')); });
      }
      if (rawId === 'icon-trash' || rawId === 'trash' || fsItem?.type === 'folder') {
        el.addEventListener('dragover', (e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; el.classList.add('drag-target-hover'); });
        el.addEventListener('dragleave', (e) => { if (!el.contains(e.relatedTarget)) el.classList.remove('drag-target-hover'); });
        el.addEventListener('drop', (e) => {
          e.preventDefault(); e.stopPropagation(); el.classList.remove('drag-target-hover');
          const draggedId = e.dataTransfer.getData('text/plain');
          if (!draggedId || draggedId === rawId) return;
          if (rawId === 'icon-trash' || rawId === 'trash') {
            DX.fs.deleteItem(draggedId); DX.audio?.playTrash?.(); this.render(); this.emit('itemDeleted', draggedId);
          } else {
            DX.fs.moveItem(draggedId, rawId); DX.audio?.playClick?.(); this.render(); this.emit('itemMoved', { id: draggedId, targetId: rawId });
          }
        });
      }
    }

    openApp(appId) {
      DX.audio?.playWindowOpen?.();
      this.wm.openWindow(appId);
      this.updateWindowsUI();
      this.emit('openApp', appId);
      if (appId === 'taskmgr') DX.appWindows?.renderTaskManagerContent();
      if (appId === 'trash') DX.appWindows?.renderTrashContent();
    }

    openFolder(folderId) {
      this.wm.windows.explorer.currentFolderId = folderId;
      this.openApp('explorer');
      DX.appWindows?.renderExplorerContent(folderId);
      this.emit('openFolder', folderId);
    }

    openFile(fileId) {
      const file = DX.fs.getItem(fileId);
      if (!file) return;
      if (DX.appWindows) {
        DX.appWindows.currentEditorFileId = file.id;
        DX.appWindows.editorIsDirty = false;
      }
      const textarea = document.getElementById('editorTextarea');
      const titleEl = document.getElementById('winEditorTitle');
      if (textarea) textarea.value = file.content || '';
      if (titleEl) titleEl.textContent = `${file.name} — ${DX.i18n.t('sim.appEditor')}`;
      this.openApp('editor');
      this.emit('openFile', file);
    }

    openItemById(id) {
      if (id === 'icon-editor') this.openApp('editor');
      else if (id === 'icon-explorer') this.openApp('explorer');
      else if (id === 'icon-trash') this.openApp('trash');
      else {
        const item = DX.fs.getItem(id);
        if (item?.type === 'folder') this.openFolder(item.id);
        else if (item?.type === 'file') this.openFile(item.id);
      }
    }

    startRenameInline(itemId) {
      const labelEl = document.getElementById(`label-${itemId}`);
      if (!labelEl) return;
      const currentName = labelEl.textContent.trim();
      const input = document.createElement('input');
      input.type = 'text';
      input.className = 'desktop-icon-label-input';
      input.setAttribute('dir', 'auto');
      input.value = currentName;
      labelEl.replaceWith(input);
      input.focus();
      input.select();

      const finish = (save) => {
        const val = input.value.trim();
        if (save && val && val !== currentName) {
          const valRes = DX.fs.validateName(val);
          if (valRes.valid) {
            DX.fs.renameItem(itemId, val);
            this.emit('itemRenamed', { id: itemId, newName: val });
          } else DX.audio?.playError?.();
        }
        this.render();
      };
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); finish(true); }
        else if (e.key === 'Escape') { e.preventDefault(); finish(false); }
      });
      input.addEventListener('blur', () => finish(true));
    }

    createNewFolderInline(parentId) {
      const folder = DX.fs.createFolder(parentId, DX.i18n.t('sim.newFolder'));
      this.render(); this.startRenameInline(folder.id); this.emit('folderCreated', folder);
    }
    createNewDocInline(parentId) {
      const doc = DX.fs.createFile(parentId, DX.i18n.t('sim.newDocument'), '', 'txt');
      this.render(); this.startRenameInline(doc.id); this.emit('documentCreated', doc);
    }
    pasteClipboard(targetParentId) {
      const res = DX.fs.executePaste(targetParentId);
      if (res) { DX.audio?.playClick?.(); this.render(); this.emit('itemPasted', res); }
    }
    updateWindowsUI() {
      Object.keys(this.wm.windows).forEach((id) => {
        const win = this.wm.windows[id];
        const el = document.getElementById(`window${id.charAt(0).toUpperCase() + id.slice(1)}`);
        if (!el) return;
        if (win.isOpen && !win.isMinimized) {
          el.style.display = 'flex'; el.style.zIndex = String(win.zIndex);
          if (win.isMaximized) el.classList.add('maximized');
          else { el.classList.remove('maximized'); el.style.left = `${win.x}px`; el.style.top = `${win.y}px`; }
          el.classList.toggle('active-window', this.wm.activeWindowId === id);
        } else el.style.display = 'none';
      });
      DX.taskbar?.renderWindowPills?.(this.wm.windows, this.wm.activeWindowId);
    }
    setupWindowControls() {
      Object.keys(this.wm.windows).forEach((id) => {
        const cap = id.charAt(0).toUpperCase() + id.slice(1);
        document.getElementById(`btn${cap}Minimize`)?.addEventListener('click', (e) => { e.stopPropagation(); this.wm.minimizeWindow(id); this.updateWindowsUI(); });
        document.getElementById(`btn${cap}Maximize`)?.addEventListener('click', (e) => { e.stopPropagation(); this.wm.toggleMaximize(id); this.updateWindowsUI(); });
        document.getElementById(`btn${cap}Close`)?.addEventListener('click', (e) => { e.stopPropagation(); this.requestCloseWindow(id); });
      });
    }
    requestCloseWindow(id) {
      if (id === 'editor' && DX.appWindows?.editorIsDirty && window.confirm(DX.i18n.t('sim.closeConfirmMsg'))) DX.appWindows.saveEditorDocument();
      DX.audio?.playWindowClose?.(); this.wm.closeWindow(id); this.updateWindowsUI(); this.emit('windowClosed', id);
    }
    saveEditorDocument() { DX.appWindows?.saveEditorDocument?.(); }
    setWallpaper(theme) {
      this.wallpaper = theme;
      const art = document.getElementById('desktopWallpaperArt');
      if (art) art.className = `desktop-wallpaper-art theme-${theme}`;
      DX.audio?.playClick?.(); this.emit('wallpaperChanged', theme);
    }
    setIconSize(size) { this.iconSize = size; this.render(); }
    setSortBy(sort) { this.sortBy = sort; this.render(); }
    openPropertiesWindow(itemId) { DX.appWindows?.openPropertiesWindow?.(itemId); }
    setupStartMenuApps() {
      const map = { startItemEditor: 'editor', startItemExplorer: 'explorer', startItemTrash: 'trash', startItemSettings: 'settings', startItemTaskmgr: 'taskmgr' };
      Object.entries(map).forEach(([elId, appId]) => {
        document.getElementById(elId)?.addEventListener('click', (e) => {
          e.stopPropagation(); document.getElementById('startMenuPopover')?.classList.remove('active'); this.openApp(appId);
        });
      });
    }
  }

  DX.desktopSim = new DesktopSimulator();
})(window.DX);
