// ============================================================================
// TeachIT Educational Game: Desktop Explorer
// File: js/core/i18n.js
// Purpose: Internationalization engine, dictionary resolution & RTL handling
// Dependencies: window.DX.config, window.DX.i18nData
// ============================================================================

window.DX = window.DX || {};

(function (DX) {
  'use strict';

  const listeners = new Set();
  let currentLang = DX.config?.defaultLocale || 'fr';

  function init() {
    // Check localStorage for saved user language
    try {
      if (typeof localStorage !== 'undefined') {
        const savedLang = localStorage.getItem('teachit.desktopexplorer.lang');
        if (savedLang && ['fr', 'ar', 'en'].includes(savedLang)) {
          currentLang = savedLang;
        }
      }
    } catch {
      // Safe fallback in restricted sandboxes
    }
    applyHtmlAttributes(currentLang);
  }

  function applyHtmlAttributes(lang) {
    if (typeof document === 'undefined') return;
    const isRtl = lang === 'ar';
    document.documentElement.lang = lang;
    document.documentElement.dir = isRtl ? 'rtl' : 'ltr';

    if (isRtl) {
      document.body.classList.add('rtl-layout');
    } else {
      document.body.classList.remove('rtl-layout');
    }
  }

  function getLanguage() {
    return currentLang;
  }

  function setLanguage(lang) {
    if (!['fr', 'ar', 'en'].includes(lang)) return;
    currentLang = lang;
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('teachit.desktopexplorer.lang', lang);
      }
    } catch {
      // Safe fallback
    }

    applyHtmlAttributes(lang);
    updateDomTranslations();

    // Sync all language switcher buttons across header, menu, settings
    document.querySelectorAll('.lang-seg-btn').forEach((btn) => {
      btn.classList.toggle('active', btn.getAttribute('data-lang') === lang);
    });

    listeners.forEach((fn) => {
      try {
        fn(lang);
      } catch (err) {
        console.error('[DX.i18n] Error in language listener:', err);
      }
    });

    DX.screens?.updateHeaderTabs?.();
  }

  function t(key, params) {
    const dict = DX.i18nData?.[currentLang] || DX.i18nData?.fr || {};
    let text = dict[key];

    if (text === undefined) {
      // Fallback to French
      text = DX.i18nData?.fr?.[key];
      if (text === undefined) {
        // Fallback to English
        text = DX.i18nData?.en?.[key];
      }
      if (text === undefined) {
        console.warn(`[DX.i18n] Missing translation key: "${key}" (lang: ${currentLang})`);
        return key;
      }
    }

    if (params && typeof params === 'object') {
      Object.keys(params).forEach((pKey) => {
        text = text.replace(new RegExp(`\\{${pKey}\\}`, 'g'), String(params[pKey]));
      });
    }

    return text;
  }

  function onChange(callback) {
    if (typeof callback === 'function') {
      listeners.add(callback);
    }
  }

  function offChange(callback) {
    listeners.delete(callback);
  }

  function updateDomTranslations(root = document) {
    if (!root || !root.querySelectorAll) return;
    const elements = root.querySelectorAll('[data-i18n]');
    elements.forEach((el) => {
      const key = el.getAttribute('data-i18n');
      if (key) {
        el.textContent = t(key);
      }
    });

    const titleElements = root.querySelectorAll('[data-i18n-title]');
    titleElements.forEach((el) => {
      const key = el.getAttribute('data-i18n-title');
      if (key) {
        el.setAttribute('title', t(key));
      }
    });

    const placeholderElements = root.querySelectorAll('[data-i18n-placeholder]');
    placeholderElements.forEach((el) => {
      const key = el.getAttribute('data-i18n-placeholder');
      if (key) {
        el.setAttribute('placeholder', t(key));
      }
    });

    const ariaLabelElements = root.querySelectorAll('[data-i18n-aria]');
    ariaLabelElements.forEach((el) => {
      const key = el.getAttribute('data-i18n-aria');
      if (key) {
        el.setAttribute('aria-label', t(key));
      }
    });
  }

  DX.i18n = {
    init,
    getLanguage,
    setLanguage,
    t,
    onChange,
    offChange,
    updateDomTranslations,
  };

  init();
})(window.DX);
