(function (global) {
  'use strict';

  const MM2 = (global.MM2 = global.MM2 || {});
  MM2.Ateliers = MM2.Ateliers || new Map();

  MM2.Ateliers.set('atelier-1', {
    mount(container, api) {
      const atelier = api.atelier || MM2.CONFIG.ateliers[0];
      const data = atelier.data || {};
      const targets = data.targets || [];
      const requiredCorrect = data.targetCount || 12;

      const board = document.createElement('div');
      board.className = 'a1-board';
      board.style.position = 'relative';
      board.style.width = '100%';
      board.style.height = '100%';
      board.style.minHeight = '420px';

      const clicks = [];
      let lastAppearanceTime = Date.now();

      targets.forEach((targetConfig) => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = `a1-target ${targetConfig.correct ? 'is-correct' : 'is-wrong'}`;
        btn.setAttribute('aria-label', targetConfig.label || (targetConfig.correct ? 'Cible verte' : 'Piège rouge'));
        btn.style.position = 'absolute';
        btn.style.left = `${targetConfig.x}%`;
        btn.style.top = `${targetConfig.y}%`;
        btn.style.width = `${targetConfig.size}px`;
        btn.style.height = `${targetConfig.size}px`;
        btn.style.transform = 'translate(-50%, -50%)';

        btn.innerHTML = `<span class="target-inner" aria-hidden="true">${targetConfig.correct ? '🎯' : '⚠️'}</span>`;

        const onClick = () => {
          if (btn.disabled) return;
          api.attempt();

          const now = Date.now();
          const reactionMs = Math.max(50, now - lastAppearanceTime);
          lastAppearanceTime = now;

          clicks.push({
            correct: targetConfig.correct,
            reactionMs,
          });

          btn.disabled = true;
          btn.classList.add('is-hit');

          if (targetConfig.correct) {
            api.feedback('Cible touchée avec succès !', 'success', '✨');
          } else {
            api.feedback('Attention, c’était un piège rouge ! Vise uniquement les cibles vertes.', 'error', '⚠️');
          }

          const correctCount = clicks.filter((c) => c.correct).length;
          api.status(`${correctCount} / ${requiredCorrect} cibles vertes validées`);

          if (correctCount >= requiredCorrect) {
            const stats = MM2.Ateliers.helpers.a1.computeStats(clicks, requiredCorrect);
            api.finish({
              precision: stats.precision,
              measurements: {
                medianReactionMs: stats.medianReactionMs,
              },
            });
          }
        };

        btn.addEventListener('click', onClick);
        board.appendChild(btn);
      });

      container.appendChild(board);
      api.status(`0 / ${requiredCorrect} cibles vertes validées`);

      return function cleanup() {
        board.remove();
      };
    },
  });
})(typeof window !== 'undefined' ? window : globalThis);
