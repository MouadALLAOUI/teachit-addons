(function (global) {
  'use strict';

  const MM2 = (global.MM2 = global.MM2 || {});
  MM2.Ateliers = MM2.Ateliers || new Map();

  MM2.Ateliers.set('boss', {
    mount(container, api) {
      const atelier = api.atelier || MM2.CONFIG.ateliers[6];
      const data = atelier.data || {};
      const files = data.files || [];
      const lassoRequired = data.lassoRequired || ['b_doc1', 'b_doc2', 'b_doc3'];
      const ctrlAdd = data.ctrlAdd || 'b_doc4';
      const dropFolder = data.dropFolder || 'Cours';
      const docLines = data.docLines || [];
      const textTarget = data.textTarget || 'Ligne secrète : La maîtrise de la souris garantit une efficacité maximale.';
      const resizeTarget = data.resize || { targetWidth: 480, targetHeight: 360, tolerance: 4, grid: 8 };

      const bossArea = document.createElement('div');
      bossArea.className = 'boss-area';
      bossArea.style.position = 'relative';
      bossArea.style.width = '100%';
      bossArea.style.height = '100%';
      bossArea.style.minHeight = '560px';
      bossArea.style.userSelect = 'none';

      const objectives = {
        lasso: false,
        ctrl: false,
        drop: false,
        resize: false,
        scroll: false,
        text: false,
      };

      // Objectives Sidebar
      const sidebar = document.createElement('div');
      sidebar.className = 'boss-checklist';
      sidebar.innerHTML = `
        <h3 class="checklist-title">Mission Bureau : Objectifs</h3>
        <ul class="checklist-items">
          <li id="obj_lasso" class="chk-item"><span class="chk-icon">⚪</span> 1. Lasso : 3 cours</li>
          <li id="obj_ctrl" class="chk-item"><span class="chk-icon">⚪</span> 2. Ctrl+clic : Annexe</li>
          <li id="obj_drop" class="chk-item"><span class="chk-icon">⚪</span> 3. Glisser vers « ${dropFolder} »</li>
          <li id="obj_resize" class="chk-item"><span class="chk-icon">⚪</span> 4. Fenêtre à ${resizeTarget.targetWidth}×${resizeTarget.targetHeight}</li>
          <li id="obj_scroll" class="chk-item"><span class="chk-icon">⚪</span> 5. Molette : ligne secrète</li>
          <li id="obj_text" class="chk-item"><span class="chk-icon">⚪</span> 6. Sélectionner la ligne</li>
        </ul>
      `;
      bossArea.appendChild(sidebar);

      function updateChecklist() {
        for (const id of MM2.Ateliers.helpers.boss.objectiveIds) {
          const el = sidebar.querySelector(`#obj_${id}`);
          if (el) {
            const isDone = objectives[id];
            el.className = `chk-item ${isDone ? 'is-done' : ''}`;
            const icon = el.querySelector('.chk-icon');
            if (icon) icon.textContent = isDone ? '✅' : '⚪';
          }
        }
        const doneCount = MM2.Ateliers.helpers.boss.countCompleted(objectives);
        api.status(`${doneCount} / 6 objectifs accomplis`);

        if (MM2.Ateliers.helpers.boss.allCompleted(objectives)) {
          api.feedback(
            'MISSION ACCOMPLIE ! Félicitations Mouse Master, toutes les épreuves sont validées !',
            'success',
            '👑',
          );
          setTimeout(() => {
            api.finish({
              precision: MM2.Ateliers.helpers.boss.firstTryPrecision(objectives),
            });
          }, 1000);
        }
      }

      // Simulated Desktop Section
      const desktop = document.createElement('div');
      desktop.className = 'boss-desktop';
      desktop.style.position = 'relative';
      desktop.style.width = 'calc(100% - 240px)';
      desktop.style.marginLeft = '240px';
      desktop.style.height = '100%';
      desktop.style.minHeight = '560px';

      // Drop Target Folder
      const folder = document.createElement('div');
      folder.className = 'boss-folder';
      folder.id = 'bossFolderTarget';
      folder.style.position = 'absolute';
      folder.style.right = '40px';
      folder.style.top = '30px';
      folder.style.width = '120px';
      folder.style.padding = '12px';
      folder.style.textAlign = 'center';
      folder.style.border = '2px dashed var(--color-accent-primary, #6366f1)';
      folder.style.borderRadius = '8px';
      folder.style.background = 'rgba(99, 102, 241, 0.1)';
      folder.style.transition = 'all 0.2s ease';
      folder.style.cursor = 'pointer';
      folder.innerHTML = `
        <div style="font-size: 32px">📁</div>
        <div style="font-weight: 600; margin-top: 4px;">Dossier ${dropFolder}</div>
      `;
      desktop.appendChild(folder);

      // Files grid
      const selectedFiles = new Set();
      const ctrlAddedFiles = new Set();
      const fileElements = new Map();

      let isDraggingFiles = false;
      let dragGhost = null;

      function createDragGhost(x, y) {
        if (typeof document === 'undefined') return;
        dragGhost = document.createElement('div');
        dragGhost.className = 'boss-drag-ghost';
        dragGhost.style.position = 'fixed';
        dragGhost.style.left = `${x + 12}px`;
        dragGhost.style.top = `${y + 12}px`;
        dragGhost.style.pointerEvents = 'none';
        dragGhost.style.zIndex = '9999';
        dragGhost.style.background = 'var(--color-accent-primary, #6366f1)';
        dragGhost.style.color = '#ffffff';
        dragGhost.style.padding = '8px 14px';
        dragGhost.style.borderRadius = '8px';
        dragGhost.style.boxShadow = '0 8px 24px rgba(0,0,0,0.6)';
        dragGhost.style.fontWeight = '700';
        dragGhost.style.fontSize = '13px';
        dragGhost.style.display = 'flex';
        dragGhost.style.alignItems = 'center';
        dragGhost.style.gap = '8px';
        dragGhost.innerHTML = `<span>📁</span> <span>Déplacement : ${selectedFiles.size} fichier(s)</span>`;
        document.body.appendChild(dragGhost);
      }

      function handleDropOnFolder() {
        api.attempt();
        if (objectives.lasso && objectives.ctrl) {
          objectives.drop = true;
          folder.style.background = 'rgba(16, 185, 129, 0.25)';
          folder.style.borderColor = 'var(--color-success, #10b981)';
          folder.innerHTML = `
            <div style="font-size: 32px">📂</div>
            <div style="font-weight: 700; color: #10b981; margin-top: 4px;">✓ 4 fichiers classés !</div>
          `;
          selectedFiles.forEach((id) => {
            const el = fileElements.get(id);
            if (el) {
              el.style.opacity = '0.35';
              el.style.transform = 'scale(0.85)';
            }
          });
          api.feedback(`Fichiers déposés avec succès dans le dossier « ${dropFolder} » !`, 'success', '📥');
          updateChecklist();
        } else if (!objectives.lasso) {
          api.feedback('Sélectionne d’abord les 3 cours avec le lasso avant de déposer !', 'error', '⚠️');
        } else if (!objectives.ctrl) {
          api.feedback('N’oublie pas d’ajouter l’annexe (Annexe_Extra.txt) avec Ctrl+clic avant de déposer !', 'error', '⚠️');
        } else {
          api.feedback('Sélectionne les 3 cours au lasso et ajoute l’annexe avec Ctrl+clic !', 'error', '⚠️');
        }
      }

      files.forEach((f, idx) => {
        const col = idx % 3;
        const row = Math.floor(idx / 3);
        const fEl = document.createElement('div');
        fEl.className = 'boss-file';
        fEl.id = `bf_${f.id}`;
        fEl.style.position = 'absolute';
        fEl.style.left = `${30 + col * 90}px`;
        fEl.style.top = `${30 + row * 80}px`;
        fEl.style.width = '75px';
        fEl.style.textAlign = 'center';
        fEl.style.cursor = 'pointer';
        fEl.style.padding = '4px';
        fEl.style.borderRadius = '6px';
        fEl.style.transition = 'background 0.15s ease, transform 0.15s ease';

        fEl.innerHTML = `
          <div style="font-size: 26px;">${f.icon || '📄'}</div>
          <div style="font-size: 11px; word-break: break-all;">${f.name}</div>
        `;

        fEl.addEventListener('pointerdown', (e) => {
          if (e.ctrlKey || e.metaKey) return;
          if (selectedFiles.has(f.id)) {
            e.stopPropagation();
            isDraggingFiles = true;
            createDragGhost(e.clientX, e.clientY);
          }
        });

        fEl.addEventListener('click', (e) => {
          if (e.ctrlKey || e.metaKey) {
            api.attempt();
            if (f.id === ctrlAdd) {
              selectedFiles.add(f.id);
              ctrlAddedFiles.add(f.id);
              fEl.classList.add('is-selected');
              objectives.ctrl = true;
              api.feedback('Fichier supplémentaire ajouté avec Ctrl+clic !', 'success', '✨');
              updateChecklist();
            } else {
              if (selectedFiles.has(f.id)) {
                selectedFiles.delete(f.id);
                ctrlAddedFiles.delete(f.id);
                fEl.classList.remove('is-selected');
              } else {
                selectedFiles.add(f.id);
                ctrlAddedFiles.add(f.id);
                fEl.classList.add('is-selected');
              }
            }
          }
        });

        desktop.appendChild(fEl);
        fileElements.set(f.id, fEl);
      });

      // Folder Click Fallback
      folder.addEventListener('click', handleDropOnFolder);

      // Selection Lasso on Desktop
      const lasso = document.createElement('div');
      lasso.className = 'boss-lasso';
      lasso.style.position = 'absolute';
      lasso.style.display = 'none';
      lasso.style.pointerEvents = 'none';
      lasso.style.border = '1px dashed #38bdf8';
      lasso.style.background = 'rgba(56, 189, 248, 0.15)';
      lasso.style.zIndex = '15';
      desktop.appendChild(lasso);

      let isDraggingLasso = false;
      let startX = 0;
      let startY = 0;

      desktop.addEventListener('pointerdown', (e) => {
        if (isDraggingFiles) return;
        isDraggingLasso = true;
        const dRect = desktop.getBoundingClientRect();
        startX = e.clientX - dRect.left;
        startY = e.clientY - dRect.top;
      });

      // Document Resizable Window
      const docWin = document.createElement('div');
      docWin.className = 'boss-doc-win';
      docWin.style.position = 'absolute';
      docWin.style.left = '30px';
      docWin.style.top = '270px';
      docWin.style.width = '360px';
      docWin.style.height = '240px';
      docWin.style.border = '1px solid #475569';
      docWin.style.borderRadius = '8px';
      docWin.style.background = '#0f172a';
      docWin.style.display = 'flex';
      docWin.style.flexDirection = 'column';
      docWin.style.boxShadow = '0 12px 28px rgba(0,0,0,0.5)';
      docWin.style.zIndex = '10';

      // Prevent lasso or file drags when interacting inside the document window
      docWin.addEventListener('pointerdown', (e) => e.stopPropagation());
      docWin.addEventListener('mousedown', (e) => e.stopPropagation());
      docWin.addEventListener('mouseup', (e) => e.stopPropagation());

      docWin.innerHTML = `
        <div class="boss-doc-header" style="padding: 6px 12px; background: #1e293b; border-bottom: 1px solid #334155; display: flex; justify-content: space-between; align-items: center; user-select: none;">
          <span style="font-size: 11px; font-weight: 600;">Document de révision</span>
          <span id="bossWinDim" style="font-size: 10px; color: #94a3b8; font-family: monospace;">360 × 240 px</span>
        </div>
        <div class="boss-doc-scroll" style="flex: 1; overflow-y: scroll; padding: 12px 16px; cursor: text; user-select: text;">
          ${docLines
            .map((l) => {
              const isTarget = l.includes(textTarget) || l.includes('Ligne secrète');
              return `<p class="boss-line ${isTarget ? 'boss-secret-line' : ''}" style="margin: 8px 0; font-size: 13px; line-height: 1.5; ${
                isTarget ? 'background: rgba(56, 189, 248, 0.2); border-left: 3px solid #38bdf8; padding: 6px 10px; font-weight: bold; border-radius: 4px;' : ''
              }">${l}</p>`;
            })
            .join('')}
        </div>
        <div class="boss-win-handle" style="position: absolute; right: 0; bottom: 0; width: 16px; height: 16px; cursor: nwse-resize; background: #6366f1; border-top-left-radius: 4px; z-index: 35;"></div>
      `;

      const winDimDisplay = docWin.querySelector('#bossWinDim');
      const scrollArea = docWin.querySelector('.boss-doc-scroll');

      let rect = {
        left: 30,
        top: 270,
        width: 360,
        height: 240,
      };

      let isResizing = false;
      let activeHandle = 'se';
      let startRect = { ...rect };
      let startMouseX = 0;
      let startMouseY = 0;

      const handles = [
        { code: 'n', cursor: 'ns-resize', cls: 'handle-n' },
        { code: 's', cursor: 'ns-resize', cls: 'handle-s' },
        { code: 'e', cursor: 'ew-resize', cls: 'handle-e' },
        { code: 'w', cursor: 'ew-resize', cls: 'handle-w' },
        { code: 'nw', cursor: 'nwse-resize', cls: 'handle-nw' },
        { code: 'se', cursor: 'nwse-resize', cls: 'handle-se' },
        { code: 'ne', cursor: 'nesw-resize', cls: 'handle-ne' },
        { code: 'sw', cursor: 'nesw-resize', cls: 'handle-sw' },
      ];

      handles.forEach((h) => {
        const hEl = document.createElement('div');
        hEl.className = `a4-handle ${h.cls}`;
        hEl.style.cursor = h.cursor;
        hEl.addEventListener('pointerdown', (e) => {
          e.stopPropagation();
          isResizing = true;
          activeHandle = h.code;
          startRect = { ...rect };
          startMouseX = e.clientX;
          startMouseY = e.clientY;
        });
        docWin.appendChild(hEl);
      });

      const winCornerHandle = docWin.querySelector('.boss-win-handle');
      if (winCornerHandle) {
        winCornerHandle.addEventListener('pointerdown', (e) => {
          e.stopPropagation();
          isResizing = true;
          activeHandle = 'se';
          startRect = { ...rect };
          startMouseX = e.clientX;
          startMouseY = e.clientY;
        });
      }

      function handleScrollCheck() {
        api.attempt();
        if (scrollArea.scrollTop > 30 && !objectives.scroll) {
          objectives.scroll = true;
          api.feedback('Objectif 5 validé : tu as fait défiler le document jusqu’à la consigne secrète !', 'success', '✨');
          updateChecklist();
        }
      }

      scrollArea.addEventListener('wheel', (e) => {
        e.stopPropagation();
        scrollArea.scrollTop += e.deltaY;
        handleScrollCheck();
      });

      scrollArea.addEventListener('scroll', handleScrollCheck);

      const secretLines = docWin.querySelectorAll('.boss-secret-line');

      function validateTextObjective() {
        api.attempt();
        if (!objectives.text) {
          objectives.text = true;
          secretLines.forEach((el) => el.classList.add('is-text-selected'));
          api.feedback('Objectif 6 validé : ligne secrète sélectionnée avec succès !', 'success', '✨');
          updateChecklist();
        }
      }

      function checkTextSelection() {
        let selText = '';
        if (typeof window !== 'undefined' && window.getSelection) {
          selText = window.getSelection().toString().trim();
        }
        if (
          selText &&
          (selText.includes('La maîtrise de la souris') ||
            selText.includes('garantit une efficacité') ||
            selText.includes('Ligne secrète') ||
            selText.includes('maximale') ||
            selText.includes(textTarget))
        ) {
          validateTextObjective();
        }
      }

      scrollArea.addEventListener('mouseup', (e) => {
        e.stopPropagation();
        checkTextSelection();
      });

      scrollArea.addEventListener('pointerup', (e) => {
        e.stopPropagation();
        checkTextSelection();
      });

      if (typeof document !== 'undefined') {
        document.addEventListener('selectionchange', checkTextSelection);
      }

      secretLines.forEach((el) => {
        el.addEventListener('click', (e) => {
          e.stopPropagation();
          validateTextObjective();
        });
        el.addEventListener('dblclick', (e) => {
          e.stopPropagation();
          validateTextObjective();
        });
      });

      const onWindowPointerMove = (e) => {
        if (isDraggingFiles && dragGhost) {
          dragGhost.style.left = `${e.clientX + 14}px`;
          dragGhost.style.top = `${e.clientY + 14}px`;

          const folderRect = folder.getBoundingClientRect();
          const isOver =
            e.clientX >= folderRect.left &&
            e.clientX <= folderRect.right &&
            e.clientY >= folderRect.top &&
            e.clientY <= folderRect.bottom;

          if (isOver) {
            folder.style.background = 'rgba(99, 102, 241, 0.35)';
            folder.style.transform = 'scale(1.08)';
          } else {
            folder.style.background = 'rgba(99, 102, 241, 0.1)';
            folder.style.transform = 'scale(1.0)';
          }
        }

        if (isDraggingLasso) {
          const dRect = desktop.getBoundingClientRect();
          const curX = e.clientX - dRect.left;
          const curY = e.clientY - dRect.top;
          const r = MM2.Ateliers.helpers.rectFromPoints(startX, startY, curX, curY);

          lasso.style.left = `${r.left}px`;
          lasso.style.top = `${r.top}px`;
          lasso.style.width = `${r.width}px`;
          lasso.style.height = `${r.height}px`;
          lasso.style.display = 'block';

          // Select ALL files that intersect with the lasso
          files.forEach((file) => {
            const el = fileElements.get(file.id);
            if (el) {
              const eRect = el.getBoundingClientRect();
              const relRect = {
                left: eRect.left - dRect.left,
                top: eRect.top - dRect.top,
                right: eRect.right - dRect.left,
                bottom: eRect.bottom - dRect.top,
              };
              if (MM2.Ateliers.helpers.rectsIntersect(r, relRect)) {
                selectedFiles.add(file.id);
                el.classList.add('is-selected');
              } else if (!ctrlAddedFiles.has(file.id)) {
                selectedFiles.delete(file.id);
                el.classList.remove('is-selected');
              }
            }
          });
        }

        if (isResizing) {
          const delta = {
            x: Math.round(e.clientX - startMouseX),
            y: Math.round(e.clientY - startMouseY),
          };
          const next = MM2.Ateliers.helpers.a4.resizeRect(startRect, delta, activeHandle, {
            minWidth: 200,
            minHeight: 150,
            grid: 1,
          });

          rect.left = Math.round(next.left);
          rect.top = Math.round(next.top);
          rect.width = Math.round(next.width);
          rect.height = Math.round(next.height);

          docWin.style.left = `${rect.left}px`;
          docWin.style.top = `${rect.top}px`;
          docWin.style.width = `${rect.width}px`;
          docWin.style.height = `${rect.height}px`;

          if (winDimDisplay) {
            winDimDisplay.textContent = `${rect.width} × ${rect.height} px`;
          }

          const isMatch =
            Math.abs(rect.width - resizeTarget.targetWidth) <= resizeTarget.tolerance &&
            Math.abs(rect.height - resizeTarget.targetHeight) <= resizeTarget.tolerance;

          if (isMatch) {
            docWin.classList.add('is-target-size');
            if (!objectives.resize) {
              objectives.resize = true;
              api.feedback(
                'Objectif 4 validé : fenêtre redimensionnée aux dimensions cibles (480 × 360 px) !',
                'success',
                '✨',
              );
              updateChecklist();
            }
          } else {
            docWin.classList.remove('is-target-size');
          }
        }
      };

      const onWindowPointerUp = (e) => {
        if (isDraggingFiles) {
          isDraggingFiles = false;
          if (dragGhost) {
            dragGhost.remove();
            dragGhost = null;
          }
          folder.style.transform = 'scale(1.0)';
          const folderRect = folder.getBoundingClientRect();
          const isOver =
            e.clientX >= folderRect.left &&
            e.clientX <= folderRect.right &&
            e.clientY >= folderRect.top &&
            e.clientY <= folderRect.bottom;

          if (isOver) {
            handleDropOnFolder();
          }
        }

        if (isDraggingLasso) {
          isDraggingLasso = false;
          lasso.style.display = 'none';
          api.attempt();

          const selectedList = Array.from(selectedFiles);
          const hasAllLasso = lassoRequired.every((id) => selectedFiles.has(id));
          const onlyLassoFiles = selectedList.every(
            (id) => lassoRequired.includes(id) || ctrlAddedFiles.has(id),
          );

          if (hasAllLasso && onlyLassoFiles && !objectives.lasso) {
            objectives.lasso = true;
            api.feedback('Objectif 1 validé : les 3 cours sont sélectionnés au lasso !', 'success', '🎉');
            updateChecklist();
          } else if (hasAllLasso && !onlyLassoFiles) {
            api.feedback(
              'Attention : le lasso a capturé des fichiers en trop. Englobe uniquement les 3 cours du haut !',
              'info',
              '💡',
            );
          }
        }

        if (isResizing) {
          isResizing = false;
          api.attempt();
        }
      };

      if (typeof window !== 'undefined' && typeof window.addEventListener === 'function') {
        window.addEventListener('pointermove', onWindowPointerMove);
        window.addEventListener('pointerup', onWindowPointerUp);
      }

      desktop.appendChild(docWin);
      bossArea.appendChild(desktop);
      container.appendChild(bossArea);
      updateChecklist();

      return function cleanup() {
        if (typeof window !== 'undefined' && typeof window.removeEventListener === 'function') {
          window.removeEventListener('pointermove', onWindowPointerMove);
          window.removeEventListener('pointerup', onWindowPointerUp);
        }
        if (typeof document !== 'undefined') {
          document.removeEventListener('selectionchange', checkTextSelection);
        }
        if (dragGhost) {
          dragGhost.remove();
          dragGhost = null;
        }
        bossArea.remove();
      };
    },
  });
})(typeof window !== 'undefined' ? window : globalThis);
