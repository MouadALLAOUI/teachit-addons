(function (global) {
  'use strict';

  const MM2 = (global.MM2 = global.MM2 || {});
  MM2.Ateliers = MM2.Ateliers || new Map();

  MM2.Ateliers.set('atelier-4', {
    mount(container, api) {
      const _atelier = api.atelier || MM2.CONFIG.ateliers[3];
      const cfg = MM2.CONFIG.resize || {
        targetWidth: 640,
        targetHeight: 480,
        tolerance: 4,
        grid: 8,
        minWidth: 240,
        minHeight: 180,
      };

      const workspace = document.createElement('div');
      workspace.className = 'a4-workspace';
      workspace.style.position = 'relative';
      workspace.style.width = '100%';
      workspace.style.height = '100%';
      workspace.style.minHeight = '520px';
      workspace.style.overflow = 'hidden';

      const winEl = document.createElement('div');
      winEl.className = 'a4-window';
      winEl.style.position = 'absolute';
      winEl.style.left = '40px';
      winEl.style.top = '30px';
      winEl.style.width = '400px';
      winEl.style.height = '300px';

      winEl.innerHTML = `
        <div class="a4-win-header">
          <div class="a4-win-dots">
            <span class="dot dot-close"></span>
            <span class="dot dot-min"></span>
            <span class="dot dot-max"></span>
          </div>
          <span class="a4-win-title">Explorateur de fichiers — <strong id="a4DimDisplay">400 × 300 px</strong></span>
          <span class="a4-target-pill">Cible : ${cfg.targetWidth} × ${cfg.targetHeight} px</span>
        </div>
        <div class="a4-win-body">
          <p class="a4-hint">Attrape les bordures ou les coins pour étirer la fenêtre jusqu'à atteindre <strong>${cfg.targetWidth} × ${cfg.targetHeight} px</strong>.</p>
          <div class="a4-dimension-meter">
            <div class="dim-box">Largeur : <strong id="a4CurW">400</strong> px (cible: ${cfg.targetWidth})</div>
            <div class="dim-box">Hauteur : <strong id="a4CurH">300</strong> px (cible: ${cfg.targetHeight})</div>
          </div>
        </div>
      `;

      // Handles definition
      const handles = [
        { code: 'n', cursor: 'ns-resize', cls: 'handle-n' },
        { code: 's', cursor: 'ns-resize', cls: 'handle-s' },
        { code: 'e', cursor: 'ew-resize', cls: 'handle-e' },
        { code: 'w', cursor: 'ew-resize', cls: 'handle-w' },
        { code: 'nw', cursor: 'nwse-resize', cls: 'handle-nw' },
        { code: 'se', cursor: 'nwse-resize', cls: 'handle-se' },
        { code: 'ne', cursor: 'nesw-resize', cls: 'handle-ne' },
        { code: 'sw', cursor: 'nesw-resize', cls: 'handle-sw' },
      ];

      let rect = {
        left: 40,
        top: 30,
        width: 400,
        height: 300,
      };

      const dimDisplay = winEl.querySelector('#a4DimDisplay');
      const curWEl = winEl.querySelector('#a4CurW');
      const curHEl = winEl.querySelector('#a4CurH');

      function updateWinStyles() {
        winEl.style.left = `${rect.left}px`;
        winEl.style.top = `${rect.top}px`;
        winEl.style.width = `${rect.width}px`;
        winEl.style.height = `${rect.height}px`;

        if (dimDisplay) dimDisplay.textContent = `${rect.width} × ${rect.height} px`;
        if (curWEl) curWEl.textContent = String(rect.width);
        if (curHEl) curHEl.textContent = String(rect.height);

        const isMatch = MM2.Ateliers.helpers.a4.isTargetSize(
          rect.width,
          rect.height,
          { width: cfg.targetWidth, height: cfg.targetHeight },
          cfg.tolerance,
        );

        if (isMatch) {
          winEl.classList.add('is-target-size');
        } else {
          winEl.classList.remove('is-target-size');
        }

        api.status(`Dimensions actuelles : ${rect.width} × ${rect.height} px`);
      }

      let activeHandle = null;
      let startPointerX = 0;
      let startPointerY = 0;
      let startRect = null;

      const onPointerMove = (e) => {
        if (!activeHandle || !startRect) return;
        const dx = e.clientX - startPointerX;
        const dy = e.clientY - startPointerY;

        rect = MM2.Ateliers.helpers.a4.resizeRect(
          startRect,
          { x: dx, y: dy },
          activeHandle,
          cfg,
        );
        updateWinStyles();
      };

      const onPointerUp = () => {
        if (!activeHandle) return;
        activeHandle = null;
        startRect = null;
        api.attempt();

        const target = { width: cfg.targetWidth, height: cfg.targetHeight };
        const isMatch = MM2.Ateliers.helpers.a4.isTargetSize(
          rect.width,
          rect.height,
          target,
          cfg.tolerance,
        );

        if (isMatch) {
          const precision = MM2.Ateliers.helpers.a4.precisionForSize(
            rect.width,
            rect.height,
            target,
            cfg.tolerance,
          );
          api.feedback(
            `Dimensions cibles atteintes avec succès : ${rect.width} × ${rect.height} px !`,
            'success',
            '🎉',
          );
          setTimeout(() => {
            api.finish({ precision });
          }, 800);
        } else {
          const diffW = rect.width - cfg.targetWidth;
          const diffH = rect.height - cfg.targetHeight;
          api.feedback(
            `Encore un effort ! Largeur : ${diffW > 0 ? '+' : ''}${diffW} px, Hauteur : ${diffH > 0 ? '+' : ''}${diffH} px.`,
            'info',
            '📏',
          );
        }
      };

      handles.forEach((h) => {
        const hEl = document.createElement('div');
        hEl.className = `a4-handle ${h.cls}`;
        hEl.style.cursor = h.cursor;
        hEl.setAttribute('data-handle', h.code);

        hEl.addEventListener('pointerdown', (e) => {
          e.preventDefault();
          e.stopPropagation();
          activeHandle = h.code;
          startPointerX = e.clientX;
          startPointerY = e.clientY;
          startRect = { ...rect };
        });

        winEl.appendChild(hEl);
      });

      workspace.appendChild(winEl);
      container.appendChild(workspace);

      if (typeof window !== 'undefined' && typeof window.addEventListener === 'function') {
        window.addEventListener('pointermove', onPointerMove);
        window.addEventListener('pointerup', onPointerUp);
      }

      updateWinStyles();

      return function cleanup() {
        if (typeof window !== 'undefined' && typeof window.removeEventListener === 'function') {
          window.removeEventListener('pointermove', onPointerMove);
          window.removeEventListener('pointerup', onPointerUp);
        }
        workspace.remove();
      };
    },
  });
})(typeof window !== 'undefined' ? window : globalThis);
