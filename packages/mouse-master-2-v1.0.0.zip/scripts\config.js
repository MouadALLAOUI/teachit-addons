(function (global) {
  'use strict';

  const MM2 = (global.MM2 = global.MM2 || {});

  const RESIZE_CONFIG = {
    targetWidth: 640,
    targetHeight: 480,
    tolerance: 4,
    grid: 8,
    minWidth: 240,
    minHeight: 180,
  };

  const ATELIER_1_TARGETS = [
    // 12 correct (green) targets of varying sizes (40, 60, 80)
    { id: 't1', correct: true, size: 80, x: 20, y: 25, label: 'Cible A' },
    { id: 't2', correct: true, size: 60, x: 50, y: 20, label: 'Cible B' },
    { id: 't3', correct: true, size: 40, x: 75, y: 30, label: 'Cible C' },
    { id: 't4', correct: true, size: 60, x: 85, y: 60, label: 'Cible D' },
    { id: 't5', correct: true, size: 80, x: 60, y: 75, label: 'Cible E' },
    { id: 't6', correct: true, size: 40, x: 30, y: 80, label: 'Cible F' },
    { id: 't7', correct: true, size: 60, x: 15, y: 55, label: 'Cible G' },
    { id: 't8', correct: true, size: 80, x: 40, y: 45, label: 'Cible H' },
    { id: 't9', correct: true, size: 40, x: 65, y: 50, label: 'Cible I' },
    { id: 't10', correct: true, size: 60, x: 35, y: 20, label: 'Cible J' },
    { id: 't11', correct: true, size: 80, x: 80, y: 15, label: 'Cible K' },
    { id: 't12', correct: true, size: 40, x: 50, y: 85, label: 'Cible L' },
    // 4 wrong (red) targets
    { id: 't13', correct: false, size: 60, x: 25, y: 40, label: 'Piège 1' },
    { id: 't14', correct: false, size: 80, x: 70, y: 70, label: 'Piège 2' },
    { id: 't15', correct: false, size: 40, x: 45, y: 60, label: 'Piège 3' },
    { id: 't16', correct: false, size: 60, x: 85, y: 40, label: 'Piège 4' },
  ];

  const ATELIER_2_FILES = [
    { id: 'notes', name: 'Notes_SVT.docx', icon: '📄', required: true, rect: { left: 40, top: 40, right: 140, bottom: 140 } },
    { id: 'projet', name: 'Projet_Robot.pdf', icon: '📑', required: true, rect: { left: 160, top: 40, right: 260, bottom: 140 } },
    { id: 'schema', name: 'Schema_Circuit.png', icon: '🖼️', required: true, rect: { left: 40, top: 160, right: 140, bottom: 260 } },
    { id: 'devoir', name: 'Devoir_Maths.xlsx', icon: '📊', required: true, rect: { left: 160, top: 160, right: 260, bottom: 260 } },
    { id: 'photo', name: 'Vacances.jpg', icon: '🖼️', required: false, rect: { left: 320, top: 40, right: 420, bottom: 140 } },
    { id: 'musique', name: 'Piste_Audio.mp3', icon: '🎵', required: false, rect: { left: 440, top: 40, right: 540, bottom: 140 } },
    { id: 'film', name: 'Clip_Video.mp4', icon: '🎬', required: false, rect: { left: 320, top: 160, right: 420, bottom: 260 } },
    { id: 'jeu', name: 'Jeu_Retro.exe', icon: '🎮', required: false, rect: { left: 440, top: 160, right: 540, bottom: 260 } },
    { id: 'code', name: 'Programme.py', icon: '💻', required: false, rect: { left: 40, top: 280, right: 140, bottom: 380 } },
    { id: 'web', name: 'Index.html', icon: '🌐', required: false, rect: { left: 160, top: 280, right: 260, bottom: 380 } },
    { id: 'config', name: 'Settings.json', icon: '⚙️', required: false, rect: { left: 320, top: 280, right: 420, bottom: 380 } },
    { id: 'archive', name: 'Sauvegarde.zip', icon: '📦', required: false, rect: { left: 440, top: 280, right: 540, bottom: 380 } },
  ];

  const ATELIER_3_FILES = [
    { id: 'f01', name: '01_Introduction.pdf', icon: '📄', size: '15 Ko', date: '01/09' },
    { id: 'f02', name: '02_Architecture_PC.docx', icon: '📝', size: '42 Ko', date: '03/09' },
    { id: 'f03', name: '03_Composants_Carte.png', icon: '🖼️', size: '320 Ko', date: '05/09' },
    { id: 'f04', name: '04_Memoire_RAM.pdf', icon: '📄', size: '28 Ko', date: '08/09' },
    { id: 'f05', name: '05_Processeur_CPU.docx', icon: '📝', size: '55 Ko', date: '10/09' },
    { id: 'f06', name: '06_Disque_SSD.xlsx', icon: '📊', size: '18 Ko', date: '12/09' },
    { id: 'f07', name: '07_Systeme_Exploitation.pdf', icon: '📄', size: '84 Ko', date: '15/09' },
    { id: 'f08', name: '08_Fichiers_Dossiers.docx', icon: '📝', size: '36 Ko', date: '17/09' },
    { id: 'f09', name: '09_Reseau_Local.png', icon: '🖼️', size: '210 Ko', date: '20/09' },
    { id: 'f10', name: '10_Securite_MDP.pdf', icon: '📄', size: '40 Ko', date: '22/09' },
    { id: 'f11', name: '11_Algorithmique.py', icon: '💻', size: '8 Ko', date: '25/09' },
    { id: 'f12', name: '12_Projet_Final.zip', icon: '📦', size: '1.2 Mo', date: '30/09' },
  ];

  const ATELIER_5_LINES = [
    'Chapitre 1 : Les périphériques informatiques',
    'La souris est un composant essentiel de l’ordinateur.',
    'Elle permet de désigner des éléments graphiques à l’écran.',
    'Inventée par Douglas Engelbart dans les années 1960.',
    'Le curseur reproduit fidèlement les mouvements de la main.',
    'La résolution se mesure en points par pouce (DPI).',
    'Un capteur optique ou laser détecte les déplacements.',
    'Les boutons permettent d’émettre des signaux de clic.',
    'Le clic gauche active ou sélectionne un élément.',
    'Le clic droit déclenche le menu d’actions contextuel.',
    'La molette de défilement (scroll wheel) est apparue plus tard.',
    'Ligne 12 : Elle évite de devoir glisser la barre d’ascenseur manuellement.',
    'Chaque cran de molette correspond à quelques lignes de texte.',
    'Certaines souris proposent un défilement libre ou horizontal.',
    'La combinaison Ctrl + Molette modifie le niveau de zoom.',
    'Vers le haut, le zoom s’agrandit pour rendre les détails lisibles.',
    'Vers le bas, le zoom rétrécit pour avoir une vue d’ensemble.',
    'C’est un raccourci standard dans tous les navigateurs et logiciels.',
    'L’ascenseur vertical indique la position relative dans le document.',
    'Plus le document est long, plus le curseur d’ascenseur est petit.',
    'Ligne 21 : Cible secrète à observer attentivement !',
    'L’ergonomie de la souris prévient les troubles musculo-squelettiques.',
    'Il est conseillé de reposer l’avant-bras sur le bureau.',
    'Le poignet doit rester dans l’axe naturel de l’avant-bras.',
    'Le tapis de souris offre une surface régulière au capteur.',
    'Les souris pour gauchers inversent parfois les boutons logiques.',
    'La vitesse du double-clic se règle dans le panneau de configuration.',
    'Le pointeur s’adapte dynamiquement au contexte graphique.',
    'Il devient une flèche pour viser et cliquer sur les fenêtres.',
    'Il devient un curseur en forme de I (I-beam) au-dessus du texte.',
    'Il devient une double flèche sur les bordures redimensionnables.',
    'Il devient une main avec un index levé sur les liens hypertextes.',
    'Fin du document de révision — Bravo pour ta lecture !',
  ];

  const ATELIER_6_LINES = [
    'La souris d’ordinateur est un périphérique d’entrée essentiel.',
    'Un double-clic rapide permet de sélectionner un mot entier sans déborder.',
    'Un triple-clic sélectionne toute la ligne.',
    'Le curseur prend l’apparence d’une poutre en I au-dessus d’une zone textuelle.',
    'Il est possible d’étendre une sélection avec la touche Majuscule.',
  ];

  const ATELIER_6_TASKS = [
    {
      mode: 'sentence',
      lineIndex: 0,
      expected: 'La souris d’ordinateur est un périphérique d’entrée essentiel.',
      instruction: 'Sélectionne toute la première phrase en maintenant le clic gauche enfoncé et en glissant.',
    },
    {
      mode: 'word',
      lineIndex: 1,
      expected: 'sélectionner',
      instruction: 'Double-clique directement sur le mot « sélectionner » pour le capturer en un seul geste.',
    },
    {
      mode: 'line',
      lineIndex: 2,
      expected: 'Un triple-clic sélectionne toute la ligne.',
      instruction: 'Effectue un triple-clic rapide sur la troisième ligne pour sélectionner l’ensemble de la ligne.',
    },
  ];

  const BOSS_FILES = [
    { id: 'b_doc1', name: 'Cours_Intro.pdf', icon: '📄', requiredForLasso: true },
    { id: 'b_doc2', name: 'Exercices.docx', icon: '📝', requiredForLasso: true },
    { id: 'b_doc3', name: 'Schema_Reseau.png', icon: '🖼️', requiredForLasso: true },
    { id: 'b_doc4', name: 'Annexe_Extra.txt', icon: '📄', requiredForLasso: false },
    { id: 'b_doc5', name: 'Archive_Code.zip', icon: '📦', requiredForLasso: false },
    { id: 'b_doc6', name: 'Notes_Perso.docx', icon: '📝', requiredForLasso: false },
    { id: 'b_doc7', name: 'Musique_Fond.mp3', icon: '🎵', requiredForLasso: false },
    { id: 'b_doc8', name: 'Video_Demo.mp4', icon: '🎬', requiredForLasso: false },
    { id: 'b_doc9', name: 'Rapport_Final.pdf', icon: '📑', requiredForLasso: false },
  ];

  const BOSS_DOC_LINES = [
    'Mission Bureau — Station de travail TeachIT',
    'Bienvenue dans l’épreuve finale d’intégration bureautique.',
    'Chaque geste appris dans les ateliers précédents doit être appliqué.',
    'Rappel des compétences fondamentales requises sur le poste de travail :',
    '1. Sélection rectangulaire (lasso) pour regrouper plusieurs fichiers d’un coup.',
    '2. Touche Ctrl (Contrôle) pour ajouter ou soustraire un fichier de façon isolée.',
    '3. Glisser-déposer vers un dossier de destination pour classer les documents.',
    '4. Redimensionnement de fenêtre aux dimensions exactes par les bordures.',
    '5. Navigation fluide au sein d’un document long à l’aide de la molette.',
    '6. Sélection précise de fragments de texte avec le curseur en forme de I.',
    'Organisation du système de fichiers :',
    'Le bureau informatique reproduit l’organisation d’un véritable bureau physique.',
    'Les fichiers représentent des documents ou des outils de travail.',
    'Les répertoires (dossiers) permettent de structurer et d’archiver les projets.',
    'Une bonne gestion des fichiers évite l’encombrement de l’écran.',
    'Astuce : La molette de la souris permet de parcourir ce document sans déplacer l’ascenseur.',
    'Fais défiler la page encore plus bas pour découvrir la consigne secrète finale...',
    'Consigne de validation secrète :',
    'Ligne secrète : La maîtrise de la souris garantit une efficacité maximale.',
    'Pour achever la mission, sélectionne attentivement la ligne secrète ci-dessus.',
    'Félicitations pour ton professionnalisme et ta dextérité remarquable !',
  ];

  const CONFIG = {
    maxScore: 700,
    resize: RESIZE_CONFIG,
    ateliers: [
      {
        number: 1,
        id: 'atelier-1',
        title: 'Viser vite et juste',
        concept: 'La loi de Fitts',
        objective: 'Comprendre comment la taille et la distance d’une cible influencent la précision et le temps de réaction.',
        explanation: 'Plus une cible est petite ou éloignée, plus elle est difficile à atteindre avec précision.',
        targetMs: 8000,
        data: {
          targets: ATELIER_1_TARGETS,
          targetCount: 12,
        },
      },
      {
        number: 2,
        id: 'atelier-2',
        title: 'Le lasso',
        concept: 'Sélection rectangulaire',
        objective: 'Maîtriser la sélection rectangulaire par glisser-déposer pour sélectionner un groupe de fichiers précis.',
        explanation: 'Le rectangle de sélection permet d’englober rapidement plusieurs éléments situés dans une même zone.',
        targetMs: 12000,
        data: {
          files: ATELIER_2_FILES,
          requiredCount: 4,
          requiredIds: ['notes', 'projet', 'schema', 'devoir'],
        },
      },
      {
        number: 3,
        id: 'atelier-3',
        title: 'Multi-sélection',
        concept: 'Touches Ctrl et Shift',
        objective: 'Apprendre à combiner Ctrl+clic pour des éléments séparés et Shift+clic pour des plages continues de fichiers.',
        explanation: 'Shift+clic sélectionne toute la série entre deux éléments ; Ctrl+clic ajoute ou retire un élément précis.',
        targetMs: 15000,
        data: {
          files: ATELIER_3_FILES,
          order: ATELIER_3_FILES.map((f) => f.id),
          targetSelection: ['f02', 'f03', 'f04', 'f08'],
        },
      },
      {
        number: 4,
        id: 'atelier-4',
        title: 'Redimensionner',
        concept: 'Curseurs et dimensions de fenêtre',
        objective: 'Ajuster précisément la taille d’une fenêtre simulée à 640 × 480 pixels en observant les changements de curseur.',
        explanation: 'La forme du curseur indique le type d’action que tu peux effectuer : étirement horizontal, vertical ou diagonal.',
        targetMs: 12000,
        data: RESIZE_CONFIG,
      },
      {
        number: 5,
        id: 'atelier-5',
        title: 'La molette',
        concept: 'Défilement vertical et zoom Ctrl+molette',
        objective: 'Parcourir un document long avec la molette puis ajuster l’affichage à 150% grâce au zoom Ctrl+molette.',
        explanation: 'La molette permet de parcourir un document sans déplacer la barre de défilement manuellement.',
        targetMs: 12000,
        data: {
          lines: ATELIER_5_LINES,
          targetText: 'Ligne 21 : Cible secrète à observer attentivement !',
          zoomTarget: 1.5,
        },
      },
      {
        number: 6,
        id: 'atelier-6',
        title: 'Sélection de texte',
        concept: 'Curseur en I et clics successifs',
        objective: 'Sélectionner du texte avec le curseur en I : glisser pour une phrase, double-clic pour un mot, triple-clic pour une ligne.',
        explanation: 'Le curseur en forme de I permet de sélectionner du texte avec une grande précision.',
        targetMs: 15000,
        data: {
          lines: ATELIER_6_LINES,
          tasks: ATELIER_6_TASKS,
        },
      },
      {
        number: 7,
        id: 'boss',
        title: 'Mission Bureau',
        concept: 'Intégration réaliste sur poste de travail',
        objective: 'Enchaîner lasso, Ctrl+clic, glisser-déposer vers un dossier, redimensionnement de fenêtre, défilement et sélection de texte.',
        explanation: 'En combinant tous les gestes fondamentaux de la souris, tu maîtrises parfaitement ton environnement informatique.',
        targetMs: 30000,
        data: {
          files: BOSS_FILES,
          lassoRequired: ['b_doc1', 'b_doc2', 'b_doc3'],
          ctrlAdd: 'b_doc4',
          dropFolder: 'Cours',
          docLines: BOSS_DOC_LINES,
          docTargetText: 'Ligne secrète : La maîtrise de la souris garantit une efficacité maximale.',
          textTarget: 'Ligne secrète : La maîtrise de la souris garantit une efficacité maximale.',
          resize: {
            targetWidth: 480,
            targetHeight: 360,
            tolerance: 4,
            grid: 8,
          },
        },
      },
    ],
  };

  MM2.CONFIG = CONFIG;
})(typeof window !== 'undefined' ? window : globalThis);
