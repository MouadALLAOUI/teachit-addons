(function (global) {
  'use strict';

  const MM2 = (global.MM2 = global.MM2 || {});

  async function initSession() {
    const teachit = MM2.Telemetry.getTeachit();
    if (!teachit || typeof teachit.getSessionInfo !== 'function') return;

    try {
      const info = await teachit.getSessionInfo();
      if (info && info.studentId) {
        const studentBadge = document.getElementById('sessionStudentBadge');
        if (studentBadge) {
          studentBadge.style.display = 'inline-flex';
          studentBadge.textContent = 'Élève';
        }
      }
    } catch {
      // Standalone mode fallback
    }
  }

  function start() {
    if (typeof document === 'undefined') return;

    if (!MM2.engine) {
      MM2.engine = MM2.createEngine(MM2.CONFIG);
    }
    if (MM2.UI) {
      MM2.UI.init(MM2.engine);
    }
    initSession();
  }

  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', start);
    } else {
      start();
    }
  }

  MM2.start = start;
})(typeof window !== 'undefined' ? window : globalThis);
