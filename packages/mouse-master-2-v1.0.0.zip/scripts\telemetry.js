(function (global) {
  'use strict';

  const MM2 = (global.MM2 = global.MM2 || {});

  function getTeachit() {
    if (typeof window !== 'undefined' && window.teachit) {
      return window.teachit;
    }
    if (typeof global !== 'undefined' && global.teachit) {
      return global.teachit;
    }
    return null;
  }

  async function reportStarted(engine) {
    if (!engine || !engine.started) return;
    if (engine.startedReported) return;
    engine.startedReported = true;

    const teachit = getTeachit();
    if (!teachit || typeof teachit.reportProgress !== 'function') return;

    try {
      await teachit.reportProgress({
        activityId: 'mouse-master-2-complete',
        eventType: 'activity_started',
        payload: {
          score: 0,
          maxScore: 700,
          durationSeconds: 0,
          success: false,
          metrics: engine.getMetrics(),
        },
      });
    } catch {
      // offline / standalone mode fallback
    }
  }

  async function reportCompleted(engine) {
    if (!engine || !engine.started) return;
    if (engine.sessionReported) return;
    engine.sessionReported = true;

    const teachit = getTeachit();
    if (!teachit || typeof teachit.reportProgress !== 'function') return;

    try {
      await teachit.reportProgress({
        activityId: 'mouse-master-2-complete',
        eventType: 'activity_completed',
        payload: {
          score: engine.getScore(),
          maxScore: 700,
          durationSeconds: engine.getDurationSeconds(),
          success: true,
          metrics: engine.getMetrics(),
        },
      });
    } catch {
      // offline / standalone mode fallback
    }
  }

  async function reportAbandoned(engine) {
    if (!engine || !engine.started) return;
    if (engine.isComplete()) return;
    if (engine.sessionReported) return;
    engine.sessionReported = true;

    const teachit = getTeachit();
    if (!teachit || typeof teachit.reportProgress !== 'function') return;

    try {
      await teachit.reportProgress({
        activityId: 'mouse-master-2-complete',
        eventType: 'score_recorded',
        payload: {
          score: engine.getScore(),
          maxScore: 700,
          durationSeconds: engine.getDurationSeconds(),
          success: false,
          metrics: engine.getMetrics(),
        },
      });
    } catch {
      // offline / standalone mode fallback
    }
  }

  async function finalize(engine) {
    if (!engine) return;
    if (engine.isComplete()) {
      return reportCompleted(engine);
    } else {
      return reportAbandoned(engine);
    }
  }

  function exitGame(engine) {
    finalize(engine);
    const teachit = getTeachit();
    if (teachit && typeof teachit.exitGame === 'function') {
      try {
        teachit.exitGame();
      } catch {
        if (typeof window !== 'undefined' && typeof window.close === 'function') {
          window.close();
        }
      }
    } else if (typeof window !== 'undefined' && typeof window.close === 'function') {
      window.close();
    }
  }

  MM2.Telemetry = {
    getTeachit,
    reportStarted,
    reportCompleted,
    reportAbandoned,
    finalize,
    exitGame,
  };
})(typeof window !== 'undefined' ? window : globalThis);
