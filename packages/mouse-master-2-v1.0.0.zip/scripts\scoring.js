(function (global) {
  'use strict';

  const MM2 = (global.MM2 = global.MM2 || {});

  const MAX_TOTAL_SCORE = 700;
  const ATELIER_MAX_SCORE = 100;
  const COMPLETION_MAX_POINTS = 40;
  const PRECISION_MAX_POINTS = 40;
  const SPEED_MAX_POINTS = 20;

  function maxTotal() {
    return MAX_TOTAL_SCORE;
  }

  function speedPoints(elapsedMs, targetMs) {
    if (typeof elapsedMs !== 'number' || Number.isNaN(elapsedMs)) return 0;
    if (typeof targetMs !== 'number' || targetMs <= 0) return 0;

    if (elapsedMs <= targetMs) {
      return SPEED_MAX_POINTS;
    }
    if (elapsedMs >= 3 * targetMs) {
      return 0;
    }

    const ratio = (3 * targetMs - elapsedMs) / (2 * targetMs);
    return Math.max(0, Math.min(SPEED_MAX_POINTS, Math.round(ratio * SPEED_MAX_POINTS)));
  }

  function breakdown(options) {
    const opts = options || {};
    if (!opts.completed) {
      return { completion: 0, precision: 0, speed: 0, total: 0 };
    }

    const completion = COMPLETION_MAX_POINTS;

    let p = opts.precision;
    if (typeof p !== 'number' || Number.isNaN(p)) {
      p = 0;
    }
    const clampedPrecision = Math.min(1, Math.max(0, p));
    const precision = Math.round(clampedPrecision * PRECISION_MAX_POINTS);

    const speed = speedPoints(opts.elapsedMs, opts.targetMs);

    const total = Math.min(ATELIER_MAX_SCORE, Math.max(0, completion + precision + speed));

    return {
      completion,
      precision,
      speed,
      total,
    };
  }

  function stars(options) {
    const opts = options || {};
    if (!opts.completed) return 0;

    const p = typeof opts.precision === 'number' && !Number.isNaN(opts.precision) ? opts.precision : 0;
    if (p >= 0.9) return 3;
    if (p >= 0.75) return 2;
    return 1;
  }

  MM2.Scoring = {
    maxTotal,
    speedPoints,
    breakdown,
    stars,
    MAX_TOTAL_SCORE,
    ATELIER_MAX_SCORE,
  };
})(typeof window !== 'undefined' ? window : globalThis);
