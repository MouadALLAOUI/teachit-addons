(function (global) {
  'use strict';

  const MM2 = (global.MM2 = global.MM2 || {});
  MM2.Ateliers = MM2.Ateliers || new Map();

  MM2.Ateliers.set('atelier-2', {
    mount(container, api) {
      const atelier = api.atelier || MM2.CONFIG.ateliers[1];
      const data = atelier.data || {};
      const files = data.files || [];
      const requiredIds = data.requiredIds || files.filter((f) => f.required).map((f) => f.id);

      const desktop = document.createElement('div');
      desktop.className = 'a2-desktop';
      desktop.style.position = 'relative';
      desktop.style.width = '100%';
      desktop.style.height = '100%';
      desktop.style.minHeight = '420px';
      desktop.style.userSelect = 'none';

      const lasso = document.createElement('div');
      lasso.className = 'a2-lasso';
      lasso.style.position = 'absolute';
      lasso.style.display = 'none';
      lasso.style.pointerEvents = 'none';
      desktop.appendChild(lasso);

      const fileElements = new Map();
      files.forEach((file) => {
        const fileDiv = document.createElement('div');
        fileDiv.className = `a2-file ${file.required ? 'is-required' : ''}`;
        fileDiv.id = `file-${file.id}`;
        fileDiv.style.position = 'absolute';
        fileDiv.style.left = `${file.rect.left}px`;
        fileDiv.style.top = `${file.rect.top}px`;
        fileDiv.style.width = `${file.rect.right - file.rect.left}px`;
        fileDiv.style.height = `${file.rect.bottom - file.rect.top}px`;

        fileDiv.innerHTML = `
          <div class="file-icon" aria-hidden="true">${file.icon || '📄'}</div>
          <div class="file-name">${file.name}</div>
          ${file.required ? '<span class="file-badge" title="Fichier à sélectionner">Requis</span>' : ''}
        `;
        desktop.appendChild(fileDiv);
        fileElements.set(file.id, fileDiv);
      });

      let isDragging = false;
      let startX = 0;
      let startY = 0;
      let currentSelected = [];

      function updateLasso(x1, y1, x2, y2) {
        const rect = MM2.Ateliers.helpers.rectFromPoints(x1, y1, x2, y2);
        lasso.style.left = `${rect.left}px`;
        lasso.style.top = `${rect.top}px`;
        lasso.style.width = `${rect.width}px`;
        lasso.style.height = `${rect.height}px`;
        lasso.style.display = 'block';

        currentSelected = MM2.Ateliers.helpers.a2.selectByRect(rect, files);
        files.forEach((f) => {
          const el = fileElements.get(f.id);
          if (el) {
            if (currentSelected.includes(f.id)) {
              el.classList.add('is-selected');
            } else {
              el.classList.remove('is-selected');
            }
          }
        });

        api.status(`${currentSelected.length} élément(s) dans le lasso`);
      }

      const onPointerDown = (e) => {
        if (e.button !== 0) return;
        isDragging = true;
        const rect = desktop.getBoundingClientRect();
        startX = e.clientX - rect.left;
        startY = e.clientY - rect.top;
        updateLasso(startX, startY, startX, startY);
      };

      const onPointerMove = (e) => {
        if (!isDragging) return;
        const rect = desktop.getBoundingClientRect();
        const curX = e.clientX - rect.left;
        const curY = e.clientY - rect.top;
        updateLasso(startX, startY, curX, curY);
      };

      const onPointerUp = () => {
        if (!isDragging) return;
        isDragging = false;
        api.attempt();

        const evaluation = MM2.Ateliers.helpers.a2.evaluateSelection(currentSelected, requiredIds);

        if (evaluation.exact) {
          api.feedback('Sélection parfaite ! Les 4 fichiers requis sont capturés.', 'success', '🎉');
          api.finish({ precision: 1 });
        } else {
          if (evaluation.missing.length > 0 && evaluation.extra.length > 0) {
            api.feedback(
              `Il manque ${evaluation.missing.length} fichier(s) et tu as sélectionné ${evaluation.extra.length} intrus. Réessaie en ajustant ton lasso !`,
              'error',
              '⚠️',
            );
          } else if (evaluation.missing.length > 0) {
            api.feedback(
              `Il te manque ${evaluation.missing.length} fichier(s) requis. Trace un lasso plus large pour les englober !`,
              'info',
              '💡',
            );
          } else if (evaluation.extra.length > 0) {
            api.feedback(
              `Tu as sélectionné ${evaluation.extra.length} fichier(s) en trop. Évite d'englober les intrus !`,
              'error',
              '⚠️',
            );
          }
        }
      };

      desktop.addEventListener('pointerdown', onPointerDown);
      if (typeof window !== 'undefined' && typeof window.addEventListener === 'function') {
        window.addEventListener('pointermove', onPointerMove);
        window.addEventListener('pointerup', onPointerUp);
      }

      container.appendChild(desktop);
      api.status('Clique et glisse pour tracer un rectangle de sélection (lasso)');

      return function cleanup() {
        desktop.removeEventListener('pointerdown', onPointerDown);
        if (typeof window !== 'undefined' && typeof window.removeEventListener === 'function') {
          window.removeEventListener('pointermove', onPointerMove);
          window.removeEventListener('pointerup', onPointerUp);
        }
        desktop.remove();
      };
    },
  });
})(typeof window !== 'undefined' ? window : globalThis);
