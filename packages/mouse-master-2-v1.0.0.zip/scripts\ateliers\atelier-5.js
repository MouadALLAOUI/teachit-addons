(function (global) {
  'use strict';

  const MM2 = (global.MM2 = global.MM2 || {});
  MM2.Ateliers = MM2.Ateliers || new Map();

  MM2.Ateliers.set('atelier-5', {
    mount(container, api) {
      const atelier = api.atelier || MM2.CONFIG.ateliers[4];
      const data = atelier.data || {};
      const lines = data.lines || [];
      const targetText = data.targetText || 'Ligne 21 : Cible secrète à observer attentivement !';
      const zoomTarget = data.zoomTarget || 1.5;

      const wrapper = document.createElement('div');
      wrapper.className = 'a5-wrapper';

      const hud = document.createElement('div');
      hud.className = 'a5-hud';
      hud.innerHTML = `
        <div class="a5-hud-pill">Niveau de zoom : <strong id="a5ZoomDisplay">100%</strong> (Cible : 150%)</div>
        <div class="a5-hud-pill">Position : <strong id="a5StatusDisplay">Cherche la cible...</strong></div>
      `;
      wrapper.appendChild(hud);

      const viewport = document.createElement('div');
      viewport.className = 'a5-viewport';
      viewport.style.position = 'relative';
      viewport.style.overflowY = 'auto';
      viewport.style.height = '380px';
      viewport.style.border = '1px solid var(--color-border-subtle, #334155)';
      viewport.style.borderRadius = '8px';
      viewport.style.background = 'var(--color-bg-surface, #0f172a)';

      const docContent = document.createElement('div');
      docContent.className = 'a5-document';
      docContent.style.transformOrigin = 'top left';
      docContent.style.padding = '24px';
      docContent.style.transition = 'transform 0.1s ease-out';

      let targetEl = null;

      lines.forEach((lineText) => {
        const p = document.createElement('p');
        p.className = 'a5-line';
        p.textContent = lineText;
        p.style.margin = '14px 0';
        p.style.lineHeight = '1.6';

        if (lineText === targetText) {
          p.classList.add('is-target-line');
          p.style.padding = '8px 12px';
          p.style.borderRadius = '6px';
          p.style.background = 'rgba(56, 189, 248, 0.2)';
          p.style.border = '1px dashed #38bdf8';
          p.style.fontWeight = 'bold';
          targetEl = p;
        }

        docContent.appendChild(p);
      });

      viewport.appendChild(docContent);
      wrapper.appendChild(viewport);

      const btnValidate = document.createElement('button');
      btnValidate.type = 'button';
      btnValidate.className = 'btn btn-primary a5-btn-validate';
      btnValidate.style.marginTop = '12px';
      btnValidate.textContent = 'Valider le repérage et le zoom';
      wrapper.appendChild(btnValidate);

      let currentZoom = 1.0;
      const zoomDisplay = hud.querySelector('#a5ZoomDisplay');
      const statusDisplay = hud.querySelector('#a5StatusDisplay');

      function updateZoom(newZoom) {
        currentZoom = MM2.Ateliers.helpers.a5.clampZoom(newZoom, 0.8, 2.0);
        docContent.style.transform = `scale(${currentZoom})`;
        if (zoomDisplay) zoomDisplay.textContent = `${Math.round(currentZoom * 100)}%`;
      }

      function checkTargetPosition() {
        if (!targetEl) return { inView: false, overshootPx: 999 };
        const vRect = viewport.getBoundingClientRect();
        const tRect = targetEl.getBoundingClientRect();

        const vCenter = vRect.top + vRect.height / 2;
        const tCenter = tRect.top + tRect.height / 2;
        const overshootPx = Math.abs(tCenter - vCenter);

        const inView = tRect.top >= vRect.top - 20 && tRect.bottom <= vRect.bottom + 20;
        return { inView, overshootPx, vHeight: vRect.height };
      }

      const onWheel = (e) => {
        // Prevent default browser / Electron zoom
        e.preventDefault();
        api.attempt();

        if (e.ctrlKey) {
          // Zoom handling
          const delta = e.deltaY < 0 ? 0.1 : -0.1;
          updateZoom(currentZoom + delta);
        } else {
          // Internal document scroll
          viewport.scrollTop += e.deltaY;
        }

        const pos = checkTargetPosition();
        if (pos.inView) {
          if (statusDisplay) statusDisplay.textContent = '✓ Ligne cible visible !';
        } else {
          if (statusDisplay) statusDisplay.textContent = 'Fais défiler la page...';
        }

        api.status(`Zoom : ${Math.round(currentZoom * 100)}% — Position cible`);
      };

      btnValidate.addEventListener('click', () => {
        api.attempt();
        const pos = checkTargetPosition();
        const precision = MM2.Ateliers.helpers.a5.precisionFor({
          overshootPx: pos.overshootPx,
          zoom: currentZoom,
          zoomTarget,
          viewportHeight: pos.vHeight || 380,
        });

        if (pos.inView && Math.abs(currentZoom - zoomTarget) < 0.15) {
          api.feedback(
            `Parfait ! Défilement précis et zoom à 150% maîtrisé.`,
            'success',
            '🎉',
          );
          api.finish({
            precision,
            measurements: {
              overshootPx: Math.round(pos.overshootPx),
            },
          });
        } else if (!pos.inView) {
          api.feedback(
            `La ligne cible n'est pas encore visible ou centrée. Utilise la molette sans Ctrl pour faire défiler !`,
            'error',
            '⚠️',
          );
        } else {
          api.feedback(
            `La ligne est visible, mais le zoom est à ${Math.round(currentZoom * 100)}%. Utilise Ctrl+molette pour atteindre 150% !`,
            'info',
            '💡',
          );
        }
      });

      viewport.addEventListener('wheel', onWheel, { passive: false });
      container.appendChild(wrapper);
      api.status('Utilise la molette pour faire défiler, et Ctrl+molette pour zoomer');

      return function cleanup() {
        viewport.removeEventListener('wheel', onWheel);
        wrapper.remove();
      };
    },
  });
})(typeof window !== 'undefined' ? window : globalThis);
