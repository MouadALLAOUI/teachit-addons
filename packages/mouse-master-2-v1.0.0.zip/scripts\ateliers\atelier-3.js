(function (global) {
  'use strict';

  const MM2 = (global.MM2 = global.MM2 || {});
  MM2.Ateliers = MM2.Ateliers || new Map();

  MM2.Ateliers.set('atelier-3', {
    mount(container, api) {
      const atelier = api.atelier || MM2.CONFIG.ateliers[2];
      const data = atelier.data || {};
      const files = data.files || [];
      const order = data.order || files.map((f) => f.id);
      const targetSelection = data.targetSelection || ['f02', 'f03', 'f04', 'f08'];

      const wrapper = document.createElement('div');
      wrapper.className = 'a3-wrapper';

      const taskHeader = document.createElement('div');
      taskHeader.className = 'a3-task-header';
      taskHeader.innerHTML = `
        <div class="a3-instruction-badge">Mission multi-sélection :</div>
        <p class="a3-instruction-text">
          Sélectionne la plage de fichiers <strong>du 02 au 04 inclus</strong> (avec <em>Shift+clic</em>),
          puis ajoute le fichier <strong>08</strong> à ta sélection (avec <em>Ctrl+clic</em>).
        </p>
      `;
      wrapper.appendChild(taskHeader);

      const list = document.createElement('div');
      list.className = 'a3-list';
      list.setAttribute('role', 'listbox');
      list.setAttribute('aria-multiselectable', 'true');
      wrapper.appendChild(list);

      let selectionState = {
        selected: new Set(),
        anchor: null,
      };

      const rowElements = new Map();

      function updateUI() {
        files.forEach((file) => {
          const row = rowElements.get(file.id);
          if (!row) return;
          const isSelected = selectionState.selected.has(file.id);
          row.setAttribute('aria-selected', isSelected ? 'true' : 'false');
          if (isSelected) {
            row.classList.add('is-selected');
          } else {
            row.classList.remove('is-selected');
          }
        });

        const count = selectionState.selected.size;
        api.status(`${count} fichier(s) sélectionné(s)`);
      }

      function handleItemInteraction(fileId, modifiers) {
        api.attempt();

        selectionState = MM2.Ateliers.helpers.a3.applySelection(
          selectionState,
          fileId,
          modifiers,
          order,
        );

        updateUI();

        // Check if selection matches target
        const evaluation = MM2.Ateliers.helpers.a3.evaluate(
          Array.from(selectionState.selected),
          targetSelection,
        );

        if (evaluation.exact) {
          api.feedback(
            'Sélection multiple parfaite ! Tu as combiné Shift+clic et Ctrl+clic avec brio.',
            'success',
            '🎉',
          );
          setTimeout(() => {
            api.finish({ precision: 1 });
          }, 800);
        }
      }

      files.forEach((file) => {
        const row = document.createElement('div');
        row.className = 'a3-row';
        row.id = `a3-${file.id}`;
        row.setAttribute('role', 'option');
        row.setAttribute('tabindex', '0');
        row.setAttribute('aria-selected', 'false');

        row.innerHTML = `
          <span class="a3-check" aria-hidden="true"></span>
          <span class="a3-icon" aria-hidden="true">${file.icon || '📄'}</span>
          <span class="a3-name">${file.name}</span>
          <span class="a3-size">${file.size || ''}</span>
          <span class="a3-date">${file.date || ''}</span>
        `;

        row.addEventListener('click', (e) => {
          handleItemInteraction(file.id, {
            ctrl: e.ctrlKey || e.metaKey,
            shift: e.shiftKey,
          });
        });

        row.addEventListener('keydown', (e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            handleItemInteraction(file.id, {
              ctrl: e.ctrlKey || e.metaKey,
              shift: e.shiftKey,
            });
          }
        });

        list.appendChild(row);
        rowElements.set(file.id, row);
      });

      const btnValidate = document.createElement('button');
      btnValidate.type = 'button';
      btnValidate.className = 'btn btn-primary a3-btn-validate';
      btnValidate.textContent = 'Valider ma sélection';
      btnValidate.addEventListener('click', () => {
        api.attempt();
        const evaluation = MM2.Ateliers.helpers.a3.evaluate(
          Array.from(selectionState.selected),
          targetSelection,
        );
        if (evaluation.exact) {
          api.feedback('Sélection parfaite !', 'success', '🎉');
          api.finish({ precision: 1 });
        } else {
          api.feedback(
            `Sélection incomplète (${evaluation.missing.length} manquant(s), ${evaluation.extra.length} intrus). Utilise Shift pour les plages et Ctrl pour ajouter/retirer.`,
            'error',
            '⚠️',
          );
        }
      });
      wrapper.appendChild(btnValidate);

      container.appendChild(wrapper);
      api.status('0 fichier(s) sélectionné(s)');

      return function cleanup() {
        wrapper.remove();
      };
    },
  });
})(typeof window !== 'undefined' ? window : globalThis);
