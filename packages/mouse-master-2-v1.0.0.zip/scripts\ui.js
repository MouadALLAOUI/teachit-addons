(function (global) {
  'use strict';

  const MM2 = (global.MM2 = global.MM2 || {});

  class MouseMaster2UI {
    constructor() {
      this.engine = null;
      this.currentAtelierIndex = 0;
      this.currentCleanup = null;
      this.timerInterval = null;

      // Screen elements
      this.screenWelcome = null;
      this.screenMap = null;
      this.screenIntro = null;
      this.screenGame = null;
      this.screenResults = null;

      // HUD elements
      this.hudScore = null;
      this.hudAttempts = null;
      this.hudTimer = null;
      this.atelierGrid = null;

      // Intro elements
      this.introTitle = null;
      this.introConcept = null;
      this.introObjective = null;
      this.introExplanation = null;
      this.btnPlayAtelier = null;

      // Game stage elements
      this.stageArea = null;
      this.gameTitle = null;
      this.gameFeedback = null;
      this.gameStatus = null;
      this.atelierResult = null;
      this.resultScore = null;
      this.resultStars = null;
      this.btnNextAtelier = null;
      this.btnReplayAtelier = null;
      this.btnReturnMap = null;

      // Global buttons
      this.btnStart = null;
      this.btnQuit = null;
    }

    init(engine) {
      this.engine = engine;
      this.bindDOMElements();
      this.bindEvents();
      if (this.atelierResult) {
        this.atelierResult.hidden = true;
        this.atelierResult.style.display = 'none';
        this.atelierResult.classList.add('is-hidden');
      }
      this.checkSavedProgress();
      this.renderAtelierGrid();
      this.updateHUD();
      this.showScreen('welcome');
    }

    bindDOMElements() {
      if (typeof document === 'undefined') return;

      this.screenWelcome = document.getElementById('screenWelcome');
      this.screenMap = document.getElementById('screenMap');
      this.screenIntro = document.getElementById('screenIntro');
      this.screenGame = document.getElementById('screenGame');
      this.screenResults = document.getElementById('screenResults');

      this.hudScore = document.getElementById('hudScore');
      this.hudAttempts = document.getElementById('hudAttempts');
      this.hudTimer = document.getElementById('hudTimer');
      this.atelierGrid = document.getElementById('atelierGrid');

      this.introTitle = document.getElementById('introTitle');
      this.introConcept = document.getElementById('introConcept');
      this.introObjective = document.getElementById('introObjective');
      this.introExplanation = document.getElementById('introExplanation');
      this.btnPlayAtelier = document.getElementById('btnPlayAtelier');

      this.stageArea = document.getElementById('stageArea');
      this.gameTitle = document.getElementById('gameTitle');
      this.gameFeedback = document.getElementById('gameFeedback');
      this.gameStatus = document.getElementById('gameStatus');
      this.atelierResult = document.getElementById('atelierResult');
      this.resultScore = document.getElementById('resultScore');
      this.resultStars = document.getElementById('resultStars');
      this.btnNextAtelier = document.getElementById('btnNextAtelier');
      this.btnReplayAtelier = document.getElementById('btnReplayAtelier');
      this.btnReturnMap = document.getElementById('btnReturnMap');

      this.btnStart = document.getElementById('btnStart');
      this.btnResume = document.getElementById('btnResume');
      this.btnQuit = document.getElementById('btnQuit');
    }

    checkSavedProgress() {
      if (this.engine && this.engine.hasSavedProgress()) {
        const savedCount = this.engine.getSavedCompletedCount();
        if (this.btnResume) {
          this.btnResume.style.display = 'inline-flex';
          this.btnResume.className = 'btn btn-primary btn-lg';
          this.btnResume.textContent = `▶ Continuer mon parcours (${savedCount}/7 complétés)`;
        }
        if (this.btnStart) {
          this.btnStart.className = 'btn btn-secondary btn-lg';
          this.btnStart.textContent = '🔄 Recommencer à zéro';
        }
      } else {
        if (this.btnResume) {
          this.btnResume.style.display = 'none';
        }
        if (this.btnStart) {
          this.btnStart.className = 'btn btn-primary btn-lg';
          this.btnStart.textContent = "🚀 Commencer l'entraînement";
        }
      }
    }

    bindEvents() {
      if (this.btnResume) {
        this.btnResume.addEventListener('click', () => {
          this.engine.loadFromStorage();
          this.engine.started = true;
          MM2.Telemetry.reportStarted(this.engine);
          this.updateHUD();
          this.renderAtelierGrid();
          this.showScreen('map');
        });
      }

      if (this.btnStart) {
        this.btnStart.addEventListener('click', () => {
          if (this.engine.hasSavedProgress()) {
            this.engine.clearStorage();
          }
          this.engine.start();
          MM2.Telemetry.reportStarted(this.engine);
          this.updateHUD();
          this.renderAtelierGrid();
          this.showScreen('map');
        });
      }

      if (this.btnQuit) {
        this.btnQuit.addEventListener('click', () => {
          this.stopTimer();
          MM2.Telemetry.exitGame(this.engine);
        });
      }

      if (this.btnPlayAtelier) {
        this.btnPlayAtelier.addEventListener('click', () => {
          this.launchAtelier(this.currentAtelierIndex);
        });
      }

      if (this.btnNextAtelier) {
        this.btnNextAtelier.addEventListener('click', () => {
          if (this.atelierResult) {
            this.atelierResult.hidden = true;
            this.atelierResult.style.display = 'none';
            this.atelierResult.classList.add('is-hidden');
          }
          if (this.currentAtelierIndex + 1 < this.engine.ateliers.length) {
            this.showAtelierIntro(this.currentAtelierIndex + 1);
          } else {
            this.showResults();
          }
        });
      }

      if (this.btnReplayAtelier) {
        this.btnReplayAtelier.addEventListener('click', () => {
          if (this.atelierResult) {
            this.atelierResult.hidden = true;
            this.atelierResult.style.display = 'none';
            this.atelierResult.classList.add('is-hidden');
          }
          this.launchAtelier(this.currentAtelierIndex);
        });
      }

      if (this.btnReturnMap) {
        this.btnReturnMap.addEventListener('click', () => {
          if (this.atelierResult) {
            this.atelierResult.hidden = true;
            this.atelierResult.style.display = 'none';
            this.atelierResult.classList.add('is-hidden');
          }
          this.cleanupCurrentAtelier();
          this.renderAtelierGrid();
          this.showScreen('map');
        });
      }

      const btnResultsReturn = document.getElementById('btnResultsReturn');
      if (btnResultsReturn) {
        btnResultsReturn.addEventListener('click', () => {
          MM2.Telemetry.exitGame(this.engine);
        });
      }
    }

    showScreen(screenId) {
      const screens = [
        this.screenWelcome,
        this.screenMap,
        this.screenIntro,
        this.screenGame,
        this.screenResults,
      ];

      screens.forEach((s) => {
        if (s) s.classList.remove('is-active');
      });

      if (screenId === 'welcome' && this.screenWelcome) this.screenWelcome.classList.add('is-active');
      if (screenId === 'map' && this.screenMap) this.screenMap.classList.add('is-active');
      if (screenId === 'intro' && this.screenIntro) this.screenIntro.classList.add('is-active');
      if (screenId === 'game' && this.screenGame) this.screenGame.classList.add('is-active');
      if (screenId === 'results' && this.screenResults) this.screenResults.classList.add('is-active');
    }

    updateHUD() {
      if (this.hudScore && this.engine) {
        this.hudScore.textContent = String(this.engine.getScore());
      }
      if (this.hudAttempts && this.engine) {
        const curAtelier = this.engine.ateliers[this.currentAtelierIndex];
        const count = curAtelier ? this.engine.getAttempts(curAtelier.id) : this.engine.getTotalAttempts();
        this.hudAttempts.textContent = String(count);
      }
    }

    renderAtelierGrid() {
      if (!this.atelierGrid || !this.engine) return;
      this.atelierGrid.innerHTML = '';

      this.engine.ateliers.forEach((atelier, idx) => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'map-card';
        btn.setAttribute('data-index', String(idx));

        const unlocked = this.engine.isUnlocked(idx);
        const completed = this.engine.isCompleted(atelier.id);

        btn.disabled = !unlocked;
        if (completed) btn.classList.add('is-completed');

        const res = this.engine.getResult(atelier.id);
        const starStr = res ? '★'.repeat(res.stars) + '☆'.repeat(3 - res.stars) : '☆☆☆';

        btn.innerHTML = `
          <div class="card-badge">${atelier.number}</div>
          <div class="card-body">
            <h4 class="card-title">${atelier.title}</h4>
            <span class="card-concept">${atelier.concept || ''}</span>
            <div class="card-stars">${completed ? starStr : 'Non complété'}</div>
          </div>
          <div class="card-status">${completed ? '✓ Fait' : unlocked ? 'Prêt' : '🔒'}</div>
        `;

        btn.addEventListener('click', () => {
          if (unlocked) {
            this.showAtelierIntro(idx);
          }
        });

        this.atelierGrid.appendChild(btn);
      });
    }

    showAtelierIntro(index) {
      this.currentAtelierIndex = index;
      const atelier = this.engine.ateliers[index];
      if (!atelier) return;

      if (this.introTitle) this.introTitle.textContent = atelier.title;
      if (this.introConcept) this.introConcept.textContent = atelier.concept || '';
      if (this.introObjective) this.introObjective.textContent = atelier.objective || '';
      if (this.introExplanation) this.introExplanation.textContent = atelier.explanation || '';

      this.showScreen('intro');
    }

    cleanupCurrentAtelier() {
      if (typeof this.currentCleanup === 'function') {
        try {
          this.currentCleanup();
        } catch {
          // safe cleanup
        }
        this.currentCleanup = null;
      }
      if (this.stageArea) {
        this.stageArea.innerHTML = '';
      }
    }

    launchAtelier(index) {
      this.currentAtelierIndex = index;
      const atelier = this.engine.ateliers[index];
      if (!atelier) return;

      this.cleanupCurrentAtelier();
      if (this.atelierResult) {
        this.atelierResult.hidden = true;
        this.atelierResult.style.display = 'none';
        this.atelierResult.classList.add('is-hidden');
      }
      if (this.gameTitle) this.gameTitle.textContent = `Atelier ${atelier.number} : ${atelier.title}`;
      if (this.gameFeedback) this.gameFeedback.style.display = 'none';

      const atelierComponent = MM2.Ateliers.get(atelier.id);
      if (!atelierComponent || typeof atelierComponent.mount !== 'function') return;

      const atelierStartTime = Date.now();

      const api = {
        atelier,
        engine: this.engine,
        attempt: () => {
          this.engine.recordAttempt(atelier.id);
          this.updateHUD();
        },
        feedback: (text, type = 'info', icon = '💡') => {
          if (this.gameFeedback) {
            this.gameFeedback.className = `feedback-box ${type}`;
            this.gameFeedback.innerHTML = `<span class="feedback-icon">${icon}</span> <span>${text}</span>`;
            this.gameFeedback.style.display = 'flex';
          }
        },
        status: (text) => {
          if (this.gameStatus) this.gameStatus.textContent = text;
        },
        finish: (finishOptions) => {
          const elapsedMs = Date.now() - atelierStartTime;
          const completeRes = this.engine.completeAtelier(atelier.id, {
            precision: finishOptions?.precision ?? 1,
            elapsedMs,
            measurements: finishOptions?.measurements || {},
          });

          this.updateHUD();
          this.renderAtelierGrid();

          if (this.atelierResult) {
            this.atelierResult.hidden = false;
            this.atelierResult.style.display = 'flex';
            this.atelierResult.classList.remove('is-hidden');
            if (this.resultScore) this.resultScore.textContent = `${completeRes.score} / 100`;
            if (this.resultStars) this.resultStars.textContent = '★'.repeat(completeRes.stars);
          }

          if (this.engine.isComplete()) {
            MM2.Telemetry.reportCompleted(this.engine);
          }
        },
      };

      this.currentCleanup = atelierComponent.mount(this.stageArea, api);
      this.updateHUD();
      this.showScreen('game');
    }

    showResults() {
      this.stopTimer();
      const summary = this.engine.getSummary();
      this.showScreen('results');

      const resScore = document.getElementById('resultsTotalScore');
      const resPercent = document.getElementById('resultsPercent');
      const resStars = document.getElementById('resultsTotalStars');
      const resAttempts = document.getElementById('resultsTotalAttempts');
      const resDuration = document.getElementById('resultsDuration');
      const breakdownList = document.getElementById('resultsBreakdownList');

      if (resScore) resScore.textContent = `${summary.score} / ${summary.maxScore}`;
      if (resPercent) resPercent.textContent = `${summary.percent}%`;
      if (resStars) resStars.textContent = `${summary.totalStars} / ${summary.maxStars} ★`;
      if (resAttempts) resAttempts.textContent = String(summary.totalAttempts);

      const mins = Math.floor(summary.durationSeconds / 60);
      const secs = summary.durationSeconds % 60;
      if (resDuration) resDuration.textContent = `${mins}m ${secs < 10 ? '0' : ''}${secs}s`;

      if (breakdownList) {
        breakdownList.innerHTML = summary.ateliers
          .map((a) => {
            const r = a.result;
            const starText = r ? '★'.repeat(r.stars) : '☆☆☆';
            return `
              <li class="breakdown-row">
                <span class="breakdown-title">${a.title}</span>
                <span class="breakdown-score">${r ? r.score : 0} pts (${starText})</span>
              </li>
            `;
          })
          .join('');
      }

      MM2.Telemetry.reportCompleted(this.engine);
    }

    stopTimer() {
      if (this.timerInterval) {
        clearInterval(this.timerInterval);
        this.timerInterval = null;
      }
    }
  }

  MM2.UI = new MouseMaster2UI();
})(typeof window !== 'undefined' ? window : globalThis);
