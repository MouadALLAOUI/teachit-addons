(function (global) {
  'use strict';

  const MM2 = (global.MM2 = global.MM2 || {});

  // Register Map for ateliers
  MM2.Ateliers = MM2.Ateliers || new Map();

  function snap(value, grid) {
    if (!grid || grid <= 1) return value;
    return Math.round(value / grid) * grid;
  }

  function rectFromPoints(x1, y1, x2, y2) {
    const left = Math.min(x1, x2);
    const top = Math.min(y1, y2);
    const right = Math.max(x1, x2);
    const bottom = Math.max(y1, y2);
    return {
      left,
      top,
      right,
      bottom,
      width: right - left,
      height: bottom - top,
    };
  }

  function rectsIntersect(r1, r2) {
    return !(
      r1.right < r2.left ||
      r1.left > r2.right ||
      r1.bottom < r2.top ||
      r1.top > r2.bottom
    );
  }

  // Atelier 1 Helpers
  const a1 = {
    computeStats(clicks, targetCount) {
      const arr = clicks || [];
      const correctClicks = arr.filter((c) => c.correct);
      const wrongClicks = arr.filter((c) => !c.correct);
      const correct = correctClicks.length;
      const wrong = wrongClicks.length;
      const total = arr.length;
      const completed = correct >= (targetCount || 12);
      const precision = total > 0 ? correct / total : 0;
      const accuracyPercent = Math.round(precision * 100);

      const reactions = correctClicks
        .map((c) => c.reactionMs)
        .filter((r) => typeof r === 'number' && r > 0)
        .sort((a, b) => a - b);

      let medianReactionMs = 0;
      if (reactions.length > 0) {
        const mid = Math.floor(reactions.length / 2);
        if (reactions.length % 2 === 1) {
          medianReactionMs = reactions[mid];
        } else {
          medianReactionMs = Math.round((reactions[mid - 1] + reactions[mid]) / 2);
        }
      }

      return {
        correct,
        wrong,
        total,
        completed,
        precision,
        accuracyPercent,
        medianReactionMs,
      };
    },
  };

  // Atelier 2 Helpers
  const a2 = {
    selectByRect(selectionRect, boxes) {
      if (!selectionRect || !Array.isArray(boxes)) return [];
      return boxes
        .filter((box) => box && box.rect && rectsIntersect(selectionRect, box.rect))
        .map((box) => box.id);
    },

    evaluateSelection(selectedIds, requiredIds) {
      const selSet = new Set(selectedIds || []);
      const reqSet = new Set(requiredIds || []);

      const exact = selSet.size === reqSet.size && [...selSet].every((id) => reqSet.has(id));
      const missing = [...reqSet].filter((id) => !selSet.has(id));
      const extra = [...selSet].filter((id) => !reqSet.has(id));

      const intersection = [...selSet].filter((id) => reqSet.has(id)).length;
      const union = new Set([...selSet, ...reqSet]).size;
      const precision = union > 0 ? intersection / union : 0;

      return {
        exact,
        missing,
        extra,
        precision,
      };
    },
  };

  // Atelier 3 Helpers
  const a3 = {
    applySelection(state, itemId, modifiers, order) {
      const selected = new Set(state?.selected || []);
      const anchor = state?.anchor || null;
      const mods = modifiers || {};
      const fileOrder = order || [];

      if (mods.shift && anchor && fileOrder.includes(anchor) && fileOrder.includes(itemId)) {
        const idx1 = fileOrder.indexOf(anchor);
        const idx2 = fileOrder.indexOf(itemId);
        const minIdx = Math.min(idx1, idx2);
        const maxIdx = Math.max(idx1, idx2);
        const range = fileOrder.slice(minIdx, maxIdx + 1);

        let newSelected;
        if (mods.ctrl) {
          newSelected = new Set(selected);
          for (const id of range) {
            newSelected.add(id);
          }
        } else {
          newSelected = new Set(range);
        }
        return {
          selected: newSelected,
          anchor,
        };
      }

      if (mods.ctrl) {
        const newSelected = new Set(selected);
        if (newSelected.has(itemId)) {
          newSelected.delete(itemId);
        } else {
          newSelected.add(itemId);
        }
        return {
          selected: newSelected,
          anchor: itemId,
        };
      }

      return {
        selected: new Set([itemId]),
        anchor: itemId,
      };
    },

    evaluate(selectedIds, requiredIds) {
      const selSet = new Set(selectedIds || []);
      const reqSet = new Set(requiredIds || []);

      const exact = selSet.size === reqSet.size && [...selSet].every((id) => reqSet.has(id));
      const missing = [...reqSet].filter((id) => !selSet.has(id));
      const extra = [...selSet].filter((id) => !reqSet.has(id));

      const intersection = [...selSet].filter((id) => reqSet.has(id)).length;
      const union = new Set([...selSet, ...reqSet]).size;
      const quality = union > 0 ? intersection / union : 0;

      return {
        exact,
        missing,
        extra,
        quality,
      };
    },
  };

  // Atelier 4 Helpers
  const a4 = {
    resizeRect(startRect, delta, handle, options) {
      const grid = options?.grid || 1;
      const dx = snap(delta.x || 0, grid);
      const dy = snap(delta.y || 0, grid);

      const minW = options?.minWidth || 100;
      const minH = options?.minHeight || 100;

      let left = startRect.left;
      let top = startRect.top;
      let width = startRect.width;
      let height = startRect.height;

      if (handle.includes('e')) {
        width = Math.max(minW, startRect.width + dx);
      }
      if (handle.includes('w')) {
        const rawW = startRect.width - dx;
        width = Math.max(minW, rawW);
        left = startRect.left + (startRect.width - width);
      }
      if (handle.includes('s')) {
        height = Math.max(minH, startRect.height + dy);
      }
      if (handle.includes('n')) {
        const rawH = startRect.height - dy;
        height = Math.max(minH, rawH);
        top = startRect.top + (startRect.height - height);
      }

      return {
        left,
        top,
        width,
        height,
      };
    },

    isTargetSize(width, height, target, tolerance) {
      const tol = typeof tolerance === 'number' ? tolerance : 4;
      return (
        Math.abs(width - target.width) <= tol &&
        Math.abs(height - target.height) <= tol
      );
    },

    precisionForSize(width, height, target, tolerance) {
      const tol = typeof tolerance === 'number' ? tolerance : 4;
      const error = Math.max(Math.abs(width - target.width), Math.abs(height - target.height));
      if (error <= 0) return 1;
      if (error > tol) return 0;
      return 1 - error / (tol * 2);
    },
  };

  // Atelier 5 Helpers
  const a5 = {
    idealScrollTop(targetLineTop, targetLineHeight, viewportHeight) {
      return targetLineTop + targetLineHeight / 2 - viewportHeight / 2;
    },

    clampZoom(zoom, minZoom, maxZoom) {
      return Math.min(maxZoom, Math.max(minZoom, zoom));
    },

    precisionFor({ overshootPx, zoom, zoomTarget, viewportHeight }) {
      const vh = viewportHeight || 400;
      const overshoot = typeof overshootPx === 'number' ? Math.abs(overshootPx) : 0;
      const overshootScore = Math.max(0, 1 - overshoot / (vh / 2));

      const curZoom = typeof zoom === 'number' ? zoom : 1;
      const target = typeof zoomTarget === 'number' ? zoomTarget : 1.5;
      const zoomDiff = Math.abs(curZoom - target);
      const zoomScore = Math.max(0, 1 - zoomDiff / 0.5);

      return (overshootScore + zoomScore) / 2;
    },
  };

  // Atelier 6 Helpers
  const a6 = {
    validate(mode, selectedText, expectedText) {
      const normalize = (str) => (str || '').trim().replace(/\s+/g, ' ');
      const sel = normalize(selectedText);
      const exp = normalize(expectedText);
      return {
        exact: sel === exp && sel.length > 0,
        mode,
        selected: sel,
        expected: exp,
      };
    },
  };

  // Boss Mission Helpers
  const boss = {
    objectiveIds: ['lasso', 'ctrl', 'drop', 'resize', 'scroll', 'text'],

    countCompleted(objectives) {
      const obj = objectives || {};
      let count = 0;
      for (const id of boss.objectiveIds) {
        if (obj[id]) count++;
      }
      return count;
    },

    allCompleted(objectives) {
      return boss.countCompleted(objectives) === boss.objectiveIds.length;
    },

    firstTryPrecision(objectives) {
      return boss.countCompleted(objectives) / boss.objectiveIds.length;
    },
  };

  const helpers = {
    snap,
    rectFromPoints,
    rectsIntersect,
    a1,
    a2,
    a3,
    a4,
    a5,
    a6,
    boss,
  };

  MM2.Ateliers.helpers = helpers;
})(typeof window !== 'undefined' ? window : globalThis);
