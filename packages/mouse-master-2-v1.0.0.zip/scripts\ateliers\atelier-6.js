(function (global) {
  'use strict';

  const MM2 = (global.MM2 = global.MM2 || {});
  MM2.Ateliers = MM2.Ateliers || new Map();

  MM2.Ateliers.set('atelier-6', {
    mount(container, api) {
      const atelier = api.atelier || MM2.CONFIG.ateliers[5];
      const data = atelier.data || {};
      const lines = data.lines || [];
      const tasks = data.tasks || [];

      const wrapper = document.createElement('div');
      wrapper.className = 'a6-wrapper';
      wrapper.style.cursor = 'text';

      let currentTaskIdx = 0;

      const instructionBox = document.createElement('div');
      instructionBox.className = 'a6-instruction-box';
      wrapper.appendChild(instructionBox);

      const docArea = document.createElement('div');
      docArea.className = 'a6-doc-area';
      wrapper.appendChild(docArea);

      const lineElements = [];

      lines.forEach((lineText, idx) => {
        const p = document.createElement('p');
        p.className = 'a6-line';
        p.textContent = lineText;
        p.setAttribute('data-line-index', String(idx));
        docArea.appendChild(p);
        lineElements.push(p);
      });

      function updateTaskUI() {
        if (currentTaskIdx >= tasks.length) return;
        const task = tasks[currentTaskIdx];

        instructionBox.innerHTML = `
          <div class="a6-task-pill">Étape ${currentTaskIdx + 1} / ${tasks.length} : Mode ${task.mode.toUpperCase()}</div>
          <p class="a6-task-instruction">${task.instruction || 'Sélectionne le texte demandé.'}</p>
          <div class="a6-task-target">Texte à capturer : <code>${task.expected}</code></div>
        `;

        lineElements.forEach((el, idx) => {
          if (idx === task.lineIndex) {
            el.classList.add('is-current');
          } else {
            el.classList.remove('is-current');
          }
        });

        api.status(`Étape ${currentTaskIdx + 1} / ${tasks.length}`);
      }

      function checkCurrentSelection() {
        if (currentTaskIdx >= tasks.length) return;
        const task = tasks[currentTaskIdx];

        let selectedText = '';
        if (typeof window !== 'undefined' && window.getSelection) {
          const sel = window.getSelection();
          selectedText = sel ? sel.toString() : '';
        }

        if (!selectedText || selectedText.trim().length === 0) return;

        api.attempt();

        const val = MM2.Ateliers.helpers.a6.validate(
          task.mode,
          selectedText,
          task.expected,
        );

        if (val.exact) {
          api.feedback(`Excellent ! Étape ${currentTaskIdx + 1} validée.`, 'success', '✨', 1200);
          currentTaskIdx++;
          if (currentTaskIdx >= tasks.length) {
            api.feedback(
              'Bravo ! Tu as maîtrisé les 3 modes de sélection de texte.',
              'success',
              '🎉',
            );
            setTimeout(() => {
              api.finish({ precision: 1 });
            }, 800);
          } else {
            updateTaskUI();
          }
        }
      }

      const onMouseUp = () => {
        setTimeout(checkCurrentSelection, 20);
      };

      docArea.addEventListener('mouseup', onMouseUp);

      container.appendChild(wrapper);
      updateTaskUI();

      return function cleanup() {
        docArea.removeEventListener('mouseup', onMouseUp);
        wrapper.remove();
      };
    },
  });
})(typeof window !== 'undefined' ? window : globalThis);
