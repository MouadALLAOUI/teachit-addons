(function (global) {
  'use strict';

  const MM2 = (global.MM2 = global.MM2 || {});

  class MouseMaster2Engine {
    constructor(config) {
      this.config = config || MM2.CONFIG || {};
      this.ateliers = this.config.ateliers || [];
      this.started = false;
      this.startTime = Date.now();
      this.score = 0;
      this.attempts = new Map();
      this.completedSet = new Set();
      this.results = new Map();
      this.measurements = {};
      this.sessionReported = false;
    }

    getStorageKey() {
      return 'teachit_mouse_master_2_progress';
    }

    saveToStorage() {
      try {
        if (typeof localStorage === 'undefined') return;
        const data = {
          score: this.score,
          completedAteliers: Array.from(this.completedSet),
          results: Array.from(this.results.entries()),
          attempts: Array.from(this.attempts.entries()),
          savedAt: Date.now(),
        };
        localStorage.setItem(this.getStorageKey(), JSON.stringify(data));
      } catch {
        // Safe fallback in restricted environments
      }
    }

    loadFromStorage() {
      try {
        if (typeof localStorage === 'undefined') return false;
        const raw = localStorage.getItem(this.getStorageKey());
        if (!raw) return false;
        const data = JSON.parse(raw);
        if (Array.isArray(data.completedAteliers) && data.completedAteliers.length > 0) {
          this.completedSet = new Set(data.completedAteliers);
        }
        if (typeof data.score === 'number') {
          this.score = data.score;
        }
        if (Array.isArray(data.results)) {
          this.results = new Map(data.results);
        }
        if (Array.isArray(data.attempts)) {
          this.attempts = new Map(data.attempts);
        }
        return this.completedSet.size > 0;
      } catch {
        return false;
      }
    }

    hasSavedProgress() {
      try {
        if (typeof localStorage === 'undefined') return false;
        const raw = localStorage.getItem(this.getStorageKey());
        if (!raw) return false;
        const data = JSON.parse(raw);
        return Array.isArray(data.completedAteliers) && data.completedAteliers.length > 0;
      } catch {
        return false;
      }
    }

    getSavedCompletedCount() {
      try {
        if (typeof localStorage === 'undefined') return 0;
        const raw = localStorage.getItem(this.getStorageKey());
        if (!raw) return 0;
        const data = JSON.parse(raw);
        return Array.isArray(data.completedAteliers) ? data.completedAteliers.length : 0;
      } catch {
        return 0;
      }
    }

    clearStorage() {
      try {
        if (typeof localStorage !== 'undefined') {
          localStorage.removeItem(this.getStorageKey());
        }
      } catch {
        // Safe fallback
      }
    }

    start() {
      this.started = true;
      this.startTime = Date.now();
      this.score = 0;
      this.attempts = new Map();
      this.completedSet = new Set();
      this.results = new Map();
      this.measurements = {};
      this.sessionReported = false;
    }

    isUnlocked(index) {
      if (!this.started) return false;
      if (index === 0) return true;
      if (index < 0 || index >= this.ateliers.length) return false;
      const prevAtelier = this.ateliers[index - 1];
      return prevAtelier ? this.completedSet.has(prevAtelier.id) : false;
    }

    isCompleted(atelierId) {
      return this.completedSet.has(atelierId);
    }

    recordAttempt(atelierId) {
      const current = this.attempts.get(atelierId) || 0;
      this.attempts.set(atelierId, current + 1);
    }

    getAttempts(atelierId) {
      return this.attempts.get(atelierId) || 0;
    }

    getTotalAttempts() {
      let sum = 0;
      for (const count of this.attempts.values()) {
        sum += count;
      }
      return sum;
    }

    completeAtelier(atelierId, options) {
      const opts = options || {};
      const atelier = this.ateliers.find((a) => a.id === atelierId);
      const targetMs = atelier ? atelier.targetMs : 10000;

      if (opts.measurements) {
        Object.assign(this.measurements, opts.measurements);
      }

      if (this.completedSet.has(atelierId)) {
        const prev = this.results.get(atelierId) || { score: 100, stars: 3 };
        return {
          awarded: false,
          alreadyRecorded: true,
          score: prev.score,
          stars: prev.stars,
        };
      }

      const bd = MM2.Scoring.breakdown({
        completed: true,
        precision: opts.precision,
        elapsedMs: opts.elapsedMs,
        targetMs,
      });

      const starCount = MM2.Scoring.stars({
        completed: true,
        precision: opts.precision,
      });

      const maxScore = typeof this.config.maxScore === 'number' ? this.config.maxScore : 700;
      this.score = Math.min(maxScore, this.score + bd.total);
      this.completedSet.add(atelierId);

      const res = {
        completed: true,
        score: bd.total,
        stars: starCount,
        breakdown: bd,
        precision: opts.precision,
        elapsedMs: opts.elapsedMs,
        attempts: this.getAttempts(atelierId),
        measurements: opts.measurements || {},
      };
      this.results.set(atelierId, res);
      this.saveToStorage();

      return {
        awarded: true,
        alreadyRecorded: false,
        score: bd.total,
        stars: starCount,
        breakdown: bd,
      };
    }

    getScore() {
      return this.score;
    }

    getResult(atelierId) {
      return this.results.get(atelierId) || null;
    }

    isComplete() {
      return this.ateliers.length > 0 && this.completedSet.size >= this.ateliers.length;
    }

    getTotalStars() {
      let stars = 0;
      for (const res of this.results.values()) {
        stars += res.stars || 0;
      }
      return stars;
    }

    getDurationSeconds() {
      return Math.max(0, Math.round((Date.now() - this.startTime) / 1000));
    }

    getSummary() {
      const maxScore = typeof this.config.maxScore === 'number' ? this.config.maxScore : 700;
      return {
        score: this.score,
        maxScore,
        percent: maxScore > 0 ? Math.round((this.score / maxScore) * 100) : 0,
        totalStars: this.getTotalStars(),
        maxStars: this.ateliers.length * 3,
        totalAttempts: this.getTotalAttempts(),
        completedCount: this.completedSet.size,
        totalAteliers: this.ateliers.length,
        durationSeconds: this.getDurationSeconds(),
        ateliers: this.ateliers.map((a) => ({
          id: a.id,
          title: a.title,
          completed: this.completedSet.has(a.id),
          result: this.results.get(a.id) || null,
        })),
      };
    }

    getMetrics() {
      let precSum = 0;
      let precCount = 0;
      for (const res of this.results.values()) {
        if (typeof res.precision === 'number' && !Number.isNaN(res.precision)) {
          precSum += res.precision;
          precCount++;
        }
      }
      const precisionPercent = precCount > 0 ? Math.round((precSum / precCount) * 100) : 0;

      const medianReaction =
        typeof this.measurements.medianReactionMs === 'number' && !Number.isNaN(this.measurements.medianReactionMs)
          ? Math.round(this.measurements.medianReactionMs)
          : 0;

      const overshoot =
        typeof this.measurements.overshootPx === 'number' && !Number.isNaN(this.measurements.overshootPx)
          ? Math.round(this.measurements.overshootPx)
          : 0;

      return {
        status: this.isComplete() ? 'completed' : 'abandoned',
        atelier1_flick: this.isCompleted('atelier-1'),
        atelier2_lasso: this.isCompleted('atelier-2'),
        atelier3_multiselect: this.isCompleted('atelier-3'),
        atelier4_resize: this.isCompleted('atelier-4'),
        atelier5_scroll: this.isCompleted('atelier-5'),
        atelier6_text: this.isCompleted('atelier-6'),
        boss_desktop: this.isCompleted('boss'),
        completedAteliers: this.completedSet.size,
        totalAteliers: this.ateliers.length,
        totalAttempts: this.getTotalAttempts(),
        precisionPercent,
        medianReactionMs: medianReaction,
        overshootPx: overshoot,
      };
    }
  }

  function createEngine(config) {
    return new MouseMaster2Engine(config);
  }

  MM2.createEngine = createEngine;
})(typeof window !== 'undefined' ? window : globalThis);
