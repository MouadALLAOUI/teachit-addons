let arr = [64, 34, 25, 12, 22, 11, 90, 48];
let comparisons = 0;
let swaps = 0;
let isSorting = false;

function renderBars(comparingIdxs = [], sortedIdxs = []) {
  const chart = document.getElementById('chart');
  if (!chart) return;
  chart.innerHTML = '';
  const maxVal = Math.max(...arr, 100);

  arr.forEach((val, idx) => {
    const col = document.createElement('div');
    col.className = 'bar-col';

    const bar = document.createElement('div');
    bar.className = 'bar';
    bar.style.height = (val / maxVal) * 200 + 'px';

    if (comparingIdxs.includes(idx)) {
      bar.classList.add('comparing');
    } else if (sortedIdxs.includes(idx)) {
      bar.classList.add('sorted');
    }

    const label = document.createElement('div');
    label.className = 'bar-label';
    label.textContent = val;

    col.appendChild(bar);
    col.appendChild(label);
    chart.appendChild(col);
  });
}

function resetArray() {
  if (isSorting) return;
  arr = Array.from({ length: 8 }, () => Math.floor(Math.random() * 80) + 15);
  comparisons = 0;
  swaps = 0;
  const compEl = document.getElementById('comparisons');
  if (compEl) compEl.textContent = 0;
  const swapEl = document.getElementById('swaps');
  if (swapEl) swapEl.textContent = 0;
  renderBars();
}

async function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function runBubbleSort() {
  if (isSorting) return;
  isSorting = true;
  const sortBtn = document.getElementById('sort-btn');
  const resetBtn = document.getElementById('reset-btn');
  if (sortBtn) sortBtn.disabled = true;
  if (resetBtn) resetBtn.disabled = true;

  const n = arr.length;
  const sorted = [];

  for (let i = 0; i < n - 1; i++) {
    for (let j = 0; j < n - i - 1; j++) {
      comparisons++;
      const compEl = document.getElementById('comparisons');
      if (compEl) compEl.textContent = comparisons;
      renderBars([j, j + 1], sorted);
      await sleep(250);

      if (arr[j] > arr[j + 1]) {
        swaps++;
        const swapEl = document.getElementById('swaps');
        if (swapEl) swapEl.textContent = swaps;
        const temp = arr[j];
        arr[j] = arr[j + 1];
        arr[j + 1] = temp;
        renderBars([j, j + 1], sorted);
        await sleep(250);
      }
    }
    sorted.push(n - i - 1);
  }
  sorted.push(0);
  renderBars(
    [],
    Array.from({ length: n }, (_, i) => i),
  );

  isSorting = false;
  if (sortBtn) sortBtn.disabled = false;
  if (resetBtn) resetBtn.disabled = false;

  // Report progress via TeachIT safe game integration API
  if (window.teachit && window.teachit.reportProgress) {
    window.teachit
      .reportProgress({
        activityId: 'sort-arena-bubble',
        eventType: 'activity_completed',
        payload: {
          score: Math.max(10, 100 - swaps * 2),
          durationSeconds: 15,
          success: true,
          metrics: { comparisons, swaps, algorithm: 'Bubble Sort' },
        },
      })
      .catch(() => {});
  }
}

function exitToTeachIT() {
  if (window.teachit && typeof window.teachit.exitGame === 'function') {
    window.teachit.exitGame().catch(() => window.close());
  } else {
    window.close();
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const resetBtn = document.getElementById('reset-btn');
  if (resetBtn) resetBtn.addEventListener('click', resetArray);

  const sortBtn = document.getElementById('sort-btn');
  if (sortBtn) sortBtn.addEventListener('click', runBubbleSort);

  const exitBtn = document.getElementById('exit-btn');
  if (exitBtn) exitBtn.addEventListener('click', exitToTeachIT);

  resetArray();
});

// Run directly in case DOM is already loaded
if (document.readyState === 'interactive' || document.readyState === 'complete') {
  const resetBtn = document.getElementById('reset-btn');
  if (resetBtn) resetBtn.addEventListener('click', resetArray);

  const sortBtn = document.getElementById('sort-btn');
  if (sortBtn) sortBtn.addEventListener('click', runBubbleSort);

  const exitBtn = document.getElementById('exit-btn');
  if (exitBtn) exitBtn.addEventListener('click', exitToTeachIT);

  resetArray();
}
