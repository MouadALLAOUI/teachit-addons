/**
 * Computer Quest — Challenge 2: Visual Recognition
 * Quiz to identify components from visual cues and descriptions.
 * Dependencies: CQ.challenges, CQ.config
 */
window.CQ = window.CQ || {};
window.CQ.challenges = window.CQ.challenges || {};

(function () {
  const QUESTIONS = [
    {
      id: 'l2-q1',
      questionFr: 'Quel élément permet de déplacer le pointeur à l’écran ?',
      questionAr: 'ما هو الجزء الذي يتيح تحريك المؤشر على الشاشة والتفاعل معها؟',
      questionEn: 'Which device is used to move the on-screen pointer and interact?',
      targetComponentId: 'souris',
      options: ['souris', 'clavier', 'ecran', 'imprimante'],
      explanationFr: 'La souris est le périphérique de pointage essentiel pour guider le curseur et cliquer.',
      explanationAr: 'الفأرة هي أداة التأشير الأساسية لتوجيه المؤشر والنقر على العناصر.',
      explanationEn: 'The mouse is the primary pointing device to steer the cursor and click.',
    },
    {
      id: 'l2-q2',
      questionFr: 'Quel composant affiche les images, les textes et les vidéos ?',
      questionAr: 'ما هو المكوّن الذي يعرض الصور والنصوص ومقاطع الفيديو؟',
      questionEn: 'Which component displays images, text, and videos?',
      targetComponentId: 'ecran',
      options: ['ecran', 'haut-parleurs', 'unite-centrale', 'webcam'],
      explanationFr: "L'écran est la surface d'affichage visuel qui te permet de voir l'environnement informatique.",
      explanationAr: 'الشاشة هي سطح العرض المرئي الذي يمكنك من رؤية كل ما يعالجه الحاسوب.',
      explanationEn: 'The screen is the visual display surface that lets you see computer output.',
    },
    {
      id: 'l2-q3',
      questionFr: 'Où se trouvent les composants essentiels qui effectuent tous les calculs de l’ordinateur ?',
      questionAr: 'أين توجد المكونات الأساسية التي تقوم بجميع الحسابات ومعالجة البيانات؟',
      questionEn: 'Where are the primary components that perform calculations and data processing located?',
      targetComponentId: 'unite-centrale',
      options: ['unite-centrale', 'imprimante', 'clavier', 'souris'],
      explanationFr: "L'unité centrale (la tour) renferme le processeur, la mémoire et le disque dur.",
      explanationAr: 'الوحدة المركزية (صندوق الحاسوب) هي التي تحتوي على المعالج والذاكرة والقرص الصلب.',
      explanationEn: 'The PC tower houses the CPU processor, system memory, and storage drives.',
    },
    {
      id: 'l2-q4',
      questionFr: 'Quel périphérique permet de saisir du texte, des lettres et des chiffres ?',
      questionAr: 'ما هو الجهاز الذي يتيح إدخال النصوص والحروف والأرقام؟',
      questionEn: 'Which peripheral is used to type text, letters, and numbers?',
      targetComponentId: 'clavier',
      options: ['clavier', 'webcam', 'haut-parleurs', 'ecran'],
      explanationFr: 'Le clavier comporte toutes les touches nécessaires pour taper du texte et coder.',
      explanationAr: 'لوحة المفاتيح تحتوي على كل المفاتيح اللازمة لكتابة النصوص والأوامر البرمجية.',
      explanationEn: 'The keyboard contains keys required to type text and input commands.',
    },
    {
      id: 'l2-q5',
      questionFr: 'Comment appelle-t-on les prises qui permettent de brancher une clé ou une souris sur la tour ?',
      questionAr: 'ماذا تسمى المقابس التي تتيح ربط ذاكرة الفلاش أو الفأرة بصندوق الحاسوب؟',
      questionEn: 'What are the ports called that allow plugging USB flash drives or mice into the tower?',
      targetComponentId: 'ports-usb',
      options: ['ports-usb', 'haut-parleurs', 'imprimante', 'ecran'],
      explanationFr: 'Les ports USB sont des prises standardisées universelles présentes sur l’unité centrale.',
      explanationAr: 'منافذ USB هي واجهات توصيل قياسية مدمجة في واجهة وخلفية صندوق الحاسوب.',
      explanationEn: 'USB ports are universal connection sockets built into the computer case.',
    },
  ];

  let activeContainer = null;
  let activeContext = null;
  let questionIdx = 0;
  let score = 0;
  let answered = false;
  let questionOptions = [];

  function shuffle(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  function render() {
    if (!activeContainer || !activeContext) return;
    const lang = window.CQ.core.i18n ? window.CQ.core.i18n.getLanguage() : 'fr';
    const isAr = lang === 'ar';
    const q = QUESTIONS[questionIdx];
    const components = activeContext.components || [];
    const optionsToRender = questionOptions[questionIdx] || q.options;
    const qTitle = lang === 'ar' ? q.questionAr : (lang === 'en' ? (q.questionEn || q.questionFr) : q.questionFr);

    activeContainer.innerHTML = `
      <div class="cq-challenge-header-bar">
        <span class="cq-badge">${activeContext.t('level2Badge')}</span>
        <h2>${activeContext.t('level2Title')}</h2>
        <p>${activeContext.t('tab1')} : Question ${questionIdx + 1} / ${QUESTIONS.length}</p>
      </div>

      <div class="quiz-container">
        <div class="quiz-question-card">
          <div class="quiz-question-num">Question ${questionIdx + 1} / ${QUESTIONS.length}</div>
          <h3 class="quiz-question-title">${qTitle}</h3>
        </div>

        <div class="quiz-choices-grid">
          ${optionsToRender.map((optId) => {
            const comp = components.find((c) => c.id === optId) || components[0];
            const compName = (activeContext.t && comp.id) ? activeContext.t(`discovery.${comp.id}.name`) : (isAr ? comp.nameAr : (lang === 'en' ? (comp.nameEn || comp.nameFr) : comp.nameFr));
            const compType = isAr ? comp.typeLabelAr : (lang === 'en' ? (comp.typeLabelEn || comp.typeLabelFr) : comp.typeLabelFr);
            return `
              <button type="button" class="quiz-choice-card" data-id="${optId}">
                <div class="quiz-choice-icon">
                  <img src="assets/icons/${optId}.svg" width="48" height="48" alt="" />
                </div>
                <div class="quiz-choice-text">
                  <h4>${compName}</h4>
                  <p>${compType}</p>
                </div>
              </button>
            `;
          }).join('')}
        </div>

        <div class="quiz-explanation-box" id="l2-explanation" style="display: none;">
          <span id="l2-explanation-text"></span>
          <button type="button" class="cq-btn cq-btn-primary" id="btn-next-l2">
            ${activeContext.t('nextQuestion')} ➔
          </button>
        </div>
      </div>
    `;

    const choiceCards = activeContainer.querySelectorAll('.quiz-choice-card');
    const explanationBox = document.getElementById('l2-explanation');
    const explanationText = document.getElementById('l2-explanation-text');
    const btnNext = document.getElementById('btn-next-l2');

    choiceCards.forEach((card) => {
      card.addEventListener('click', () => {
        if (answered) return;
        const selectedId = card.getAttribute('data-id');

        if (selectedId === q.targetComponentId) {
          answered = true;
          score += 20;
          card.classList.add('correct');
          if (activeContext.audio) activeContext.audio.playSfx('correct');

          if (explanationBox && explanationText) {
            const exp = isAr ? q.explanationAr : (lang === 'en' ? (q.explanationEn || q.explanationFr) : q.explanationFr);
            explanationText.textContent = exp;
            explanationBox.style.display = 'flex';
          }
          choiceCards.forEach((c) => c.classList.add('disabled'));
        } else {
          card.classList.add('wrong');
          if (activeContext.audio) activeContext.audio.playSfx('wrong');
          setTimeout(() => card.classList.remove('wrong'), 600);
        }
      });
    });

    if (btnNext) {
      btnNext.addEventListener('click', () => {
        if (questionIdx + 1 < QUESTIONS.length) {
          questionIdx++;
          answered = false;
          render();
        } else {
          if (activeContext.audio) activeContext.audio.playSfx('complete');
          activeContext.complete({ score, total: QUESTIONS.length * 20 });
        }
      });
    }
  }

  window.CQ.challenges.register({
    id: 'recognition',
    order: 2,
    titleKey: 'tab1',
    icon: 'assets/icons/02-recognition.svg',
    mount(container, ctx) {
      activeContainer = container;
      activeContext = ctx;
      questionIdx = 0;
      score = 0;
      answered = false;
      questionOptions = QUESTIONS.map((q) => shuffle(q.options));
      render();
    },
    onLanguageChange() {
      render();
    },
    start() {},
    destroy() {
      activeContainer = null;
      activeContext = null;
    },
  });
})();
