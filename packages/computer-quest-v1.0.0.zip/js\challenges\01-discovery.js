/**
 * Computer Quest — Challenge 1: Interactive Schematic (Discovery)
 * Fully data-driven trilingual component exploration with gallery integration.
 * Dependencies: CQ.data.discoveryComponents, CQ.challenges.discoverySchematic, CQ.challenges.discoveryLightbox
 */
window.CQ = window.CQ || {};
window.CQ.challenges = window.CQ.challenges || {};

(function () {
  let activeContainer = null;
  let activeContext = null;
  let activeComponentId = 'ecran';
  let discoveredSet = new Set();

  function getComponents() {
    return (window.CQ.data && window.CQ.data.discoveryComponents) || [];
  }

  function getActiveComponent() {
    const list = getComponents();
    return list.find((c) => c.id === activeComponentId) || list[0] || { id: 'ecran', images: [] };
  }

  function render(options = {}) {
    if (!activeContainer || !activeContext) return;
    const t = activeContext.t;
    const isAr = window.CQ.core.i18n ? window.CQ.core.i18n.isRtl() : false;
    const components = getComponents();
    const comp = getActiveComponent();

    if (!options.isLanguageSwitch) {
      discoveredSet.add(comp.id);
      activeContext.saveProgress({ discovered: Array.from(discoveredSet) });
    }

    const progressPct = Math.min(100, (discoveredSet.size / components.length) * 100);
    const scrollAreaPrev = activeContainer.querySelector('#detail-scroll-area');
    const savedScrollTop = options.isLanguageSwitch && scrollAreaPrev ? scrollAreaPrev.scrollTop : 0;
    const schematicHtml = window.CQ.challenges.discoverySchematic
      ? window.CQ.challenges.discoverySchematic.render(comp, t, isAr)
      : '';

    activeContainer.innerHTML = `
      <div class="cq-challenge-header-bar">
        <span class="cq-badge">${t('level1Badge')}</span>
        <h2>${t('level1Title')}</h2>
        <p>${t('level1Instruction')}</p>
      </div>

      <div class="level1-container">
        <!-- Left: Workstation Schematic -->
        <div class="level1-workstation-panel">
          ${schematicHtml}
        </div>

        <!-- Right: Description Panel with Fixed Header/Footer and Scrollable Body -->
        <div class="level1-detail-panel">
          <div class="level1-detail-fixed-header">
            <div class="detail-header">
              <span class="detail-type-badge ${comp.type || 'interface'}">
                ${t(comp.categoryKey)}
              </span>
              <img src="${comp.icon}" width="36" height="36" alt="" class="detail-icon" />
            </div>

            <div class="components-chip-list" role="tablist">
              ${components.map((c) => `
                <button type="button" class="chip-btn ${c.id === comp.id ? 'active' : ''} ${discoveredSet.has(c.id) ? 'discovered' : ''}" data-id="${c.id}" role="tab" aria-selected="${c.id === comp.id}">
                  ${t('discovery.' + c.id + '.name')}
                </button>
              `).join('')}
            </div>
          </div>

          <div class="level1-detail-scroll-area" id="detail-scroll-area" tabindex="0" role="region" aria-label="${t('discovery.' + comp.id + '.name')}">
            <h3 class="detail-title">${t('discovery.' + comp.id + '.name')}</h3>
            <p class="detail-desc">${t('discovery.' + comp.id + '.definition')}</p>

            <div class="detail-funfact">
              <strong>💡 ${t('didYouKnow')}</strong>
              <p>${t('discovery.' + comp.id + '.tip')}</p>
            </div>

            ${renderGalleryHtml(comp, t)}
          </div>

          <div class="level1-detail-fade-edge" id="detail-fade-edge"></div>

          <div class="level1-detail-fixed-footer">
            <div class="discovery-progress-bar-wrap">
              <div class="discovery-progress-label">
                <span>${t('level1Progress', { count: discoveredSet.size })}</span>
                <strong>${Math.round(progressPct)}%</strong>
              </div>
              <div class="progress-track">
                <div class="progress-fill" style="width: ${progressPct}%;"></div>
              </div>

              ${discoveredSet.size >= components.length ? `
                <button type="button" class="cq-btn cq-btn-success" id="btnGoToLevel2" style="margin-top: 0.75rem; width: 100%;">
                  ${t('btnProceedLevel2')}
                </button>
              ` : ''}
            </div>
          </div>
        </div>
      </div>

      <div id="cq-lightbox-host"></div>
    `;

    bindEvents(savedScrollTop);
  }

  function getCaption(comp, idx, t) {
    const rawCap = t(`discovery.${comp.id}.image.${idx + 1}.caption`);
    if (rawCap && !rawCap.startsWith('discovery.')) {
      return rawCap;
    }
    const compName = t(`discovery.${comp.id}.name`);
    return `${compName} — Photo ${idx + 1}`;
  }

  function renderGalleryHtml(comp, t) {
    if (!comp.images || comp.images.length === 0) return '';

    return `
      <div class="discovery-gallery-section" id="gallery-section-${comp.id}">
        <div class="discovery-gallery-header">
          <h4 class="discovery-gallery-title">${t('discovery.gallery.title')}</h4>
          <span class="discovery-gallery-hint">🔍 ${t('discovery.gallery.hint')}</span>
        </div>
        <div class="discovery-gallery-strip" role="list">
          ${comp.images.map((imgName, idx) => {
            const imgPath = `assets/images/discovery/${comp.id}/${imgName}`;
            const caption = getCaption(comp, idx, t);
            return `
              <button type="button" class="gallery-thumb-btn" data-img-idx="${idx}" aria-label="${caption}" title="${caption}">
                <img src="${imgPath}" alt="${caption}" loading="lazy" class="gallery-thumb-img" />
              </button>
            `;
          }).join('')}
        </div>
      </div>
    `;
  }

  function bindGalleryEvents() {
    if (!activeContainer) return;
    activeContainer.querySelectorAll('.gallery-thumb-img').forEach((img) => {
      img.addEventListener('error', () => {
        console.warn(`[CQ Discovery Gallery] Image missing or failed to load: ${img.src}`);
        img.src = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="200" height="140" fill="%231e293b"><rect width="100%" height="100%"/><text x="50%" y="50%" fill="%2394a3b8" text-anchor="middle" dominant-baseline="central" font-family="sans-serif" font-size="12">PHOTO INDISPONIBLE</text></svg>';
      }, { once: true });
    });

    activeContainer.querySelectorAll('.gallery-thumb-btn').forEach((btn) => {
      btn.onclick = () => {
        const idx = parseInt(btn.getAttribute('data-img-idx'), 10) || 0;
        if (window.CQ.challenges.discoveryLightbox) {
          window.CQ.challenges.discoveryLightbox.open(getActiveComponent(), idx, btn);
        }
      };
    });
  }

  function onImagesDiscovered(comp, images) {
    if (!activeContainer || comp.id !== activeComponentId || !activeContext) return;
    const gallerySection = activeContainer.querySelector('.discovery-gallery-section');
    if (!gallerySection) {
      const scrollArea = activeContainer.querySelector('#detail-scroll-area');
      if (scrollArea) {
        scrollArea.insertAdjacentHTML('beforeend', renderGalleryHtml(comp, activeContext.t));
        bindGalleryEvents();
      }
      return;
    }
    const strip = gallerySection.querySelector('.discovery-gallery-strip');
    if (strip) {
      const currentSrcs = Array.from(strip.querySelectorAll('.gallery-thumb-img')).map((img) =>
        img.getAttribute('src'),
      );
      const newSrcs = images.map((name) => `assets/images/discovery/${comp.id}/${name}`);
      if (currentSrcs.length === newSrcs.length && currentSrcs.every((s, i) => s === newSrcs[i])) {
        return;
      }

      const t = activeContext.t;
      strip.innerHTML = images.map((imgName, idx) => {
        const imgPath = `assets/images/discovery/${comp.id}/${imgName}`;
        const caption = getCaption(comp, idx, t);
        return `
          <button type="button" class="gallery-thumb-btn" data-img-idx="${idx}" aria-label="${caption}" title="${caption}">
            <img src="${imgPath}" alt="${caption}" loading="lazy" class="gallery-thumb-img" />
          </button>
        `;
      }).join('');
      bindGalleryEvents();
    }
  }

  function bindEvents(savedScrollTop) {
    const scrollArea = activeContainer.querySelector('#detail-scroll-area');
    const fadeEdge = activeContainer.querySelector('#detail-fade-edge');

    if (scrollArea) {
      scrollArea.scrollTop = savedScrollTop;
      const checkScroll = () => {
        if (!fadeEdge) return;
        const isBottom = scrollArea.scrollHeight - scrollArea.scrollTop - scrollArea.clientHeight < 12;
        fadeEdge.style.opacity = isBottom ? '0' : '1';
      };
      scrollArea.addEventListener('scroll', checkScroll);
      setTimeout(checkScroll, 50);
    }

    bindGalleryEvents();

    activeContainer.querySelectorAll('.workstation-component-hotspot, .chip-btn').forEach((el) => {
      const clickHandler = () => {
        const id = el.getAttribute('data-id');
        if (id && id !== activeComponentId) {
          activeComponentId = id;
          if (activeContext.audio) activeContext.audio.playSfx('click');
          render();
          const current = getActiveComponent();
          if (window.CQ.challenges.discoveryScanner) {
            window.CQ.challenges.discoveryScanner.scan(current);
          }
        }
      };
      el.addEventListener('click', clickHandler);
      el.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          clickHandler();
        }
      });
    });

    const btnNext = activeContainer.querySelector('#btnGoToLevel2');
    if (btnNext) {
      btnNext.addEventListener('click', () => {
        if (activeContext.audio) activeContext.audio.playSfx('complete');
        activeContext.complete({ discovered: Array.from(discoveredSet) });
      });
    }
  }

  function onLanguageChange() {
    if (activeContainer && activeContext) {
      render({ isLanguageSwitch: true });
      if (window.CQ.challenges.discoveryLightbox && window.CQ.challenges.discoveryLightbox.isOpen()) {
        window.CQ.challenges.discoveryLightbox.update();
      }
    }
  }

  window.CQ.challenges.register({
    id: 'discovery',
    order: 1,
    titleKey: 'tab0',
    icon: 'assets/icons/01-discovery.svg',
    mount(container, ctx) {
      activeContainer = container;
      activeContext = ctx;
      const saved = (ctx.progress && ctx.progress.discovered) || [];
      discoveredSet = new Set(saved);
      if (window.CQ.core.i18n && typeof window.CQ.core.i18n.addChangeListener === 'function') {
        window.CQ.core.i18n.addChangeListener(onLanguageChange);
      }
      if (window.CQ.challenges.discoveryScanner) {
        window.CQ.challenges.discoveryScanner.prewarmAll(getComponents());
        window.CQ.challenges.discoveryScanner.addListener(onImagesDiscovered);
        window.CQ.challenges.discoveryScanner.scan(getActiveComponent());
      }
      render();
    },
    start() {},
    onLanguageChange,
    destroy() {
      if (window.CQ.core.i18n && typeof window.CQ.core.i18n.removeChangeListener === 'function') {
        window.CQ.core.i18n.removeChangeListener(onLanguageChange);
      }
      if (window.CQ.challenges.discoveryScanner) {
        window.CQ.challenges.discoveryScanner.removeListener(onImagesDiscovered);
      }
      if (window.CQ.challenges.discoveryLightbox) {
        window.CQ.challenges.discoveryLightbox.close();
      }
      activeContainer = null;
      activeContext = null;
    },
  });
})();
