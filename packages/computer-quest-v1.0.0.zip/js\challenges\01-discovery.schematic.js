/**
 * Computer Quest — Challenge 1: Workstation Schematic SVG Generator
 * Generates interactive SVG schematic with trilingual component hotspot labels.
 */
window.CQ = window.CQ || {};
window.CQ.challenges = window.CQ.challenges || {};

window.CQ.challenges.discoverySchematic = {
  render(comp, t, isAr) {
    return `
      <svg class="workstation-svg-wrap" viewBox="0 0 600 420" xmlns="http://www.w3.org/2000/svg">
        <polygon points="20,290 80,240 520,240 580,290" fill="#1e293b" stroke="#334155" stroke-width="2" />
        <rect x="50" y="290" width="500" height="15" fill="#0f172a" stroke="#334155" stroke-width="1.5" />

        <!-- Monitor -->
        <g class="workstation-component-hotspot ${comp.id === 'ecran' ? 'active' : ''}" data-id="ecran" transform="translate(180, 50)" tabindex="0" role="button" aria-label="${t('discovery.ecran.name')}">
          <rect x="0" y="0" width="240" height="155" rx="6" fill="#0f172a" stroke="#38bdf8" stroke-width="2.5" />
          <rect x="10" y="10" width="220" height="135" rx="3" fill="#0284c7" fill-opacity="0.2" />
          <path d="M 100 155 L 140 155 L 145 190 L 95 190 Z" fill="#334155" stroke="#1e293b" stroke-width="1.5" />
          <ellipse cx="120" cy="190" rx="55" ry="9" fill="#1e293b" stroke="#38bdf8" stroke-width="2" />
          <text x="120" y="80" fill="#38bdf8" font-size="${isAr ? '12' : '13'}" font-weight="bold" text-anchor="middle" dominant-baseline="central">
            ${t('discovery.ecran.svgLabel')}
          </text>
        </g>

        <!-- Webcam -->
        <g class="workstation-component-hotspot ${comp.id === 'webcam' ? 'active' : ''}" data-id="webcam" transform="translate(285, 38)" tabindex="0" role="button" aria-label="${t('discovery.webcam.name')}">
          <rect x="0" y="0" width="30" height="12" rx="3" fill="#1e293b" stroke="#38bdf8" stroke-width="1.5" />
          <circle cx="15" cy="6" r="3.5" fill="#38bdf8" />
        </g>

        <!-- Tower -->
        <g class="workstation-component-hotspot ${comp.id === 'unite-centrale' ? 'active' : ''}" data-id="unite-centrale" transform="translate(450, 75)" tabindex="0" role="button" aria-label="${t('discovery.unite-centrale.name')}">
          <rect x="0" y="0" width="105" height="185" rx="5" fill="#1e293b" stroke="#f59e0b" stroke-width="2.5" />
          <circle cx="52" cy="25" r="7" stroke="#f59e0b" stroke-width="2" fill="#fbbf24" />
          <rect x="25" y="45" width="55" height="6" rx="2" fill="#0f172a" />
          <text x="52" y="120" fill="#fbbf24" font-size="${isAr ? '9.5' : '10.5'}" font-weight="bold" text-anchor="middle" dominant-baseline="central">
            ${t('discovery.unite-centrale.svgLabel')}
          </text>
        </g>

        <!-- USB Ports -->
        <g class="workstation-component-hotspot ${comp.id === 'ports-usb' ? 'active' : ''}" data-id="ports-usb" transform="translate(470, 135)" tabindex="0" role="button" aria-label="${t('discovery.ports-usb.name')}">
          <rect x="0" y="0" width="65" height="25" rx="3" fill="#0f172a" stroke="#38bdf8" stroke-width="1.5" />
          <rect x="10" y="7" width="18" height="10" rx="1" fill="#38bdf8" />
          <rect x="36" y="7" width="18" height="10" rx="1" fill="#38bdf8" />
          <text x="32" y="38" fill="#38bdf8" font-size="${isAr ? '8.5' : '9'}" font-weight="bold" text-anchor="middle">
            ${t('discovery.ports-usb.svgLabel')}
          </text>
        </g>

        <!-- Speakers -->
        <g class="workstation-component-hotspot ${comp.id === 'haut-parleurs' ? 'active' : ''}" data-id="haut-parleurs" transform="translate(125, 115)" tabindex="0" role="button" aria-label="${t('discovery.haut-parleurs.name')}">
          <rect x="0" y="0" width="38" height="95" rx="4" fill="#1e293b" stroke="#818cf8" stroke-width="2" />
          <circle cx="19" cy="30" r="11" stroke="#818cf8" stroke-width="1.5" />
          <circle cx="19" cy="65" r="14" stroke="#818cf8" stroke-width="2" />
        </g>

        <!-- Keyboard -->
        <g class="workstation-component-hotspot ${comp.id === 'clavier' ? 'active' : ''}" data-id="clavier" transform="translate(195, 260)" tabindex="0" role="button" aria-label="${t('discovery.clavier.name')}">
          <polygon points="0,35 15,0 205,0 220,35" fill="#1e293b" stroke="#10b981" stroke-width="2.5" />
          <rect x="65" y="20" width="90" height="8" rx="2" fill="#34d399" />
          <text x="110" y="14" fill="#34d399" font-size="${isAr ? '9.5' : '10.5'}" font-weight="bold" text-anchor="middle" dominant-baseline="central">
            ${t('discovery.clavier.svgLabel')}
          </text>
        </g>

        <!-- Mouse -->
        <g class="workstation-component-hotspot ${comp.id === 'souris' ? 'active' : ''}" data-id="souris" transform="translate(435, 268)" tabindex="0" role="button" aria-label="${t('discovery.souris.name')}">
          <ellipse cx="18" cy="20" rx="16" ry="24" fill="#1e293b" stroke="#10b981" stroke-width="2.5" />
          <line x1="18" y1="2" x2="18" y2="18" stroke="#10b981" stroke-width="1.5" />
          <text x="18" y="35" fill="#34d399" font-size="${isAr ? '9' : '10'}" font-weight="bold" text-anchor="middle">
            ${t('discovery.souris.svgLabel')}
          </text>
        </g>

        <!-- Printer -->
        <g class="workstation-component-hotspot ${comp.id === 'imprimante' ? 'active' : ''}" data-id="imprimante" transform="translate(30, 165)" tabindex="0" role="button" aria-label="${t('discovery.imprimante.name')}">
          <rect x="0" y="18" width="80" height="46" rx="4" fill="#1e293b" stroke="#a78bfa" stroke-width="2" />
          <rect x="15" y="2" width="50" height="18" rx="2" fill="#e2e8f0" stroke="#94a3b8" />
          <rect x="18" y="40" width="44" height="22" rx="1" fill="#f8fafc" stroke="#94a3b8" />
          <text x="40" y="32" fill="#a78bfa" font-size="${isAr ? '9.5' : '10'}" font-weight="bold" text-anchor="middle">
            ${t('discovery.imprimante.svgLabel')}
          </text>
        </g>
      </svg>
    `;
  }
};
