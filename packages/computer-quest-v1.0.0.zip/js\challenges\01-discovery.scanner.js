/**
 * Computer Quest — Challenge 1: Discovery Photo Scanner
 * Dynamically probes the local component folder for existing images (jpg, png, webp, svg).
 * Completely offline, zero network requests, DOM Image-based filesystem discovery.
 * Namespace: CQ.challenges.discoveryScanner
 */
window.CQ = window.CQ || {};
window.CQ.challenges = window.CQ.challenges || {};

window.CQ.challenges.discoveryScanner = (function () {
  const cache = new Map();
  const listeners = new Set();
  const EXTENSIONS = ['jpg', 'jpeg', 'png', 'webp', 'svg', 'avif'];
  const MAX_SLOTS = 8;

  function probeImage(src, timeout = 600) {
    return new Promise((resolve) => {
      const img = new Image();
      let done = false;
      const finish = (exists) => {
        if (!done) {
          done = true;
          img.onload = null;
          img.onerror = null;
          resolve(exists);
        }
      };
      img.onload = () => finish(true);
      img.onerror = () => finish(false);
      img.src = src;
      setTimeout(() => finish(false), timeout);
    });
  }

  function getBaseDir(componentId) {
    return `assets/images/discovery/${componentId}`;
  }

  function generateCandidatesForSlot(slotNum, compId) {
    const pad = String(slotNum).padStart(2, '0');
    const raw = String(slotNum);
    const stems = [pad, raw, `photo${slotNum}`, `photo-${slotNum}`, `image${slotNum}`, `image-${slotNum}`];
    if (slotNum === 1) {
      stems.push(compId, `${compId}-1`, `${compId}_1`, 'main', 'cover');
    } else {
      stems.push(`${compId}-${slotNum}`, `${compId}_${slotNum}`);
    }

    const candidates = [];
    stems.forEach((stem) => {
      EXTENSIONS.forEach((ext) => {
        candidates.push(`${stem}.${ext}`);
      });
    });
    return Array.from(new Set(candidates));
  }

  async function probeFirstMatch(componentId, candidateList) {
    const base = getBaseDir(componentId);
    for (const filename of candidateList) {
      const exists = await probeImage(`${base}/${filename}`);
      if (exists) {
        return filename;
      }
    }
    return null;
  }

  async function scan(comp, options = {}) {
    if (!comp || !comp.id) return [];
    if (!options.force && cache.has(comp.id)) {
      return cache.get(comp.id);
    }

    const discovered = [];
    const seenFiles = new Set();
    const satisfiedSlots = new Set();

    // Check pre-configured images first as high-priority candidates
    if (Array.isArray(comp.images)) {
      for (const imgName of comp.images) {
        const lowerKey = (imgName || '').toLowerCase();
        if (imgName && !seenFiles.has(lowerKey)) {
          const exists = await probeImage(`${getBaseDir(comp.id)}/${imgName}`);
          if (exists) {
            seenFiles.add(lowerKey);
            discovered.push(imgName);
            const m = imgName.match(/^0?(\d+)\./);
            if (m && m[1]) satisfiedSlots.add(parseInt(m[1], 10));
          }
        }
      }
    }

    // Sequentially probe numbered slots that are not yet satisfied
    let consecutiveMisses = 0;
    for (let slot = 1; slot <= MAX_SLOTS; slot++) {
      if (satisfiedSlots.has(slot)) {
        consecutiveMisses = 0;
        continue;
      }

      const candidates = generateCandidatesForSlot(slot, comp.id).filter(
        (f) => !seenFiles.has(f.toLowerCase()),
      );
      const match = await probeFirstMatch(comp.id, candidates);
      if (match) {
        seenFiles.add(match.toLowerCase());
        discovered.push(match);
        satisfiedSlots.add(slot);
        consecutiveMisses = 0;
      } else {
        consecutiveMisses++;
        if (consecutiveMisses >= 2 && slot >= 3) {
          break; // Stop after two consecutive empty slots
        }
      }
    }

    // Sort naturally (01 before 02, etc.)
    discovered.sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));

    const finalImages = discovered.length > 0 ? discovered : (comp.images || ['01.svg', '02.svg']);
    cache.set(comp.id, finalImages);
    comp.images = finalImages;

    listeners.forEach((fn) => {
      try {
        fn(comp, finalImages);
      } catch (e) {
        console.error('[CQ Discovery Scanner] Listener error:', e);
      }
    });

    return finalImages;
  }

  function prewarmAll(components) {
    if (!Array.isArray(components)) return;
    components.forEach((comp) => {
      scan(comp).catch(() => {});
    });
  }

  function addListener(fn) {
    listeners.add(fn);
  }

  function removeListener(fn) {
    listeners.delete(fn);
  }

  return {
    scan,
    prewarmAll,
    addListener,
    removeListener,
    getCached(componentId) {
      return cache.get(componentId) || null;
    },
  };
})();
