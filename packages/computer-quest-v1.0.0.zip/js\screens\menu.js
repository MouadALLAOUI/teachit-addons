/**
 * Computer Quest — Main Menu Screen
 * Full-screen layout: action buttons on left, game branding on right (mirrored in RTL).
 * Dependencies: CQ.core.storage, CQ.core.i18n, CQ.core.dialog, CQ.core.app
 */
window.CQ = window.CQ || {};
window.CQ.screens = window.CQ.screens || {};

(function () {
  const containerId = 'screen-menu';

  function onShow() {
    render();
    setupKeyboardNav();
  }

  function render() {
    const el = document.getElementById(containerId);
    if (!el) return;

    const t = window.CQ.core.i18n.t;
    const state = window.CQ.core.storage.load();
    const hasProgress = (state.completedChallenges && state.completedChallenges.length > 0) || state.currentChallenge > 0;
    const currentWorkshopNum = (state.currentChallenge || 0) + 1;

    el.innerHTML = `
      <div class="cq-menu-container">
        <!-- Left Column: Actions -->
        <div class="cq-menu-left">
          <div class="cq-menu-btn-stack" role="menu">
            ${
              hasProgress
                ? `
              <button type="button" class="cq-menu-btn primary" id="btn-menu-continue" role="menuitem">
                <span class="cq-menu-btn-icon">▶</span>
                <div class="cq-menu-btn-text">
                  <span class="cq-menu-btn-title">${t('menu.continue')}</span>
                  <span class="cq-menu-btn-sub">${t('menu.continueSub')} (${currentWorkshopNum}/5)</span>
                </div>
              </button>
            `
                : ''
            }

            <button type="button" class="cq-menu-btn ${!hasProgress ? 'primary' : ''}" id="btn-menu-start" role="menuitem">
              <span class="cq-menu-btn-icon">⚡</span>
              <div class="cq-menu-btn-text">
                <span class="cq-menu-btn-title">${t('menu.start')}</span>
                <span class="cq-menu-btn-sub">${t('menu.startSub')}</span>
              </div>
            </button>

            <button type="button" class="cq-menu-btn" id="btn-menu-settings" role="menuitem">
              <span class="cq-menu-btn-icon">⚙</span>
              <div class="cq-menu-btn-text">
                <span class="cq-menu-btn-title">${t('menu.settings')}</span>
                <span class="cq-menu-btn-sub">${t('menu.settingsSub')}</span>
              </div>
            </button>

            <button type="button" class="cq-menu-btn" id="btn-menu-about" role="menuitem">
              <span class="cq-menu-btn-icon">ℹ</span>
              <div class="cq-menu-btn-text">
                <span class="cq-menu-btn-title">${t('menu.about')}</span>
                <span class="cq-menu-btn-sub">${t('menu.aboutSub')}</span>
              </div>
            </button>

            <button type="button" class="cq-menu-btn danger" id="btn-menu-exit" role="menuitem">
              <span class="cq-menu-btn-icon">🚪</span>
              <div class="cq-menu-btn-text">
                <span class="cq-menu-btn-title">${t('menu.exit')}</span>
              </div>
            </button>
          </div>
        </div>

        <!-- Right Column: Branding -->
        <div class="cq-menu-right">
          <div class="cq-menu-badge">TEACHIT EDUCATION</div>
          <h1 class="cq-menu-title">${t('brandTitle')}</h1>
          <p class="cq-menu-tagline">${t('menu.tagline')}</p>
          <div class="cq-menu-meta">
            <span class="cq-version-tag">v${(window.CQ.config && window.CQ.config.version) || '2.0.0'}</span>
            <span class="cq-offline-tag">${t('badgeOffline')}</span>
          </div>
        </div>
      </div>
    `;

    // Bind Button Clicks
    const btnContinue = document.getElementById('btn-menu-continue');
    if (btnContinue) {
      btnContinue.addEventListener('click', () => {
        if (window.CQ.core.audio) window.CQ.core.audio.playSfx('confirm');
        window.CQ.core.app.launchChallenge(state.currentChallenge || 0);
      });
    }

    const btnStart = document.getElementById('btn-menu-start');
    if (btnStart) {
      btnStart.addEventListener('click', () => {
        if (hasProgress) {
          window.CQ.core.dialog.confirm({
            title: t('dialog.confirmStartTitle'),
            message: t('dialog.confirmStartMsg'),
            confirmText: t('dialog.confirm'),
            cancelText: t('dialog.cancel'),
            isDestructive: true,
            onConfirm: () => {
              window.CQ.core.storage.reset();
              window.CQ.core.app.launchChallenge(0);
            },
          });
        } else {
          if (window.CQ.core.audio) window.CQ.core.audio.playSfx('confirm');
          window.CQ.core.app.launchChallenge(0);
        }
      });
    }

    document.getElementById('btn-menu-settings')?.addEventListener('click', () => {
      if (window.CQ.core.audio) window.CQ.core.audio.playSfx('click');
      window.CQ.core.screens.show('settings');
    });

    document.getElementById('btn-menu-about')?.addEventListener('click', () => {
      if (window.CQ.core.audio) window.CQ.core.audio.playSfx('click');
      window.CQ.core.screens.show('about');
    });

    document.getElementById('btn-menu-exit')?.addEventListener('click', () => {
      window.CQ.core.app.confirmExitToTeachit();
    });
  }

  function setupKeyboardNav() {
    const keyHandler = (e) => {
      if (window.CQ.core.screens.getCurrent() !== 'menu') return;
      const buttons = Array.from(document.querySelectorAll('.cq-menu-btn'));
      if (!buttons.length) return;

      const activeIdx = buttons.indexOf(document.activeElement);

      if (e.key === 'ArrowDown') {
        e.preventDefault();
        const nextIdx = (activeIdx + 1) % buttons.length;
        buttons[nextIdx].focus();
        if (window.CQ.core.audio) window.CQ.core.audio.playSfx('hover');
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        const prevIdx = (activeIdx - 1 + buttons.length) % buttons.length;
        buttons[prevIdx].focus();
        if (window.CQ.core.audio) window.CQ.core.audio.playSfx('hover');
      } else if (e.key === 'Escape') {
        window.CQ.core.app.confirmExitToTeachit();
      }
    };

    window.removeEventListener('keydown', window._cq_menu_key);
    window._cq_menu_key = keyHandler;
    window.addEventListener('keydown', keyHandler);
  }

  window.CQ.screens.menu = {
    onShow,
    render,
  };
})();
