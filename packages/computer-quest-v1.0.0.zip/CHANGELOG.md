# CHANGELOG — Computer Quest Refactoring & Upgrade

## Version 2.1.2 (2026-10-31) — Workshop 5 Recovery, Assembly Matching & Multilingual Polish

### Fixes & Enhancements
1. **Restored All 5 Workshops (Tab Bar & Registration):**
   - Fixed a rogue syntax error at the tail of `05-final.js`, restoring the registration of Workshop 5 (*Défi final*).
   - All 5 workshops (`Découverte`, `Reconnaissance`, `Fonctions`, `Assemblage`, `Défi final`) are now registered and rendered in the navigation tab bar.
2. **Fixed "undefined" Category Badges (Workshops 2 & 3):**
   - Corrected property lookup to use `comp.typeLabelFr`, `comp.typeLabelAr`, and `comp.typeLabelEn` instead of missing `categoryKey`.
   - Component badges now display proper peripheral classifications (e.g. *Périphérique d'entrée*, *Périphérique de pointage*, *وحدة إدخال النصوص*) across all languages.
3. **Upgraded Assembly Station to Real Name-to-Icon Matching (Workshop 4):**
   - Transformed the assembly workshop from identical icon-on-icon dragging to an educational recognition puzzle:
     - Desk drop slots show ONLY the hardware SVG icon/silhouette and a question mark `?` (name is hidden until placed).
     - Draggable items in the tray show ONLY the component name on a label card with a randomized tray order.
     - Students must recognize which component name corresponds to which physical silhouette on the desk.
     - Successful placement locks the slot, illuminates the icon, and reveals the confirmed name with a green checkmark (`✓`).
4. **Instant In-Place Language Switching Across All Workshops:**
   - Wired `i18n.addChangeListener` into the core app and added `onLanguageChange()` handlers to Workshops 2, 3, 4, and 5.
   - Toggling language in the top header switcher now immediately updates the tab bar titles, question prompts, component names, descriptions, and buttons in real time without reloading.

---

## Version 2.1.1 (2026-10-31) — Workshop Gameplay & Progression Refinements

### Fixes & Enhancements
1. **Dynamic Answer Shuffling (Workshops 2, 3, and 5):**
   - Implemented Fisher-Yates array shuffling on every challenge run.
   - Workshop 2 (*Reconnaissance*), Workshop 3 (*Fonctions*), and Workshop 5 (*Défi final*) now display answer choices in a randomized order every time, eliminating predictable first-position answers while maintaining accurate score tracking.
2. **Workshop 4 (PC Assembly) Crash Resolution:**
   - Resolved `TypeError: object is not iterable` in `04-assembly.js` by safely normalizing stored progress (`ctx.progress.placed`) regardless of whether it was stored as an Array or an Object.
   - Updated default state in `storage.js` to `placed: []` with automatic migration for legacy saves.
   - Added trilingual component labeling for desktop assembly targets.
3. **Linear Workshop Progression & Tab Locking:**
   - Enforced strict linear workshop progression: players cannot jump ahead to subsequent workshops without completing prior ones.
   - Locked tabs show a lock badge (`🔒`), are disabled with `aria-disabled="true"`, and trigger an audio warning if clicked.
   - Direct launch attempts through URL/storage tampering redirect automatically to the highest unlocked workshop.

---

## Version 2.1.0 (2026-10-31) — Level 1 "Découverte" Overhaul & Shared UI Enhancements

### Features & Improvements
1. **Bilingual / Trilingual Data-Driven Architecture (Level 1):**
   - Extracted structural component data into `js/data/discovery-components.js` (IDs, categories, icons, and image paths only; zero hardcoded display text).
   - Moved all component names, definitions, "Le savais-tu ?" tips, SVG hotspot labels, and gallery captions into trilingual dictionaries (`fr.js`, `ar.js`, `en.js`).
   - Switching language instantly re-renders Level 1 without page reload while preserving selected component, discovery status, progress, and scroll position.
   - Spatial workstation SVG stays oriented realistically in RTL mode, with localized text labels dynamically scaled to prevent clipping.
   - Added `TODO: Native-speaker review needed` tags in `ar.js` and `en.js`.
   - Added development missing-translation auditing via `CQ.i18n.auditTranslations()`.

2. **Persistent Global Header & Language Switcher:**
   - Added high-contrast, accessible segmented language switcher (`العربية` | `Français` | `English`) to the persistent header across all screens (menu, all levels, settings, about).
   - Buttons are ≥40px tall with clear active indicators and keyboard focus rings.
   - Moved student session UUID badge to the About screen for a clean, distraction-free header.

3. **Fixed-Height, Scrollable Description Panel:**
   - Level 1 now strictly fits 100vh viewport without whole-page scrolling across 1280×720, 1366×768, and 1920×1080 resolutions.
   - Component chips header and progress counter footer remain fixed; only the middle detail content scrolls (`overflow-y: auto`, `tabindex="0"`, custom high-contrast scrollbar, soft bottom fade edge).
   - Scroll position resets cleanly when a new component is selected.

4. **Interactive Component Photo Gallery & Lightbox:**
   - Created thumbnail strip and full-screen modal lightbox (`js/challenges/01-discovery.lightbox.js` and `css/challenges/01-discovery.gallery.css`).
   - Keyboard accessible (Left/Right arrows, Escape), focus trap with restoration on close, backdrop click dismissal, and RTL navigation mirroring.
   - Generated 16 offline placeholder SVGs across all 8 hardware components (`assets/images/discovery/<componentId>/`).
   - Viewing photos does not modify discovery progression counters.

5. **Modularity & Code Standard Compliance:**
   - Split Level 1 logic into `01-discovery.schematic.js`, `01-discovery.lightbox.js`, and `01-discovery.js`.
   - Split styles into `01-discovery.css` and `01-discovery.gallery.css`.
   - All files adhere strictly to the ≤300 line limit.

---

## Version 2.0.0 (2026-10-31)

### Overview
Refactored the monolithic, single-file implementation of **Computer Quest** into a modular, multi-file architecture with a full-screen game menu, WebAudio sound system, customizable settings, and trilingual support (French, Arabic, English).

---

### What Moved Where (Mapping from Legacy Monolith)

| Legacy Section in `scripts.js` / `styles.css` | New File Location | Description |
| :--- | :--- | :--- |
| `COMPONENTS` metadata (lines 35–160) | `js/config.js` | Centralized hardware component specifications (names, roles, fun facts, icons) |
| `TRANSLATIONS.fr` & `TRANSLATIONS.ar` (lines 162–312) | `js/i18n/fr.js`, `js/i18n/ar.js`, `js/i18n/en.js` | Extracted into modular dictionaries; added English localization and menu strings |
| `LEVEL_2_QUESTIONS` (lines 315–370) | `js/challenges/02-recognition.js` | Visual recognition question bank & self-contained quiz lifecycle |
| `LEVEL_3_QUESTIONS` (lines 371–428) | `js/challenges/03-functions.js` | Role & function matching question bank & choice grid |
| `LEVEL_5_QUESTIONS` (lines 429–570) | `js/challenges/05-final.js` | Final comprehensive evaluation and rank calculation |
| SVG Graphics Generator (lines 572–642) | `assets/icons/*.svg` | Dedicated vector SVG icon assets in `assets/icons/` |
| `ComputerQuestEngine` class (lines 644–760) | `js/core/challenges.js` & `scripts.js` facade | Modular challenge registry contract + backward-compatible test facade |
| TeachIT IPC hooks & Session (lines 762–780) | `js/core/app.js` | Typed IPC communication, session retrieval, and student ID badge |
| UI State & Screen switching (lines 845–970) | `js/core/screens.js`, `js/core/app.js` | Clean view coordinator handling menu, settings, about, and game views |
| Level 1: Découverte (lines 980–1154) | `js/challenges/01-discovery.js` | Interactive workstation schematic with hotspot SVG and detail panel |
| Level 2: Reconnaissance (lines 1155–1252) | `js/challenges/02-recognition.js` | Choice cards, explanation card, and scoring |
| Level 3: Fonctions (lines 1253–1350) | `js/challenges/03-functions.js` | Role questions and choice grid |
| Level 4: Assemblage (lines 1351–1510) | `js/challenges/04-assembly.js` | Drag-and-drop desk drop zones & click-to-place accessibility |
| Level 5: Défi final & Bilan (lines 1511–1650) | `js/challenges/05-final.js` | Final evaluation, accuracy scoring, and rank display |
| Monolithic CSS (`styles.css`, 1243 lines) | `css/base.css`, `css/ui.css`, `css/menu.css`, `css/challenges/*.css` | Split into modular stylesheets with `@import` master bundle |
| New Full-Screen Menu & Background | `js/screens/menu.js`, `css/menu.css`, `js/core/app.js` | Responsive circuit background with floating silhouettes and vertical action stack |
| New Settings Screen | `js/screens/settings.js` | Independent SFX/music volume sliders, toggles, language switcher, reset progress |
| New About Screen | `js/screens/about.js` | Pedagogical mission, TeachIT platform linkage, version tag, student badge |
| New Audio Synthesizer | `js/core/audio.js` | 100% procedural WebAudio synth (ambient loop + 8 SFX) |
| New Persistence Layer | `js/core/storage.js` | Safe `localStorage` under `teachit.computerquest.v1` with migration fallbacks |

---

### Key Architectural Assumptions & Design Decisions

1. **Launcher Integration Test Compatibility:**
   - The launcher test suite (`apps/launcher/tests/game-computer-quest.test.ts`) verifies the engine by reading `scripts.js` directly with `fs.readFileSync` and evaluating `ComputerQuestEngine`, `COMPONENTS`, and `TRANSLATIONS`.
   - `scripts.js` was preserved as an export facade to maintain 100% test compatibility while `index.html` loads the modular `CQ` architecture.

2. **No Build Step / No ES Modules:**
   - To avoid Electron `file://` CORS/MIME-type module loading restrictions, all modules attach cleanly to `window.CQ` via IIFE closures.

3. **Offline & Safety Boundaries:**
   - Zero remote network requests or CDNs.
   - All audio synthesized procedurally with WebAudio API.
   - `prefers-reduced-motion` halts canvas animations and transitions.

4. **Persistence Migration:**
   - Saves under `localStorage["teachit.computerquest.v1"]`.
   - Gracefully handles storage access failures without throwing exceptions.
