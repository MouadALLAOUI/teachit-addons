# Audio Assets

Computer Quest uses 100% synthetic procedural WebAudio generated in real-time via `js/core/audio.js`.
No external or copyrighted audio files are loaded at runtime, fulfilling the 100% offline educational constraint.
