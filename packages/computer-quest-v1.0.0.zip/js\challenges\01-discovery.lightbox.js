/**
 * Computer Quest — Challenge 1: Discovery Photo Lightbox Overlay
 * Full-screen accessible image viewer with keyboard navigation and focus trapping.
 * Dependencies: CQ.core.i18n, CQ.core.audio
 */
window.CQ = window.CQ || {};
window.CQ.challenges = window.CQ.challenges || {};
window.CQ.challenges.discoveryLightbox = (function () {
  let lightboxState = null;
  let lastFocusedEl = null;

  function open(comp, index, triggerEl) {
    if (!comp || !comp.images || comp.images.length === 0) return;
    lastFocusedEl = triggerEl;
    lightboxState = { comp, index: Math.max(0, Math.min(index, comp.images.length - 1)) };
    render();
  }

  function render() {
    const host = document.getElementById('cq-lightbox-host');
    if (!host || !lightboxState) return;

    const { comp, index } = lightboxState;
    const t = window.CQ.core.i18n.t;
    const isAr = window.CQ.core.i18n.isRtl();
    const imgName = comp.images[index] || comp.images[0] || '';
    const imgPath = `assets/images/discovery/${comp.id}/${imgName}`;
    const rawCaption = t(`discovery.${comp.id}.image.${index + 1}.caption`);
    const caption = (rawCaption && !rawCaption.startsWith('discovery.'))
      ? rawCaption
      : `${t('discovery.' + comp.id + '.name')} — Photo ${index + 1}`;
    const counterText = t('discovery.gallery.counter', { current: index + 1, total: comp.images.length });

    host.innerHTML = `
      <div class="cq-lightbox-overlay" role="dialog" aria-modal="true" aria-label="${caption}">
        <div class="cq-lightbox-card">
          <div class="cq-lightbox-top-bar">
            <span class="cq-lightbox-counter">${counterText}</span>
            <button type="button" class="cq-lightbox-close" id="btn-lb-close" aria-label="${t('discovery.gallery.close')}" title="${t('discovery.gallery.close')}">✕</button>
          </div>

          <div class="cq-lightbox-body">
            <button type="button" class="cq-lightbox-nav prev" id="btn-lb-prev" aria-label="${t('discovery.gallery.prev')}">
              ${isAr ? '➔' : '←'}
            </button>
            <div class="cq-lightbox-img-wrap">
              <img src="${imgPath}" alt="${caption}" class="cq-lightbox-img" id="lb-current-img" />
            </div>
            <button type="button" class="cq-lightbox-nav next" id="btn-lb-next" aria-label="${t('discovery.gallery.next')}">
              ${isAr ? '←' : '➔'}
            </button>
          </div>

          <div class="cq-lightbox-caption">${caption}</div>
        </div>
      </div>
    `;

    const overlay = host.querySelector('.cq-lightbox-overlay');
    const closeBtn = host.querySelector('#btn-lb-close');
    const prevBtn = host.querySelector('#btn-lb-prev');
    const nextBtn = host.querySelector('#btn-lb-next');
    const imgEl = host.querySelector('#lb-current-img');

    imgEl?.addEventListener('error', () => {
      console.warn(`[CQ Lightbox] Image failed to load: ${imgEl.src}`);
      imgEl.src = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="600" height="400" fill="%231e293b"><rect width="100%" height="100%"/><text x="50%" y="50%" fill="%2394a3b8" text-anchor="middle" dominant-baseline="central" font-family="sans-serif" font-size="16">IMAGE INDISPONIBLE</text></svg>';
    }, { once: true });

    closeBtn?.addEventListener('click', close);
    prevBtn?.addEventListener('click', () => step(isAr ? 1 : -1));
    nextBtn?.addEventListener('click', () => step(isAr ? -1 : 1));

    overlay?.addEventListener('click', (e) => {
      if (e.target === overlay) close();
    });

    window.removeEventListener('keydown', keyListener);
    window.addEventListener('keydown', keyListener);

    setTimeout(() => closeBtn?.focus(), 50);
  }

  function step(dir) {
    if (!lightboxState) return;
    const count = lightboxState.comp.images.length;
    lightboxState.index = (lightboxState.index + dir + count) % count;
    if (window.CQ.core.audio) window.CQ.core.audio.playSfx('hover');
    render();
  }

  function close() {
    const host = document.getElementById('cq-lightbox-host');
    if (host) host.innerHTML = '';
    lightboxState = null;
    window.removeEventListener('keydown', keyListener);
    if (lastFocusedEl) {
      lastFocusedEl.focus();
      lastFocusedEl = null;
    }
  }

  function keyListener(e) {
    if (!lightboxState) return;
    const isAr = window.CQ.core.i18n.isRtl();
    if (e.key === 'Escape') {
      e.preventDefault();
      close();
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault();
      step(isAr ? 1 : -1);
    } else if (e.key === 'ArrowRight') {
      e.preventDefault();
      step(isAr ? -1 : 1);
    } else if (e.key === 'Tab') {
      const closeBtn = document.getElementById('btn-lb-close');
      const prevBtn = document.getElementById('btn-lb-prev');
      const nextBtn = document.getElementById('btn-lb-next');
      const focusable = [closeBtn, prevBtn, nextBtn].filter(Boolean);
      const idx = focusable.indexOf(document.activeElement);
      if (e.shiftKey && idx <= 0) {
        e.preventDefault();
        focusable[focusable.length - 1].focus();
      } else if (!e.shiftKey && idx === focusable.length - 1) {
        e.preventDefault();
        focusable[0].focus();
      }
    }
  }

  return {
    open,
    close,
    isOpen: () => !!lightboxState,
    update: () => {
      if (lightboxState) render();
    },
  };
})();
