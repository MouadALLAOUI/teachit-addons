# Font Assets

Computer Quest relies on native high-legibility system fonts (`Segoe UI`, `Cairo`, and system Arabic fallbacks) already bundled with Windows 10/11, ensuring zero network traffic and instantaneous loading.
