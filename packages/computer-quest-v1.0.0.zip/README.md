# Computer Quest — Educational Game Documentation

**Computer Quest** (`computer-quest`) is an offline-first educational desktop workshop game integrated within the **TeachIT** Windows launcher. It teaches computer architecture, hardware components, and peripherals to Moroccan middle-school students (_informatique_).

---

## 1. Project Structure & Architecture

The game is built with zero runtime bundler dependencies (plain HTML5, CSS3, and modern JavaScript running directly via Chromium / Electron `file://` protocol). Every module attaches to the centralized namespace `window.CQ`.

```text
computer-quest/
├── index.html                  # Main markup and ordered script/link declarations
├── README.md                   # Architecture documentation and extension guide
├── CHANGELOG.md                # Migration map and version history
├── game.json                   # TeachIT launcher metadata and manifest
├── thumbnail.svg               # Launcher grid cover art
├── styles.css                  # Unified stylesheet bundle (@import master)
├── scripts.js                  # Backward-compatibility engine and launcher facade
├── css/
│   ├── base.css                # CSS variables, typography, reset, RTL helpers
│   ├── ui.css                  # Persistent header, buttons, modals, tabs, controls
│   ├── menu.css                # Full-screen menu, settings, about screens
│   ├── panels.css              # Generic panel layouts
│   └── challenges/             # Modular challenge stylesheets
│       ├── 01-discovery.css    # Level 1 workstation schematic & scrollable panel
│       ├── 01-discovery.gallery.css # Level 1 photo gallery grid & lightbox modal
│       ├── 02-recognition.css
│       ├── 03-functions.css
│       ├── 04-assembly.css
│       └── 05-final.css
├── js/
│   ├── config.js               # Metadata, version, components, challenge order
│   ├── data/
│   │   └── discovery-components.js # Structural component metadata (no display text)
│   ├── core/                   # Core game services
│   │   ├── storage.js          # Persistent save/load under teachit.computerquest.v1
│   │   ├── i18n.js             # Translation engine (t, setLanguage, RTL dir)
│   │   ├── audio.js            # Procedural WebAudio synth (music + SFX)
│   │   ├── dialog.js           # Accessible confirmation modal helper
│   │   ├── challenges.js       # Modular workshop registry & lifecycle manager
│   │   ├── screens.js          # High-level screen navigation (Menu/Settings/Game)
│   │   └── app.js              # Application boot and lifecycle management
│   ├── screens/                # Full-screen views
│   │   ├── menu.js             # Full-screen main menu with keyboard nav
│   │   ├── settings.js         # Sound/music toggles, sliders, language selector
│   │   └── about.js            # Pedagogical info, version, student UUID badge
│   ├── challenges/             # Self-contained workshops
│   │   ├── 01-discovery.schematic.js # SVG workstation generator & hotspot labels
│   │   ├── 01-discovery.lightbox.js  # Accessible full-screen photo lightbox
│   │   ├── 01-discovery.js     # Workshop 1: Interactive Schematic controller
│   │   ├── 02-recognition.js   # Workshop 2: Visual Recognition
│   │   ├── 03-functions.js     # Workshop 3: Role & Function Matching
│   │   ├── 04-assembly.js      # Workshop 4: PC Assembly Station
│   │   └── 05-final.js         # Workshop 5: Final Evaluation & Results
│   └── i18n/                   # Translation dictionaries
│       ├── fr.js               # French (default)
│       ├── ar.js               # Arabic (RTL) — Moroccan Informatique curriculum
│       └── en.js               # English
└── assets/
    ├── icons/                  # Local SVG component & challenge vector icons
    ├── images/                 # Local raster & vector imagery
    │   └── discovery/          # High-resolution component photos (<id>/01.svg, etc.)
    ├── audio/                  # Offline audio notes (WebAudio synthesizer used)
    ├── video/                  # Offline video notes
    └── fonts/                  # Offline system-fallback fonts
```

---

## 2. How to Add a New Challenge

To add a new challenge (e.g., `06-network.js`), follow these 4 simple steps:

### Step 1: Create the Challenge Script
Create `js/challenges/06-network.js`:
```javascript
window.CQ.challenges.register({
  id: 'network',
  order: 6,
  titleKey: 'tab5',
  icon: 'assets/icons/06-network.svg',
  mount(container, ctx) {
    // Build your UI inside container using ctx.t(), ctx.audio, etc.
    container.innerHTML = `<h2>${ctx.t('networkTitle')}</h2>`;
  },
  start() {
    // Start timers, listeners, animations
  },
  destroy() {
    // Clean up event listeners, timers, and audio nodes
  }
});
```

### Step 2: Create the Challenge CSS
Create `css/challenges/06-network.css` with your workshop styles, and add an `@import` in `styles.css`.

### Step 3: Register in Config
In `js/config.js`, add your new challenge to the `CQ.config.challenges` array:
```javascript
{ id: 'network', order: 6, titleKey: 'tab5', icon: 'assets/icons/06-network.svg' }
```

### Step 4: Link in `index.html`
Add the CSS `<link>` tag in the `<head>` and the `<script>` tag in the body:
```html
<link rel="stylesheet" href="./css/challenges/06-network.css" />
...
<script src="./js/challenges/06-network.js"></script>
```

---

## 3. How to Add a New Language

To add a new language (e.g., Spanish `es`):

1. **Create the Dictionary File:**
   Create `js/i18n/es.js`:
   ```javascript
   window.CQ = window.CQ || {};
   window.CQ.i18n = window.CQ.i18n || {};
   window.CQ.i18n.es = {
     brandTitle: 'Misión Ordenador',
     // ... copy all keys from fr.js and translate
   };
   ```

2. **Add Script Tag to `index.html`:**
   ```html
   <script src="./js/i18n/es.js"></script>
   ```

3. **Add Button to Settings:**
   In `js/screens/settings.js`, add an `es` button inside `.cq-lang-picker`:
   ```html
   <button type="button" class="cq-lang-btn" data-lang="es">Español</button>
   ```

4. **Add to `setLanguage` Validation:**
   In `js/core/i18n.js`, ensure `['fr', 'ar', 'en', 'es'].includes(lang)`.

---

## 4. Offline & Security Constraints

- **Zero Network Calls:** No remote CDNs, Google Fonts, or external tracking scripts.
- **Strict CSP:** Enforced via `<meta http-equiv="Content-Security-Policy">`.
- **Procedural Audio:** 100% WebAudio synthetic sounds and arpeggios (no copyrighted audio files).
- **Reduced Motion:** Halts floating background silhouettes and CSS animations when `prefers-reduced-motion` is detected.

---

## 5. Adding or Replacing Gallery Photos

Level 1 (*Découverte*) includes an interactive photo gallery and lightbox modal for each hardware component.

### Directory Structure & Automatic Discovery
Photos are organized by component ID under `assets/images/discovery/`:
```text
assets/images/discovery/
├── clavier/          (01.jpg, 02.svg, etc.)
├── ecran/            (01.svg, 02.svg, etc.)
├── unite-centrale/   (01.svg, 02.svg, etc.)
├── souris/           (01.svg, 02.svg, etc.)
├── haut-parleurs/    (01.svg, 02.svg, etc.)
├── webcam/           (01.svg, 02.svg, etc.)
├── imprimante/       (01.svg, 02.svg, etc.)
└── ports-usb/        (01.svg, 02.svg, etc.)
```

The game features an **offline dynamic image scanner** (`js/challenges/01-discovery.scanner.js`). You do **not** need to edit code to add or replace photos:
- When you place an image such as `01.jpg`, `02.png`, `01.webp`, etc., in any component's folder, the scanner automatically detects it, verifies that it loads cleanly on disk, and immediately displays it in the component's photo gallery strip and lightbox viewer.
- Supported extensions: `.jpg`, `.jpeg`, `.png`, `.webp`, `.svg`, `.avif` (case-insensitive).
- Supported slot naming: `01` to `08`, `1` to `8`, `photo1` to `photo8`, `<componentId>-1`, etc.

### Image Specifications
- **Recommended Resolution:** ~1600px long side (1600×900 or 1600×1200).
- **File Size:** Under 300 KB per photo (use compressed `.webp` or `.jpg`).
- **Aspect Ratio:** 16:9 or 4:3 preferred.
- **Offline Safety:** All assets must remain local inside the game directory.

### Adding or Replacing Photos
1. Drop your photo file into `assets/images/discovery/<componentId>/` (e.g. `01.jpg` into `clavier/`).
2. Reload or launch the game; the photo gallery dynamically discovers and displays it.
3. (Optional) Provide custom localized captions in:
   - `js/i18n/fr.js` under `discovery.<componentId>.image.1.caption`
   - `js/i18n/ar.js` under `discovery.<componentId>.image.1.caption`
   - `js/i18n/en.js` under `discovery.<componentId>.image.1.caption`

> **Note:** The included vector SVG files in `assets/images/discovery/*` are standalone placeholders containing technical schematic diagrams and marked "replace me". They are fully operational offline until photographic assets are loaded. Missing images gracefully fallback to a placeholder card without throwing errors.
