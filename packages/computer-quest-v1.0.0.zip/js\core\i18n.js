/**
 * Computer Quest — i18n Translation Engine
 * Handles string lookups, parameter interpolation, and instant RTL/LTR switching.
 * Dependencies: CQ.i18n (fr, ar, en), CQ.core.storage
 */
window.CQ = window.CQ || {};
window.CQ.core = window.CQ.core || {};

(function () {
  let currentLang = 'fr';
  const listeners = [];

  function t(key, params) {
    const dict = (window.CQ.i18n && window.CQ.i18n[currentLang]) || (window.CQ.i18n && window.CQ.i18n.fr) || {};
    let val = dict[key];

    if (val === undefined) {
      const fallback = (window.CQ.i18n && window.CQ.i18n.fr) || {};
      val = fallback[key];
    }

    if (val === undefined) {
      console.warn(`[CQ i18n] Missing translation for key: "${key}" (lang: ${currentLang})`);
      return key;
    }

    if (params && typeof params === 'object') {
      return Object.keys(params).reduce((str, paramKey) => {
        return str.replace(new RegExp(`\\{${paramKey}\\}`, 'g'), params[paramKey]);
      }, val);
    }

    return val;
  }

  function setLanguage(lang) {
    if (!['fr', 'ar', 'en'].includes(lang)) {
      lang = 'fr';
    }
    currentLang = lang;
    const isRtl = lang === 'ar';

    document.documentElement.lang = lang;
    document.documentElement.dir = isRtl ? 'rtl' : 'ltr';

    if (document.body) {
      document.body.classList.toggle('rtl', isRtl);
    }

    // Persist language choice in game storage
    if (window.CQ.core.storage && typeof window.CQ.core.storage.save === 'function') {
      window.CQ.core.storage.save({ settings: { lang } });
    }

    // Synchronize language buttons across header and settings
    document.querySelectorAll('.cq-lang-pill-btn, .cq-lang-btn').forEach((btn) => {
      const btnLang = btn.getAttribute('data-lang');
      const isActive = btnLang === lang;
      btn.classList.toggle('active', isActive);
      btn.setAttribute('aria-pressed', isActive ? 'true' : 'false');
    });

    // Refresh all data-i18n text nodes
    document.querySelectorAll('[data-i18n]').forEach((el) => {
      const key = el.getAttribute('data-i18n');
      if (key) {
        el.textContent = t(key);
      }
    });

    document.querySelectorAll('[data-i18n-title]').forEach((el) => {
      const key = el.getAttribute('data-i18n-title');
      if (key) {
        el.setAttribute('title', t(key));
      }
    });

    document.querySelectorAll('[data-i18n-aria]').forEach((el) => {
      const key = el.getAttribute('data-i18n-aria');
      if (key) {
        el.setAttribute('aria-label', t(key));
      }
    });

    // Notify registered listeners (challenges, screens, etc.)
    listeners.forEach((fn) => {
      try {
        fn(lang);
      } catch (e) {
        console.warn('[CQ i18n] Error in change listener:', e);
      }
    });

    if (window.CQ.core.i18n.onChange) {
      window.CQ.core.i18n.onChange(lang);
    }
  }

  function addChangeListener(fn) {
    if (typeof fn === 'function' && !listeners.includes(fn)) {
      listeners.push(fn);
    }
  }

  function removeChangeListener(fn) {
    const idx = listeners.indexOf(fn);
    if (idx !== -1) listeners.splice(idx, 1);
  }

  // Dev-only translation completeness auditor
  function auditTranslations() {
    const frKeys = Object.keys((window.CQ.i18n && window.CQ.i18n.fr) || {});
    ['ar', 'en'].forEach((lang) => {
      const langDict = (window.CQ.i18n && window.CQ.i18n[lang]) || {};
      const missing = frKeys.filter((k) => langDict[k] === undefined);
      if (missing.length > 0) {
        console.warn(`[CQ i18n Audit] Language "${lang}" is missing ${missing.length} keys:`, missing);
      }
    });
  }

  window.CQ.core.i18n = {
    t,
    setLanguage,
    getLanguage: () => currentLang,
    isRtl: () => currentLang === 'ar',
    addChangeListener,
    removeChangeListener,
    auditTranslations,
    onChange: null,
  };
})();
