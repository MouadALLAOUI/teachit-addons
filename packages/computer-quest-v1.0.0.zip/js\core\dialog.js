/**
 * Computer Quest — Dialog Helper
 * Accessible modal confirmations with focus trapping and default Stay button.
 * Dependencies: CQ.core.i18n, CQ.core.audio
 */
window.CQ = window.CQ || {};
window.CQ.core = window.CQ.core || {};

(function () {
  let activeOverlay = null;

  function showConfirm(options) {
    const {
      title = '',
      message = '',
      confirmText = 'Confirmer',
      cancelText = 'Annuler',
      isDestructive = false,
      onConfirm = () => {},
      onCancel = () => {},
    } = options;

    close();

    const overlay = document.createElement('div');
    overlay.className = 'cq-dialog-overlay';
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');

    const modal = document.createElement('div');
    modal.className = 'cq-dialog-card';

    const h3 = document.createElement('h3');
    h3.className = 'cq-dialog-title';
    h3.textContent = title;

    const p = document.createElement('p');
    p.className = 'cq-dialog-msg';
    p.textContent = message;

    const actions = document.createElement('div');
    actions.className = 'cq-dialog-actions';

    // Cancel / Stay button (Default focus)
    const btnCancel = document.createElement('button');
    btnCancel.type = 'button';
    btnCancel.className = 'cq-btn cq-btn-secondary';
    btnCancel.textContent = cancelText;

    // Confirm button
    const btnConfirm = document.createElement('button');
    btnConfirm.type = 'button';
    btnConfirm.className = `cq-btn ${isDestructive ? 'cq-btn-danger' : 'cq-btn-primary'}`;
    btnConfirm.textContent = confirmText;

    actions.appendChild(btnCancel);
    actions.appendChild(btnConfirm);

    modal.appendChild(h3);
    modal.appendChild(p);
    modal.appendChild(actions);
    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    activeOverlay = overlay;

    function handleDismiss() {
      if (window.CQ.core.audio) window.CQ.core.audio.playSfx('back');
      close();
      onCancel();
    }

    function handleConfirm() {
      if (window.CQ.core.audio) window.CQ.core.audio.playSfx('confirm');
      close();
      onConfirm();
    }

    btnCancel.addEventListener('click', handleDismiss);
    btnConfirm.addEventListener('click', handleConfirm);

    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) handleDismiss();
    });

    const keyListener = (e) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        window.removeEventListener('keydown', keyListener);
        handleDismiss();
      } else if (e.key === 'Tab') {
        const focusable = [btnCancel, btnConfirm];
        if (e.shiftKey && document.activeElement === btnCancel) {
          e.preventDefault();
          btnConfirm.focus();
        } else if (!e.shiftKey && document.activeElement === btnConfirm) {
          e.preventDefault();
          btnCancel.focus();
        }
      }
    };

    window.addEventListener('keydown', keyListener);
    overlay._keyListener = keyListener;

    // Default focus to cancel/stay for safety
    setTimeout(() => btnCancel.focus(), 50);
  }

  function close() {
    if (activeOverlay) {
      if (activeOverlay._keyListener) {
        window.removeEventListener('keydown', activeOverlay._keyListener);
      }
      activeOverlay.remove();
      activeOverlay = null;
    }
  }

  window.CQ.core.dialog = {
    confirm: showConfirm,
    close,
  };
})();
