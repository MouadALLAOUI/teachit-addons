/**
 * Computer Quest — Screen Manager
 * Coordinates navigation between Menu, Settings, About, and Game screens.
 * Dependencies: CQ.challenges
 */
window.CQ = window.CQ || {};
window.CQ.core = window.CQ.core || {};

(function () {
  let currentScreen = null;
  const historyStack = [];

  function show(screenName, options = {}) {
    if (currentScreen === screenName && !options.force) return;

    // Cleanup active challenge if leaving game
    if (currentScreen === 'game' && screenName !== 'game') {
      if (window.CQ.challenges) {
        window.CQ.challenges.destroyActive();
      }
    }

    if (!options.isBack && currentScreen) {
      historyStack.push(currentScreen);
    }

    currentScreen = screenName;

    // Toggle screen DOM visibility
    document.querySelectorAll('.cq-screen').forEach((screen) => {
      const match = screen.id === `screen-${screenName}`;
      screen.classList.toggle('active', match);
    });

    // In-game Return to Menu button in persistent header
    const menuBtn = document.getElementById('btn-header-menu');
    if (menuBtn) {
      menuBtn.style.display = screenName === 'menu' ? 'none' : 'inline-flex';
    }

    // Notify registered screen handlers
    const screenHandler = window.CQ.screens && window.CQ.screens[screenName];
    if (screenHandler && typeof screenHandler.onShow === 'function') {
      screenHandler.onShow(options);
    }
  }

  function back() {
    const prev = historyStack.pop() || 'menu';
    show(prev, { isBack: true });
  }

  window.CQ.core.screens = {
    show,
    back,
    getCurrent: () => currentScreen,
  };
})();
