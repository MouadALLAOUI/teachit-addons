/**
 * Computer Quest — Audio Engine
 * 100% Procedural WebAudio Synth (Zero external audio files).
 * Ambient music loop + interactive sound effects.
 */
window.CQ = window.CQ || {};
window.CQ.core = window.CQ.core || {};

(function () {
  let ctx = null;
  let musicGain = null;
  let sfxGain = null;
  let musicTimer = null;
  let isPlayingMusic = false;
  let userInteracted = false;

  let sfxEnabled = true;
  let musicEnabled = true;
  let sfxVolume = 0.8;
  let musicVolume = 0.4;

  function initContext() {
    if (ctx) return;
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      ctx = new AudioCtx();

      sfxGain = ctx.createGain();
      sfxGain.gain.setValueAtTime(sfxEnabled ? sfxVolume : 0, ctx.currentTime);
      sfxGain.connect(ctx.destination);

      musicGain = ctx.createGain();
      musicGain.gain.setValueAtTime(musicEnabled ? musicVolume : 0, ctx.currentTime);
      musicGain.connect(ctx.destination);
    } catch (e) {
      console.warn('[CQ Audio] WebAudio not available:', e);
    }
  }

  function handleFirstInteraction() {
    if (userInteracted) return;
    userInteracted = true;
    initContext();
    if (ctx && ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }
    if (musicEnabled) {
      startMusic();
    }
  }

  // Register user interaction triggers
  window.addEventListener('click', handleFirstInteraction, { once: true });
  window.addEventListener('keydown', handleFirstInteraction, { once: true });
  window.addEventListener('touchstart', handleFirstInteraction, { once: true });

  // Handle visibility changes
  document.addEventListener('visibilitychange', () => {
    if (!ctx) return;
    if (document.hidden) {
      if (ctx.state === 'running') ctx.suspend().catch(() => {});
    } else {
      if (ctx.state === 'suspended' && userInteracted) {
        ctx.resume().catch(() => {});
      }
    }
  });

  function playTone(freq, type, duration, gainNode, stopDelay = 0) {
    if (!ctx || ctx.state !== 'running') return;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    const now = ctx.currentTime + stopDelay;

    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);

    g.gain.setValueAtTime(0.3, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + duration);

    osc.connect(g);
    g.connect(gainNode);

    osc.start(now);
    osc.stop(now + duration);
  }

  function playSfx(name) {
    if (!sfxEnabled) return;
    initContext();
    if (!ctx || ctx.state !== 'running') return;

    switch (name) {
      case 'click':
        playTone(520, 'sine', 0.06, sfxGain);
        break;
      case 'hover':
        playTone(330, 'sine', 0.04, sfxGain);
        break;
      case 'confirm':
        playTone(440, 'triangle', 0.1, sfxGain, 0);
        playTone(660, 'triangle', 0.15, sfxGain, 0.08);
        break;
      case 'back':
        playTone(440, 'sine', 0.08, sfxGain, 0);
        playTone(330, 'sine', 0.12, sfxGain, 0.06);
        break;
      case 'correct':
        playTone(523.25, 'triangle', 0.12, sfxGain, 0); // C5
        playTone(659.25, 'triangle', 0.12, sfxGain, 0.09); // E5
        playTone(783.99, 'triangle', 0.2, sfxGain, 0.18); // G5
        break;
      case 'wrong':
        playTone(220, 'sawtooth', 0.15, sfxGain, 0);
        playTone(180, 'sawtooth', 0.25, sfxGain, 0.12);
        break;
      case 'drop':
        playTone(380, 'sine', 0.07, sfxGain);
        break;
      case 'complete':
        [440, 554.37, 659.25, 880].forEach((f, i) => {
          playTone(f, 'sine', 0.25, sfxGain, i * 0.1);
        });
        break;
      default:
        playTone(440, 'sine', 0.05, sfxGain);
        break;
    }
  }

  // Procedural calm ambient arpeggios
  const chordFrequencies = [261.63, 329.63, 392.0, 523.25, 392.0, 329.63, 293.66, 369.99];
  let noteIndex = 0;

  function scheduleMusicStep() {
    if (!isPlayingMusic || !musicEnabled) return;
    if (ctx && ctx.state === 'running') {
      const f = chordFrequencies[noteIndex % chordFrequencies.length];
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      const now = ctx.currentTime;

      osc.type = 'sine';
      osc.frequency.setValueAtTime(f, now);

      g.gain.setValueAtTime(0.001, now);
      g.gain.linearRampToValueAtTime(0.08, now + 0.15);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.75);

      osc.connect(g);
      g.connect(musicGain);

      osc.start(now);
      osc.stop(now + 0.8);
      noteIndex++;
    }
    musicTimer = setTimeout(scheduleMusicStep, 600);
  }

  function startMusic() {
    if (isPlayingMusic) return;
    isPlayingMusic = true;
    scheduleMusicStep();
  }

  function stopMusic() {
    isPlayingMusic = false;
    if (musicTimer) {
      clearTimeout(musicTimer);
      musicTimer = null;
    }
  }

  function setSfxEnabled(val) {
    sfxEnabled = !!val;
    if (sfxGain && ctx) {
      sfxGain.gain.setValueAtTime(sfxEnabled ? sfxVolume : 0, ctx.currentTime);
    }
  }

  function setMusicEnabled(val) {
    musicEnabled = !!val;
    if (musicGain && ctx) {
      musicGain.gain.setValueAtTime(musicEnabled ? musicVolume : 0, ctx.currentTime);
    }
    if (musicEnabled && userInteracted) {
      startMusic();
    } else {
      stopMusic();
    }
  }

  function setSfxVolume(vol) {
    sfxVolume = Math.max(0, Math.min(1, vol));
    if (sfxGain && ctx && sfxEnabled) {
      sfxGain.gain.setValueAtTime(sfxVolume, ctx.currentTime);
    }
  }

  function setMusicVolume(vol) {
    musicVolume = Math.max(0, Math.min(1, vol));
    if (musicGain && ctx && musicEnabled) {
      musicGain.gain.setValueAtTime(musicVolume, ctx.currentTime);
    }
  }

  window.CQ.core.audio = {
    init: initContext,
    playSfx,
    startMusic,
    stopMusic,
    setSfxEnabled,
    setMusicEnabled,
    setSfxVolume,
    setMusicVolume,
    isSfxEnabled: () => sfxEnabled,
    isMusicEnabled: () => musicEnabled,
    getSfxVolume: () => sfxVolume,
    getMusicVolume: () => musicVolume,
  };
})();
