# Video Assets

Computer Quest does not require remote or local video media. All animations and schematics are rendered natively via HTML5 canvas and SVG vectors.
