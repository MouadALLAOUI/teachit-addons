/**
 * Computer Quest — Challenge Registry
 * Manages modular workshop lifecycle (mount, start, destroy).
 * Dependencies: CQ.core.storage, CQ.core.i18n, CQ.core.audio
 */
window.CQ = window.CQ || {};
window.CQ.challenges = window.CQ.challenges || {};

(function () {
  const registry = new Map();
  let activeChallenge = null;

  function register(spec) {
    if (!spec || !spec.id) {
      console.error('[CQ Registry] Invalid challenge specification:', spec);
      return;
    }
    registry.set(spec.id, spec);
  }

  function get(id) {
    return registry.get(id);
  }

  function getAll() {
    return Array.from(registry.values()).sort((a, b) => a.order - b.order);
  }

  function createContext(challengeId) {
    const t = (key, params) => (window.CQ.core.i18n ? window.CQ.core.i18n.t(key, params) : key);
    const audio = window.CQ.core.audio;
    const storageState = (window.CQ.core.storage && window.CQ.core.storage.getState()) || {};
    const challengeProgress = (storageState.challenges && storageState.challenges[challengeId]) || {};

    return {
      t,
      audio,
      components: (window.CQ.config && window.CQ.config.components) || [],
      progress: challengeProgress,
      saveProgress: (data) => {
        if (window.CQ.core.storage) {
          const s = window.CQ.core.storage.getState();
          s.challenges = s.challenges || {};
          s.challenges[challengeId] = { ...(s.challenges[challengeId] || {}), ...data };
          window.CQ.core.storage.save({ challenges: s.challenges });
        }
      },
      complete: (result = {}) => {
        if (window.CQ.core.storage) {
          const s = window.CQ.core.storage.getState();
          if (!s.completedChallenges.includes(challengeId)) {
            s.completedChallenges.push(challengeId);
          }
          window.CQ.core.storage.save({ completedChallenges: s.completedChallenges });
        }
        if (window.CQ.core.app && typeof window.CQ.core.app.onChallengeComplete === 'function') {
          window.CQ.core.app.onChallengeComplete(challengeId, result);
        }
      },
      goToMenu: () => {
        if (window.CQ.core.screens) {
          window.CQ.core.screens.show('menu');
        }
      },
      reportTeachit: (eventType, payload) => {
        if (window.teachit && typeof window.teachit.reportProgress === 'function') {
          window.teachit.reportProgress({
            activityId: `computer-quest-${challengeId}`,
            eventType: eventType || 'challenge_completed',
            payload: payload || {},
          }).catch(() => {});
        }
      },
    };
  }

  function mountActive(challengeId, container) {
    destroyActive();
    const spec = registry.get(challengeId);
    if (!spec) {
      console.error(`[CQ Registry] Challenge "${challengeId}" not found.`);
      return false;
    }

    const ctx = createContext(challengeId);
    container.innerHTML = '';
    spec.mount(container, ctx);
    spec.start();
    activeChallenge = spec;
    return true;
  }

  function destroyActive() {
    if (activeChallenge && typeof activeChallenge.destroy === 'function') {
      try {
        activeChallenge.destroy();
      } catch (e) {
        console.warn(`[CQ Registry] Error destroying challenge "${activeChallenge.id}":`, e);
      }
    }
    activeChallenge = null;
  }

  window.CQ.challenges = {
    register,
    get,
    getAll,
    mountActive,
    destroyActive,
    getActive: () => activeChallenge,
    onLanguageChange: (lang) => {
      if (activeChallenge && typeof activeChallenge.onLanguageChange === 'function') {
        try {
          activeChallenge.onLanguageChange(lang);
        } catch (e) {
          console.warn(`[CQ Registry] Error on language change for "${activeChallenge.id}":`, e);
        }
      }
    },
  };
})();
