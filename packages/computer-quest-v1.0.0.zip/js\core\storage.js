/**
 * Computer Quest — Storage Service
 * Handles persistence, migration, and safe failover under teachit.computerquest.v1
 * Dependencies: CQ.config
 */
window.CQ = window.CQ || {};
window.CQ.core = window.CQ.core || {};

(function () {
  const SAVE_KEY = (window.CQ.config && window.CQ.config.saveKey) || 'teachit.computerquest.v1';

  const defaultState = {
    version: 1,
    currentChallenge: 0,
    completedChallenges: [],
    settings: {
      lang: 'fr',
      sfxEnabled: true,
      musicEnabled: true,
      sfxVolume: 0.8,
      musicVolume: 0.4,
    },
    challenges: {
      discovery: { discovered: [] },
      recognition: { score: 0, currentQuestion: 0, completed: false },
      functions: { matched: [], completed: false },
      assembly: { placed: [], completed: false },
      final: { score: 0, completed: false, answers: [] },
    },
  };

  let inMemoryState = JSON.parse(JSON.stringify(defaultState));

  function isLocalStorageAvailable() {
    try {
      const testKey = '__cq_storage_test__';
      window.localStorage.setItem(testKey, '1');
      window.localStorage.removeItem(testKey);
      return true;
    } catch {
      return false;
    }
  }

  function migrateLegacy() {
    if (!isLocalStorageAvailable()) return;
    try {
      // Check if old keys exist from previous test versions
      const legacyRaw = window.localStorage.getItem('teachit.computerquest.v0');
      if (legacyRaw) {
        const legacyData = JSON.parse(legacyRaw);
        if (legacyData && typeof legacyData === 'object') {
          inMemoryState = { ...defaultState, ...legacyData };
          save(inMemoryState);
        }
      }
    } catch (e) {
      console.warn('[CQ Storage] Migration failed safely:', e);
    }
  }

  function load() {
    migrateLegacy();
    if (!isLocalStorageAvailable()) return inMemoryState;
    try {
      const raw = window.localStorage.getItem(SAVE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        inMemoryState = {
          ...defaultState,
          ...parsed,
          settings: { ...defaultState.settings, ...(parsed.settings || {}) },
          challenges: { ...defaultState.challenges, ...(parsed.challenges || {}) },
        };
        if (
          inMemoryState.challenges &&
          inMemoryState.challenges.assembly &&
          !Array.isArray(inMemoryState.challenges.assembly.placed)
        ) {
          inMemoryState.challenges.assembly.placed = Object.keys(
            inMemoryState.challenges.assembly.placed || {},
          );
        }
      }
    } catch (e) {
      console.warn('[CQ Storage] Load failed safely, using memory state:', e);
    }
    return inMemoryState;
  }

  function save(patch) {
    if (patch) {
      inMemoryState = {
        ...inMemoryState,
        ...patch,
        settings: { ...inMemoryState.settings, ...(patch.settings || {}) },
        challenges: { ...inMemoryState.challenges, ...(patch.challenges || {}) },
      };
    }
    if (isLocalStorageAvailable()) {
      try {
        window.localStorage.setItem(SAVE_KEY, JSON.stringify(inMemoryState));
      } catch (e) {
        console.warn('[CQ Storage] Save failed safely:', e);
      }
    }
    return inMemoryState;
  }

  function reset() {
    inMemoryState = JSON.parse(JSON.stringify(defaultState));
    if (isLocalStorageAvailable()) {
      try {
        window.localStorage.removeItem(SAVE_KEY);
      } catch (e) {
        console.warn('[CQ Storage] Reset failed safely:', e);
      }
    }
    return inMemoryState;
  }

  window.CQ.core.storage = {
    load,
    save,
    reset,
    getState: () => inMemoryState,
  };
})();
