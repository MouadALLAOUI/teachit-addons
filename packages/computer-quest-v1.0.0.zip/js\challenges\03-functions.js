/**
 * Computer Quest — Challenge 3: Role & Function
 * Match each computer component to its educational computing role.
 * Dependencies: CQ.challenges, CQ.config
 */
window.CQ = window.CQ || {};
window.CQ.challenges = window.CQ.challenges || {};

(function () {
  const QUESTIONS = [
    {
      id: 'l3-q1',
      functionFr: 'Fonction : Produire du son et de la musique pour entendre les alertes et les jeux.',
      functionAr: 'الوظيفة: إخراج وبث الأصوات والموسيقى لسماع تنبيهات النظام وأصوات الألعاب.',
      functionEn: 'Function: Produce audio and music to hear system alerts and game sound effects.',
      targetComponentId: 'haut-parleurs',
      options: ['haut-parleurs', 'webcam', 'clavier', 'unite-centrale'],
      explanationFr: 'Les haut-parleurs transforment le signal audio de l’ordinateur en sons audibles.',
      explanationAr: 'مكبرات الصوت تحول الإشارات الصوتية إلى موجات مسموعة للأذن.',
      explanationEn: 'Speakers convert digital audio signals into audible sound waves.',
    },
    {
      id: 'l3-q2',
      functionFr: 'Fonction : Capturer des vidéos en direct et des photos pour une visioconférence.',
      functionAr: 'الوظيفة: التقاط صور وفيديوهات مباشرة للمحادثات والدروس الافتراضية.',
      functionEn: 'Function: Capture live video and photos for online distance learning and video calls.',
      targetComponentId: 'webcam',
      options: ['webcam', 'imprimante', 'ecran', 'souris'],
      explanationFr: 'La webcam est une caméra connectée qui filme l’utilisateur pour les échanges en ligne.',
      explanationAr: 'كاميرا الويب تسجل لقطاتك وتنقلك في المكالمات المرئية عبر الإنترنت.',
      explanationEn: 'The webcam is a video sensor that records the user for online communication.',
    },
    {
      id: 'l3-q3',
      functionFr: 'Fonction : Transférer des documents et des exercices sur de vraies feuilles de papier.',
      functionAr: 'الوظيفة: طباعة التمارين والمستندات والرسومات على أوراق مادية ملموسة.',
      functionEn: 'Function: Transfer digital worksheets and text onto physical sheets of paper.',
      targetComponentId: 'imprimante',
      options: ['imprimante', 'ecran', 'clavier', 'ports-usb'],
      explanationFr: 'L’imprimante dépose de l’encre sur du papier pour créer un document physique.',
      explanationAr: 'تقوم الطابعة بنسخ المحتوى الرقمي بالحبر على أوراق حقيقية.',
      explanationEn: 'The printer deposits ink or toner onto paper to create physical documents.',
    },
    {
      id: 'l3-q4',
      functionFr: 'Fonction : Traiter les données, exécuter les calculs et faire fonctionner tout le système.',
      functionAr: 'الوظيفة: معالجة البيانات، إجراء العمليات الحسابية، وتشغيل نظام التشغيل.',
      functionEn: 'Function: Process data, perform mathematical calculations, and operate the system.',
      targetComponentId: 'unite-centrale',
      options: ['unite-centrale', 'ecran', 'haut-parleurs', 'souris'],
      explanationFr: 'C’est le rôle exclusif de l’unité centrale avec son processeur et sa mémoire vive.',
      explanationAr: 'هذا هو الدور الحصري للوحدة المركزية عبر المعالج الدقيق والذاكرة.',
      explanationEn: 'This is the role of the computer tower housing the CPU processor and RAM.',
    },
    {
      id: 'l3-q5',
      functionFr: 'Fonction : Transmettre les frappes de l’élève pour écrire des phrases ou des lignes de code.',
      functionAr: 'الوظيفة: إرسال ضغطات المفاتيح لكتابة الكلمات أو التعليمات البرمجية.',
      functionEn: 'Function: Transmit student keystrokes to type words or write lines of code.',
      targetComponentId: 'clavier',
      options: ['clavier', 'webcam', 'imprimante', 'haut-parleurs'],
      explanationFr: 'Chaque touche pressée envoie un code unique à l’ordinateur pour inscrire le caractère.',
      explanationAr: 'كل مفتاح يضغط عليه التلميذ يرسل رمزاً فريداً لكتابة الحرف المناسب.',
      explanationEn: 'Every pressed key sends an input scan-code to display the desired character.',
    },
  ];

  let activeContainer = null;
  let activeContext = null;
  let questionIdx = 0;
  let score = 0;
  let answered = false;
  let questionOptions = [];

  function shuffle(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  function render() {
    if (!activeContainer || !activeContext) return;
    const lang = window.CQ.core.i18n ? window.CQ.core.i18n.getLanguage() : 'fr';
    const isAr = lang === 'ar';
    const q = QUESTIONS[questionIdx];
    const components = activeContext.components || [];
    const optionsToRender = questionOptions[questionIdx] || q.options;
    const funcTitle = lang === 'ar' ? q.functionAr : (lang === 'en' ? (q.functionEn || q.functionFr) : q.functionFr);

    activeContainer.innerHTML = `
      <div class="cq-challenge-header-bar">
        <span class="cq-badge">${activeContext.t('level3Badge')}</span>
        <h2>${activeContext.t('level3Title')}</h2>
        <p>${activeContext.t('tab2')} : Question ${questionIdx + 1} / ${QUESTIONS.length}</p>
      </div>

      <div class="quiz-container">
        <div class="quiz-question-card">
          <div class="quiz-question-num">Question ${questionIdx + 1} / ${QUESTIONS.length}</div>
          <h3 class="quiz-question-title">${funcTitle}</h3>
        </div>

        <div class="quiz-choices-grid">
          ${optionsToRender.map((optId) => {
            const comp = components.find((c) => c.id === optId) || components[0];
            const compName = (activeContext.t && comp.id) ? activeContext.t(`discovery.${comp.id}.name`) : (isAr ? comp.nameAr : (lang === 'en' ? (comp.nameEn || comp.nameFr) : comp.nameFr));
            const compType = isAr ? comp.typeLabelAr : (lang === 'en' ? (comp.typeLabelEn || comp.typeLabelFr) : comp.typeLabelFr);
            return `
              <button type="button" class="quiz-choice-card" data-id="${optId}">
                <div class="quiz-choice-icon">
                  <img src="assets/icons/${optId}.svg" width="48" height="48" alt="" />
                </div>
                <div class="quiz-choice-text">
                  <h4>${compName}</h4>
                  <p>${compType}</p>
                </div>
              </button>
            `;
          }).join('')}
        </div>

        <div class="quiz-explanation-box" id="l3-explanation" style="display: none;">
          <span id="l3-explanation-text"></span>
          <button type="button" class="cq-btn cq-btn-primary" id="btn-next-l3">
            ${activeContext.t('nextQuestion')} ➔
          </button>
        </div>
      </div>
    `;

    const choiceCards = activeContainer.querySelectorAll('.quiz-choice-card');
    const explanationBox = document.getElementById('l3-explanation');
    const explanationText = document.getElementById('l3-explanation-text');
    const btnNext = document.getElementById('btn-next-l3');

    choiceCards.forEach((card) => {
      card.addEventListener('click', () => {
        if (answered) return;
        const selectedId = card.getAttribute('data-id');

        if (selectedId === q.targetComponentId) {
          answered = true;
          score += 20;
          card.classList.add('correct');
          if (activeContext.audio) activeContext.audio.playSfx('correct');

          if (explanationBox && explanationText) {
            const exp = isAr ? q.explanationAr : (lang === 'en' ? (q.explanationEn || q.explanationFr) : q.explanationFr);
            explanationText.textContent = exp;
            explanationBox.style.display = 'flex';
          }
          choiceCards.forEach((c) => c.classList.add('disabled'));
        } else {
          card.classList.add('wrong');
          if (activeContext.audio) activeContext.audio.playSfx('wrong');
          setTimeout(() => card.classList.remove('wrong'), 600);
        }
      });
    });

    if (btnNext) {
      btnNext.addEventListener('click', () => {
        if (questionIdx + 1 < QUESTIONS.length) {
          questionIdx++;
          answered = false;
          render();
        } else {
          if (activeContext.audio) activeContext.audio.playSfx('complete');
          activeContext.complete({ score, total: QUESTIONS.length * 20 });
        }
      });
    }
  }

  window.CQ.challenges.register({
    id: 'functions',
    order: 3,
    titleKey: 'tab2',
    icon: 'assets/icons/03-functions.svg',
    mount(container, ctx) {
      activeContainer = container;
      activeContext = ctx;
      questionIdx = 0;
      score = 0;
      answered = false;
      questionOptions = QUESTIONS.map((q) => shuffle(q.options));
      render();
    },
    onLanguageChange() {
      render();
    },
    start() {},
    destroy() {
      activeContainer = null;
      activeContext = null;
    },
  });
})();
