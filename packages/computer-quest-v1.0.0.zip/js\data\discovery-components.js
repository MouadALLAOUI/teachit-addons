/**
 * Computer Quest — Challenge 1: Discovery Components Structural Metadata
 * Pure data-driven model containing NO display text.
 * Display strings, titles, definitions, and SVG labels are loaded from CQ.i18n.
 * Namespace: CQ.data.discoveryComponents
 */
window.CQ = window.CQ || {};
window.CQ.data = window.CQ.data || {};

window.CQ.data.discoveryComponents = [
  {
    id: 'ecran',
    categoryKey: 'discovery.ecran.category',
    illustrationElementId: 'ecran',
    icon: 'assets/icons/ecran.svg',
    type: 'affichage',
    images: ['01.svg', '02.svg'],
  },
  {
    id: 'unite-centrale',
    categoryKey: 'discovery.unite-centrale.category',
    illustrationElementId: 'unite-centrale',
    icon: 'assets/icons/unite-centrale.svg',
    type: 'traitement',
    images: ['01.svg', '02.svg'],
  },
  {
    id: 'clavier',
    categoryKey: 'discovery.clavier.category',
    illustrationElementId: 'clavier',
    icon: 'assets/icons/clavier.svg',
    type: 'entree',
    images: ['01.jpg', '02.svg'],
  },
  {
    id: 'souris',
    categoryKey: 'discovery.souris.category',
    illustrationElementId: 'souris',
    icon: 'assets/icons/souris.svg',
    type: 'entree',
    images: ['01.svg', '02.svg'],
  },
  {
    id: 'haut-parleurs',
    categoryKey: 'discovery.haut-parleurs.category',
    illustrationElementId: 'haut-parleurs',
    icon: 'assets/icons/haut-parleurs.svg',
    type: 'sortie',
    images: ['01.svg', '02.svg'],
  },
  {
    id: 'webcam',
    categoryKey: 'discovery.webcam.category',
    illustrationElementId: 'webcam',
    icon: 'assets/icons/webcam.svg',
    type: 'entree',
    images: ['01.svg', '02.svg'],
  },
  {
    id: 'imprimante',
    categoryKey: 'discovery.imprimante.category',
    illustrationElementId: 'imprimante',
    icon: 'assets/icons/imprimante.svg',
    type: 'sortie',
    images: ['01.svg', '02.svg'],
  },
  {
    id: 'ports-usb',
    categoryKey: 'discovery.ports-usb.category',
    illustrationElementId: 'ports-usb',
    icon: 'assets/icons/ports-usb.svg',
    type: 'interface',
    images: ['01.svg', '02.svg'],
  },
];
