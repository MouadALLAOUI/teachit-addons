// ==========================================================================
// TeachIT Educational Game: Computer Quest (Découvrir l'ordinateur)
// Complete Educational Game Engine with French & Arabic Bilingual Support
// ==========================================================================

(function (global) {
  'use strict';

  // --- 1. Educational Components Data ---
  const COMPONENTS = [
    {
      id: 'ecran',
      type: 'affichage',
      iconEmoji: '🖥️',
      nameFr: 'Écran',
      nameAr: 'الشاشة',
      typeLabelFr: "Périphérique d'affichage",
      typeLabelAr: 'وحدة العرض البصري',
      descFr:
        "L'écran (ou moniteur) affiche les images, les textes, les vidéos et tout ce que l'ordinateur calcule. Il permet à l'utilisateur de voir ce qu'il fait.",
      descAr:
        'الشاشة تعرض الصور والنصوص ومقاطع الفيديو وكل ما يقوم الحاسوب بمعالجته. تتيح للمستخدم رؤية ما يفعله والتفاعل معه.',
      funFactFr:
        "Attention à ne pas le confondre avec l'unité centrale ! L'écran ne fait aucun calcul : il reçoit simplement l'image envoyée par la tour.",
      funFactAr:
        'انتبه ولا تخلط بين الشاشة والوحدة المركزية! الشاشة لا تقوم بالحسابات أو التفكير، بل تعرض فقط الصورة المرسلة إليها.',
      roleFr: 'Afficher les informations visuelles',
      roleAr: 'عرض المعلومات والبيانات البصرية',
    },
    {
      id: 'unite-centrale',
      type: 'traitement',
      iconEmoji: '🖲️',
      nameFr: 'Unité centrale',
      nameAr: 'الوحدة المركزية',
      typeLabelFr: 'Boîtier principal & Traitement',
      typeLabelAr: 'وحدة المعالجة الرئيسية',
      descFr:
        "L'unité centrale (la tour) contient le « cerveau » de l'ordinateur : le processeur, la mémoire vive et le disque de stockage. C'est elle qui exécute tous les calculs et fait fonctionner les logiciels.",
      descAr:
        'الوحدة المركزية (صندوق الحاسوب) تحتوي على «عقل» الجهاز: المعالج، الذاكرة العشوائية، وقرص التخزين. هي المسؤولة عن تشغيل البرامج ومعالجة البيانات.',
      funFactFr:
        "C'est le composant le plus important d'un ordinateur de bureau. Sans elle, rien ne fonctionne !",
      funFactAr: 'تعد أهم جزء في الحاسوب المكتبي. بدونها لا يمكن للحاسوب أن يعمل على الإطلاق!',
      roleFr: 'Traiter les données et exécuter les programmes',
      roleAr: 'معالجة البيانات وتشغيل البرامج والتعليمات',
    },
    {
      id: 'clavier',
      type: 'entree',
      iconEmoji: '⌨️',
      nameFr: 'Clavier',
      nameAr: 'لوحة المفاتيح',
      typeLabelFr: "Périphérique d'entrée",
      typeLabelAr: 'وحدة إدخال النصوص',
      descFr:
        "Le clavier permet à l'élève de saisir du texte, des chiffres, des symboles et d'envoyer des commandes grâce à des touches spécialisées (Entrée, Espace, Échap...).",
      descAr:
        'تتيح لوحة المفاتيح إدخال النصوص والأرقام والرموز وإرسال الأوامر عبر مفاتيح مخصصة (مفتاح الإدخال، المسافة، الهروب...).',
      funFactFr:
        "En France, on utilise principalement la disposition AZERTY, tandis que d'autres pays utilisent QWERTY ou des dispositions bilingues arabes.",
      funFactAr:
        'تتوفر لوحات المفاتيح بعدة توزيعات مثل AZERTY و QWERTY وتحتوي في منطقتنا على الحروف العربية واللاتينية معاً.',
      roleFr: 'Saisir du texte et des commandes',
      roleAr: 'إدخال النصوص والأوامر والرموز',
    },
    {
      id: 'souris',
      type: 'entree',
      iconEmoji: '🖱️',
      nameFr: 'Souris',
      nameAr: 'الفأرة',
      typeLabelFr: 'Périphérique de pointage',
      typeLabelAr: 'وحدة التأشير والتحكم',
      descFr:
        "La souris permet de déplacer le pointeur à l'écran, de sélectionner des éléments avec le clic gauche, d'ouvrir des menus avec le clic droit et de faire défiler les pages avec la molette.",
      descAr:
        'تتيح الفأرة تحريك مؤشر الفأرة على الشاشة، وتحديد العناصر بالنقر الأيسر، وفتح القوائم بالنقر الأيمن، والتمرير عبر العجلة.',
      funFactFr:
        "La toute première souris d'ordinateur a été inventée en 1964 et était fabriquée en bois avec deux roues en métal !",
      funFactAr:
        'أول فأرة حاسوب تم اختراعها في عام 1964 وكانت مصنوعة من قطعة خشبية بداخلها عجلتان معدنيتان!',
      roleFr: 'Déplacer le pointeur et cliquer sur les éléments',
      roleAr: 'تحريك المؤشر والتفاعل بالنقر',
    },
    {
      id: 'haut-parleurs',
      type: 'sortie',
      iconEmoji: '🔊',
      nameFr: 'Haut-parleurs',
      nameAr: 'مكبرات الصوت',
      typeLabelFr: 'Périphérique de sortie audio',
      typeLabelAr: 'وحدة إخراج الصوت',
      descFr:
        "Les haut-parleurs diffusent le son, la musique, les effets sonores des jeux et les voix des vidéos émis par l'ordinateur.",
      descAr:
        'تقوم مكبرات الصوت بإصدار وبث الأصوات والموسيقى والمؤثرات الصوتية للألعاب ومحادثات الفيديو الصادرة من الحاسوب.',
      funFactFr:
        "Si l'ordinateur n'a pas de haut-parleurs branchés, tu peux utiliser un casque ou des écouteurs pour entendre le son sans déranger les autres élèves.",
      funFactAr:
        'إذا لم تكن مكبرات الصوت متصلة، يمكنك استخدام سماعات الرأس للاستماع إلى الصوت بمفردك دون إزعاج زملائك في الفصل.',
      roleFr: 'Produire du son et de la musique',
      roleAr: 'إخراج الصوت والموسيقى والمؤثرات',
    },
    {
      id: 'webcam',
      type: 'entree',
      iconEmoji: '📷',
      nameFr: 'Webcam',
      nameAr: 'كاميرا الويب',
      typeLabelFr: "Périphérique d'entrée vidéo",
      typeLabelAr: 'وحدة إدخال الفيديو',
      descFr:
        "La webcam capture des images et des vidéos en direct. Elle se place souvent au-dessus de l'écran et sert principalement pour les cours à distance et les visioconférences.",
      descAr:
        'تلتقط كاميرا الويب الصور ومقاطع الفيديو المباشرة. توضع عادة أعلى الشاشة وتستخدم للتواصل في الدروس الافتراضية ومكالمات الفيديو.',
      funFactFr:
        "Un petit voyant lumineux s'allume souvent à côté de la lentille pour indiquer que la caméra est en train d'enregistrer.",
      funFactAr:
        'يوجد عادة مصباح ضوئي صغير بجوار العدسة يضيء عند تشغيل الكاميرا لتنبيهك بأنها تقوم بالتصوير.',
      roleFr: 'Capturer des images et des flux vidéo',
      roleAr: 'التقاط الصور ومقاطع الفيديو المباشرة',
    },
    {
      id: 'imprimante',
      type: 'sortie',
      iconEmoji: '🖨️',
      nameFr: 'Imprimante',
      nameAr: 'الطابعة',
      typeLabelFr: 'Périphérique de sortie papier',
      typeLabelAr: 'وحدة إخراج ورقية',
      descFr:
        "L'imprimante permet de transférer des textes, des dessins ou des photos de l'ordinateur sur de vraies feuilles de papier physique.",
      descAr:
        'تتيح الطابعة نقل النصوص والرسومات والصور من شاشة الحاسوب وطباعتها على أوراق ورقية حقيقية.',
      funFactFr:
        "L'imprimante est un périphérique de sortie car l'information sort de l'ordinateur pour aller sur le papier.",
      funFactAr: 'تعتبر الطابعة وحدة إخراج لأن البيانات تخرج من الحاسوب لتصبح وثيقة ورقية ملموسة.',
      roleFr: 'Imprimer des documents sur papier',
      roleAr: 'طباعة المستندات والصور على الورق',
    },
    {
      id: 'ports-usb',
      type: 'interface',
      iconEmoji: '🔌',
      nameFr: 'Ports USB',
      nameAr: 'منافذ USB',
      typeLabelFr: 'Interface de connexion universelle',
      typeLabelAr: 'واجهة توصيل موحدة',
      descFr:
        "Les ports USB sont des prises universelles situées sur l'unité centrale. Ils permettent de brancher des périphériques comme la souris, le clavier, une clé USB ou l'imprimante.",
      descAr:
        'منافذ USB هي مقابس قياسية مدمجة في الوحدة المركزية، تتيح ربط الأجهزة والملحقات مثل الفأرة ولوحة المفاتيح وذاكرة الفلاش والطابعة.',
      funFactFr:
        'Attention : les ports USB ne sont pas des accessoires indépendants, mais des prises de connexion indispensables situées directement sur la tour !',
      funFactAr:
        'تنبيه: منافذ USB ليست ملحقات منفصلة تباع لوحدها، بل هي فتحات توصيل مدمجة في واجهة وخلفية صندوق الحاسوب!',
      roleFr: 'Connecter des câbles et des périphériques',
      roleAr: 'توصيل الكابلات والملحقات ووحدات التخزين',
    },
  ];

  // --- 2. Centralized Bilingual Localization Dictionary ---
  const TRANSLATIONS = {
    fr: {
      brandTitle: 'Computer Quest',
      badgeOffline: 'Mode Hors-Ligne',
      badgeCategory: 'Matériel IT',
      tab0: 'Découverte',
      tab1: 'Reconnaissance',
      tab2: 'Fonctions',
      tab3: 'Assemblage',
      tab4: 'Défi final',
      welcomeTitle: 'Computer Quest',
      welcomeSubtitle: "Découvrir l'ordinateur et ses composants",
      welcomeDesc:
        'Explore le poste de travail informatique, découvre le nom et le rôle de chaque composant physique (écran, unité centrale, clavier, souris, ports USB...), puis assemble ton propre ordinateur dans une série de 5 ateliers interactifs !',
      objTitle1: 'Identification visuelle',
      objDesc1: 'Reconnaître chaque élément matériel et son emplacement',
      objTitle2: 'Unité centrale & Écran',
      objDesc2: "Distinguer le centre de traitement de la surface d'affichage",
      objTitle3: 'Périphériques & USB',
      objDesc3: 'Comprendre le rôle des interfaces et des périphériques',
      objTitle4: "Atelier d'assemblage",
      objDesc4: 'Positionner chaque élément sur le poste de travail complet',
      btnStart: 'Commencer la quête',
      btnExit: 'Quitter',
      lblStudent: 'Élève :',
      lblScore: 'Score :',
      lblAttempts: 'Essais :',
      level1Badge: 'Niveau 1',
      level1Title: "Découverte de l'ordinateur",
      level1Sub: 'Clique sur chaque composant pour explorer son rôle',
      level1Instruction: 'Clique sur les 8 composants pour les observer et lire leur description.',
      level1Progress: '{count} / 8 composants découverts',
      level1CompleteMsg:
        'Bravo ! Tu as exploré tous les composants. Tu peux maintenant passer au niveau suivant !',
      btnProceedLevel2: 'Passer au Niveau 2 ➔',
      level2Badge: 'Niveau 2',
      level2Title: 'Reconnaissance visuelle',
      level2Sub: 'Identifie le bon composant demandé parmi les choix',
      level3Badge: 'Niveau 3',
      level3Title: 'À quoi ça sert ?',
      level3Sub: 'Associe chaque fonction essentielle au matériel informatique',
      level4Badge: 'Niveau 4',
      level4Title: 'Assemble ton ordinateur',
      level4Sub: 'Glisse et dépose les composants sur le bureau informatique',
      level4Instruction:
        'Glisse chaque composant vers son emplacement sur le bureau (ou clique dessus pour le placer).',
      level4CompleteMsg:
        'Superbe assemblage ! Tous les éléments sont branchés et le poste informatique est prêt !',
      btnProceedLevel5: 'Passer au Défi Final ➔',
      level5Badge: 'Niveau 5',
      level5Title: 'Le défi final',
      level5Sub: 'Prouve tes connaissances sur le matériel informatique',
      resultsTitle: 'Mission accomplie !',
      resultsRankMaster: 'Grand Maître du Matériel Informatique 🏆',
      resultsRankExpert: 'Technicien Informatique Émérite ⭐',
      resultsRankApprentice: 'Apprenti Informaticien 💡',
      resultsRankBeginner: 'Explorateur en Apprentissage 📚',
      lblResultScore: 'Score total',
      lblResultChallenges: 'Défis complétés',
      lblResultSuccesses: 'Réponses exactes',
      lblResultTime: 'Temps écoulé',
      resultsReviewHeading: 'Bilan pédagogique & Notions recommandées',
      perfectScoreReview:
        'Félicitations ! Tu maîtrises parfaitement les composants de base d’un ordinateur de bureau.',
      reviewPrefix: 'Notion à réviser :',
      btnReplay: 'Rejouer',
      btnReturnLauncher: 'Retour au lanceur',
      correctFeedback: 'Excellent ! C’est la bonne réponse.',
      incorrectFeedback: 'Pas tout à fait. Essaie encore !',
      dropSuccess: 'Parfait ! L’élément est branché au bon endroit.',
      dropError: 'Ce composant ne se place pas ici. Essaie un autre emplacement !',
      nextQuestion: 'Question suivante ➔',
      didYouKnow: 'Le savais-tu ?',
      funFactTitle: 'À retenir :',
    },
    ar: {
      brandTitle: 'مغامرة الحاسوب',
      badgeOffline: 'وضع عدم الاتصال',
      badgeCategory: 'عتاد الحاسوب',
      tab0: 'استكشاف',
      tab1: 'تمييز',
      tab2: 'وظائف',
      tab3: 'تجميع',
      tab4: 'التحدي النهائي',
      welcomeTitle: 'مغامرة الحاسوب (Computer Quest)',
      welcomeSubtitle: 'اكتشف مكونات الحاسوب المكتبي ووظائفها',
      welcomeDesc:
        'استكشف مكتب الحاسوب وتعرّف على أسماء وأدوار المكونات المادية الأساسية (الشاشة، الوحدة المركزية، لوحة المفاتيح، الفأرة، منافذ USB...)، ثم اجمع حاسوبك الخاص في 5 ورشات تفاعلية مشوقة!',
      objTitle1: 'التعرف البصري',
      objDesc1: 'تمييز كل مكوّن مادي ومعرفة اسمه ومكانه الصحيح',
      objTitle2: 'الوحدة المركزية والشاشة',
      objDesc2: 'التفريق بين مركز المعالجة وسطح العرض المرئي',
      objTitle3: 'الملحقات ومنافذ USB',
      objDesc3: 'فهم أدوار وحدات الإدخال والإخراج وواجهات التوصيل',
      objTitle4: 'ورشة التجميع المكتبي',
      objDesc4: 'تركيب وتوصيل كل مكوّن في موضعه المناسب على المكتب',
      btnStart: 'ابدأ المغامرة',
      btnExit: 'خروج',
      lblStudent: 'التلميذ:',
      lblScore: 'النقاط:',
      lblAttempts: 'المحاولات:',
      level1Badge: 'المستوى 1',
      level1Title: 'استكشاف الحاسوب',
      level1Sub: 'انقر على كل مكون لاستكشاف اسمه ومهمته الأساسية',
      level1Instruction: 'انقر على المكونات الثمانية للاطلاع على تفاصيلها ووظائفها.',
      level1Progress: 'تم استكشاف {count} من 8 مكونات',
      level1CompleteMsg:
        'أحسنت! لقد استكشفت جميع المكونات. يمكنك الآن الانتقال إلى المستوى التالي!',
      btnProceedLevel2: 'الانتقال إلى المستوى 2 ➔',
      level2Badge: 'المستوى 2',
      level2Title: 'التمييز البصري',
      level2Sub: 'حدد المكون المناسب من بين الخيارات المصورة',
      level3Badge: 'المستوى 3',
      level3Title: 'ما هي وظيفتها؟',
      level3Sub: 'اربط كل مهمة بالعتاد الحاسوبي المسؤول عنها',
      level4Badge: 'المستوى 4',
      level4Title: 'جمّع حاسوبك بنفسك',
      level4Sub: 'اسحب وأسقط المكونات في مواضعها الصحيحة على المكتب',
      level4Instruction:
        'اسحب كل عنصر إلى مكانه على المكتب (أو انقر عليه لاختياره ثم انقر على موضعه).',
      level4CompleteMsg: 'عمل رائع! تم توصيل جميع الأجزاء وأصبح الحاسوب جاهزاً للإقلاع والعمل!',
      btnProceedLevel5: 'الانتقال إلى التحدي النهائي ➔',
      level5Badge: 'المستوى 5',
      level5Title: 'التحدي النهائي',
      level5Sub: 'أثبت مهاراتك ومعلوماتك حول عتاد الحاسوب',
      resultsTitle: 'تم إنجاز المهمة بنجاح!',
      resultsRankMaster: 'خبير عتاد الحاسوب 🏆',
      resultsRankExpert: 'تقني حاسوب متميز ⭐',
      resultsRankApprentice: 'متدرب واعد في المعلوميات 💡',
      resultsRankBeginner: 'مستكشف في مرحلة التعلّم 📚',
      lblResultScore: 'مجموع النقاط',
      lblResultChallenges: 'التحديات المنجزة',
      lblResultSuccesses: 'الإجابات الصحيحة',
      lblResultTime: 'الوقت المستغرق',
      resultsReviewHeading: 'التقييم التربوي والمفاهيم الموصى بمراجعتها',
      perfectScoreReview:
        'تهانينا! لقد أتقنت التعرف على جميع مكونات الحاسوب المكتبي ووظائفها بدقة متناهية.',
      reviewPrefix: 'مفهوم يحتاج مراجعة:',
      btnReplay: 'إعادة اللعب',
      btnReturnLauncher: 'العودة إلى المنصة',
      correctFeedback: 'ممتاز! إجابة صحيحة.',
      incorrectFeedback: 'ليس تماماً، حاول مرة أخرى!',
      dropSuccess: 'ممتاز! تم تركيب الجزء في مكانه الصحيح.',
      dropError: 'هذا الجزء لا يوضع هنا. حاول وضعه في مكان آخر!',
      nextQuestion: 'السؤال التالي ➔',
      didYouKnow: 'هل تعلم؟',
      funFactTitle: 'معلومة هامة:',
    },
  };

  // --- 3. Questions Bank for Levels 2, 3, 5 ---
  const LEVEL_2_QUESTIONS = [
    {
      id: 'l2-q1',
      questionFr: 'Quel élément permet de déplacer le pointeur à l’écran ?',
      questionAr: 'ما هو الجزء الذي يتيح تحريك المؤشر على الشاشة والتفاعل معها؟',
      targetComponentId: 'souris',
      options: ['souris', 'clavier', 'ecran', 'imprimante'],
      explanationFr:
        'La souris est le périphérique de pointage essentiel pour guider le curseur et cliquer.',
      explanationAr: 'الفأرة هي أداة التأشير الأساسية لتوجيه المؤشر والنقر على العناصر.',
    },
    {
      id: 'l2-q2',
      questionFr: 'Quel composant affiche les images, les textes et les vidéos ?',
      questionAr: 'ما هو المكوّن الذي يعرض الصور والنصوص ومقاطع الفيديو؟',
      targetComponentId: 'ecran',
      options: ['ecran', 'haut-parleurs', 'unite-centrale', 'webcam'],
      explanationFr:
        "L'écran est la surface d'affichage visuel qui te permet de voir l'environnement informatique.",
      explanationAr: 'الشاشة هي سطح العرض المرئي الذي يمكنك من رؤية كل ما يعالجه الحاسوب.',
    },
    {
      id: 'l2-q3',
      questionFr:
        'Où se trouvent les composants essentiels qui effectuent tous les calculs de l’ordinateur ?',
      questionAr: 'أين توجد المكونات الأساسية التي تقوم بجميع الحسابات ومعالجة البيانات؟',
      targetComponentId: 'unite-centrale',
      options: ['unite-centrale', 'imprimante', 'clavier', 'souris'],
      explanationFr:
        "L'unité centrale (la tour) renferme le processeur, la mémoire et le disque dur.",
      explanationAr:
        'الوحدة المركزية (صندوق الحاسوب) هي التي تحتوي على المعالج والذاكرة والقرص الصلب.',
    },
    {
      id: 'l2-q4',
      questionFr: 'Quel périphérique permet de saisir du texte, des lettres et des chiffres ?',
      questionAr: 'ما هو الجهاز الذي يتيح إدخال النصوص والحروف والأرقام؟',
      targetComponentId: 'clavier',
      options: ['clavier', 'webcam', 'haut-parleurs', 'ecran'],
      explanationFr:
        'Le clavier comporte toutes les touches nécessaires pour taper du texte et coder.',
      explanationAr: 'لوحة المفاتيح تحتوي على كل المفاتيح اللازمة لكتابة النصوص والأوامر البرمجية.',
    },
    {
      id: 'l2-q5',
      questionFr:
        'Comment appelle-t-on les prises qui permettent de brancher une clé ou une souris sur la tour ?',
      questionAr: 'ماذا تسمى المقابس التي تتيح ربط ذاكرة الفلاش أو الفأرة بصندوق الحاسوب؟',
      targetComponentId: 'ports-usb',
      options: ['ports-usb', 'haut-parleurs', 'imprimante', 'ecran'],
      explanationFr:
        'Les ports USB sont des prises standardisées universelles présentes sur l’unité centrale.',
      explanationAr: 'منافذ USB هي واجهات توصيل قياسية مدمجة في واجهة وخلفية صندوق الحاسوب.',
    },
  ];

  const LEVEL_3_QUESTIONS = [
    {
      id: 'l3-q1',
      functionFr:
        'Fonction : Produire du son et de la musique pour entendre les alertes et les jeux.',
      functionAr: 'الوظيفة: إخراج وبث الأصوات والموسيقى لسماع تنبيهات النظام وأصوات الألعاب.',
      targetComponentId: 'haut-parleurs',
      options: ['haut-parleurs', 'webcam', 'clavier', 'unite-centrale'],
      explanationFr:
        'Les haut-parleurs transforment le signal audio de l’ordinateur en sons audibles.',
      explanationAr: 'مكبرات الصوت تحول الإشارات الصوتية إلى موجات مسموعة للأذن.',
    },
    {
      id: 'l3-q2',
      functionFr:
        'Fonction : Capturer des vidéos en direct et des photos pour une visioconférence.',
      functionAr: 'الوظيفة: التقاط صور وفيديوهات مباشرة للمحادثات والدروس الافتراضية.',
      targetComponentId: 'webcam',
      options: ['webcam', 'imprimante', 'ecran', 'souris'],
      explanationFr:
        'La webcam est une caméra connectée qui filme l’utilisateur pour les échanges en ligne.',
      explanationAr: 'كاميرا الويب تسجل لقطاتك وتنقلك في المكالمات المرئية عبر الإنترنت.',
    },
    {
      id: 'l3-q3',
      functionFr:
        'Fonction : Transférer des documents et des exercices sur de vraies feuilles de papier.',
      functionAr: 'الوظيفة: طباعة التمارين والمستندات والرسومات على أوراق مادية ملموسة.',
      targetComponentId: 'imprimante',
      options: ['imprimante', 'ecran', 'clavier', 'ports-usb'],
      explanationFr:
        'L’imprimante dépose de l’encre sur du papier pour créer un document physique.',
      explanationAr: 'تقوم الطابعة بنسخ المحتوى الرقمي بالحبر على أوراق حقيقية.',
    },
    {
      id: 'l3-q4',
      functionFr:
        'Fonction : Traiter les données, exécuter les calculs et faire fonctionner tout le système.',
      functionAr: 'الوظيفة: معالجة البيانات، إجراء العمليات الحسابية، وتشغيل نظام التشغيل.',
      targetComponentId: 'unite-centrale',
      options: ['unite-centrale', 'ecran', 'haut-parleurs', 'souris'],
      explanationFr:
        'C’est le rôle exclusif de l’unité centrale avec son processeur et sa mémoire vive.',
      explanationAr: 'هذا هو الدور الحصري للوحدة المركزية عبر المعالج الدقيق والذاكرة.',
    },
    {
      id: 'l3-q5',
      functionFr:
        'Fonction : Transmettre les frappes de l’élève pour écrire des phrases ou des lignes de code.',
      functionAr: 'الوظيفة: إرسال ضغطات المفاتيح لكتابة الكلمات أو التعليمات البرمجية.',
      targetComponentId: 'clavier',
      options: ['clavier', 'webcam', 'imprimante', 'haut-parleurs'],
      explanationFr:
        'Chaque touche pressée envoie un code unique à l’ordinateur pour inscrire le caractère.',
      explanationAr: 'كل مفتاح يضغط عليه التلميذ يرسل رمزاً فريداً لكتابة الحرف المناسب.',
    },
  ];

  const LEVEL_5_QUESTIONS = [
    {
      id: 'l5-q1',
      questionFr: 'L’écran et l’unité centrale sont-ils exactement le même appareil ?',
      questionAr: 'هل الشاشة والوحدة المركزية هما نفس الجهاز تماماً؟',
      answersFr: [
        {
          text: 'Non, l’écran affiche tandis que l’unité centrale traite les données.',
          correct: true,
        },
        { text: 'Oui, ce sont deux mots pour désigner exactement la même chose.', correct: false },
        {
          text: 'Oui, le processeur se trouve obligatoirement sous la vitre de l’écran.',
          correct: false,
        },
        { text: 'Non, l’écran est une imprimante spéciale sans papier.', correct: false },
      ],
      answersAr: [
        {
          text: 'لا، الشاشة تعرض فقط بينما الوحدة المركزية تعالج البيانات وتحسبها.',
          correct: true,
        },
        { text: 'نعم، هما كلمتان مختلفتان لجهاز واحد لا فرق بينهما.', correct: false },
        { text: 'نعم، المعالج الدقيق موجود حتماً خلف زجاج الشاشة.', correct: false },
        { text: 'لا، الشاشة هي طابعة خاصة لا تستعمل الورق.', correct: false },
      ],
      componentId: 'ecran',
      explanationFr:
        'Distinction capitale : la tour (unité centrale) est le moteur, l’écran n’est que la vitre d’affichage !',
      explanationAr:
        'ملاحظة جوهرية: صندوق الحاسوب هو المحرك، بينما الشاشة هي واجهة العرض المرئي فقط!',
    },
    {
      id: 'l5-q2',
      questionFr:
        'Lequel de ces éléments est une interface de connexion et NON un accessoire externe indépendant ?',
      questionAr: 'أي من هذه العناصر يعتبر واجهة توصيل مدمجة وليس ملحقاً خارجياً مستقلاً؟',
      answersFr: [
        { text: 'Les ports USB', correct: true },
        { text: 'La souris optique', correct: false },
        { text: 'Le casque audio', correct: false },
        { text: 'L’imprimante jet d’encre', correct: false },
      ],
      answersAr: [
        { text: 'منافذ USB', correct: true },
        { text: 'الفأرة الضوئية', correct: false },
        { text: 'سماعات الرأس', correct: false },
        { text: 'الطابعة الورقية', correct: false },
      ],
      componentId: 'ports-usb',
      explanationFr:
        'Les ports USB sont des prises intégrées à l’ordinateur pour y brancher d’autres matériels.',
      explanationAr: 'منافذ USB هي مقابس مدمجة في الجهاز لربط الملحقات والتجهيزات به.',
    },
    {
      id: 'l5-q3',
      questionFr:
        'Tu souhaites envoyer un compte-rendu imprimé par la poste à ton professeur. Quel matériel utilises-tu ?',
      questionAr: 'تريد إرسال تقرير ورقي مطبوع بالبريد إلى أستاذك. ما هو الجهاز الذي تستخدمه؟',
      answersFr: [
        { text: 'L’imprimante', correct: true },
        { text: 'La webcam', correct: false },
        { text: 'Les haut-parleurs', correct: false },
        { text: 'La souris', correct: false },
      ],
      answersAr: [
        { text: 'الطابعة', correct: true },
        { text: 'كاميرا الويب', correct: false },
        { text: 'مكبرات الصوت', correct: false },
        { text: 'الفأرة', correct: false },
      ],
      componentId: 'imprimante',
      explanationFr:
        'L’imprimante est le périphérique de sortie dédié à la production de documents sur papier.',
      explanationAr: 'الطابعة هي وحدة الإخراج المخصصة لطباعة المستندات على الأوراق.',
    },
    {
      id: 'l5-q4',
      questionFr:
        'Si aucun haut-parleur ni casque n’est branché à l’ordinateur, que se passe-t-il ?',
      questionAr: 'إذا لم تكن مكبرات الصوت أو السماعات موصولة بالحاسوب، ماذا يحدث؟',
      answersFr: [
        { text: 'Tu ne pourras entendre aucun son ni musique.', correct: true },
        { text: 'L’ordinateur refusera de démarrer et restera éteint.', correct: false },
        { text: 'L’écran s’éteindra automatiquement.', correct: false },
        { text: 'Le clavier cessera immédiatement d’écrire.', correct: false },
      ],
      answersAr: [
        { text: 'لن تتمكن من سماع أي صوت أو موسيقى أو تنبيه.', correct: true },
        { text: 'سيرفض الحاسوب الإقلاع وسيتوقف عن العمل.', correct: false },
        { text: 'ستنطفئ الشاشة تلقائياً.', correct: false },
        { text: 'ستتوقف لوحة المفاتيح عن الكتابة فوراً.', correct: false },
      ],
      componentId: 'haut-parleurs',
      explanationFr:
        'L’ordinateur fonctionne normalement, mais sans périphérique de sortie audio, le son reste inaudible.',
      explanationAr: 'يعمل الحاسوب بشكل عادي، لكن بدون وحدة إخراج صوتية لن تسمع أي مؤثرات.',
    },
    {
      id: 'l5-q5',
      questionFr:
        'Quel outil est conçu pour diriger facilement le pointeur et cliquer sur des boutons ?',
      questionAr: 'ما هي الأداة المصممة لتوجيه المؤشر بسهولة والنقر على الأزرار؟',
      answersFr: [
        { text: 'La souris', correct: true },
        { text: 'La webcam', correct: false },
        { text: 'L’unité centrale', correct: false },
        { text: 'Les haut-parleurs', correct: false },
      ],
      answersAr: [
        { text: 'الفأرة', correct: true },
        { text: 'كاميرا الويب', correct: false },
        { text: 'الوحدة المركزية', correct: false },
        { text: 'مكبرات الصوت', correct: false },
      ],
      componentId: 'souris',
      explanationFr:
        'La souris est l’instrument de pointage le plus direct et pratique pour interagir à l’écran.',
      explanationAr: 'الفأرة هي أداة التوجيه والتأشير الأكثر ملاءمة وسرعة للتفاعل مع الشاشة.',
    },
    {
      id: 'l5-q6',
      questionFr: 'Quelle est la fonction principale d’une webcam lors d’un cours en ligne ?',
      questionAr: 'ما هي الوظيفة الأساسية لكاميرا الويب أثناء متابعة درس عبر الإنترنت؟',
      answersFr: [
        { text: 'Filmer et transmettre la vidéo en direct de l’élève.', correct: true },
        { text: 'Afficher les exercices sur le bureau.', correct: false },
        { text: 'Augmenter la vitesse de calcul du processeur.', correct: false },
        { text: 'Imprimer les devoirs scolaires.', correct: false },
      ],
      answersAr: [
        { text: 'تصوير وبث الفيديو المباشر للتلميذ ليتواصل مع معلمه.', correct: true },
        { text: 'عرض التمارين على الشاشة.', correct: false },
        { text: 'تسريع معالج الحاسوب.', correct: false },
        { text: 'طباعة الواجبات المدرسية.', correct: false },
      ],
      componentId: 'webcam',
      explanationFr:
        'La webcam est un capteur vidéo qui transforme ce qu’elle voit en signal numérique.',
      explanationAr: 'كاميرا الويب هي مستشعر رقمي ينقل صورتك بالصوت والصورة عبر الشبكة.',
    },
  ];

  // --- 4. Component SVG Graphics Generator (Offline-First) ---
  function getComponentSvg(id, size = 48) {
    switch (id) {
      case 'ecran':
        return `<svg viewBox="0 0 48 48" width="${size}" height="${size}" fill="none" stroke="currentColor">
          <rect x="4" y="6" width="40" height="26" rx="3" stroke="#38bdf8" stroke-width="2.5" fill="#0f172a" />
          <rect x="8" y="10" width="32" height="18" rx="1" fill="#0284c7" fill-opacity="0.25" stroke="#38bdf8" stroke-width="1" />
          <line x1="12" y1="16" x2="24" y2="16" stroke="#38bdf8" stroke-width="1.5" stroke-linecap="round" />
          <line x1="12" y1="20" x2="30" y2="20" stroke="#94a3b8" stroke-width="1" stroke-linecap="round" />
          <path d="M 20 32 L 20 39 L 28 39 L 28 32" stroke="#38bdf8" stroke-width="2" />
          <line x1="14" y1="41" x2="34" y2="41" stroke="#38bdf8" stroke-width="2.5" stroke-linecap="round" />
        </svg>`;
      case 'unite-centrale':
        return `<svg viewBox="0 0 48 48" width="${size}" height="${size}" fill="none">
          <rect x="10" y="4" width="28" height="40" rx="3" stroke="#f59e0b" stroke-width="2.5" fill="#0f172a" />
          <circle cx="24" cy="11" r="3" stroke="#f59e0b" stroke-width="1.5" fill="#fbbf24" />
          <rect x="16" y="18" width="6" height="2" rx="0.5" fill="#38bdf8" />
          <rect x="26" y="18" width="6" height="2" rx="0.5" fill="#38bdf8" />
          <circle cx="24" cy="31" r="7" stroke="#f59e0b" stroke-width="1.5" stroke-dasharray="3,2" />
        </svg>`;
      case 'clavier':
        return `<svg viewBox="0 0 48 48" width="${size}" height="${size}" fill="none">
          <rect x="4" y="14" width="40" height="22" rx="3" stroke="#10b981" stroke-width="2.5" fill="#0f172a" />
          <rect x="8" y="18" width="5" height="4" rx="1" fill="#34d399" />
          <rect x="15" y="18" width="5" height="4" rx="1" fill="#34d399" />
          <rect x="22" y="18" width="5" height="4" rx="1" fill="#34d399" />
          <rect x="29" y="18" width="5" height="4" rx="1" fill="#34d399" />
          <rect x="36" y="18" width="4" height="4" rx="1" fill="#10b981" />
          <rect x="8" y="24" width="7" height="4" rx="1" fill="#34d399" />
          <rect x="17" y="24" width="14" height="4" rx="1" fill="#10b981" />
          <rect x="33" y="24" width="7" height="4" rx="1" fill="#34d399" />
        </svg>`;
      case 'souris':
        return `<svg viewBox="0 0 48 48" width="${size}" height="${size}" fill="none">
          <rect x="14" y="8" width="20" height="32" rx="10" stroke="#10b981" stroke-width="2.5" fill="#0f172a" />
          <line x1="24" y1="8" x2="24" y2="20" stroke="#10b981" stroke-width="1.5" />
          <rect x="22.5" y="13" width="3" height="6" rx="1.5" fill="#34d399" />
        </svg>`;
      case 'haut-parleurs':
        return `<svg viewBox="0 0 48 48" width="${size}" height="${size}" fill="none">
          <rect x="12" y="8" width="24" height="32" rx="3" stroke="#818cf8" stroke-width="2.5" fill="#0f172a" />
          <circle cx="24" cy="18" r="4" stroke="#818cf8" stroke-width="1.5" fill="#312e81" />
          <circle cx="24" cy="29" r="6" stroke="#818cf8" stroke-width="2" fill="#312e81" />
          <circle cx="24" cy="29" r="2" fill="#818cf8" />
        </svg>`;
      case 'webcam':
        return `<svg viewBox="0 0 48 48" width="${size}" height="${size}" fill="none">
          <circle cx="24" cy="20" r="12" stroke="#38bdf8" stroke-width="2.5" fill="#0f172a" />
          <circle cx="24" cy="20" r="6" stroke="#38bdf8" stroke-width="1.5" fill="#0284c7" />
          <circle cx="26" cy="18" r="1.5" fill="#ffffff" />
          <path d="M 18 32 L 20 40 L 28 40 L 30 32" stroke="#38bdf8" stroke-width="2" />
        </svg>`;
      case 'imprimante':
        return `<svg viewBox="0 0 48 48" width="${size}" height="${size}" fill="none">
          <rect x="8" y="18" width="32" height="18" rx="3" stroke="#a78bfa" stroke-width="2.5" fill="#0f172a" />
          <rect x="14" y="8" width="20" height="10" rx="1" fill="#e2e8f0" stroke="#94a3b8" stroke-width="1" />
          <rect x="13" y="27" width="22" height="12" rx="1" fill="#f8fafc" stroke="#94a3b8" stroke-width="1" />
          <line x1="16" y1="31" x2="28" y2="31" stroke="#64748b" stroke-width="1" />
          <line x1="16" y1="35" x2="25" y2="35" stroke="#64748b" stroke-width="1" />
        </svg>`;
      case 'ports-usb':
        return `<svg viewBox="0 0 48 48" width="${size}" height="${size}" fill="none">
          <rect x="8" y="16" width="32" height="16" rx="3" stroke="#38bdf8" stroke-width="2.5" fill="#0f172a" />
          <rect x="14" y="21" width="8" height="6" rx="1" fill="#38bdf8" />
          <rect x="26" y="21" width="8" height="6" rx="1" fill="#38bdf8" />
        </svg>`;
      default:
        return `<svg viewBox="0 0 48 48" width="${size}" height="${size}"><circle cx="24" cy="24" r="20" fill="#38bdf8" /></svg>`;
    }
  }

  // --- 5. Core Game Engine Class ---
  class ComputerQuestEngine {
    constructor() {
      this.currentLang = 'fr';
      this.currentLevelIndex = 0;
      this.unlockedLevels = new Set([0]);
      this.completedLevels = new Set();
      this.discoveredComponents = new Set();
      this.score = 0;
      this.attemptsCount = 0;
      this.successesCount = 0;
      this.startTime = Date.now();
      this.sessionReported = false;
      this.sessionInfo = null;

      // Mistake logging per component ID to build personalized review recommendations
      this.mistakesByComponent = {};

      // Level 2, 3, 5 progression state
      this.level2QuestionIdx = 0;
      this.level3QuestionIdx = 0;
      this.level5QuestionIdx = 0;

      // Level 4 assembly state
      this.assembledSlots = new Set();
      this.selectedForKeyboard = null;
    }

    start() {
      this.currentLevelIndex = 0;
      this.unlockedLevels = new Set([0]);
      this.completedLevels = new Set();
      this.discoveredComponents = new Set();
      this.score = 0;
      this.attemptsCount = 0;
      this.successesCount = 0;
      this.startTime = Date.now();
      this.sessionReported = false;
      this.mistakesByComponent = {};
      this.level2QuestionIdx = 0;
      this.level3QuestionIdx = 0;
      this.level5QuestionIdx = 0;
      this.assembledSlots = new Set();
      this.selectedForKeyboard = null;
    }

    setLanguage(lang) {
      if (lang === 'fr' || lang === 'ar') {
        this.currentLang = lang;
      }
    }

    t(key, params) {
      const dict = TRANSLATIONS[this.currentLang] || TRANSLATIONS.fr;
      let text = dict[key] || TRANSLATIONS.fr[key] || key;
      if (params) {
        Object.keys(params).forEach((p) => {
          text = text.replace(new RegExp(`\\{${p}\\}`, 'g'), params[p]);
        });
      }
      return text;
    }

    recordAttempt(componentId) {
      this.attemptsCount++;
      if (componentId) {
        this.mistakesByComponent[componentId] = (this.mistakesByComponent[componentId] || 0) + 1;
      }
    }

    recordSuccess(points = 20) {
      this.successesCount++;
      this.score += points;
    }

    discoverComponent(id) {
      if (!this.discoveredComponents.has(id)) {
        this.discoveredComponents.add(id);
        this.score += 12; // 12 pts per discovered component up to ~100 pts
        if (this.discoveredComponents.size >= 8) {
          this.completedLevels.add(0);
          this.unlockedLevels.add(1);
        }
        return true;
      }
      return false;
    }

    completeLevel(levelIdx) {
      this.completedLevels.add(levelIdx);
      this.score += 20; // Level completion bonus
      if (levelIdx + 1 < 5) {
        this.unlockedLevels.add(levelIdx + 1);
        this.currentLevelIndex = levelIdx + 1;
        return { isGameComplete: false, nextLevel: levelIdx + 1 };
      }
      return { isGameComplete: true, nextLevel: null };
    }

    goToLevel(index) {
      if (this.unlockedLevels.has(index)) {
        this.currentLevelIndex = index;
        return true;
      }
      return false;
    }

    getDurationSeconds() {
      return Math.max(1, Math.round((Date.now() - this.startTime) / 1000));
    }

    getSummary() {
      const durationSeconds = this.getDurationSeconds();
      const mins = Math.floor(durationSeconds / 60);
      const secs = durationSeconds % 60;
      const formattedDuration = `${mins}:${secs < 10 ? '0' : ''}${secs}`;

      // Rank title calculation based on performance
      let rankKey = 'resultsRankBeginner';
      if (this.score >= 450) rankKey = 'resultsRankMaster';
      else if (this.score >= 350) rankKey = 'resultsRankExpert';
      else if (this.score >= 250) rankKey = 'resultsRankApprentice';

      // Build review items list
      const reviewComponents = Object.keys(this.mistakesByComponent).filter(
        (id) => this.mistakesByComponent[id] > 0,
      );

      const reviewRecommendations = reviewComponents.map((id) => {
        const comp = COMPONENTS.find((c) => c.id === id);
        if (!comp) return id;
        return this.currentLang === 'ar'
          ? `${comp.nameAr} (${comp.roleAr})`
          : `${comp.nameFr} (${comp.roleFr})`;
      });

      return {
        score: Math.min(500, this.score),
        maxScore: 500,
        completedChallenges: this.completedLevels.size,
        totalChallenges: 5,
        totalAttempts: this.attemptsCount,
        successfulActions: this.successesCount,
        durationSeconds,
        formattedDuration,
        rankKey,
        rankTitle: this.t(rankKey),
        reviewRecommendations,
      };
    }
  }

  // --- 6. TeachIT Desktop Integration ---
  function getTeachit() {
    return typeof window !== 'undefined' && window.teachit ? window.teachit : null;
  }

  // Instantiate Game Engine
  const engine = new ComputerQuestEngine();

  // --- 7. DOM References ---
  const screenWelcome = document.getElementById('screenWelcome');
  const screenGame = document.getElementById('screenGame');
  const screenResults = document.getElementById('screenResults');

  const btnToggleLang = document.getElementById('btnToggleLang');
  const langCurrentFlag = document.getElementById('langCurrentFlag');
  const langCurrentText = document.getElementById('langCurrentText');

  const sessionBadge = document.getElementById('sessionBadge');
  const sessionStudentName = document.getElementById('sessionStudentName');
  const btnExitHeader = document.getElementById('btnExitHeader');
  const btnStartGame = document.getElementById('btnStartGame');
  const btnReplay = document.getElementById('btnReplay');
  const btnExitResults = document.getElementById('btnExitResults');

  const levelBadge = document.getElementById('levelBadge');
  const levelTitle = document.getElementById('levelTitle');
  const levelSubtitle = document.getElementById('levelSubtitle');
  const scoreVal = document.getElementById('scoreVal');
  const attemptsVal = document.getElementById('attemptsVal');
  const instructionText = document.getElementById('instructionText');
  const instructionExtraAction = document.getElementById('instructionExtraAction');
  const feedbackBanner = document.getElementById('feedbackBanner');
  const feedbackIcon = document.getElementById('feedbackIcon');
  const feedbackText = document.getElementById('feedbackText');
  const stageArea = document.getElementById('stageArea');

  const resultScoreVal = document.getElementById('resultScoreVal');
  const resultChallengesVal = document.getElementById('resultChallengesVal');
  const resultSuccessesVal = document.getElementById('resultSuccessesVal');
  const resultTimeVal = document.getElementById('resultTimeVal');
  const resultsRank = document.getElementById('resultsRank');
  const resultsReviewList = document.getElementById('resultsReviewList');
  const saveStatusMsg = document.getElementById('saveStatusMsg');
  const saveStatusIcon = document.getElementById('saveStatusIcon');
  const saveStatusBox = document.getElementById('saveStatusBox');

  // --- 8. Screen & Feedback Controllers ---
  function showScreen(screenId) {
    [screenWelcome, screenGame, screenResults].forEach((s) => {
      if (s) s.classList.remove('active');
    });
    if (screenId === 'welcome' && screenWelcome) screenWelcome.classList.add('active');
    if (screenId === 'game' && screenGame) screenGame.classList.add('active');
    if (screenId === 'results' && screenResults) screenResults.classList.add('active');
  }

  let feedbackTimer = null;
  function showFeedback(text, type = 'info', icon = '💡', autoHideMs = 3500) {
    if (!feedbackBanner) return;
    if (feedbackTimer) clearTimeout(feedbackTimer);

    feedbackBanner.className = `feedback-banner ${type}`;
    if (feedbackIcon) feedbackIcon.textContent = icon;
    if (feedbackText) feedbackText.textContent = text;
    feedbackBanner.style.display = 'flex';

    if (autoHideMs > 0) {
      feedbackTimer = setTimeout(() => {
        feedbackBanner.style.display = 'none';
      }, autoHideMs);
    }
  }

  function hideFeedback() {
    if (feedbackBanner) feedbackBanner.style.display = 'none';
  }

  function updateHeaderStats() {
    if (scoreVal) scoreVal.textContent = engine.score;
    if (attemptsVal) attemptsVal.textContent = engine.attemptsCount;
  }

  function updateTabs() {
    for (let i = 0; i < 5; i++) {
      const tab = document.getElementById(`tab${i}`);
      if (!tab) continue;

      tab.classList.remove('active', 'completed', 'locked');
      if (i === engine.currentLevelIndex) tab.classList.add('active');
      if (engine.completedLevels.has(i)) tab.classList.add('completed');
      if (!engine.unlockedLevels.has(i)) tab.classList.add('locked');
    }
  }

  // --- 9. Language Switcher & Text Refresh ---
  function applyLanguage(lang) {
    engine.setLanguage(lang);
    const isAr = lang === 'ar';

    if (typeof document !== 'undefined') {
      document.documentElement.lang = lang;
      document.documentElement.dir = isAr ? 'rtl' : 'ltr';
    }

    if (langCurrentFlag) langCurrentFlag.textContent = isAr ? '🇫🇷' : '🌐';
    if (langCurrentText) langCurrentText.textContent = isAr ? 'Français' : 'العربية';

    // Static Header & Nav Labels
    const appBrandTitle = document.getElementById('appBrandTitle');
    const badgeOffline = document.getElementById('badgeOffline');
    const badgeCategory = document.getElementById('badgeCategory');
    const btnExitHeaderText = document.getElementById('btnExitHeaderText');
    const lblSessionStudent = document.getElementById('lblSessionStudent');
    const lblScore = document.getElementById('lblScore');
    const lblAttempts = document.getElementById('lblAttempts');

    if (appBrandTitle) appBrandTitle.textContent = engine.t('brandTitle');
    if (badgeOffline) badgeOffline.textContent = engine.t('badgeOffline');
    if (badgeCategory) badgeCategory.textContent = engine.t('badgeCategory');
    if (btnExitHeaderText) btnExitHeaderText.textContent = engine.t('btnExit');
    if (lblSessionStudent) lblSessionStudent.textContent = engine.t('lblStudent');
    if (lblScore) lblScore.textContent = engine.t('lblScore');
    if (lblAttempts) lblAttempts.textContent = engine.t('lblAttempts');

    for (let i = 0; i < 5; i++) {
      const lbl = document.getElementById(`tabLabel${i}`);
      if (lbl) lbl.textContent = engine.t(`tab${i}`);
    }

    // Welcome Screen Labels
    const welcomeTitle = document.getElementById('welcomeTitle');
    const welcomeSubtitle = document.getElementById('welcomeSubtitle');
    const welcomeDesc = document.getElementById('welcomeDesc');
    const objTitle1 = document.getElementById('objTitle1');
    const objDesc1 = document.getElementById('objDesc1');
    const objTitle2 = document.getElementById('objTitle2');
    const objDesc2 = document.getElementById('objDesc2');
    const objTitle3 = document.getElementById('objTitle3');
    const objDesc3 = document.getElementById('objDesc3');
    const objTitle4 = document.getElementById('objTitle4');
    const objDesc4 = document.getElementById('objDesc4');
    const btnStartGameText = document.getElementById('btnStartGameText');

    if (welcomeTitle) welcomeTitle.textContent = engine.t('welcomeTitle');
    if (welcomeSubtitle) welcomeSubtitle.textContent = engine.t('welcomeSubtitle');
    if (welcomeDesc) welcomeDesc.textContent = engine.t('welcomeDesc');
    if (objTitle1) objTitle1.textContent = engine.t('objTitle1');
    if (objDesc1) objDesc1.textContent = engine.t('objDesc1');
    if (objTitle2) objTitle2.textContent = engine.t('objTitle2');
    if (objDesc2) objDesc2.textContent = engine.t('objDesc2');
    if (objTitle3) objTitle3.textContent = engine.t('objTitle3');
    if (objDesc3) objDesc3.textContent = engine.t('objDesc3');
    if (objTitle4) objTitle4.textContent = engine.t('objTitle4');
    if (objDesc4) objDesc4.textContent = engine.t('objDesc4');
    if (btnStartGameText) btnStartGameText.textContent = engine.t('btnStart');

    // Results Screen Labels
    const resultsTitle = document.getElementById('resultsTitle');
    const lblResultScore = document.getElementById('lblResultScore');
    const lblResultChallenges = document.getElementById('lblResultChallenges');
    const lblResultSuccesses = document.getElementById('lblResultSuccesses');
    const lblResultTime = document.getElementById('lblResultTime');
    const resultsReviewHeading = document.getElementById('resultsReviewHeading');
    const btnReplayText = document.getElementById('btnReplayText');
    const btnExitResultsText = document.getElementById('btnExitResultsText');

    if (resultsTitle) resultsTitle.textContent = engine.t('resultsTitle');
    if (lblResultScore) lblResultScore.textContent = engine.t('lblResultScore');
    if (lblResultChallenges) lblResultChallenges.textContent = engine.t('lblResultChallenges');
    if (lblResultSuccesses) lblResultSuccesses.textContent = engine.t('lblResultSuccesses');
    if (lblResultTime) lblResultTime.textContent = engine.t('lblResultTime');
    if (resultsReviewHeading) resultsReviewHeading.textContent = engine.t('resultsReviewHeading');
    if (btnReplayText) btnReplayText.textContent = engine.t('btnReplay');
    if (btnExitResultsText) btnExitResultsText.textContent = engine.t('btnReturnLauncher');

    // If active game is visible, reload the current level view
    if (screenGame && screenGame.classList.contains('active')) {
      loadLevel(engine.currentLevelIndex);
    }
  }

  // --- 10. Level View Controllers ---

  // LEVEL 1: Découverte de l'ordinateur
  let activeLevel1ComponentId = 'ecran';
  function renderLevel1() {
    if (!stageArea) return;
    hideFeedback();

    levelBadge.textContent = engine.t('level1Badge');
    levelTitle.textContent = engine.t('level1Title');
    levelSubtitle.textContent = engine.t('level1Sub');
    instructionText.textContent = engine.t('level1Instruction');
    instructionExtraAction.innerHTML = '';

    const isAr = engine.currentLang === 'ar';
    const comp = COMPONENTS.find((c) => c.id === activeLevel1ComponentId) || COMPONENTS[0];
    engine.discoverComponent(comp.id);
    updateHeaderStats();

    const progressPct = Math.min(100, (engine.discoveredComponents.size / 8) * 100);

    stageArea.innerHTML = `
      <div class="level1-container">
        <!-- Left: Interactive Schematic -->
        <div class="level1-workstation-panel">
          <svg class="workstation-svg-wrap" viewBox="0 0 600 420" xmlns="http://www.w3.org/2000/svg">
            <!-- Desk -->
            <polygon points="20,290 80,240 520,240 580,290" fill="#1e293b" stroke="#334155" stroke-width="2" />
            <rect x="50" y="290" width="500" height="15" fill="#0f172a" stroke="#334155" stroke-width="1.5" />

            <!-- Monitor -->
            <g class="workstation-component-hotspot ${comp.id === 'ecran' ? 'active' : ''}" data-id="ecran" transform="translate(180, 50)">
              <rect x="0" y="0" width="240" height="155" rx="6" fill="#0f172a" stroke="#38bdf8" stroke-width="2.5" />
              <rect x="10" y="10" width="220" height="135" rx="3" fill="#0284c7" fill-opacity="0.2" />
              <path d="M 100 155 L 140 155 L 145 190 L 95 190 Z" fill="#334155" stroke="#1e293b" stroke-width="1.5" />
              <ellipse cx="120" cy="190" rx="55" ry="9" fill="#1e293b" stroke="#38bdf8" stroke-width="2" />
              <text x="120" y="80" fill="#38bdf8" font-size="14" font-weight="bold" text-anchor="middle">
                ${isAr ? 'الشاشة' : 'ÉCRAN'}
              </text>
            </g>

            <!-- Webcam on top of monitor -->
            <g class="workstation-component-hotspot ${comp.id === 'webcam' ? 'active' : ''}" data-id="webcam" transform="translate(285, 38)">
              <rect x="0" y="0" width="30" height="12" rx="3" fill="#1e293b" stroke="#38bdf8" stroke-width="1.5" />
              <circle cx="15" cy="6" r="3.5" fill="#38bdf8" />
            </g>

            <!-- Tower / System Unit -->
            <g class="workstation-component-hotspot ${comp.id === 'unite-centrale' ? 'active' : ''}" data-id="unite-centrale" transform="translate(450, 75)">
              <rect x="0" y="0" width="105" height="185" rx="5" fill="#1e293b" stroke="#f59e0b" stroke-width="2.5" />
              <circle cx="52" cy="25" r="7" stroke="#f59e0b" stroke-width="2" fill="#fbbf24" />
              <rect x="25" y="45" width="55" height="6" rx="2" fill="#0f172a" />
              <text x="52" y="120" fill="#fbbf24" font-size="11" font-weight="bold" text-anchor="middle">
                ${isAr ? 'الوحدة المركزية' : 'UNITÉ CENTRALE'}
              </text>
            </g>

            <!-- USB Port indicator on Tower -->
            <g class="workstation-component-hotspot ${comp.id === 'ports-usb' ? 'active' : ''}" data-id="ports-usb" transform="translate(470, 135)">
              <rect x="0" y="0" width="65" height="25" rx="3" fill="#0f172a" stroke="#38bdf8" stroke-width="1.5" />
              <rect x="10" y="7" width="18" height="10" rx="1" fill="#38bdf8" />
              <rect x="36" y="7" width="18" height="10" rx="1" fill="#38bdf8" />
              <text x="32" y="38" fill="#38bdf8" font-size="9" font-weight="bold" text-anchor="middle">
                ${isAr ? 'منافذ USB' : 'PORTS USB'}
              </text>
            </g>

            <!-- Left Speaker -->
            <g class="workstation-component-hotspot ${comp.id === 'haut-parleurs' ? 'active' : ''}" data-id="haut-parleurs" transform="translate(125, 115)">
              <rect x="0" y="0" width="38" height="95" rx="4" fill="#1e293b" stroke="#818cf8" stroke-width="2" />
              <circle cx="19" cy="30" r="11" stroke="#818cf8" stroke-width="1.5" />
              <circle cx="19" cy="65" r="14" stroke="#818cf8" stroke-width="2" />
            </g>

            <!-- Keyboard -->
            <g class="workstation-component-hotspot ${comp.id === 'clavier' ? 'active' : ''}" data-id="clavier" transform="translate(195, 260)">
              <polygon points="0,35 15,0 205,0 220,35" fill="#1e293b" stroke="#10b981" stroke-width="2.5" />
              <rect x="65" y="20" width="90" height="8" rx="2" fill="#34d399" />
              <text x="110" y="14" fill="#34d399" font-size="11" font-weight="bold" text-anchor="middle">
                ${isAr ? 'لوحة المفاتيح' : 'CLAVIER'}
              </text>
            </g>

            <!-- Mouse -->
            <g class="workstation-component-hotspot ${comp.id === 'souris' ? 'active' : ''}" data-id="souris" transform="translate(435, 268)">
              <ellipse cx="18" cy="20" rx="16" ry="24" fill="#1e293b" stroke="#10b981" stroke-width="2.5" />
              <line x1="18" y1="2" x2="18" y2="18" stroke="#10b981" stroke-width="1.5" />
              <text x="18" y="35" fill="#34d399" font-size="10" font-weight="bold" text-anchor="middle">
                ${isAr ? 'فأرة' : 'SOURIS'}
              </text>
            </g>

            <!-- Printer -->
            <g class="workstation-component-hotspot ${comp.id === 'imprimante' ? 'active' : ''}" data-id="imprimante" transform="translate(30, 165)">
              <rect x="0" y="18" width="80" height="46" rx="4" fill="#1e293b" stroke="#a78bfa" stroke-width="2" />
              <rect x="15" y="2" width="50" height="18" rx="2" fill="#e2e8f0" stroke="#94a3b8" />
              <rect x="18" y="40" width="44" height="22" rx="1" fill="#f8fafc" stroke="#94a3b8" />
              <text x="40" y="32" fill="#a78bfa" font-size="10" font-weight="bold" text-anchor="middle">
                ${isAr ? 'طابعة' : 'IMPRIMANTE'}
              </text>
            </g>
          </svg>
        </div>

        <!-- Right: Detail Panel -->
        <div class="level1-detail-panel">
          <div>
            <div class="detail-header">
              <span class="detail-type-badge ${comp.type}">
                ${isAr ? comp.typeLabelAr : comp.typeLabelFr}
              </span>
              <span style="font-size: 1.8rem;">${comp.iconEmoji}</span>
            </div>

            <div class="components-chip-list">
              ${COMPONENTS.map(
                (c) => `
                <button type="button" class="chip-btn ${c.id === comp.id ? 'active' : ''} ${engine.discoveredComponents.has(c.id) ? 'discovered' : ''}" data-id="${c.id}">
                  ${isAr ? c.nameAr : c.nameFr}
                </button>
              `,
              ).join('')}
            </div>

            <h3 class="detail-title">${isAr ? comp.nameAr : comp.nameFr}</h3>
            <p class="detail-desc">${isAr ? comp.descAr : comp.descFr}</p>

            <div class="detail-funfact">
              <strong>💡 ${engine.t('didYouKnow')}</strong>
              <p>${isAr ? comp.funFactAr : comp.funFactFr}</p>
            </div>
          </div>

          <!-- Bottom Discovery Tracker -->
          <div class="discovery-progress-bar-wrap">
            <div class="discovery-progress-label">
              <span>${engine.t('level1Progress', { count: engine.discoveredComponents.size })}</span>
              <strong>${Math.round(progressPct)}%</strong>
            </div>
            <div class="progress-track">
              <div class="progress-fill" style="width: ${progressPct}%;"></div>
            </div>

            ${
              engine.discoveredComponents.size >= 8
                ? `
              <button type="button" class="btn btn-success" id="btnGoToLevel2" style="margin-top: 0.6rem;">
                ${engine.t('btnProceedLevel2')}
              </button>
            `
                : ''
            }
          </div>
        </div>
      </div>
    `;

    // Bind Hotspot & Chip Click Listeners
    stageArea.querySelectorAll('.workstation-component-hotspot, .chip-btn').forEach((elem) => {
      elem.addEventListener('click', () => {
        const id = elem.getAttribute('data-id');
        if (id) {
          activeLevel1ComponentId = id;
          renderLevel1();
        }
      });
    });

    const btnGoToLevel2 = document.getElementById('btnGoToLevel2');
    if (btnGoToLevel2) {
      btnGoToLevel2.addEventListener('click', () => {
        engine.completeLevel(0);
        updateTabs();
        loadLevel(1);
      });
    }
  }

  // LEVEL 2: Reconnaissance Visuelle
  function renderLevel2() {
    if (!stageArea) return;
    hideFeedback();

    levelBadge.textContent = engine.t('level2Badge');
    levelTitle.textContent = engine.t('level2Title');
    levelSubtitle.textContent = engine.t('level2Sub');

    const q = LEVEL_2_QUESTIONS[engine.level2QuestionIdx];
    const isAr = engine.currentLang === 'ar';
    instructionText.textContent = `${engine.t('tab1')} : Question ${engine.level2QuestionIdx + 1} / ${LEVEL_2_QUESTIONS.length}`;
    instructionExtraAction.innerHTML = '';

    stageArea.innerHTML = `
      <div class="quiz-container">
        <div class="quiz-question-card">
          <div class="quiz-question-num">Question ${engine.level2QuestionIdx + 1} / ${LEVEL_2_QUESTIONS.length}</div>
          <h3 class="quiz-question-title">${isAr ? q.questionAr : q.questionFr}</h3>
        </div>

        <div class="quiz-choices-grid" id="quizChoicesGrid">
          ${q.options
            .map((optId) => {
              const comp = COMPONENTS.find((c) => c.id === optId) || COMPONENTS[0];
              return `
              <button type="button" class="quiz-choice-card" data-id="${optId}" role="button">
                <div class="quiz-choice-icon">${getComponentSvg(optId, 48)}</div>
                <div class="quiz-choice-text">
                  <h4>${isAr ? comp.nameAr : comp.nameFr}</h4>
                  <p>${isAr ? comp.typeLabelAr : comp.typeLabelFr}</p>
                </div>
              </button>
            `;
            })
            .join('')}
        </div>

        <div class="quiz-explanation-box" id="quizExplanationBox">
          <span id="quizExplanationText"></span>
          <button type="button" class="btn btn-primary btn-sm" id="btnNextQuizQuestion">
            ${engine.t('nextQuestion')}
          </button>
        </div>
      </div>
    `;

    const choiceCards = stageArea.querySelectorAll('.quiz-choice-card');
    const explanationBox = document.getElementById('quizExplanationBox');
    const explanationText = document.getElementById('quizExplanationText');
    const btnNext = document.getElementById('btnNextQuizQuestion');

    let answered = false;

    choiceCards.forEach((card) => {
      card.addEventListener('click', () => {
        if (answered) return;
        const selectedId = card.getAttribute('data-id');

        if (selectedId === q.targetComponentId) {
          answered = true;
          card.classList.add('correct');
          engine.recordSuccess(20);
          updateHeaderStats();
          showFeedback(engine.t('correctFeedback'), 'success', '🎉');

          if (explanationBox && explanationText) {
            explanationText.textContent = isAr ? q.explanationAr : q.explanationFr;
            explanationBox.style.display = 'flex';
          }

          choiceCards.forEach((c) => c.classList.add('disabled'));
        } else {
          engine.recordAttempt(q.targetComponentId);
          updateHeaderStats();
          card.classList.add('wrong');
          showFeedback(engine.t('incorrectFeedback'), 'error', '⚠️');
          setTimeout(() => {
            card.classList.remove('wrong');
          }, 600);
        }
      });
    });

    if (btnNext) {
      btnNext.addEventListener('click', () => {
        if (engine.level2QuestionIdx + 1 < LEVEL_2_QUESTIONS.length) {
          engine.level2QuestionIdx++;
          renderLevel2();
        } else {
          engine.completeLevel(1);
          updateTabs();
          loadLevel(2);
        }
      });
    }
  }

  // LEVEL 3: À quoi ça sert ?
  function renderLevel3() {
    if (!stageArea) return;
    hideFeedback();

    levelBadge.textContent = engine.t('level3Badge');
    levelTitle.textContent = engine.t('level3Title');
    levelSubtitle.textContent = engine.t('level3Sub');

    const q = LEVEL_3_QUESTIONS[engine.level3QuestionIdx];
    const isAr = engine.currentLang === 'ar';
    instructionText.textContent = `${engine.t('tab2')} : Question ${engine.level3QuestionIdx + 1} / ${LEVEL_3_QUESTIONS.length}`;
    instructionExtraAction.innerHTML = '';

    stageArea.innerHTML = `
      <div class="quiz-container">
        <div class="quiz-question-card">
          <div class="quiz-question-num">Question ${engine.level3QuestionIdx + 1} / ${LEVEL_3_QUESTIONS.length}</div>
          <h3 class="quiz-question-title">${isAr ? q.functionAr : q.functionFr}</h3>
        </div>

        <div class="quiz-choices-grid" id="quizChoicesGrid">
          ${q.options
            .map((optId) => {
              const comp = COMPONENTS.find((c) => c.id === optId) || COMPONENTS[0];
              return `
              <button type="button" class="quiz-choice-card" data-id="${optId}" role="button">
                <div class="quiz-choice-icon">${getComponentSvg(optId, 48)}</div>
                <div class="quiz-choice-text">
                  <h4>${isAr ? comp.nameAr : comp.nameFr}</h4>
                  <p>${isAr ? comp.roleAr : comp.roleFr}</p>
                </div>
              </button>
            `;
            })
            .join('')}
        </div>

        <div class="quiz-explanation-box" id="quizExplanationBox">
          <span id="quizExplanationText"></span>
          <button type="button" class="btn btn-primary btn-sm" id="btnNextFunctionQuestion">
            ${engine.t('nextQuestion')}
          </button>
        </div>
      </div>
    `;

    const choiceCards = stageArea.querySelectorAll('.quiz-choice-card');
    const explanationBox = document.getElementById('quizExplanationBox');
    const explanationText = document.getElementById('quizExplanationText');
    const btnNext = document.getElementById('btnNextFunctionQuestion');

    let answered = false;

    choiceCards.forEach((card) => {
      card.addEventListener('click', () => {
        if (answered) return;
        const selectedId = card.getAttribute('data-id');

        if (selectedId === q.targetComponentId) {
          answered = true;
          card.classList.add('correct');
          engine.recordSuccess(20);
          updateHeaderStats();
          showFeedback(engine.t('correctFeedback'), 'success', '🎯');

          if (explanationBox && explanationText) {
            explanationText.textContent = isAr ? q.explanationAr : q.explanationFr;
            explanationBox.style.display = 'flex';
          }

          choiceCards.forEach((c) => c.classList.add('disabled'));
        } else {
          engine.recordAttempt(q.targetComponentId);
          updateHeaderStats();
          card.classList.add('wrong');
          showFeedback(engine.t('incorrectFeedback'), 'error', '⚠️');
          setTimeout(() => {
            card.classList.remove('wrong');
          }, 600);
        }
      });
    });

    if (btnNext) {
      btnNext.addEventListener('click', () => {
        if (engine.level3QuestionIdx + 1 < LEVEL_3_QUESTIONS.length) {
          engine.level3QuestionIdx++;
          renderLevel3();
        } else {
          engine.completeLevel(2);
          updateTabs();
          loadLevel(3);
        }
      });
    }
  }

  // LEVEL 4: Assemble ton ordinateur (Drag and Drop + Keyboard Accessible)
  function renderLevel4() {
    if (!stageArea) return;
    hideFeedback();

    levelBadge.textContent = engine.t('level4Badge');
    levelTitle.textContent = engine.t('level4Title');
    levelSubtitle.textContent = engine.t('level4Sub');
    instructionText.textContent = engine.t('level4Instruction');
    instructionExtraAction.innerHTML = '';

    const isAr = engine.currentLang === 'ar';
    const isAllPlaced = engine.assembledSlots.size >= 8;

    stageArea.innerHTML = `
      <div class="assembly-container">
        <!-- Assembly Desk Drop Zones -->
        <div class="assembly-desk-area" id="assemblyDeskArea">
          ${COMPONENTS.map((comp) => {
            const isFilled = engine.assembledSlots.has(comp.id);
            return `
              <div class="drop-slot ${isFilled ? 'filled' : ''}" data-target-id="${comp.id}" role="region" aria-label="${isAr ? comp.nameAr : comp.nameFr}">
                <div class="drop-slot-silhouette">
                  ${getComponentSvg(comp.id, 56)}
                </div>
                <div class="drop-slot-label">
                  ${isFilled ? '✓ ' : ''}${isAr ? comp.nameAr : comp.nameFr}
                </div>
              </div>
            `;
          }).join('')}
        </div>

        <!-- Assembly Bottom Tray with Draggables -->
        <div class="assembly-tray-area">
          <div class="assembly-tray-title">
            <span>${isAr ? 'عناصر المكتب المتبقية للتجميع :' : 'Composants à placer sur le bureau :'}</span>
            <strong>${engine.assembledSlots.size} / 8</strong>
          </div>

          <div class="assembly-items-list" id="assemblyItemsList">
            ${COMPONENTS.map((comp) => {
              const isPlaced = engine.assembledSlots.has(comp.id);
              return `
                <div
                  class="draggable-item ${isPlaced ? 'placed' : ''} ${engine.selectedForKeyboard === comp.id ? 'selected-for-keyboard' : ''}"
                  draggable="${!isPlaced}"
                  data-item-id="${comp.id}"
                  tabindex="${isPlaced ? -1 : 0}"
                  role="button"
                >
                  <div class="draggable-item-icon">${getComponentSvg(comp.id, 28)}</div>
                  <span>${isAr ? comp.nameAr : comp.nameFr}</span>
                </div>
              `;
            }).join('')}
          </div>
        </div>

        ${
          isAllPlaced
            ? `
          <div style="display: flex; justify-content: center; margin-top: 0.5rem;">
            <button type="button" class="btn btn-success btn-lg" id="btnGoToFinalChallenge">
              ${engine.t('btnProceedLevel5')}
            </button>
          </div>
        `
            : ''
        }
      </div>
    `;

    // Attach Drag and Drop & Keyboard handlers
    const draggables = stageArea.querySelectorAll('.draggable-item');
    const dropSlots = stageArea.querySelectorAll('.drop-slot');

    draggables.forEach((item) => {
      item.addEventListener('dragstart', (e) => {
        const id = item.getAttribute('data-item-id');
        e.dataTransfer.setData('text/plain', id);
      });

      // Accessible click-to-pick-up & click-to-place fallback
      item.addEventListener('click', () => {
        const id = item.getAttribute('data-item-id');
        if (engine.assembledSlots.has(id)) return;

        if (engine.selectedForKeyboard === id) {
          engine.selectedForKeyboard = null;
        } else {
          engine.selectedForKeyboard = id;
          showFeedback(
            isAr
              ? 'تم تحديد العنصر. انقر الآن على موضعه المناسب على المكتب.'
              : 'Élément sélectionné. Clique maintenant sur son emplacement sur le bureau.',
            'info',
            '👆',
          );
        }
        renderLevel4();
      });
    });

    dropSlots.forEach((slot) => {
      slot.addEventListener('dragover', (e) => {
        e.preventDefault();
        slot.classList.add('drag-over');
      });

      slot.addEventListener('dragleave', () => {
        slot.classList.remove('drag-over');
      });

      slot.addEventListener('drop', (e) => {
        e.preventDefault();
        slot.classList.remove('drag-over');
        const itemId = e.dataTransfer.getData('text/plain');
        handleDropItem(itemId, slot.getAttribute('data-target-id'));
      });

      // Keyboard & Click placement
      slot.addEventListener('click', () => {
        if (engine.selectedForKeyboard) {
          handleDropItem(engine.selectedForKeyboard, slot.getAttribute('data-target-id'));
          engine.selectedForKeyboard = null;
        }
      });
    });

    function handleDropItem(itemId, targetId) {
      if (!itemId || !targetId) return;

      if (itemId === targetId) {
        engine.assembledSlots.add(itemId);
        engine.recordSuccess(15);
        updateHeaderStats();
        showFeedback(engine.t('dropSuccess'), 'success', '✅');

        if (engine.assembledSlots.size >= 8) {
          showFeedback(engine.t('level4CompleteMsg'), 'success', '⚡', 5000);
        }
        renderLevel4();
      } else {
        engine.recordAttempt(targetId);
        updateHeaderStats();
        showFeedback(engine.t('dropError'), 'error', '❌');
      }
    }

    const btnGoToLevel5 = document.getElementById('btnGoToFinalChallenge');
    if (btnGoToLevel5) {
      btnGoToLevel5.addEventListener('click', () => {
        engine.completeLevel(3);
        updateTabs();
        loadLevel(4);
      });
    }
  }

  // LEVEL 5: Le Défi Final
  function renderLevel5() {
    if (!stageArea) return;
    hideFeedback();

    levelBadge.textContent = engine.t('level5Badge');
    levelTitle.textContent = engine.t('level5Title');
    levelSubtitle.textContent = engine.t('level5Sub');

    const q = LEVEL_5_QUESTIONS[engine.level5QuestionIdx];
    const isAr = engine.currentLang === 'ar';
    instructionText.textContent = `${engine.t('tab4')} : Question ${engine.level5QuestionIdx + 1} / ${LEVEL_5_QUESTIONS.length}`;
    instructionExtraAction.innerHTML = '';

    const answersList = isAr ? q.answersAr : q.answersFr;

    stageArea.innerHTML = `
      <div class="quiz-container">
        <div class="quiz-question-card">
          <div class="quiz-question-num">Question ${engine.level5QuestionIdx + 1} / ${LEVEL_5_QUESTIONS.length}</div>
          <h3 class="quiz-question-title">${isAr ? q.questionAr : q.questionFr}</h3>
        </div>

        <div class="quiz-choices-grid" id="finalChoicesGrid">
          ${answersList
            .map(
              (ans, idx) => `
              <button type="button" class="quiz-choice-card" data-idx="${idx}" role="button">
                <div class="quiz-choice-icon">${getComponentSvg(q.componentId, 40)}</div>
                <div class="quiz-choice-text">
                  <p style="font-size: 0.95rem; color: #f8fafc; font-weight: 600;">${ans.text}</p>
                </div>
              </button>
            `,
            )
            .join('')}
        </div>

        <div class="quiz-explanation-box" id="quizExplanationBox">
          <span id="quizExplanationText"></span>
          <button type="button" class="btn btn-primary btn-sm" id="btnNextFinalQuestion">
            ${engine.level5QuestionIdx + 1 < LEVEL_5_QUESTIONS.length ? engine.t('nextQuestion') : 'Voir le bilan final ➔'}
          </button>
        </div>
      </div>
    `;

    const choiceCards = stageArea.querySelectorAll('.quiz-choice-card');
    const explanationBox = document.getElementById('quizExplanationBox');
    const explanationText = document.getElementById('quizExplanationText');
    const btnNext = document.getElementById('btnNextFinalQuestion');

    let answered = false;

    choiceCards.forEach((card) => {
      card.addEventListener('click', () => {
        if (answered) return;
        const ansIdx = parseInt(card.getAttribute('data-idx'), 10);
        const ans = answersList[ansIdx];

        if (ans && ans.correct) {
          answered = true;
          card.classList.add('correct');
          engine.recordSuccess(25);
          updateHeaderStats();
          showFeedback(engine.t('correctFeedback'), 'success', '🏆');

          if (explanationBox && explanationText) {
            explanationText.textContent = isAr ? q.explanationAr : q.explanationFr;
            explanationBox.style.display = 'flex';
          }

          choiceCards.forEach((c) => c.classList.add('disabled'));
        } else {
          engine.recordAttempt(q.componentId);
          updateHeaderStats();
          card.classList.add('wrong');
          showFeedback(engine.t('incorrectFeedback'), 'error', '⚠️');
          setTimeout(() => {
            card.classList.remove('wrong');
          }, 600);
        }
      });
    });

    if (btnNext) {
      btnNext.addEventListener('click', () => {
        if (engine.level5QuestionIdx + 1 < LEVEL_5_QUESTIONS.length) {
          engine.level5QuestionIdx++;
          renderLevel5();
        } else {
          engine.completeLevel(4);
          updateTabs();
          showResultsScreen();
        }
      });
    }
  }

  // Level Loader Dispatcher
  function loadLevel(idx) {
    if (idx < 0 || idx > 4) return;
    engine.goToLevel(idx);
    updateTabs();

    switch (idx) {
      case 0:
        renderLevel1();
        break;
      case 1:
        renderLevel2();
        break;
      case 2:
        renderLevel3();
        break;
      case 3:
        renderLevel4();
        break;
      case 4:
        renderLevel5();
        break;
    }
  }

  // --- 11. Results Screen & TeachIT Telemetry ---
  function showResultsScreen() {
    showScreen('results');
    const summary = engine.getSummary();

    if (resultScoreVal) resultScoreVal.textContent = summary.score;
    if (resultChallengesVal) resultChallengesVal.textContent = `${summary.completedChallenges} / 5`;
    if (resultSuccessesVal) resultSuccessesVal.textContent = summary.successfulActions;
    if (resultTimeVal) resultTimeVal.textContent = summary.formattedDuration;
    if (resultsRank) resultsRank.textContent = summary.rankTitle;

    // Review List Generation
    if (resultsReviewList) {
      if (summary.reviewRecommendations.length === 0) {
        resultsReviewList.innerHTML = `<li>🌟 ${engine.t('perfectScoreReview')}</li>`;
      } else {
        resultsReviewList.innerHTML = summary.reviewRecommendations
          .map((item) => `<li>🔹 ${engine.t('reviewPrefix')} <strong>${item}</strong></li>`)
          .join('');
      }
    }

    // Save Progress to TeachIT IPC
    reportProgressToTeachit(true);
  }

  function reportProgressToTeachit(isComplete = true) {
    if (engine.sessionReported) return;
    engine.sessionReported = true;

    const teachit = getTeachit();
    if (!teachit || typeof teachit.reportProgress !== 'function') {
      if (saveStatusMsg) {
        saveStatusMsg.textContent =
          engine.currentLang === 'ar'
            ? 'وضع مستقل (غير متصل بمشغل TeachIT)'
            : 'Mode autonome (non connecté au lanceur TeachIT)';
      }
      return;
    }

    if (saveStatusMsg) {
      saveStatusMsg.textContent =
        engine.currentLang === 'ar'
          ? 'جارٍ حفظ النتائج في الملف الشخصي للتلميذ...'
          : 'Enregistrement des compétences dans le profil élève...';
      if (saveStatusIcon) saveStatusIcon.textContent = '⏳';
    }

    const summary = engine.getSummary();
    const isSuccess = isComplete && summary.completedChallenges >= 5;
    const eventType = isSuccess ? 'activity_completed' : 'score_recorded';

    teachit
      .reportProgress({
        activityId: 'computer-quest-complete',
        eventType,
        payload: {
          score: summary.score,
          maxScore: 500,
          durationSeconds: summary.durationSeconds,
          success: isSuccess,
          metrics: {
            completedChallenges: summary.completedChallenges,
            totalChallenges: 5,
            totalAttempts: summary.totalAttempts,
            successfulActions: summary.successfulActions,
            durationSeconds: summary.durationSeconds,
            status: isSuccess ? 'completed' : 'abandoned',
            level1_discovery: engine.completedLevels.has(0),
            level2_recognition: engine.completedLevels.has(1),
            level3_functions: engine.completedLevels.has(2),
            level4_assembly: engine.completedLevels.has(3),
            level5_finalQuiz: engine.completedLevels.has(4),
          },
        },
      })
      .then((res) => {
        if (res && res.success) {
          if (saveStatusMsg) {
            saveStatusMsg.textContent =
              engine.currentLang === 'ar'
                ? '✓ تم حفظ التقدم بنجاح في ملف التلميذ TeachIT'
                : '✓ Progression enregistrée dans le profil TeachIT';
          }
          if (saveStatusIcon) saveStatusIcon.textContent = '✅';
          if (saveStatusBox) saveStatusBox.classList.add('saved');
        } else {
          if (saveStatusMsg) {
            saveStatusMsg.textContent = res?.error || 'Non enregistré (Mode invité sans profil)';
          }
        }
      })
      .catch((err) => {
        if (saveStatusMsg) {
          saveStatusMsg.textContent = `Erreur d'enregistrement : ${String(err)}`;
        }
      });
  }

  function handleExitGame() {
    if (engine.completedLevels.size < 5 && !engine.sessionReported) {
      reportProgressToTeachit(false);
    }

    const teachit = getTeachit();
    if (teachit && typeof teachit.exitGame === 'function') {
      teachit.exitGame().catch(() => {
        window.close();
      });
    } else {
      window.close();
    }
  }

  // --- 12. Setup Event Listeners ---
  function setupListeners() {
    // Navigation tabs
    for (let i = 0; i < 5; i++) {
      const tab = document.getElementById(`tab${i}`);
      if (tab) {
        tab.addEventListener('click', () => {
          if (engine.unlockedLevels.has(i)) {
            showScreen('game');
            loadLevel(i);
          }
        });
      }
    }

    // Toggle Language Button
    if (btnToggleLang) {
      btnToggleLang.addEventListener('click', () => {
        const nextLang = engine.currentLang === 'fr' ? 'ar' : 'fr';
        applyLanguage(nextLang);
      });
    }

    // Start Button
    if (btnStartGame) {
      btnStartGame.addEventListener('click', () => {
        showScreen('game');
        loadLevel(0);
      });
    }

    // Replay Button
    if (btnReplay) {
      btnReplay.addEventListener('click', () => {
        engine.start();
        updateHeaderStats();
        updateTabs();
        showScreen('game');
        loadLevel(0);
      });
    }

    // Exit Buttons
    if (btnExitHeader) btnExitHeader.addEventListener('click', handleExitGame);
    if (btnExitResults) btnExitResults.addEventListener('click', handleExitGame);
  }

  // Session Info Initialization from TeachIT IPC
  async function initSession() {
    const teachit = getTeachit();
    if (!teachit || typeof teachit.getSessionInfo !== 'function') return;

    try {
      const info = await teachit.getSessionInfo();
      if (info) {
        engine.sessionInfo = info;
        if (info.studentId && sessionBadge && sessionStudentName) {
          sessionBadge.style.display = 'inline-flex';
          sessionStudentName.textContent = info.studentId.substring(0, 8) + '...';
        }
      }
    } catch {
      // Standalone mode fallback
    }
  }

  // Init on DOM Ready
  function init() {
    setupListeners();
    initSession();
    applyLanguage('fr');
    updateTabs();
  }

  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', init);
    } else {
      init();
    }
  }

  // Expose engine class & data for Vitest unit testing and modular inspection
  const exportTarget = typeof exports !== 'undefined' ? exports : global;
  exportTarget.ComputerQuestEngine = ComputerQuestEngine;
  exportTarget.COMPONENTS = COMPONENTS;
  exportTarget.TRANSLATIONS = TRANSLATIONS;
  exportTarget.LEVEL_2_QUESTIONS = LEVEL_2_QUESTIONS;
  exportTarget.LEVEL_3_QUESTIONS = LEVEL_3_QUESTIONS;
  exportTarget.LEVEL_5_QUESTIONS = LEVEL_5_QUESTIONS;
})(typeof window !== 'undefined' ? window : globalThis);
