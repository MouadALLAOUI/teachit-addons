/**
 * Computer Quest — About Screen
 * Educational context, version metadata, TeachIT platform linkage, and credits.
 * Dependencies: CQ.config, CQ.core.i18n, CQ.core.screens, CQ.core.app
 */
window.CQ = window.CQ || {};
window.CQ.screens = window.CQ.screens || {};

(function () {
  const containerId = 'screen-about';

  function onShow() {
    render();
  }

  function render() {
    const el = document.getElementById(containerId);
    if (!el) return;

    const t = window.CQ.core.i18n.t;
    const session = window.CQ.core.app.getSession();
    const studentId = session && session.studentId ? session.studentId : 'GUEST-OFFLINE';

    el.innerHTML = `
      <div class="cq-panel-container">
        <div class="cq-panel-card">
          <div class="cq-panel-header">
            <h2 class="cq-panel-title">${t('about.title')}</h2>
            <button type="button" class="cq-btn cq-btn-secondary" id="btn-about-back">
              ← ${t('about.back')}
            </button>
          </div>

          <div class="cq-about-content">
            <div class="cq-about-hero">
              <div class="cq-about-badge">TEACHIT DESKTOP LAUNCHER</div>
              <h3 class="cq-about-game-name">${t('brandTitle')}</h3>
              <p class="cq-about-version">${t('about.version')} ${(window.CQ.config && window.CQ.config.version) || '2.0.0'}</p>
            </div>

            <p class="cq-about-desc">${t('about.desc')}</p>

            <div class="cq-about-info-box">
              <div class="cq-info-item">
                <span class="cq-info-label">${t('about.partOf')}</span>
              </div>
              <div class="cq-info-item">
                <span class="cq-info-label">${t('about.studentId')}:</span>
                <span class="cq-info-val cq-pill">${studentId}</span>
              </div>
            </div>

            <div class="cq-about-credits">
              <h4>${t('about.credits')}</h4>
              <p>TeachIT Offline-First Educational Suite for Moroccan Middle Schools</p>
            </div>
          </div>
        </div>
      </div>
    `;

    document.getElementById('btn-about-back')?.addEventListener('click', () => {
      if (window.CQ.core.audio) window.CQ.core.audio.playSfx('back');
      window.CQ.core.screens.back();
    });
  }

  window.CQ.screens.about = {
    onShow,
    render,
  };
})();
