/**
 * Computer Quest — Challenge 4: PC Assembly Station
 * Drag-and-drop & keyboard/click placement of computer components onto the workstation desk.
 * Dependencies: CQ.challenges, CQ.config
 */
window.CQ = window.CQ || {};
window.CQ.challenges = window.CQ.challenges || {};

(function () {
  let activeContainer = null;
  let activeContext = null;
  let assembledSlots = new Set();
  let selectedItem = null;
  let trayOrder = [];

  function shuffle(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  function render() {
    if (!activeContainer || !activeContext) return;
    const lang = window.CQ.core.i18n ? window.CQ.core.i18n.getLanguage() : 'fr';
    const isAr = lang === 'ar';
    const components = activeContext.components || [];
    const isAllPlaced = assembledSlots.size >= components.length;

    activeContainer.innerHTML = `
      <div class="cq-challenge-header-bar">
        <span class="cq-badge">${activeContext.t('level4Badge')}</span>
        <h2>${activeContext.t('level4Title')}</h2>
        <p>${activeContext.t('level4Instruction')}</p>
      </div>

      <div class="assembly-container">
        <!-- Assembly Desk Drop Zones (Display hardware icons/silhouettes to match) -->
        <div class="assembly-desk-area">
          ${components.map((comp) => {
            const isFilled = assembledSlots.has(comp.id);
            const compName = (activeContext.t && comp.id) ? activeContext.t(`discovery.${comp.id}.name`) : (isAr ? comp.nameAr : (lang === 'en' ? (comp.nameEn || comp.nameFr) : comp.nameFr));
            return `
              <div class="drop-slot ${isFilled ? 'filled' : ''}" data-target-id="${comp.id}" role="region">
                <div class="drop-slot-silhouette">
                  <img src="assets/icons/${comp.id}.svg" width="56" height="56" alt="" />
                </div>
                <div class="drop-slot-label">
                  ${isFilled ? '✓ ' + compName : '?'}
                </div>
              </div>
            `;
          }).join('')}
        </div>

        <!-- Assembly Bottom Tray with Draggables (Display component names to match against icons) -->
        <div class="assembly-tray-area">
          <div class="assembly-tray-title">
            <span>${isAr ? 'عناصر المكتب المتبقية للتجميع :' : (lang === 'en' ? 'Hardware components to place on desk:' : 'Composants à placer sur le bureau :')}</span>
            <strong>${assembledSlots.size} / ${components.length}</strong>
          </div>

          <div class="assembly-items-list">
            ${(trayOrder.length ? trayOrder : components).map((comp) => {
              const isPlaced = assembledSlots.has(comp.id);
              const compName = (activeContext.t && comp.id) ? activeContext.t(`discovery.${comp.id}.name`) : (isAr ? comp.nameAr : (lang === 'en' ? (comp.nameEn || comp.nameFr) : comp.nameFr));
              return `
                <div
                  class="draggable-item ${isPlaced ? 'placed' : ''} ${selectedItem === comp.id ? 'selected-for-keyboard' : ''}"
                  draggable="${!isPlaced}"
                  data-item-id="${comp.id}"
                  tabindex="${isPlaced ? -1 : 0}"
                  role="button"
                >
                  <span style="font-size: 1.1rem;">🏷️</span>
                  <span style="font-weight: 700;">${compName}</span>
                </div>
              `;
            }).join('')}
          </div>
        </div>

        ${isAllPlaced ? `
          <div style="display: flex; justify-content: center; margin-top: 1rem;">
            <button type="button" class="cq-btn cq-btn-success" id="btn-proceed-l5">
              ${activeContext.t('btnProceedLevel5')} ➔
            </button>
          </div>
        ` : ''}
      </div>
    `;

    // Draggable listeners
    activeContainer.querySelectorAll('.draggable-item').forEach((item) => {
      item.addEventListener('dragstart', (e) => {
        const id = item.getAttribute('data-item-id');
        e.dataTransfer.setData('text/plain', id);
      });

      // Accessible click-to-pick-up & click-to-place fallback
      item.addEventListener('click', () => {
        const id = item.getAttribute('data-item-id');
        if (assembledSlots.has(id)) return;

        if (selectedItem === id) {
          selectedItem = null;
        } else {
          selectedItem = id;
          if (activeContext.audio) activeContext.audio.playSfx('click');
        }
        render();
      });
    });

    // Drop slot listeners
    activeContainer.querySelectorAll('.drop-slot').forEach((slot) => {
      slot.addEventListener('dragover', (e) => {
        e.preventDefault();
        slot.classList.add('drag-over');
      });

      slot.addEventListener('dragleave', () => {
        slot.classList.remove('drag-over');
      });

      slot.addEventListener('drop', (e) => {
        e.preventDefault();
        slot.classList.remove('drag-over');
        const itemId = e.dataTransfer.getData('text/plain');
        handlePlace(itemId, slot.getAttribute('data-target-id'));
      });

      slot.addEventListener('click', () => {
        if (selectedItem) {
          handlePlace(selectedItem, slot.getAttribute('data-target-id'));
          selectedItem = null;
        }
      });
    });

    function handlePlace(itemId, targetId) {
      if (!itemId || !targetId) return;

      if (itemId === targetId) {
        assembledSlots.add(itemId);
        if (activeContext.audio) activeContext.audio.playSfx('drop');
        activeContext.saveProgress({ placed: Array.from(assembledSlots) });
        render();
      } else {
        if (activeContext.audio) activeContext.audio.playSfx('wrong');
        const slotEl = activeContainer.querySelector(`[data-target-id="${targetId}"]`);
        if (slotEl) {
          slotEl.classList.add('wrong');
          setTimeout(() => slotEl.classList.remove('wrong'), 600);
        }
      }
    }

    const btnNext = document.getElementById('btn-proceed-l5');
    if (btnNext) {
      btnNext.addEventListener('click', () => {
        if (activeContext.audio) activeContext.audio.playSfx('complete');
        activeContext.complete({ placed: Array.from(assembledSlots) });
      });
    }
  }

  window.CQ.challenges.register({
    id: 'assembly',
    order: 4,
    titleKey: 'tab3',
    icon: 'assets/icons/04-assembly.svg',
    mount(container, ctx) {
      activeContainer = container;
      activeContext = ctx;
      const rawPlaced = ctx.progress && ctx.progress.placed;
      const placedList = Array.isArray(rawPlaced)
        ? rawPlaced
        : (rawPlaced && typeof rawPlaced === 'object' ? Object.keys(rawPlaced) : []);
      assembledSlots = new Set(placedList);
      selectedItem = null;
      trayOrder = shuffle(ctx.components || []);
      render();
    },
    onLanguageChange() {
      render();
    },
    start() {},
    destroy() {
      activeContainer = null;
      activeContext = null;
    },
  });
})();
