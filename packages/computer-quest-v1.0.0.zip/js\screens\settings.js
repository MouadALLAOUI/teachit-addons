/**
 * Computer Quest — Settings Screen
 * Audio toggles, volume sliders, language selection, and progress reset.
 * Dependencies: CQ.core.storage, CQ.core.i18n, CQ.core.audio, CQ.core.dialog, CQ.core.screens
 */
window.CQ = window.CQ || {};
window.CQ.screens = window.CQ.screens || {};

(function () {
  const containerId = 'screen-settings';

  function onShow() {
    render();
  }

  function render() {
    const el = document.getElementById(containerId);
    if (!el) return;

    const t = window.CQ.core.i18n.t;
    const currentLang = window.CQ.core.i18n.getLanguage();
    const audio = window.CQ.core.audio;

    const sfxOn = audio ? audio.isSfxEnabled() : true;
    const musicOn = audio ? audio.isMusicEnabled() : true;
    const sfxVol = Math.round((audio ? audio.getSfxVolume() : 0.8) * 100);
    const musicVol = Math.round((audio ? audio.getMusicVolume() : 0.4) * 100);

    el.innerHTML = `
      <div class="cq-panel-container">
        <div class="cq-panel-card">
          <div class="cq-panel-header">
            <h2 class="cq-panel-title">${t('settings.title')}</h2>
            <button type="button" class="cq-btn cq-btn-secondary" id="btn-settings-back">
              ← ${t('settings.back')}
            </button>
          </div>

          <div class="cq-settings-content">
            <!-- SFX Section -->
            <div class="cq-setting-group">
              <div class="cq-setting-row">
                <label class="cq-setting-label" for="toggle-sfx">${t('settings.sfx')}</label>
                <input type="checkbox" id="toggle-sfx" class="cq-toggle" ${sfxOn ? 'checked' : ''} />
              </div>
              <div class="cq-slider-row">
                <input type="range" id="slider-sfx" min="0" max="100" value="${sfxVol}" class="cq-slider" />
                <span class="cq-slider-val" id="val-sfx">${sfxVol}%</span>
              </div>
            </div>

            <!-- Music Section -->
            <div class="cq-setting-group">
              <div class="cq-setting-row">
                <label class="cq-setting-label" for="toggle-music">${t('settings.music')}</label>
                <input type="checkbox" id="toggle-music" class="cq-toggle" ${musicOn ? 'checked' : ''} />
              </div>
              <div class="cq-slider-row">
                <input type="range" id="slider-music" min="0" max="100" value="${musicVol}" class="cq-slider" />
                <span class="cq-slider-val" id="val-music">${musicVol}%</span>
              </div>
            </div>

            <!-- Language Section -->
            <div class="cq-setting-group">
              <label class="cq-setting-label">${t('settings.language')}</label>
              <div class="cq-lang-picker">
                <button type="button" class="cq-lang-btn ${currentLang === 'fr' ? 'active' : ''}" data-lang="fr">
                  Français
                </button>
                <button type="button" class="cq-lang-btn ${currentLang === 'ar' ? 'active' : ''}" data-lang="ar">
                  العربية
                </button>
                <button type="button" class="cq-lang-btn ${currentLang === 'en' ? 'active' : ''}" data-lang="en">
                  English
                </button>
              </div>
            </div>

            <!-- Reset Progress -->
            <div class="cq-setting-group cq-danger-zone">
              <label class="cq-setting-label">${t('settings.reset')}</label>
              <p class="cq-setting-desc">${t('settings.resetWarn')}</p>
              <button type="button" class="cq-btn cq-btn-danger" id="btn-settings-reset">
                ${t('settings.reset')}
              </button>
            </div>
          </div>
        </div>
      </div>
    `;

    // Event Bindings
    document.getElementById('btn-settings-back')?.addEventListener('click', () => {
      if (audio) audio.playSfx('back');
      window.CQ.core.screens.back();
    });

    const chkSfx = document.getElementById('toggle-sfx');
    const chkMusic = document.getElementById('toggle-music');
    const sldSfx = document.getElementById('slider-sfx');
    const sldMusic = document.getElementById('slider-music');

    chkSfx?.addEventListener('change', (e) => {
      const enabled = e.target.checked;
      if (audio) audio.setSfxEnabled(enabled);
      saveSettings();
    });

    chkMusic?.addEventListener('change', (e) => {
      const enabled = e.target.checked;
      if (audio) audio.setMusicEnabled(enabled);
      saveSettings();
    });

    sldSfx?.addEventListener('input', (e) => {
      const val = Number(e.target.value);
      document.getElementById('val-sfx').textContent = `${val}%`;
      if (audio) audio.setSfxVolume(val / 100);
      saveSettings();
    });

    sldMusic?.addEventListener('input', (e) => {
      const val = Number(e.target.value);
      document.getElementById('val-music').textContent = `${val}%`;
      if (audio) audio.setMusicVolume(val / 100);
      saveSettings();
    });

    document.querySelectorAll('.cq-lang-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const lang = btn.getAttribute('data-lang');
        if (lang) {
          if (audio) audio.playSfx('click');
          window.CQ.core.i18n.setLanguage(lang);
          saveSettings();
          render(); // Re-render settings with new strings
        }
      });
    });

    document.getElementById('btn-settings-reset')?.addEventListener('click', () => {
      window.CQ.core.dialog.confirm({
        title: t('dialog.confirmResetTitle'),
        message: t('dialog.confirmResetMsg'),
        confirmText: t('dialog.confirm'),
        cancelText: t('dialog.cancel'),
        isDestructive: true,
        onConfirm: () => {
          window.CQ.core.storage.reset();
          if (audio) audio.playSfx('confirm');
          window.CQ.core.screens.show('menu');
        },
      });
    });

    function saveSettings() {
      const state = window.CQ.core.storage.load();
      state.settings = {
        lang: window.CQ.core.i18n.getLanguage(),
        sfxEnabled: chkSfx ? chkSfx.checked : true,
        musicEnabled: chkMusic ? chkMusic.checked : true,
        sfxVolume: sldSfx ? Number(sldSfx.value) / 100 : 0.8,
        musicVolume: sldMusic ? Number(sldMusic.value) / 100 : 0.4,
      };
      window.CQ.core.storage.save({ settings: state.settings });
    }
  }

  window.CQ.screens.settings = {
    onShow,
    render,
  };
})();
