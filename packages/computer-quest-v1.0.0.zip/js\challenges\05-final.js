/**
 * Computer Quest — Challenge 5: Final Evaluation
 * Comprehensive quiz validating computer hardware knowledge and generating final results.
 * Dependencies: CQ.challenges, CQ.config
 */
window.CQ = window.CQ || {};
window.CQ.challenges = window.CQ.challenges || {};

(function () {
  const QUESTIONS = [
    {
      id: 'l5-q1',
      questionFr: 'L’écran et l’unité centrale sont-ils exactement le même appareil ?',
      questionAr: 'هل الشاشة والوحدة المركزية هما نفس الجهاز تماماً؟',
      answersFr: [
        { text: 'Non, l’écran affiche tandis que l’unité centrale traite les données.', correct: true },
        { text: 'Oui, ce sont deux mots pour désigner exactement la même chose.', correct: false },
        { text: 'Oui, le processeur se trouve obligatoirement sous la vitre de l’écran.', correct: false },
        { text: 'Non, l’écran est une imprimante spéciale sans papier.', correct: false },
      ],
      answersAr: [
        { text: 'لا، الشاشة تعرض فقط بينما الوحدة المركزية تعالج البيانات وتحسبها.', correct: true },
        { text: 'نعم، هما كلمتان مختلفتان لجهاز واحد لا فرق بينهما.', correct: false },
        { text: 'نعم، المعالج الدقيق موجود حتماً خلف زجاج الشاشة.', correct: false },
        { text: 'لا، الشاشة هي طابعة خاصة لا تستعمل الورق.', correct: false },
      ],
      componentId: 'ecran',
      explanationFr: 'Distinction capitale : la tour (unité centrale) est le moteur, l’écran n’est que la vitre d’affichage !',
      explanationAr: 'ملاحظة جوهرية: صندوق الحاسوب هو المحرك، بينما الشاشة هي واجهة العرض المرئي فقط!',
    },
    {
      id: 'l5-q2',
      questionFr: 'Lequel de ces éléments est une interface de connexion et NON un accessoire externe indépendant ?',
      questionAr: 'أي من هذه العناصر يعتبر واجهة توصيل مدمجة وليس ملحقاً خارجياً مستقلاً؟',
      answersFr: [
        { text: 'Les ports USB', correct: true },
        { text: 'La souris optique', correct: false },
        { text: 'Le casque audio', correct: false },
        { text: 'L’imprimante jet d’encre', correct: false },
      ],
      answersAr: [
        { text: 'منافذ USB', correct: true },
        { text: 'الفأرة الضوئية', correct: false },
        { text: 'سماعات الرأس', correct: false },
        { text: 'الطابعة الورقية', correct: false },
      ],
      componentId: 'ports-usb',
      explanationFr: 'Les ports USB sont des prises intégrées à l’ordinateur pour y brancher d’autres matériels.',
      explanationAr: 'منافذ USB هي مقابس مدمجة في الجهاز لربط الملحقات والتجهيزات به.',
    },
    {
      id: 'l5-q3',
      questionFr: 'Tu souhaites envoyer un compte-rendu imprimé par la poste à ton professeur. Quel matériel utilises-tu ?',
      questionAr: 'تريد إرسال تقرير ورقي مطبوع بالبريد إلى أستاذك. ما هو الجهاز الذي تستخدمه؟',
      answersFr: [
        { text: 'L’imprimante', correct: true },
        { text: 'La webcam', correct: false },
        { text: 'Les haut-parleurs', correct: false },
        { text: 'La souris', correct: false },
      ],
      answersAr: [
        { text: 'الطابعة', correct: true },
        { text: 'كاميرا الويب', correct: false },
        { text: 'مكبرات الصوت', correct: false },
        { text: 'الفأرة', correct: false },
      ],
      componentId: 'imprimante',
      explanationFr: 'L’imprimante est le périphérique de sortie dédié à la production de documents sur papier.',
      explanationAr: 'الطابعة هي وحدة الإخراج المخصصة لطباعة المستندات على الأوراق.',
    },
    {
      id: 'l5-q4',
      questionFr: 'Si aucun haut-parleur ni casque n’est branché à l’ordinateur, que se passe-t-il ?',
      questionAr: 'إذا لم تكن مكبرات الصوت أو السماعات موصولة بالحاسوب، ماذا يحدث؟',
      answersFr: [
        { text: 'Tu ne pourras entendre aucun son ni musique.', correct: true },
        { text: 'L’ordinateur refusera de démarrer et restera éteint.', correct: false },
        { text: 'L’écran s’éteindra automatiquement.', correct: false },
        { text: 'Le clavier cessera immédiatement d’écrire.', correct: false },
      ],
      answersAr: [
        { text: 'لن تتمكن من سماع أي صوت أو موسيقى أو تنبيه.', correct: true },
        { text: 'سيرفض الحاسوب الإقلاع وسيتوقف عن العمل.', correct: false },
        { text: 'ستنطفئ الشاشة تلقائياً.', correct: false },
        { text: 'ستتوقف لوحة المفاتيح عن الكتابة فوراً.', correct: false },
      ],
      componentId: 'haut-parleurs',
      explanationFr: 'L’ordinateur fonctionne normalement, mais sans périphérique de sortie audio, le son reste inaudible.',
      explanationAr: 'يعمل الحاسوب بشكل عادي، لكن بدون وحدة إخراج صوتية لن تسمع أي مؤثرات.',
    },
    {
      id: 'l5-q5',
      questionFr: 'Quel outil est conçu pour diriger facilement le pointeur et cliquer sur des boutons ?',
      questionAr: 'ما هي الأداة المصممة لتوجيه المؤشر بسهولة والنقر على الأزرار؟',
      answersFr: [
        { text: 'La souris', correct: true },
        { text: 'La webcam', correct: false },
        { text: 'L’unité centrale', correct: false },
        { text: 'Les haut-parleurs', correct: false },
      ],
      answersAr: [
        { text: 'الفأرة', correct: true },
        { text: 'كاميرا الويب', correct: false },
        { text: 'الوحدة المركزية', correct: false },
        { text: 'مكبرات الصوت', correct: false },
      ],
      componentId: 'souris',
      explanationFr: 'La souris est l’instrument de pointage le plus direct et pratique pour interagir à l’écran.',
      explanationAr: 'الفأرة هي أداة التوجيه والتأشير الأكثر ملاءمة وسرعة للتفاعل مع الشاشة.',
    },
    {
      id: 'l5-q6',
      questionFr: 'Quelle est la fonction principale d’une webcam lors d’un cours en ligne ?',
      questionAr: 'ما هي الوظيفة الأساسية لكاميرا الويب أثناء متابعة درس عبر الإنترنت؟',
      answersFr: [
        { text: 'Filmer et transmettre la vidéo en direct de l’élève.', correct: true },
        { text: 'Afficher les exercices sur le bureau.', correct: false },
        { text: 'Augmenter la vitesse de calcul du processeur.', correct: false },
        { text: 'Imprimer les devoirs scolaires.', correct: false },
      ],
      answersAr: [
        { text: 'تصوير وبث الفيديو المباشر للتلميذ ليتواصل مع معلمه.', correct: true },
        { text: 'عرض التمارين على الشاشة.', correct: false },
        { text: 'تسريع معالج الحاسوب.', correct: false },
        { text: 'طباعة الواجبات المدرسية.', correct: false },
      ],
      componentId: 'webcam',
      explanationFr: 'La webcam est un capteur vidéo qui transforme ce qu’elle voit en signal numérique.',
      explanationAr: 'كاميرا الويب هي مستشعر رقمي ينقل صورتك بالصوت والصورة عبر الشبكة.',
    },
  ];

  let activeContainer = null;
  let activeContext = null;
  let questionIdx = 0;
  let score = 0;
  let answered = false;
  let questionIndices = [];

  function shuffle(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  function renderQuiz() {
    if (!activeContainer || !activeContext) return;
    const isAr = window.CQ.core.i18n ? window.CQ.core.i18n.isRtl() : false;
    const q = QUESTIONS[questionIdx];
    const answersList = isAr ? q.answersAr : q.answersFr;
    const indices = questionIndices[questionIdx] || answersList.map((_, i) => i);

    activeContainer.innerHTML = `
      <div class="cq-challenge-header-bar">
        <span class="cq-badge">${activeContext.t('level5Badge')}</span>
        <h2>${activeContext.t('level5Title')}</h2>
        <p>${activeContext.t('tab4')} : Question ${questionIdx + 1} / ${QUESTIONS.length}</p>
      </div>

      <div class="quiz-container">
        <div class="quiz-question-card">
          <div class="quiz-question-num">Question ${questionIdx + 1} / ${QUESTIONS.length}</div>
          <h3 class="quiz-question-title">${isAr ? q.questionAr : q.questionFr}</h3>
        </div>

        <div class="quiz-choices-grid">
          ${indices.map((origIdx) => {
            const ans = answersList[origIdx];
            return `
              <button type="button" class="quiz-choice-card" data-idx="${origIdx}">
                <div class="quiz-choice-icon">
                  <img src="assets/icons/${q.componentId}.svg" width="40" height="40" alt="" />
                </div>
                <div class="quiz-choice-text">
                  <p style="font-size: 0.95rem; color: #f8fafc; font-weight: 600;">${ans.text}</p>
                </div>
              </button>
            `;
          }).join('')}
        </div>

        <div class="quiz-explanation-box" id="l5-explanation" style="display: none;">
          <span id="l5-explanation-text"></span>
          <button type="button" class="cq-btn cq-btn-primary" id="btn-next-l5">
            ${questionIdx + 1 < QUESTIONS.length ? activeContext.t('nextQuestion') + ' ➔' : 'Voir le bilan final ➔'}
          </button>
        </div>
      </div>
    `;

    const choiceCards = activeContainer.querySelectorAll('.quiz-choice-card');
    const explanationBox = document.getElementById('l5-explanation');
    const explanationText = document.getElementById('l5-explanation-text');
    const btnNext = document.getElementById('btn-next-l5');

    choiceCards.forEach((card) => {
      card.addEventListener('click', () => {
        if (answered) return;
        const ansIdx = parseInt(card.getAttribute('data-idx'), 10);
        const ans = answersList[ansIdx];

        if (ans && ans.correct) {
          answered = true;
          score += 25;
          card.classList.add('correct');
          if (activeContext.audio) activeContext.audio.playSfx('correct');

          if (explanationBox && explanationText) {
            explanationText.textContent = isAr ? q.explanationAr : q.explanationFr;
            explanationBox.style.display = 'flex';
          }
          choiceCards.forEach((c) => c.classList.add('disabled'));
        } else {
          card.classList.add('wrong');
          if (activeContext.audio) activeContext.audio.playSfx('wrong');
          setTimeout(() => card.classList.remove('wrong'), 600);
        }
      });
    });

    if (btnNext) {
      btnNext.addEventListener('click', () => {
        if (questionIdx + 1 < QUESTIONS.length) {
          questionIdx++;
          answered = false;
          renderQuiz();
        } else {
          renderResults();
        }
      });
    }
  }

  function renderResults() {
    if (!activeContainer || !activeContext) return;
    const isAr = window.CQ.core.i18n ? window.CQ.core.i18n.isRtl() : false;
    const maxScore = QUESTIONS.length * 25;
    const pct = Math.round((score / maxScore) * 100);
    const rankTitle = pct >= 80 ? (isAr ? 'خبير المعلوميات' : 'Expert Informatique') : (isAr ? 'مستكشف واعد' : 'Explorateur Prometteur');

    if (activeContext.audio) activeContext.audio.playSfx('complete');
    activeContext.complete({ score, maxScore, rank: rankTitle });

    activeContainer.innerHTML = `
      <div class="cq-results-card">
        <div class="cq-results-badge">🎉 ${activeContext.t('congratsTitle')}</div>
        <h2 class="cq-results-title">${rankTitle}</h2>
        <p class="cq-results-desc">${activeContext.t('congratsMsg')}</p>

        <div class="cq-results-stats-row">
          <div class="cq-stat-box">
            <span class="cq-stat-label">${activeContext.t('scoreLabel')}</span>
            <span class="cq-stat-val">${score} / ${maxScore}</span>
          </div>
          <div class="cq-stat-box">
            <span class="cq-stat-label">Précision</span>
            <span class="cq-stat-val">${pct}%</span>
          </div>
        </div>

        <div class="cq-results-actions">
          <button type="button" class="cq-btn cq-btn-secondary" id="btn-replay-quiz">
            🔄 ${activeContext.t('btnRestart')}
          </button>
          <button type="button" class="cq-btn cq-btn-primary" id="btn-results-menu">
            🏠 ${activeContext.t('btn.menu')}
          </button>
        </div>
      </div>
    `;

    document.getElementById('btn-replay-quiz')?.addEventListener('click', () => {
      questionIdx = 0;
      score = 0;
      answered = false;
      questionIndices = QUESTIONS.map((q) => shuffle(q.answersFr.map((_, i) => i)));
      renderQuiz();
    });

    document.getElementById('btn-results-menu')?.addEventListener('click', () => {
      activeContext.goToMenu();
    });
  }

  window.CQ.challenges.register({
    id: 'final',
    order: 5,
    titleKey: 'tab4',
    icon: 'assets/icons/05-final.svg',
    mount(container, ctx) {
      activeContainer = container;
      activeContext = ctx;
      questionIdx = 0;
      score = 0;
      answered = false;
      questionIndices = QUESTIONS.map((q) => shuffle(q.answersFr.map((_, i) => i)));
      renderQuiz();
    },
    onLanguageChange() {
      renderQuiz();
    },
    start() {},
    destroy() {
      activeContainer = null;
      activeContext = null;
    },
  });
})();
