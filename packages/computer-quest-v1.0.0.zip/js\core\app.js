/**
 * Computer Quest — Application Boot & Global Lifecycle
 * Handles initialization, TeachIT IPC hooks, background animation, and challenge transitions.
 * Dependencies: CQ.config, CQ.core.*, CQ.screens.*
 */
window.CQ = window.CQ || {};
window.CQ.core = window.CQ.core || {};

(function () {
  let canvas = null;
  let ctx2d = null;
  let animId = null;
  let particles = [];
  let studentSession = null;

  function exitGame() {
    if (window.teachit && typeof window.teachit.exitGame === 'function') {
      window.teachit.exitGame().catch(() => window.close());
    } else if (window.teachit && typeof window.teachit.exit === 'function') {
      window.teachit.exit().catch(() => window.close());
    } else if (window.history.length > 1) {
      window.history.back();
    } else {
      window.close();
    }
  }

  function confirmExitToTeachit() {
    const t = window.CQ.core.i18n.t;
    window.CQ.core.dialog.confirm({
      title: t('dialog.confirmExitTitle'),
      message: t('dialog.confirmExitMsg'),
      confirmText: t('dialog.leave'),
      cancelText: t('dialog.stay'),
      isDestructive: true,
      onConfirm: exitGame,
    });
  }

  // Themed Full-Screen Circuit Background with floating computer silhouettes
  function initBackground() {
    canvas = document.getElementById('cq-bg-canvas');
    if (!canvas) return;
    ctx2d = canvas.getContext('2d');
    if (!ctx2d) return;

    function resize() {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    }
    window.addEventListener('resize', resize);
    resize();

    // Check reduced motion
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion) return;

    // Create silhouettes & circuit traces
    const types = ['monitor', 'keyboard', 'mouse', 'cpu', 'usb'];
    particles = Array.from({ length: 22 }, () => ({
      x: Math.random() * window.innerWidth,
      y: Math.random() * window.innerHeight,
      vx: (Math.random() - 0.5) * 0.4,
      vy: (Math.random() - 0.5) * 0.4,
      size: 28 + Math.random() * 24,
      opacity: 0.04 + Math.random() * 0.08,
      type: types[Math.floor(Math.random() * types.length)],
      angle: Math.random() * Math.PI * 2,
      vAngle: (Math.random() - 0.5) * 0.005,
    }));

    function drawSilhouette(p) {
      ctx2d.save();
      ctx2d.translate(p.x, p.y);
      ctx2d.rotate(p.angle);
      ctx2d.strokeStyle = `rgba(56, 189, 248, ${p.opacity})`;
      ctx2d.fillStyle = `rgba(30, 41, 59, ${p.opacity * 0.4})`;
      ctx2d.lineWidth = 1.5;

      const s = p.size;
      ctx2d.beginPath();
      if (p.type === 'monitor') {
        ctx2d.rect(-s / 2, -s / 2.5, s, s * 0.7);
        ctx2d.rect(-s / 6, s * 0.3, s / 3, s * 0.2);
      } else if (p.type === 'keyboard') {
        ctx2d.rect(-s / 2, -s / 4, s, s * 0.5);
      } else if (p.type === 'mouse') {
        ctx2d.ellipse(0, 0, s * 0.3, s * 0.45, 0, 0, Math.PI * 2);
      } else if (p.type === 'cpu') {
        ctx2d.rect(-s * 0.3, -s * 0.5, s * 0.6, s);
      } else {
        ctx2d.rect(-s * 0.2, -s * 0.35, s * 0.4, s * 0.7);
      }
      ctx2d.fill();
      ctx2d.stroke();
      ctx2d.restore();
    }

    function loop() {
      if (document.hidden) {
        animId = requestAnimationFrame(loop);
        return;
      }
      ctx2d.clearRect(0, 0, canvas.width, canvas.height);

      // Draw subtle circuit grid lines
      ctx2d.strokeStyle = 'rgba(56, 189, 248, 0.025)';
      ctx2d.lineWidth = 1;
      const step = 80;
      for (let x = 0; x < canvas.width; x += step) {
        ctx2d.beginPath();
        ctx2d.moveTo(x, 0);
        ctx2d.lineTo(x, canvas.height);
        ctx2d.stroke();
      }
      for (let y = 0; y < canvas.height; y += step) {
        ctx2d.beginPath();
        ctx2d.moveTo(0, y);
        ctx2d.lineTo(canvas.width, y);
        ctx2d.stroke();
      }

      particles.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;
        p.angle += p.vAngle;

        if (p.x < -60) p.x = canvas.width + 60;
        if (p.x > canvas.width + 60) p.x = -60;
        if (p.y < -60) p.y = canvas.height + 60;
        if (p.y > canvas.height + 60) p.y = -60;

        drawSilhouette(p);
      });

      animId = requestAnimationFrame(loop);
    }

    animId = requestAnimationFrame(loop);
  }

  function isChallengeUnlocked(challengeIndex, state) {
    if (challengeIndex <= 0) return true;
    const s = state || window.CQ.core.storage.load();
    const completed = s.completedChallenges || [];
    const challenges = window.CQ.challenges.getAll();
    const prevChallenge = challenges[challengeIndex - 1];
    if (!prevChallenge) return false;
    return completed.includes(prevChallenge.id);
  }

  function launchChallenge(challengeIndex) {
    const challenges = window.CQ.challenges.getAll();
    const state = window.CQ.core.storage.load();

    // Enforce strict progression locking
    if (!isChallengeUnlocked(challengeIndex, state)) {
      if (window.CQ.core.audio) window.CQ.core.audio.playSfx('wrong');
      let highestUnlocked = 0;
      for (let i = 0; i < challenges.length; i++) {
        if (isChallengeUnlocked(i, state)) highestUnlocked = i;
        else break;
      }
      challengeIndex = highestUnlocked;
    }

    const target = challenges[challengeIndex] || challenges[0];
    if (!target) return;

    // Update current challenge in storage
    window.CQ.core.storage.save({ currentChallenge: challengeIndex });

    // Show game screen
    window.CQ.core.screens.show('game');

    // Update game navigation tabs
    renderTabs(challengeIndex);

    // Mount challenge inside challenge stage container
    const container = document.getElementById('cq-challenge-container');
    if (container) {
      window.CQ.challenges.mountActive(target.id, container);
    }
  }

  function renderTabs(activeIdx) {
    const tabNav = document.getElementById('cq-game-tabs');
    if (!tabNav) return;
    const challenges = window.CQ.challenges.getAll();
    const state = window.CQ.core.storage.load();
    const currentIdx = typeof activeIdx === 'number' ? activeIdx : (state.currentChallenge || 0);

    tabNav.innerHTML = '';
    challenges.forEach((ch, idx) => {
      const unlocked = isChallengeUnlocked(idx, state);
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `cq-tab-btn ${idx === currentIdx ? 'active' : ''} ${!unlocked ? 'locked' : ''}`;
      btn.disabled = !unlocked;
      const lockIcon = !unlocked ? ' 🔒' : '';
      btn.textContent = window.CQ.core.i18n.t(ch.titleKey) + lockIcon;
      btn.addEventListener('click', () => {
        if (!unlocked) {
          if (window.CQ.core.audio) window.CQ.core.audio.playSfx('wrong');
          return;
        }
        if (idx !== currentIdx) {
          launchChallenge(idx);
        }
      });
      tabNav.appendChild(btn);
    });
  }

  function init() {
    const state = window.CQ.core.storage.load();
    const settings = state.settings || {};

    // Apply language
    window.CQ.core.i18n.setLanguage(settings.lang || 'fr');

    // Apply audio settings
    if (window.CQ.core.audio) {
      window.CQ.core.audio.setSfxEnabled(settings.sfxEnabled !== false);
      window.CQ.core.audio.setMusicEnabled(settings.musicEnabled !== false);
      window.CQ.core.audio.setSfxVolume(settings.sfxVolume !== undefined ? settings.sfxVolume : 0.8);
      window.CQ.core.audio.setMusicVolume(settings.musicVolume !== undefined ? settings.musicVolume : 0.4);
    }

    // Fetch TeachIT Session Info
    if (window.teachit && typeof window.teachit.getSessionInfo === 'function') {
      window.teachit.getSessionInfo().then((session) => {
        studentSession = session;
        if (session && session.studentId) {
          const badge = document.getElementById('cq-student-badge');
          if (badge) badge.textContent = `ID: ${session.studentId}`;
        }
      }).catch(() => {});
    }

    // Initialize canvas background
    initBackground();

    // Attach global header actions
    document.querySelectorAll('.cq-exit-teachit-btn').forEach((btn) => {
      btn.addEventListener('click', confirmExitToTeachit);
    });

    document.querySelectorAll('.cq-btn-to-menu').forEach((btn) => {
      btn.addEventListener('click', () => {
        window.CQ.core.screens.show('menu');
      });
    });

    document.querySelectorAll('.cq-btn-to-settings').forEach((btn) => {
      btn.addEventListener('click', () => {
        window.CQ.core.screens.show('settings');
      });
    });

    // Attach persistent language switcher buttons
    document.querySelectorAll('.cq-lang-pill-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const lang = btn.getAttribute('data-lang');
        if (lang) {
          if (window.CQ.core.audio) window.CQ.core.audio.playSfx('click');
          window.CQ.core.i18n.setLanguage(lang);
        }
      });
    });

    // Listen for global language changes to re-render tabs and active workshop
    if (window.CQ.core.i18n && typeof window.CQ.core.i18n.addChangeListener === 'function') {
      window.CQ.core.i18n.addChangeListener((lang) => {
        renderTabs();
        if (window.CQ.challenges && typeof window.CQ.challenges.onLanguageChange === 'function') {
          window.CQ.challenges.onLanguageChange(lang);
        }
      });
    }

    // Dev translation audit
    if (window.CQ.core.i18n && typeof window.CQ.core.i18n.auditTranslations === 'function') {
      window.CQ.core.i18n.auditTranslations();
    }

    // Start on menu screen
    window.CQ.core.screens.show('menu', { force: true });
  }

  window.CQ.core.app = {
    init,
    exitGame,
    confirmExitToTeachit,
    launchChallenge,
    getSession: () => studentSession,
    onChallengeComplete: (id) => {
      const challenges = window.CQ.challenges.getAll();
      const currIdx = challenges.findIndex((c) => c.id === id);
      if (currIdx !== -1 && currIdx < challenges.length - 1) {
        // Auto advance after short victory pause
        setTimeout(() => {
          launchChallenge(currIdx + 1);
        }, 1200);
      }
    },
  };
})();
